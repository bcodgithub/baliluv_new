<?php

namespace Soulfy;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;
use SammyK\LaravelFacebookSdk\SyncableGraphNodeTrait;

class User extends Model implements AuthenticatableContract, CanResetPasswordContract
{
    use Authenticatable, CanResetPassword;
    use SyncableGraphNodeTrait;
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['name', 'email', 'password'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['password', 'remember_token','access_token'];



    protected static $graph_node_field_aliases = [
        'id' => 'facebook_user_id',
        'name' => 'full_name',
        'graph_node_field_name' => 'database_column_name',
    ];

    public function usertoken()
    {
        return $this->hasOne('Soulfy\UserToken');
    }
    public function userMails()
    {
        return $this->hasMany('Soulfy\UserMail');
    }


    public function Twitter(){
        return $this->hasOne('Soulfy\TwitterProfile');
    }
    
    public static function createEmail($domain,$user,$password){
        
        require_once(base_path() . "/vendor/cpanel_api/xmlapi.php");
        $ip = env('SERVER_IP', "127.0.0.1"); //your server's IP

        $xmlapi = new \xmlapi($ip);
//        $xmlapi->set_port(2083);
        $xmlapi->password_auth(env('CPANEL_USER', "root"),env('CPANEL_PASSWORD', "")); //the server login info for the user you want to create the emails under

        $xmlapi->set_output('json');
        $xmlapi->set_debug(0);
        
        $acct = json_decode($xmlapi->listaccts('domain', $domain), true);
        if($acct && count($acct['acct']) == 1) {
        	$U = $acct['acct'][0]['user'];
        	
        	$params = array('domain'=>$domain, 'email'=>$user, 'password'=>$password, 'quota'=>env('EMAIL_QUOTA', 25)); //quota is in MB
        	$addEmail = json_decode($xmlapi->api2_query($U, "Email", "addpop", $params), true);
        }
        else {
        	return false;
        }
        
        
        if($addEmail && isset($addEmail['cpanelresult']) && isset($addEmail['cpanelresult']['data']) && isset($addEmail['cpanelresult']['data'][0]) && $addEmail['cpanelresult']['data'][0]['result']){
            return true;
        }
        else {
            //echo "Error creating email account:\n".$addEmail['cpanelresult']['data'][0]['reason'];
            return false;
        }


    }
}