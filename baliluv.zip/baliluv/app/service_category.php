<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class service_category extends Model
{
    protected $connection = 'mysql_2';
    protected $table = "service_category";
}