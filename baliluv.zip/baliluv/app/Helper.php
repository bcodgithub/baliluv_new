<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class Helper extends Model
{
    //

    public static function http_post($url, $param)
    {
        //set POST variables

        $fields_string = "";
        //url-ify the data for the POST
        foreach ($param as $key => $value) {
            $fields_string .= $key . '=' . $value . '&';
        }
        rtrim($fields_string, '&');

        //open connection
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/1.0");
        //set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        //  curl_setopt($ch, CURLOPT_COOKIESESSION, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR, public_path() . '/cookies_post');  //could be empty, but cause problems on some hosts
        curl_setopt($ch, CURLOPT_COOKIEFILE, public_path() . '/cookies_post');  //could be empty, but cause problems on some hosts

        curl_setopt($ch, CURLOPT_POST, count($param));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        //execute post
        $result = curl_exec($ch);
        //echo $result;
        //exit;
        //close connection
        curl_close($ch);
        return $result;
    }

    public static function appendMessage($from,$to,$subject, $message,$date){
        /* connect to gmail */
        $hostname = '{mail.soulfy.com:143/novalidate-cert}INBOX.Sent';
        $username = 'khadafi@soulfy.com';
        $password = 'admin123';

        /* try to connect */
        $inbox = imap_open($hostname, $username, $password) or die('Cannot connect to Gmail: ' . imap_last_error());

        //imap_append($inbox,$hostname,$message);

        imap_append($inbox, $hostname
            , "From: $from\r\n"
            . "To: $to\r\n"
            . "Date: $date\r\n"
            . "Subject: $subject\r\n"
            . "\r\n"
            . "$message\r\n"
        );
        imap_close ($inbox);
    }
}
