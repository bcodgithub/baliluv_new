<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Setting extends Model
{
    static $UPDATE_URL = "http://soulfy.com/timeline_app-feAC58adasdSdaaSfe8Afea512vcHsjd55dsf/";
    //
    protected $table = "user_setting";

    /*public static function isNewVersionAvailable(){
        if(Auth::check()) {
            $SERVER_VERSION_FILE = $_SERVER['DOCUMENT_ROOT'] . "/version.txt";

            $latestVersion = file_get_contents(str_replace(" ", "", self::$UPDATE_URL . "version.txt")) or die("Unable to proceed to update. error code 2001");
            if (!file_exists($SERVER_VERSION_FILE)) {
                file_put_contents($SERVER_VERSION_FILE, $latestVersion);
            }
            $currentVersion = file_get_contents($SERVER_VERSION_FILE);
           
            if($currentVersion != $latestVersion){
                return true;
            }
        }

        return false;
    }*/
}
