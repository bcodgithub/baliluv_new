<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class RssConfig extends Model
{
    //
    protected $table = "rss_config";

    protected $fillable = [
    	'tittle' ,'url','user_is', 'status'
    ];
}
