<?php

namespace Soulfy\Events;

abstract class Event
{
    //
}
