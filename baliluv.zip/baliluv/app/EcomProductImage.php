<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class EcomProductImage extends Model
{
    //
    protected $table = "ecom_product_image";
}
