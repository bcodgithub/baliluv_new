<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class EcomCategory extends Model
{
    //
    protected $table = "ecom_category";
}
