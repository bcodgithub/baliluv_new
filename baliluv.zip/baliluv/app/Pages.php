<?php


namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class Pages extends Model
{
    //
    protected $table = "cms_pages";
        

    public function page()
    {
    	return $this->belongsTo('Soulfy\User');
    } 
}
