<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class UserToken extends Model
{
    //
    protected $table = "user_token";
}
