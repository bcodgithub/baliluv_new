<?php

namespace Soulfy\Http\helper;

use File;

class BaseimgHelper
{

    public static function socialimg($baseimg)
    {
        $image = explode(";base64,", $baseimg);
        $imgExtpf = str_replace('data:image/', '', $image[0]);      
        $baseimg = str_replace(' ', '+', $image[1]);
        $id = uniqid();
        $imageName = 'Img_'.$id.".".$imgExtpf;
        $dataImage  = base64_decode($baseimg);
        file_put_contents("uploads/$imageName", $dataImage);
        return $imageName;
    }

    public static function profileimg($baseimg)
    {
        $image = explode(";base64,", $baseimg);
        $imgExtpf = str_replace('data:image/', '', $image[0]);      
        $baseimg = str_replace(' ', '+', $image[1]);
        $id = uniqid();
        $imageName = 'Img_'.$id.".".$imgExtpf;
        $dataImage  = base64_decode($baseimg);
        file_put_contents("uploads/user/$imageName", $dataImage);
        return $imageName;
    }

}