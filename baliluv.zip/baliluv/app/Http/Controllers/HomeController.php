<?php

namespace Soulfy\Http\Controllers;

use DB;

use Soulfy\Gallery;
use Soulfy\Timeline;
use Soulfy\Setting;

use Soulfy\Article;
use Soulfy\TwitterProfile;
use Soulfy\User;
use Soulfy\UserProfile;
use Soulfy\UserToken;
use Soulfy\WhatsApp;
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Facebook;

use Illuminate\Http\Request;
use Soulfy\Http\Requests;
use Soulfy\Http\Requests\ContactMailRequest;
use Soulfy\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use MetzWeb\Instagram\Instagram;
use SammyK\LaravelFacebookSdk\LaravelFacebookSdk;

use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Soulfy\Announcement;
use Soulfy\Category;

use ZipArchive;
use RegexIterator;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */

    private $UPDATE_URL = "http://soulfy.com/timeline_app-feAC58adasdSdaaSfe8Afea512vcHsjd55dsf/";

    public function index()
    {

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request $request
     * @param  int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }
    
    public function getIndex()
    {
        $fb = new Facebook([
            'app_id' => env('FACEBOOK_APP_ID'),
            'app_secret' => env('FACEBOOK_APP_SECRET'),
            'default_graph_version' => 'v2.4',
            'default_access_token' => '{access-token}', // optional
        ]);
        try {
            // Get the Facebook\GraphNodes\GraphUser object for the current user.
            // If you provided a 'default_access_token', the '{access-token}' is optional.
            $response = $fb->get('/me', null);
        } catch (FacebookResponseException $e) {
            // When Graph returns an error
            echo 'Graph returned an error: ' . $e->getMessage();
            exit;
        } catch (FacebookResponseException $e) {
            // When validation fails or other local issues
            echo 'Facebook SDK returned an error: ' . $e->getMessage();
            exit;
        }

        $me = $response->getGraphUser();
        echo 'Logged in as ' . $me->getName();
        exit;
        return view('soulfy.test');
    }


    public function getInstagram()
    {
        $instagram = new Instagram(array(
            'apiKey' => 'c76be42410e84c6bbcbf47adbe4f8a1c',
            'apiSecret' => 'd823d1300ccf443695620dbb43faa0c4',
            'apiCallback' => 'http://localhost:81/soulfy/laravel/public/home/callback'
        ));
        echo "<a href='{$instagram->getLoginUrl()}'>Login with Instagram</a>";
    }

    public function getInstagram2()
    {
    	$domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        return view('soulfy.instagram2', ['user' => $user]); 
    }

    public function getCallback()
    {
        $instagram = new Instagram(array(
            'apiKey' => 'c76be42410e84c6bbcbf47adbe4f8a1c',
            'apiSecret' => 'd823d1300ccf443695620dbb43faa0c4',
            'apiCallback' => 'http://localhost:81/soulfy/laravel/public/home/callback'
        ));
        // grab OAuth callback code
        $code = $_GET['code'];
        $data = $instagram->getOAuthToken($code);
        $instagram->setAccessToken($data->access_token);
        var_dump($data);
        echo 'Your username is: ' . $data->user->username;
        Session::set('access_token', $data->access_token);
        $data = $instagram->getUserFeed(10);
        var_dump($data);
    }

    public function getInstagramfeed()
    {
        $instagram = new Instagram(array(
            'apiKey' => 'c76be42410e84c6bbcbf47adbe4f8a1c',
            'apiSecret' => 'd823d1300ccf443695620dbb43faa0c4',
            'apiCallback' => 'http://localhost:81/soulfy/laravel/public/home/callback'
        ));
        $instagram->setAccessToken(Session::get('access_token'));
        $data = $instagram->getUserFeed(10);
        var_dump($data);
    }

    public function getFbfee()
    {
        $token = Session::get('facebook_access_token');
        $fb = new LaravelFacebookSdk();
        $fb->setDefaultAccessToken($token);

    }

    public function getTwitter()
    {

    }

    public function getFacebook(Request $request)
    {
        //$user = User::find($request->get("user_id"));
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();

        $user_token = UserToken::where('user_id', $user->id)->first();
        $token = $user_token->fb_token;

        if ($token == null) {
            return redirect(route('fb.login'));
        } else {

            $user_token = UserToken::where('user_id', $user->id)->first();
            if ($user_token == null) {
                $user_token = new UserToken();
                $user_token->user_id = $user->id;
                $user_token->fb_token = $token;
                $user_token->save();
            } else {
                // $token = $user_token->fb_token;
            }
        }
        //  echo $token;
        //exit;

        $fb = new Facebook([
            'app_id' => env('FACEBOOK_APP_ID'),
            'app_secret' => env('FACEBOOK_APP_SECRET'),
            'default_graph_version' => 'v2.4',
            'default_access_token' => $token, // optional
        ]);
        try {
            // Get the Facebook\GraphNodes\GraphUser object for the current user.
            // If you provided a 'default_access_token', the '{access-token}' is optional.
            // $response = $fb->get('/me?fields=permissions');
            // $response = $fb->get('/me?fields=id,name,email,picture');
            //$response = $fb->get('/me/feed?filter=app_2915120374');
            $response = $fb->get('/me/feed');
            //$response = $fb->get('/100001017777374_942627715781145?fields=object_id');
            // var_dump($response);
        } catch (FacebookResponseException $e) {
            // When Graph returns an error
            echo 'Graph returned an error: ' . $e->getMessage();
            exit;
        } catch (FacebookResponseException $e) {
            // When validation fails or other local issues
            echo 'Facebook SDK returned an error: ' . $e->getMessage();
            exit;
        }

        // exit;

        //$me = $response->getGraphUser();
        // echo 'Logged in as ' . $me->getName();

        //var_dump($response->getBody());
        //exit;

        // Page 1
        $feedEdge = $response->getGraphEdge();
        //  var_dump($feedEdge);

        foreach ($feedEdge as $status) {
            $data = json_decode($status->asJson());
            if (property_exists($data, 'message')) {
                $timeline = Timeline::where('social_id', $data->id)->where('user_id', $user->id)->first();
                if ($timeline == null) {
                    $timeline = new Timeline();
                    $timeline->user_id = $user->id;
                    $timeline->social_id = $data->id;
                    $timeline->social = "fb";
                    $timeline->content = $data->message;
                    $timeline->date = $data->created_time;
                    $timeline->save();
                    var_dump($data);
                }
            }
        }
    }

    public function getCategory()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $user_setting = Setting::where('user_id',$user->id)->first();
        $category = Category::where('parent_id',0)->select('id','name')->get();
        $category1 = Category::where('id',$user_setting->category_level1)->select('id','name')->get();
        $category2 = Category::where('id',$user_setting->category_level2)->select('id','name')->get();
        $category3 = Category::where('id',$user_setting->category_level3)->select('id','name')->get();
        $user_settinglevel3 = Setting::where('user_id',$user->id)->first();

        return view('soulfy.category',compact('articles','category','user','user_setting','category1','category2','category3','user_settinglevel3'));

    }
    public function postCategory(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $category_id = $request->category_id;
        $category_level1 = $request->level1_id;
        $category_level2 = $request->level2_id;
        $category_level3 = $request->level3_id;
        $category = Setting::where('user_id',$user->id)->first();
        if($category_id == '' || $category_level1 == '')
        {
            $arrResponse = array('message' => 'empty');
        }
        else{
            $category->category_id = $category_id;
            $category->category_level1 = $category_level1;
            $category->category_level2 = $category_level2;
            $category->category_level3 = $category_level3;
            $act = $category->update();
            if ($act) {
                $arrResponse = array('message' => 'success'); 
            } else {
                $arrResponse = array('message' => 'error'); 
            }
        }
        echo json_encode($arrResponse);
    }

    public function getTimeline()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();

        $timeline = Timeline::take(2)->where('user_id', $user->id)->get();
        foreach ($timeline as $data) {
            echo Timeline::split_words($data->content, 100, "...");
        }
    }

    public function getUpdateNews()
    {
        if (Auth::check()) {
            $domain = $_SERVER['SERVER_NAME'];
            $user = User::where('domain', $domain)->first();
            $user_setting = \Soulfy\Setting::where('user_id',$user['id'])->first();
            $announcement = Announcement::where('status',1)->orderBy('id','DESC')->first();
            return view('soulfy.updatenews', ['user' => $user, 'announcement' => $announcement, 'user_setting' => $user_setting]);
        } else {
            return redirect('/');
        }
    }

    public function getGoogle()
    {
        $token = Session::get('google_token');
        $googleService = \OAuth::consumer('Google');
        $result = json_decode($googleService->request('https://www.googleapis.com/plus/v1/people/me/activities/public'), true);

        // $message = 'Your unique Google user id is: ' . $result['id'] . ' and your name is ' . $result['name'];
        // echo $message. "<br/>";

        //Var_dump
        //display whole array.
        dd($result);
    }

    public function getSoulfy()
    {
        return view('soulfy.soulfy');
    }

    public function getTest()
    {
        return view('soulfy.test');
    }

    public function getHome()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $user_profile = \Soulfy\UserProfile::where('user_id', $user->id)->first();
        if ($user_profile == null) {
            $user_profile = new UserProfile();
            $user_profile->user_id = $user->id;
            $user_profile->save();
        }
        if (Auth::check()) {
            $articles = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'article')->orderBy('created_at', 'desc')->get();
        } else {
            $articles = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'article')->where('status', true)->orderBy('created_at', 'desc')->get();
        }
        $settings = Setting::where('user_id', $user->id)->get();
        if ($settings) $settings = $settings[0];
        return view('soulfy.index_v2', [
            'user' => $user, 
            'articles' => $articles, 
            'settings' => $settings,
            /*'total_sale_4' => $total_sale_4,*/
        ]);
        //return view('soulfy.index_v2',compact('user'));
    }

    public function getAdmin()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        if (Auth::check()) {
            $articles = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'article')->orderBy('created_at', 'desc')->get();
        } else {
            $articles = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'article')->where('status', true)->orderBy('created_at', 'desc')->get();
        }
        $settings = Setting::where('user_id', $user->id)->get();
        if ($settings) $settings = $settings[0];

        return view('soulfy.index_v2_admin', [
            'user' => $user, 
            'articles' => $articles, 
            'settings' => $settings,
        ]); 
        //return view('soulfy.index_v2',compact('user'));
    }

    public function postSendEmail(ContactMailRequest $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $to = $user->contact_email;
        $subject = $request->subject;
        $from = $request->email;
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: <' . $from . '>' . "\r\n";
        echo mail($to, $subject, $request->msg, $headers);
    }

    public function postLogin()
    {

    }

    public function getSocial()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $articles = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'article')->orderBy('created_at', 'desc')->get();
        $settings = Setting::where('user_id', $user->id)->get();
        if ($settings) $settings = $settings[0];
        return view('soulfy.social', ['user' => $user, 'articles' => $articles, 'settings' => $settings]);
        //return view('soulfy.social',['user'=>$user,'articles'=>$articles]);
        //return view('soulfy.social',['user'=>$user]);
    }

    public function getSetting(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        if (Auth::check()) {
        	$themes = DB::table('theme_background')->paginate(6);
        	$request->session()->flash('tab', 'tab3');
	        return view('soulfy.setting', [
    			'user' => $user,
            	'themes' => $themes,
            ]);
        } else {
            return redirect('/');
        }
    }

    /*public function getUpdateSystem()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        if($user!=null){
            $profile = TwitterProfile::where('user_id',$user->id)->first();
            if($profile == null){
                $profile = new TwitterProfile();
                $profile->user_id = $user->id;
                $profile->save();
            }
        }
        
        if (Auth::check()) {
            $SERVER_VERSION_FILE = $_SERVER['DOCUMENT_ROOT'] . "/version.txt";
            $latestVersion = file_get_contents(str_replace(" ", "", $this->UPDATE_URL . "version.txt")) or die("Unable to proceed to update. error code 2001");
            if (!file_exists($SERVER_VERSION_FILE)) {
                file_put_contents($SERVER_VERSION_FILE, $latestVersion);
            }
            $currentVersion = file_get_contents($SERVER_VERSION_FILE);
            $fixes = "";
            if ($currentVersion != $latestVersion) {
                $fixes = file_get_contents(str_replace(" ", "", $this->UPDATE_URL . $latestVersion . "/fixes.txt")) or die("Unable to proceed to update. error code 2001");
            }
            return view('soulfy.updatesystem', ['user' => $user, 'currentVersion' => $currentVersion, 'latestVersion' => $latestVersion, 'fixes' => $fixes]);
        } else {
            return redirect('/');
        }
    }*/

    public function getDeletebackup()
    {
        ini_set("memory_limit", "1024M");
        set_time_limit(0);

        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();

        if (Auth::check()) {
            $latestVersion = file_get_contents($this->UPDATE_URL . "version.txt");
            $last_array = explode(".",$latestVersion);

            // var_dump($last_array[2]);
            // echo $latestVersion."<br>";

            $backup_dir = $_SERVER['DOCUMENT_ROOT'] . "/../backups";
            $prev1= $last_array[2]-3;
            $backup_dir1 = $backup_dir."/" . "$last_array[0].$last_array[1].$prev1";

            $prev2= $last_array[2]-4;
            $backup_dir2 = $backup_dir."/" . "$last_array[0].$last_array[1].$prev2";

            $prev3= $last_array[2]-5;
            $backup_dir3 = $backup_dir."/" . "$last_array[0].$last_array[1].$prev3";

            if (file_exists($backup_dir1)) {
                // echo "The file $backup_dir1 exists";
                $this->delete_directory($backup_dir1);
            } else {
                // echo "The file $backup_dir1 does not exist";
            }
            if (file_exists($backup_dir2)) {
                // echo "The file $backup_dir2 exists";
                $this->delete_directory($backup_dir2);
            } else {
                // echo "The file $backup_dir2 does not exist";
            }

            if (file_exists($backup_dir3)) {
                // echo "The file $backup_dir3 exists";
                $this->delete_directory($backup_dir3);
            } else {
                // echo "The file $backup_dir3 does not exist";
            }
        }
    }

    function delete_directory($dirPath){
        if(is_dir($dirPath)){
            $objects=new \DirectoryIterator($dirPath);
            foreach ($objects as $object){
                if(!$object->isDot()){
                    if($object->isDir()){
                        $this->delete_directory($object->getPathname());
                    }else{
                        unlink($object->getPathname());
                    }
                }
            }
            rmdir($dirPath);
        }else{
//            throw new \Exception(__FUNCTION__.'(dirPath): dirPath is not a directory!');
        }
    }

    /*public function getDoUpdateSystem()
    {
        ini_set("memory_limit", "1024M");
        set_time_limit(0);
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        if (Auth::check()) {
            if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/update.lock')) {
                return redirect('/');
            }
            file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/update.lock', '');
            $SERVER_VERSION_FILE = $_SERVER['DOCUMENT_ROOT'] . "/version.txt";
            $latestVersion = file_get_contents($this->UPDATE_URL . "version.txt");
            if (file_exists($SERVER_VERSION_FILE)) {

                $currentVersion = file_get_contents($SERVER_VERSION_FILE);

                if ($currentVersion != $latestVersion) {
                    //$framework = file_get_contents(str-replace(" ","", $this->UPDATE_URL.$latestVersion."/framework.zip"));
                    //$public_html = file_get_contents($this->UPDATE_URL.$latestVersion."/public_html.zip");
                    //file_put_contents($_SERVER['DOCUMENT_ROOT']."/_framework.zip", $framework);
                    //file_put_contents($_SERVER['DOCUMENT_ROOT']."/_public_html.zip", $public_html);

                    $backup_dir = $_SERVER['DOCUMENT_ROOT'] . "/../backups";
                    @mkdir($backup_dir); // make sure, the backup directory exists
                    $backup_dir .= "/" . $currentVersion;
                    @mkdir($backup_dir); // make sure, the backup directory exists

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    $time = time();@mkdir($backup_dir . "/" . $time);
					$this->copyRecursively($_SERVER['DOCUMENT_ROOT']."/../framework", $backup_dir."/".$time.'/framework');
					$this->copyRecursively($_SERVER['DOCUMENT_ROOT'], $backup_dir."/".$time.'/public_html');
					
					$this->copyRecursively($_SERVER['DOCUMENT_ROOT']."/uploads", $backup_dir."/uploads");
					$this->copyRecursively($_SERVER['DOCUMENT_ROOT']."/source", $backup_dir."/source");
					
					$this->delete_files($_SERVER['DOCUMENT_ROOT']);
					@mkdir($_SERVER['DOCUMENT_ROOT']);
					
					file_put_contents($_SERVER['DOCUMENT_ROOT']."/public_html.zip", file_get_contents($this->UPDATE_URL . $latestVersion . "/public_html.zip"));
					$this->unzip($_SERVER['DOCUMENT_ROOT']."/public_html.zip", $_SERVER['DOCUMENT_ROOT']);
					@unlink($_SERVER['DOCUMENT_ROOT']."/public_html.zip");
					
					$this->delete_files($_SERVER['DOCUMENT_ROOT']."/../framework");
					@mkdir($_SERVER['DOCUMENT_ROOT']."/../framework");
					
					file_put_contents($_SERVER['DOCUMENT_ROOT']."/../framework.zip", file_get_contents($this->UPDATE_URL . $latestVersion . "/framework.zip"));
					$res=$this->unzip($_SERVER['DOCUMENT_ROOT']."/../framework.zip", $_SERVER['DOCUMENT_ROOT']."/../framework");
					
					@unlink($_SERVER['DOCUMENT_ROOT']."/../framework.zip");
					
					$this->delete_files($_SERVER['DOCUMENT_ROOT']."/uploads");
					$this->copyRecursively($backup_dir."/uploads", $_SERVER['DOCUMENT_ROOT'].'/uploads');
					$this->delete_files($backup_dir."/uploads");
					
					$this->delete_files($_SERVER['DOCUMENT_ROOT']."/source");
					$this->copyRecursively($backup_dir."/source", $_SERVER['DOCUMENT_ROOT'].'/source');
					$this->delete_files($backup_dir."/source");
					
					
					
					
                    /*shell_exec("
	        		    #mkdir " . $backup_dir . "/" . time() . ";
	        			#cp -R " . $_SERVER['DOCUMENT_ROOT'] . "/../framework " . $backup_dir . "/" . time() . ";
	        			#cp -R " . $_SERVER['DOCUMENT_ROOT'] . " " . $backup_dir . "/" . time() . ";
	        			
					    #cp -R " . $_SERVER['DOCUMENT_ROOT'] . "/uploads " . $backup_dir . "/;
					    #cp -R " . $_SERVER['DOCUMENT_ROOT'] . "/source " . $backup_dir . "/;
	        			
					    #rm -R " . $_SERVER['DOCUMENT_ROOT'] . ";
	        			#mkdir " . $_SERVER['DOCUMENT_ROOT'] . ";
	        			#cd " . $_SERVER['DOCUMENT_ROOT'] . ";
	        			
					    #wget " . $this->UPDATE_URL . $latestVersion . "/public_html.zip;
	        			#unzip public_html.zip;
	        			#rm -f public_html.zip;
	        			
					    #rm -R " . $_SERVER['DOCUMENT_ROOT'] . "/../framework;
					    #mkdir " . $_SERVER['DOCUMENT_ROOT'] . "/../framework;
	        			#cd " . $_SERVER['DOCUMENT_ROOT'] . "/../framework;
	        			
					    #wget " . $this->UPDATE_URL . $latestVersion . "/framework.zip;
	        			#unzip framework.zip;
	        			#rm -f framework.zip;
						
	        			rm -R " . $_SERVER['DOCUMENT_ROOT'] . "/uploads;
	        			cp -R " . $backup_dir . "/uploads " . $_SERVER['DOCUMENT_ROOT'] . ";
	        			rm -R " . $backup_dir . "/uploads;
	        			rm -R " . $_SERVER['DOCUMENT_ROOT'] . "/source;
	        			cp -R " . $backup_dir . "/source " . $_SERVER['DOCUMENT_ROOT'] . ";
	        			rm -R " . $backup_dir . "/source;
	        		");* /
                    
                    $this->getDeletebackup();
                }
            }

            file_put_contents($SERVER_VERSION_FILE, $latestVersion);
            @unlink($_SERVER['DOCUMENT_ROOT'] . '/update.lock');
            return redirect('/home/update-system');
            //return view('soulfy.updatesystem',['user'=>$user, 'currentVersion' => $currentVersion, 'latestVersion' => $latestVersion, 'fixes' => $fixes]);
        } else {
            return redirect('/');
        }
    }*/

    public function getBussinesscard()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        return view('soulfy.bcard', ['user' => $user]);
    }

    public function getEmail()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        return view('soulfy.email', ['user' => $user]);
    }
	
    public function getArticles()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $articles = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'article')->orderBy('created_at', 'desc')->get();
        return view('soulfy.articles', ['user' => $user, 'articles' => $articles]);
    }
    public function postSeo(Request $request)
    {
       $domain = $_SERVER['SERVER_NAME'];
       $user = User::where('domain', $domain)->first();
       $data = array('meta_title' => $request->get('meta_title'),
                   'meta_keyword' => $request->get('meta_keyword'),
                   'meta_description' => $request->get('meta_description')
                   );
       \DB::table('user_profile')->where('user_id', $user->id)->update($data); 
	   $request->session()->flash('status', 'Successfully update seo info.');					
       return redirect('/home/article');				
    }

    public function showSeo(Request $request)
    {
    	/*
    	Session::flash("flash_notification", [
			"level"=>"success",
			"message"=>"Berhasil menyimpan seo baru"
		]);
		*/
		return redirect()->back();
    } 

    public function getGallery()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $galleries = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'gallery')->where('ecom',0)->orderBy('created_at', 'desc')->select('id','content','description','updated_at','created_at')->get();
        $galleriesProduct = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'gallery')->where('ecom',1)->where('parent_id',0)->orderBy('created_at', 'desc')->select('id','content','tittle','description','price','updated_at','created_at')->get();
        $user_setting = Setting::where('user_id', $user->id)->first();
        $countries = \DB::table('countries')->select('countries_name', 'countries_isd_code')->get();

        if (Auth::check()) {
            $articles = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'article')->orderBy('created_at', 'desc')->get();
        } else {
            $articles = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'article')->where('status', true)->orderBy('created_at', 'desc')->get();
        }
        return view('soulfy.gallery', ['user' => $user, 'galleries' => $galleries, 'galleriesProduct' => $galleriesProduct, 'articles'=>$articles, 'user_setting' => $user_setting, 'domain'=> $domain, 'countries' => $countries]);
    }

    public function getVideo()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $galleries = Timeline::where('user_id', $user->id)->where('social', 'youtube')->orderBy('created_at', 'desc')->get();
        if (Auth::check()) {
            $articles = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'article')->orderBy('created_at', 'desc')->get();
        } else {
            $articles = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'article')->where('status', true)->orderBy('created_at', 'desc')->get();
        }
        return view('soulfy.video', ['user' => $user, 'galleries' => $galleries,'articles'=>$articles]);
    }

    public function getManageEmails()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        if (Auth::check()) {
            require_once(base_path() . "/vendor/cpanel_api/xmlapi.php");
            $ip = env("SERVER_IP", "127.0.0.1"); //your server's IP
            $xmlapi = new \xmlapi($ip);
            $xmlapi->password_auth(env("CPANEL_USER", "root"), env("CPANEL_PASSWORD", "")); //the server login info for the user you want to create the emails under
            $xmlapi->set_output('json');
            $xmlapi->set_debug(1);

            $acct = json_decode($xmlapi->listaccts('domain', $domain), true);
            if ($acct && count($acct['acct']) == 1) {
                $U = $acct['acct'][0]['user'];
                $params = array('domain' => $domain);
                $email_accounts = json_decode($xmlapi->api2_query($U, "Email", "listpopswithdisk", $params), true);

                return view('soulfy.email-manager', ['user' => $user, 'emails' => $email_accounts['cpanelresult']['data']]);
            } else {
                return redirect('/');
            }
        } else {
            return redirect('/');
        }
    }

    public function getWebArticles()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        if (Auth::check()) {
            $articles = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'article')->orderBy('created_at', 'desc')->get();
        } else {
            $articles = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'article')->where('status', true)->orderBy('created_at', 'desc')->get();
        }

        $settings = Setting::where('user_id', $user->id)->get();
        if ($settings) $settings = $settings[0];
        return view('soulfy.web_article', ['user' => $user, 'articles' => $articles, 'settings' => $settings]);
    }

    public function getBlog()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $articles = Timeline::where('user_id', $user->id)->where('social_id', $user->id)->where('social', 'article')->orderBy('created_at', 'desc')->get();
        return view('soulfy.articles', ['user' => $user, 'articles' => $articles]);
    }
    
    private function copyRecursively($src, $dst) {
		if(!is_dir($src) && !is_file($src)) return false;
		
		$dir = opendir($src);
		@mkdir($dst);
		while(false !== ( $file = readdir($dir)) ) {
			if (( $file != '.' ) && ( $file != '..' )) {
				if ( is_dir($src . '/' . $file) ) {
					$this->copyRecursively($src . '/' . $file, $dst . '/' . $file);
				} else {
					copy($src . '/' . $file,$dst . '/' . $file);
				}
			}
		}
		closedir($dir);
	}
	
	private function delete_files($target) {
		if(is_dir($target)){
			$files = scandir($target);
			
			foreach( $files as $file ){
				if($file !== '.' && $file !== '..')
					$this->delete_files( $target.'/'.$file );
			}

			rmdir( $target );
		} else if(is_file($target)) {
			unlink( $target );  
		}
	}
	
	private function unzip($file, $path) {
		$zip = new ZipArchive;
		$res = $zip->open($file);
		if ($res === TRUE) {
			$zip->extractTo($path);
			$zip->close();
			return true;
		} else {
			return false;
		}
	}
}