<?php

namespace Soulfy\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Soulfy\EcomCategory;
use Soulfy\EcomProduct;
use Soulfy\EcomProductImage;
use Soulfy\EcomProfile;
use Soulfy\Http\Requests;
use Soulfy\Http\Controllers\Controller;
use Soulfy\User;

class EcommerceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
        $products = EcomProduct::get();
        return view("ecommerce.index",compact('products'));
    }

    public function getIndex()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $category = EcomCategory::all();
        $products = EcomProduct::get();
        $profile = EcomProfile::where('user_id',$user->id)->first();
        if($profile == null){
            $profile= new EcomProfile();
            $profile->user_id = $user->id;
            $profile->store_image = "http://spasitelbg.com/uploads/no_img.jpg";
            $profile->store_name = "Your Store Name";
            $profile->store_description = "Your Store Description.";
            $profile->save();
        }
        return view("ecommerce.index", compact('user', 'category','products','profile'));
    }

    public function anyEditProfile(Request $request){
        $user = Auth::User();
        $profile = EcomProfile::where('user_id',$user->id)->first();
        if ($request->isMethod("POST")) {

            $error = false;
            $message = "";
            $status = "success";

            ##todo
            ##add validasi



            $profile->store_name = $request->store_name;
            $profile->store_description = $request->store_description;
            $profile->payment_description = $request->store_payment;


            if($request->hasFile("files")){
                $filename = uniqid("images");
                $destinationPath = getcwd() . "/images/profile";
                $file = $request->file('files');
                $file->move($destinationPath, $filename);

                $profile->store_image = "/images/profile/" . $filename;
            }

            $profile->save();

            $message = "Update profile successfully";

            return response()->json(['error' => $error, 'status' => $status, 'message' => $message]);
        }else{
            return view("ecommerce.modals.profile",compact('profile'));
        }
    }

    public function anyBuyProduct(){
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $profile = EcomProfile::where('user_id',$user->id)->first();
        return view("ecommerce.thank_you",compact('user','profile'));
    }

    public function anyAddCategory(Request $request)
    {
        if ($request->isMethod("POST")) {

            $user = Auth::User();
            ##todo
            ##add validasi


            $error = false;
            $message = "";
            $status = "success";

            $category = new EcomCategory();
            $category->category = $request->category;
            $category->user_id = $user->id;
            $category->save();

            $message = "Add category is successfully";

            return response()->json(['error' => $error, 'status' => $status, 'message' => $message]);

        } else {
            return view("ecommerce.modals.add_category");
        }
    }

    public function anyAddProduct(Request $request)
    {
        if ($request->isMethod("POST")) {

            $user = Auth::User();
            ##todo
            ##add validasi


            $error = false;
            $message = "";
            $status = "success";
            $product_name = $request->product_name;
            $stock = $request->stock;
            $price = $request->price;
            $category_id = $request->category_id;
            $description = $request->description;

            $product = new EcomProduct();
            $product->user_id = $user->id;
            $product->product_name = $product_name;
            $product->qty = $stock;
            $product->price = $price;
            $product->category_id = $category_id;
            $product->product_description = $description;

            $product->save();
            if ($request->hasFile('files')) {
                //
                $destinationPath = getcwd() . "/images/product";
//                echo $destinationPath;
//                $filename=$file->getClientOriginalName();
//                $request->file('file_source')->move($destinationPath, uniqid());
                foreach ($request->file('files') as $file) {
//                    echo  $file->getClientOriginalName();
                    $filename = uniqid("images");

                    $file->move($destinationPath, $filename);
                    $product_images = new EcomProductImage();
                    $product_images->product_id = $product->id;
                    $product_images->path = "/images/product/" . $filename;
                    $product_images->save();

                }

            }


            $message = "Add product is successfully";

            return response()->json(['error' => $error, 'status' => $status, 'message' => $message]);

        } else {
            $categories = EcomCategory::get();
            return view("ecommerce.modals.add_product", compact('categories'));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request $request
     * @param  int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }

    public function getCategory($id){
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $products = EcomProduct::where('category_id',$id)->get();

        $category = EcomCategory::all();
        return view("ecommerce.category",compact('products','user','category','id'));
    }

    public function getView($id){
        $product = EcomProduct::find($id);

        return view("ecommerce.modals.view_product",compact('product'));
    }

    public function anyBuy($id){
        $product = EcomProduct::find($id);

        return view("ecommerce.modals.buy_product",compact('product'));
    }

    public function postDelete($id){
        $category = EcomCategory::find($id);
        $category->delete();
    }
}
