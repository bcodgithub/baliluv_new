<?php

namespace Soulfy\Http\Controllers;

use DB;

use ValidateRequests;

use Soulfy\Gallery;
use Soulfy\Timeline;
use Soulfy\Setting;

use Soulfy\Article;
use Soulfy\TwitterProfile;
use Soulfy\User;
use Soulfy\UserProfile;
use Soulfy\UserToken;
use Soulfy\WhatsApp;
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Facebook;


use Soulfy\service_category;
use Soulfy\service_subcategory;

use Illuminate\Http\Request;
use Soulfy\Http\Requests;
use Soulfy\Http\Requests\ContactMailRequest;
use Soulfy\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Schema;
use MetzWeb\Instagram\Instagram;
use SammyK\LaravelFacebookSdk\LaravelFacebookSdk;

use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Soulfy\Announcement;


use ZipArchive;
use RegexIterator;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

class adminController extends Controller
{
    public function category_page()
    {
        $service_cat = DB::connection('mysql_2')->table('service_category')->select('id','category_name','category_description','created_at', 'status')->get();
        //dd($service_cat);
        return view('soulfy.categorypage',compact('service_cat'));
    }

    public function category_page_add()
    {
        //dd('test');
        return view('soulfy.category_add_page');
    }

    public function category_page_add_submission(Request $request)
    {
         /*$request->validate([
            'title' => 'required',
            'content' => 'required'

        ]);*/

        // DB::table('service_category')->insert([
        //     'category_name'      => $request->title,
        //     'category_description'    => $request->content,
        //     'created_at' => time(),
        //     'status'     => 1,
        // ]);

        

        $test=DB::connection('mysql_2')->table('service_category')->insert([
            'category_name'      => $request->title,
            'category_description'    => $request->content,
            'created_at' => date('Y-m-d H:i:s'),
            'status'     => 1,
        ]);
        //dd($test);
       

        session::flash('status','New category Added Successfully');
        return redirect('/admin/category');
    }

    public function sub_category_page(){
        $subcategory = DB::connection('mysql_2')->table('service_category')->select('id','category_name')->get();
        return view('soulfy.sub_category_add_page',compact('subcategory'));
    }

    public function sub_category_page_submit(Request $request){
 
        $mssg = DB::connection('mysql_2')->table('service_subcategory')->insert([
            'subcategory_name'      => $request->title,
            'subcategory_description'   => $request->content,
            'category_id' =>  $request->category,
            'created_at' => date('Y-m-d H:i:s'),
            'status'     => 1,
        ]);
        if($mssg){
            echo 'done';
        }
        else{
            echo 'try again';
        }
    }


    public function service_page(){
        $subcategory = DB::connection('mysql_2')->table('service_category')->select('id','category_name')->get();
        return view('soulfy.service_page',compact('subcategory'));
    }

    public function findProductName(Request $request){
        $data = DB::connection('mysql_2')->table('service_subcategory')->select('category_id','category_name')->where('category',$request->id)->get();
        dd($data);
        return response()->json($data);

    }

    public function service_page_submit(Request $request){
        $mssg = DB::connection('mysql_2')->table('services')->insert([
            'service_name' => $request->title,
            'service_description' => $request->content,
            'price' => $request->price,
            'duration' => $request->duration
            
        ]);
        if($mssg){
            echo 'done';
        }
        else{
            echo 'try again';
        }
    }

    public function email_template(){
        return view('soulfy.emailtemplate_page');
    }

    public function email_template_add_page(){
        return view('soulfy.emailtemplate_add_page');
    }

    public function email_template_add_page_submit(Request $request){
        $mssg = DB::connection('mysql_2')->table('email_template')->insert([
            'email_code' => $request->email_code,
            'email_title' => $request->title,
            'email_subject' => $request->subject,
            'email_content' => $request->content,
            'created_at' => date('Y-m-d H:i:s'),
            
        ]);
        dd($mssg);
        if($mssg){
            echo 'done';
        }
        else{
            echo 'try again';
        }
    }
}
?>