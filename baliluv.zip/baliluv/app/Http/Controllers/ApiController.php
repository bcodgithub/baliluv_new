<?php

namespace Soulfy\Http\Controllers;

use app\Http\helper\PathApi;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Mail;
use OAuth\OAuth2\Token\StdOAuth2Token;
use Soulfy\Helper;
use Soulfy\Http\Requests\CreateEmailRequest;
use Soulfy\Http\Controllers\Controller;
use Soulfy\MailContent;
use Soulfy\Timeline;
use Soulfy\User;
use Soulfy\UserMail;
use Soulfy\UserToken;
use Thujohn\Twitter\Facades\Twitter;

class ApiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }

    public function postSendmail(Request $request)
    {

        $to = $request->input("to");
        $body = $request->input("body");
        $subject = $request->input("subject");
        $domain = $request->input("domain");

        if ($to != "") {
            Mail::send('mail.send', ['body' => "sdfsdf"], function ($message) use ($to,$subject) {
                $message->from('khadafi@soulfy.com', "Muammar Khadafi");
                $message->subject($subject);
                $message->to($to);
            });

            $user = User::where('domain',$domain)->first();

//            $mail_content = new MailContent();
//            $mail_content->body = $body;
//            $mail_content->folder = "SENT";
//
//            $mail_content->from = 'khadafi@soulfy.com';
//            $mail_content->date = date("D, j M Y H:i:s O");
//            $mail_content->subject =$subject;
//            $mail_content->save();
            Helper::appendMessage('khadafi@soulfy.com',$to,$subject,$body,date("D, j M Y H:i:s O"));
        }
    }

    public function getTestappend(){
        Helper::appendMessage('khadafi@soulfy.com',"daffigusti@gmail.com","tsdfsdf","Tset uga",date("D, j M Y H:i:s O"));
    }

    public function getTestpath(){
        $api = new PathApi();
        $user = $api->login('YOUR_PATH_USERNAME', 'YOUR_PATH_PASSWORD');
        echo $api->user->id;
        $data = $api->getHome();
        print_r($data);
    }
/*
    public function getCreatemail (){
        $domain = $_SERVER['SERVER_NAME'];
        $domain = str_replace('www.','',$domain);
        $user = User::where('domain',$domain)->first();

        require_once(base_path() . "/vendor/cpanel_api/xmlapi.php");
        $ip = env(SERVER_IP, "127.0.0.1"); //your server's IP

        $xmlapi = new \xmlapi($ip);
//        $xmlapi->set_port(2083);
        $xmlapi->password_auth(env(CPANEL_USER, "root"),env(CPANEL_PASSWORD, "")); //the server login info for the user you want to create the emails under
        $xmlapi->set_output('json');
        $xmlapi->set_debug(1);
        $params = array('domain'=>$user->domain, 'email'=>'testcreate', 'password'=>'Admin123', 'quota'=>25); //quota is in MB
        $addEmail = json_decode($xmlapi->api2_query("wwwdustr", "Email", "addpop", $params), true);


        if($addEmail['cpanelresult']['data'][0]['result']){
            echo "success";

        }
        else {
            echo "Error creating email account:\n".$addEmail['cpanelresult']['data'][0]['reason'];
        }

    }
*/
    public function postCreateEmail(CreateEmailRequest $request){
        $domain = $_SERVER['SERVER_NAME'];
        $response = 200; 
        $message = "";
        $error = false;

        $user = User::where('domain',$domain)->first();

        $username = $request->input("account");
        $firstname = $request->input("first");
        $lastname = $request->input("last");
        $password = $request->input("password");
        
        
        //$user_mail = UserMail::where('user_id',Auth::user()->id)
            //->where("email_account",$username)
            //->first();
        /*$user_mail = UserMail::where('user_id',$user->id)
            ->where("email_account",$username)
            ->first();* /
        if($user_mail==null){*/
            //$user_mail = new UserMail();
            //$user_mail->firstname = $firstname;
            //$user_mail->lastname = $lastname;
//            $user_mail->password = $password;
            // $user_mail->user_id = $user->id;
            //$user_mail->user_id = Auth::user()->id;

            //$user_mail->email_account = $username;

            if(User::createEmail($domain,$username,$password)){
                //$user_mail->save();

                $message = "Create mail success.";
                $response = 200;
            } else {
                $message = "Create mail failed.";
                $response = 400;
            }
        /*}else{
            $message = "Email already Existed.";
            
            $response = 400;
        }*/
        return response()->json(
            array(
                'error' => true,
                'message' => $message,
                'token'=>csrf_token()),
            $response);

    }
    
    public function getTwitter(Request $request){
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain',$domain)->first();

        if ($user != null) {
            $user_token = UserToken::where('user_id', $user->id)->first();

            Config::set('ttwitter.ACCESS_TOKEN', $user_token->twitter_token);
            Config::set('ttwitter.ACCESS_TOKEN_SECRET', $user_token->twitter_token_secret);


            $data = Twitter::getSettings();
            $timeline = Twitter::getUserTimeline(['screen_name' => $data->screen_name, 'count' => '5']);

            foreach($timeline as $data_timeline){
//                var_dump($data_timeline->id_str);
//                echo "<br>";
                $timeline = Timeline::where('social_id',$data_timeline->id_str)->first();
                if($timeline==null) {
                    $timeline = new Timeline();
                    $timeline->user_id = $user->id;
                    $timeline->social_id = $data_timeline->id_str;
                    $timeline->social = "twitter";
                    $timeline->content = $data_timeline->text;
                    $timeline->date = $data_timeline->created_at;
                    $timeline->save();
                    //var_dump($data);
                }
            }
        }

    }

    public function getGoogle(Request $request){
        $user = User::find($request->get("user_id"));

        if ($user != null) {
            $user_token = UserToken::where('user_id', $user->id)->first();
            $token = $user_token->google_token;

            $googleService = \OAuth::consumer('Google');

            $tokenS = new StdOAuth2Token();
            $tokenS->setAccessToken($token);
            $_SESSION["lusitanian_oauth_token"]["Google"] = serialize($tokenS);

            $result = json_decode($googleService->request('https://www.googleapis.com/plus/v1/people/me/activities/public?maxResults=5'), true);
            //var_dump($result["items"]);

            foreach($result["items"] as $data){
                var_dump($data["object"]);
               if($data["object"]["content"] !=""){
                   $timeline = new Timeline();
                   $timeline->social_id = $data["id"];
                   $timeline->social = "google";
                   $timeline->content = $data["object"]["content"];
                   $timeline->date = $data["published"];
                   $timeline->save();
               }

                echo "<br><br>";
            }

        }
    }

}