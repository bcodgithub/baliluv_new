<?php

namespace Soulfy\Http\Controllers;

use Illuminate\Http\Request;
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Facebook;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;
use OAuth\OAuth2\Token\StdOAuth2Token;
use SammyK\LaravelFacebookSdk\LaravelFacebookSdk;
use Soulfy\Http\Requests;
use Soulfy\Http\Controllers\Controller;
use Soulfy\User;
use Soulfy\UserToken;
use Thujohn\Twitter\Facades\Twitter;

class SocialController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request $request
     * @param  int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }

    public function postStatus(Request $request)
    {
        $type = $request->input("type");
        $status = $request->input("status");

        //$domain = $_SERVER['SERVER_NAME'];
        $domain = $request->input("domain");
        $user = User::where('domain', $domain)->first();

        if ($user != null) {
            $user_token = UserToken::where('user_id', $user->id)->first();

            if ($type == 1) {
                $token = $user_token->fb_token;

                $fb = new Facebook([
                    'app_id' => env('FACEBOOK_APP_ID'),
                    'app_secret' => env('FACEBOOK_APP_SECRET'),
                    'default_graph_version' => 'v2.4',
                    'default_access_token' => $token, // optional
                ]);
                $fb->post('/me/feed', array('message' => $status), $token);
            } else if ($type == 2) {

                Config::set('ttwitter.ACCESS_TOKEN', $user_token->twitter_token);
                Config::set('ttwitter.ACCESS_TOKEN_SECRET', $user_token->twitter_token_secret);

                Twitter::postTweet(['status' => $status, 'format' => 'json']);
            } else if ($type == 4) {
                $token = $user_token->google_token;

                $googleService = \OAuth::consumer('Google');
                $param = json_encode(array(
                    'object' => $status,
                    'access' => array(
                        'items' => array("type" => "domain"),
                        'domainRestricted' => true,
                    )
                ));
                $tokenS = new StdOAuth2Token();
                $tokenS->setAccessToken($token);
                $_SESSION["lusitanian_oauth_token"]["Google"] = serialize($tokenS);



                //$result = json_decode($googleService->request('https://www.googleapis.com/plusDomains/v1/people/me/activities', "POST", $param), true);
                $result = json_decode($googleService->request('https://www.googleapis.com/oauth2/v1/userinfo'), true);
                var_dump($result);

            }
        }

        echo "ok";
    }

    public function postPublishStatus(Request $request)
    {
        $type = $request->input("type");
        $status = $request->input("status");

        $domain = $_SERVER['SERVER_NAME'];
        //$domain =  $request->input("domain");

        echo self::http_post("http://callback.soulfy.com/social/status", ["type" => $type, "status" => $status, "domain" => $domain]);

    }

    public static function http_post($url, $param)
    {
        //set POST variables

        $fields_string = "";
        //url-ify the data for the POST
        foreach ($param as $key => $value) {
            $fields_string .= $key . '=' . $value . '&';
        }
        rtrim($fields_string, '&');

        //open connection
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/1.0");
        //set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        //  curl_setopt($ch, CURLOPT_COOKIESESSION, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR, public_path() . '/cookies_post');  //could be empty, but cause problems on some hosts
        curl_setopt($ch, CURLOPT_COOKIEFILE, public_path() . '/cookies_post');  //could be empty, but cause problems on some hosts

        curl_setopt($ch, CURLOPT_POST, count($param));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        //execute post
        $result = curl_exec($ch);
        //echo $result;
        //exit;
        //close connection
        curl_close($ch);
        return $result;
    }

    public function getStatus()
    {
        $domain = "dustroyer.com";
        $user = User::where('domain', $domain)->first();

        if ($user != null) {
            $user_token = UserToken::where('user_id', $user->id)->first();
//            $token = $user_token->twitter_token;
//
//            Twitter::postTweet(['status' => 'Laravel is beautiful', 'format' => 'json']);
//            $fb = new Facebook([
//                'app_id' => env('FACEBOOK_APP_ID'),
//                'app_secret' => env('FACEBOOK_APP_SECRET'),
//                'default_graph_version' => 'v2.4',
//                'default_access_token' => $token, // optional
//            ]);
//            $fb->post('/me/feed', array('message'=>"hoho"));

            // $response = $fb->get('/me', null);
            //echo $response;

                $token = $user_token->google_token;

            $googleService = \OAuth::consumer('Google');
            $param = json_encode(array(
                'object' => array(
                    'originalContent'=>"Tsdf"
                ),
                'access' => array(
                    'items' => array("type" => "domain"),
                    'domainRestricted' => true,
                )
            ));
            $tokenS = new StdOAuth2Token();
            $tokenS->setAccessToken($token);
            $_SESSION["lusitanian_oauth_token"]["Google"] = serialize($tokenS);

            echo $param;
            //exit;
            $result = json_decode($googleService->request('https://www.googleapis.com/plusDomains/v1/people/me/activities', "POST", $param), true);
            //$result = json_decode($googleService->request('https://www.googleapis.com/oauth2/v1/userinfo'), true);
            var_dump($result);
        }
        exit;
    }
}
