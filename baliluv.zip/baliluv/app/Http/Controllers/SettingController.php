<?php

namespace Soulfy\Http\Controllers;

use DB;
use Illuminate\Support\Facades\Route;
use File;
use Auth;
use Illuminate\Http\Request;
use app\UserProfile;
use Soulfy\User;
use Soulfy\UserbgProfile;
use Soulfy\Setting;
use Soulfy\Pages;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Soulfy\Http\Requests;
use Soulfy\Http\Controllers\Controller;
use Soulfy\Http\Requests\CreateContactEmailRequest;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Validator;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;

class SettingController extends Controller

{
    public function index()
    {
        //
    }
    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)

    {
        //
    }

    public function destroy($id)
    {
        //
    }

    public function postSavemail(CreateContactEmailRequest $request)
    {
        //\Storage::disk('local')->put('email.txt', $request->email);
        //$contents = \Storage::get('email.txt');

        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $user->contact_email = $request->email;
        $user->save();
        return $request->email;
    }

    public function postWhatsappapi(Request $request)
    {
        $arrResponse = array('message' => 'nexist');
        
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $setting = Setting::where('user_id',$user->id)->first();

        $username  = $request->wa_username;
        $number = $request->wa_number;

        $existUsername = Setting::where('user_id','!=',$user->id)->where('wa_username',$username)->pluck('wa_username');
        $existNumber = Setting::where('user_id','!=',$user->id)->where('wa_number',$number)->pluck('wa_number');

        if ($username =='' OR $number == '') {
            $arrResponse = array('message' =>'error');
        }
        elseif (isset($existNumber) && ($existNumber == $number)) {
            $arrResponse = array('message' => 'nexist');

        }elseif (isset($existUsername) && $existUsername == $username) {
            $arrResponse = array('message' => 'uexist'); 
        }
        else{
            $setting->wa_number = $number;
            $setting->wa_username = $username;
            $setting->update();
            $arrResponse = array('message' => 'success'); 
        }
        echo json_encode($arrResponse);
    }

    public function postWhatsappapib(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $setting = Setting::where('user_id',$user->id)->first();
        $countryCode = $request->countryCode;
        $username  = $request->wa_username;
        $number = $request->wa_number;
        $setting->wa_number = $countryCode.$number;
        $setting->wa_username = $username;
        $setting->save();
        return $number;
    }

    public function postCustommenu(Request $request)
    {
        $destinationPath = $_SERVER['DOCUMENT_ROOT'].'/uploads/';
        $image = $request->file('custom_menu1_logo');
        $menu1 = $request->menu1;
        $menu2 = $request->menu2;
        $menu3 = $request->menu3;
        $custom_menu1_logo = null;
        if($image) {
            $image_org_name = $image->getClientOriginalName();
            $extension = $image->getClientOriginalExtension();
            $custom_menu1_logo =  'menu_icon_'.time().'-'.$image_org_name;
            $parts = explode('.', $custom_menu1_logo);
            $ext = end($parts);
            unset($parts[count($parts)-1]);
            $custom_menu1_logo_hover = implode('.', $parts).'-hover.'.$ext;
            $image->move($destinationPath, $custom_menu1_logo_hover);
            File::copy($destinationPath.$custom_menu1_logo_hover, $destinationPath.$custom_menu1_logo);
        }

        $destinationPath = $_SERVER['DOCUMENT_ROOT'].'/uploads/';
        $image = $request->file('custom_menu2_logo');
        $custom_menu2_logo = null;
        if($image) {
            $image_org_name = $image->getClientOriginalName();
            $extension = $image->getClientOriginalExtension();
            $custom_menu2_logo =  'menu_icon_'.time().'-'.$image_org_name;
            $parts = explode('.', $custom_menu2_logo);
            $ext = end($parts);
            unset($parts[count($parts)-1]);
            $custom_menu2_logo_hover = implode('.', $parts).'-hover.'.$ext;
            $image->move($destinationPath, $custom_menu2_logo_hover);
            File::copy($destinationPath.$custom_menu2_logo_hover, $destinationPath.$custom_menu2_logo);
            //$image->move($destinationPath, $custom_menu2_logo);
        }

        $destinationPath = $_SERVER['DOCUMENT_ROOT'].'/uploads/';
        $image = $request->file('custom_menu3_logo');
        $custom_menu3_logo = null;
        if($image) {
            $image_org_name = $image->getClientOriginalName();
            $extension = $image->getClientOriginalExtension();
            $custom_menu3_logo =  'menu_icon_'.time().'-'.$image_org_name;
            $parts = explode('.', $custom_menu3_logo);
            $ext = end($parts);
            unset($parts[count($parts)-1]);
            $custom_menu3_logo_hover = implode('.', $parts).'-hover.'.$ext;
            $image->move($destinationPath, $custom_menu3_logo_hover);
            File::copy($destinationPath.$custom_menu3_logo_hover, $destinationPath.$custom_menu3_logo);
            //$image->move($destinationPath, $custom_menu3_logo);
        }

        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $setting = Setting::where('user_id',$user->id)->first();

        //menu_icon_1577078453-shopeetrans.png
        if($custom_menu1_logo) {
            $setting->custom_menu1_logo = $custom_menu1_logo;
        }
        else{
            $setting->custom_menu1_logo = $menu1;
        }

        if($custom_menu2_logo) {
            $setting->custom_menu2_logo = $custom_menu2_logo;
        }
        else {
            $setting->custom_menu2_logo = $menu2;
        }

        if($custom_menu3_logo) {
            $setting->custom_menu3_logo = $custom_menu3_logo;
        }
        else{
             $setting->custom_menu3_logo = $menu3;
        }

        $setting->custom_facebook_link = $request->custom_facebook_link;
        $setting->custom_twitter_link  = $request->custom_twitter_link;
        $setting->custom_linkedin_link = $request->custom_linkedin_link;

        $setting->custom_menu1_name = $request->custom_menu1_name;
        $setting->custom_menu2_name = $request->custom_menu2_name;
        $setting->custom_menu3_name = $request->custom_menu3_name;

        $setting->custom_menu1_link = $request->custom_menu1_link;
        $setting->custom_menu2_link = $request->custom_menu2_link;
        $setting->custom_menu3_link = $request->custom_menu3_link;

        $setting->custom_facebook_enable = ($request->custom_facebook_enable == "enable");
        $setting->custom_twitter_enable  = ($request->custom_twitter_enable == "enable");
        $setting->custom_linkedin_enable = ($request->custom_linkedin_enable == "enable");

        $setting->custom_menu1_enable = ($request->custom_menu1_enable == "enable");
        $setting->custom_menu2_enable = ($request->custom_menu2_enable == "enable");
        $setting->custom_menu3_enable = ($request->custom_menu3_enable == "enable");

        $setting->save();
        return "done";
    }
    
    public function postFavicon(Request $request)
    {
        $destinationPath = $_SERVER['DOCUMENT_ROOT'].'/uploads/';
        $image = $request->file('favicon');
        $favicon = null;
        if($image) {
            $image_org_name = $image->getClientOriginalName();
            $extension = $image->getClientOriginalExtension();
            if($extension == 'jpeg' || $extension == 'jpg' || $extension == 'png' || $extension == 'ico') {
                $favicon =  'menu_icon_'.time().'-'.$image_org_name;
                $image->move($destinationPath, $favicon);
                
                $domain = $_SERVER['SERVER_NAME'];
                $user = User::where('domain', $domain)->first();
                $setting = Setting::where('user_id',$user->id)->first();
                if($setting->favicon) {
                    @unlink($_SERVER['DOCUMENT_ROOT'].'/uploads/'.$setting->favicon);
                }
                
                $setting->favicon = $favicon;
                $setting->save();
                return "done";
            }
        }
    }

    public function postSave(Request $request)
    {
        $response = 200;
        $message = "";
        $error = false;
        // yg ini mesti pake id untuk ambil usernya karena bawaan laravel codingnya yg auth
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('id', Auth::user()->id)
        //->where('domain', $domain)
        ->first();

        $method = $request->input("method");
        $name = $request->input("name");
        $email = $request->input("email");
        $address = $request->input("address");
        $language = $request->input("language");
        $old_pwd = $request->input("old_pwd");
        $new_pwd = $request->input("new_pwd");
        $confirm_pwd = $request->input("confirm_pwd");

        if($name!=null){
            $user->full_name = $name;
            $message = $name;
        }

        if($email !=null){
            $user->email = $email;
            $message = $email;
        }

        if($address !=null){
            $user->address = $address;
            $message = $address;
        }

        if($language !=null){
            $user->language = $language;
            if($language == "id") $message = "Indonesia (ID)";
            else $message = "English (US)";
        }

        if($method !=null){

            if($method == "change_pwd"){
                $response = 400;
                $message = "Password is failed to changed";
                $hashedPassword = $user->password;
                if (Hash::check($old_pwd, $hashedPassword))
                {
                    if($new_pwd == "" || $confirm_pwd == ""){
                        $message = "new password or confirm password cannot be empty";
                    }elseif($new_pwd!=$confirm_pwd){
                        $message = "password is not matched. )";
                    }else {
                        $password = Hash::make($new_pwd);
                        $user->password=$password;
                        $message ="********";
                        $response = 200;
                    }
                }else{
                    $message = "Your current password doesn't match to our record $user->full_name";
                }
            }
        }

        $user->save();
        return response()->json(
            array(
                'error' => $error,
                'message' => $message,
                 'token'=>csrf_token()),
            $response);
    }

    public function postSaveSocial(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $response = 200;
        $message = "";
        $error = false;
        $url = "";
        $data = $request->input("set");
        $type = $request->input("type");
        $setting = Setting::where('user_id',$user->id)->first();
        if($data!=null && $data != ""){
            if($type == "fb"){
                $setting->fb_enable =$data;
                $url = "http://callback.soulfy.com/facebook/login?domain=$user->domain";
            }elseif($type == "twitter"){
                $setting->twitter_enable =$data;
                $url = "http://callback.soulfy.com/twitter/login?domain=$user->domain";
            }elseif($type == "google"){
                $setting->google_enable =$data;
                $url = "http://callback.soulfy.com/google/login?domain=$user->domain";
            }elseif($type == "youtube"){
                $setting->youtube_enable =$data;
            }elseif($type == "washop"){
                $setting->washop_enable =$data;
            }elseif($type == "rssfeed"){
                $setting->rssfeed_enable =$data;
            }elseif($type == "menulist"){
                $setting->menu_list =$data;
            }elseif($type == "instagram"){
                $setting->instagram_enable =$data;    
            }elseif($type == "flickr"){
                $setting->flickr_enable =$data;
            }elseif($type == "path"){
                $setting->path_enable =$data;
            }
            $setting->save();
        }else{
            $response = 400;
        }

        return response()->json(
            array(
                'error' => $error,
                'message' => $message,
                'url'=>$url,
                'token'=>csrf_token()),
            $response);
    }

    public function postReqEcommerce(Request $request)
    {
        $response = 200;
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        Log::info("Ini usernya: $user");        
        $error = true;
        $message = "error";
        // pastingkan email jalan supaya bisa in progress
        $to = 'support@soulfy.com';

        $subject = "Request Pembuatan website ecommerce untuk user $user->name";

        $body = "User soulfy : <b>$user->name ($user->domain)</b>  melakukan permintaan untuk pembuatan website ecommerce. <br> Silahkan ditindaklanjuti. <br><br> Terima kasih <br> Admin <br> Khadafi.";

        Mail::send([], [], function ($message) use ($to,$subject,$body) {
            $message->from('khadafi@soulfy.com', "Soulfy Admin");
            $message->subject($subject);
            $message->to($to);
            $message->setBody($body, 'text/html');
            $message->bcc("daffigusti0890@gmail.com");
            $message->cc("ecommerce@soulfy.com");
        });

        $setting = Setting::where('user_id',$user->id)->first();

        if($setting){
            $setting->ecommerce_status  = "IN_PROGRESS";
            $setting->save();
            $error = false;
            $message = "Sukses";
        }
        return response()->json(
            array(
                'error' => $error,
                'message' => $message,
                'token'=>csrf_token()),
            $response);
    }

    public function postNewsletter(Request $request)
    {
    	$title = "newsletter subscriber";
    	$account = $request->input('account');
    	$content = "This is a new newsletter subscriber: $account";

    	//$title = $request->input('title');
        //$content = $request->input('content');
        //Grab uploaded file
        //$attach = $request->file('file');

        Mail::send('soulfy.email.subscribe', ['title' => $title, 'content' => $content], function ($message) use ($account)//use ($attach)
        {
            $message->from('subscriber@soulfy.com', 'Admin');
            $message->to(['subscriber@soulfy.com',$account]);
            //Attach file
            //$message->attach($attach);
            //Add a subject
            $message->subject("Newsletter new subscriber");
        });
        return redirect('home/setting');
    }		

    public function postChangeTheme(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $response = 200;
        $error = false;
        $value = $request->input("value");
        $setting = Setting::where('user_id',$user->id)->first();
        if($value!=null){
            $setting->themes_enable = $value;
            $setting->save();
            $message = 'success';
        }else{
            $message = "error";
        }
        return response()->json(
            array(
                'error' => $error,
                'message' => $message,
                'token'=>csrf_token()),
            $response);
    }

    public function getNavColor(Request $request)
    {
       $domain = $_SERVER['SERVER_NAME'];
       $user = User::where('domain', $domain)->first();
       $user_id = $user->id;
       $nav_color = $request->get('navcolor');
       $pages = Pages::where('user_id', $user->id)->get();
       DB::table('user_profile')->where('user_id', $user_id)->update(['nav_color' => $nav_color]);
       return view('/soulfy/apages', ['pages' => $pages]);                        
    }

	public function postMenu(Request $request)
    {	
       $domain = $_SERVER['SERVER_NAME'];
       $user = User::where('domain', $domain)->first();
       $user_id = $user->id;
       //$user_id = Auth::user()->id;
       $menu_color = $request->get('menu');
       /*
       $uprofile = UserProfile::find($user_id);
       $uprofile->menu_color = $menu_color;
       $uprofile->update();
	   */
       DB::table('user_profile')->where('user_id', $user_id)
								->update(['menu_color' => $menu_color]);
       return redirect('/home/setting');	 
	//return view('/soulfy/setting', ['menu_color' => $menu_color]);

    }

    public function getProfilePic()
    {
    	return view('soulfy.profilepic');
    }

    public function getBackgroundTheme(Request $request)
    {
    	$request->session()->flash('tab', 'tab3');
    	// background for sell
    	$query = DB::table('theme_background');
	    if ($request->menu) {
			$theme = DB::table('kategori_name')->where('kategori_theme', $request->menu)->first();
			$query = $query->where('kategori_id', $theme->id);
    	} 
		$themes = $query->paginate(6);
		$domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        return view('soulfy.setting', [
			'themes'=> $themes,
			'user' => $user,						
		]);
    }

    public function SendPicture(Request $request)
    {
    	$request->session()->flash('tab2', 'tab1');
    	// if (chkbox_agreement == checked) {}
    	$title = "Picture Purchase";
    	//$picture = $request->input('pic');
    	$domain = $_SERVER['SERVER_NAME'];
    	$query = DB::table('users')->where('domain', $domain)->first();
    	$email = $query->contact_email;
    	$content = "$email purchase your picture : ";
    	foreach ($request->input('pic') as $key => $value) {
            $content .= "$value".".jpg ";
        }

        Mail::send('soulfy.email.purchase', ['title' => $title, 'content' => $content], function ($message) //use ($attach)
        {
            $message->from('davy.yg1@gmail.com', 'Admin');
            $message->to(['davy_yg@yahoo.com', 'stokfoto@soulfy.com']);
            //Attach file
            //$message->attach($attach);
            //Add a subject
            $message->subject("Picture Purchase");
        });
        return redirect('home/setting');
    }

    public function getBackgroundProfile()
    {
    	$domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $bgprofiles = DB::table('user_bgprofile')->where('user_id', $user->id)->get();    
       	return view('soulfy.setting', [
    			'bgprofiles' => $bgprofiles,
    			'user' => $user,
    		]);
    }

    public function selectBackgroundProfile()
    {
		// cuma mengupload ke uploads/user/ 
    }

    public function UploadBackgroundProfile(Request $request)
    {
    	$b_pic = $request->file('b_pic');
    	$id = $request->input('id');
    	$model = UserbgProfile::find($id);
		if($b_pic != NULL)
			$b_pic->move('uploads/bgprofile', $b_pic->getClientOriginalName());
		if($b_pic != NULL)
		{	
			// simpan yg baru
			$model->bgprofile = $b_pic->getClientOriginalName();
		}
		$model->save();
    	return view('soulfy.setting');
    }

    public function DeleteBackgroundProfile(Request $request, $id)
	{
		$id = $request->input('id');
		$model = user_bgprofile::find($id);
		$model->delete();
		return redirect('home/setting');
	}

}