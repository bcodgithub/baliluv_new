<?php

namespace Soulfy\Http\Controllers;

use Illuminate\Http\Request;

use Soulfy\Http\Requests;
use Soulfy\Http\Controllers\Controller;
use Soulfy\User;
use Soulfy\Timeline;
use Soulfy\Youtube;

class TimelineController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }

    public function getHome(){
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain',$domain)->first();
        return view('timeline.index_v2',['user'=>$user]);
    }

    public function getTiki(){
        return view("soulfy.index");
    }
    public function postYoutube()
    {
         $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain',$domain)->first();
        $youtube = new Youtube();
        $input = Input::text('url_video');
        if ($user!=null) {
            $url_video = $youtube->input("url_video");
            $cek_url = explode("/", $url_video);
            $cek_url_type = substr($cek_url['3'], 0,5);
            if ($cek_url_type=="watch") {
                        
                $get_video_id = explode("=", $url_video);
                $url = "https://www.youtube.com/embed/$get_video_id";

            }elseif ($cek_url_type=="embed") {
                $url = $url_video;
            }
        }
    }
}
