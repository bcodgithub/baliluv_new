<?php

namespace Soulfy\Http\Controllers;

use Soulfy\User;
use Soulfy\Setting;
use Soulfy\TestPopup;
use Soulfy\UserProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\File;
use Soulfy\Http\helper\BaseimgHelper;
use Soulfy\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class BasicsetupController extends Controller
{
	public function getIndex(Request $request)
	{
		return view('basicsetup');
	}

    public function postBasicInfo(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();

        if ($user) {
            //uploads/user/Img_10785.jpeg
            //MAHAKAM STATIONARY - ATK BENGKULU
            $fullname = $request->input("fullname");
            $profile = $request->input("profile");
            $background = $request->input("background");
            
            if (empty($fullname)) {
                $message = "error";
                
            } else {

                $pfimg = BaseimgHelper::profileimg($profile);
                $bkimg = BaseimgHelper::profileimg($background);

                date_default_timezone_set("Asia/Jakarta");

                $user->full_name = $fullname;
                $user->image_profile = "/uploads/user/$pfimg";
                $user->background_image = "/uploads/user/$bkimg";
                $act = $user->update();

                if ($act) {
                    $message = "success";
                } else {
                    $message = "error";
                }                
            }
            echo json_encode($message);
        }
    }

	public function postConInfo(Request $request)
	{
		$domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();

        if ($user) {

            $phone = $request->input("phone");
            $email = $request->input("email");
            //$fax = $request->input("fax");
            $address = $request->input("address");
            
            if (empty($phone)) {
                $message = "error";
                
            } else {
            	
                date_default_timezone_set("Asia/Jakarta");
                $user->phone = $phone;
                $user->contact_email = $email;
                $user->address = $address;
                //$user->fax = $fax;
                $act = $user->update();

                if ($act) {
                    $message = "success";
                } else {
                    $message = "error";
                }                
            }
            echo json_encode($message);
        }
	}

    public function postSocialInfo(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $user_profile = UserProfile::where('user_id', $user->id)->first();
        $user_setting = Setting::where('user_id',$user->id)->first();

        if ($user) {
            $facebook = $request->input("facebook");
            $twitter = $request->input("twitter");
            $instagram = $request->input("instagram");

            $user_profile->ig_url = $instagram;
            $user_profile->update();
            if (empty($instagram)) {
                $user_setting->instagram_enable = '0';
            } else {
                $user_setting->instagram_enable = '1';
            }
            
            if (empty($facebook)) {
                $user_setting->custom_facebook_enable = '0';
            }
            else
            {
                $user_setting->custom_facebook_enable = '1';
            }

            if (empty($twitter)) {
                $user_setting->custom_twitter_enable = '0';
            }
            else
            {
                $user_setting->custom_twitter_enable = '1';
            }
            
            $user_setting->custom_twitter_link = 'https://twitter.com/'.$twitter;
            $user_setting->custom_facebook_link = 'https://facebook.com/'.$facebook;    
            $act = $user_setting->update();

            if ($act) {
                $message = "success";
            } else {
                $message = "error";
            }                
            //echo json_encode($message);
        }
    }

    public function postProfileInfo(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();

        if ($user) {
            $info = $request->input("info");
            if (empty($info)) {
                $message = "error";
                
            } else {
                $user_setting = Setting::where('user_id',$user->id)->first();
                date_default_timezone_set("Asia/Jakarta");
                $user_setting->info_profile = $info;
                $act = $user_setting->update();

                if ($act) {
                    $message = "success";
                } else {
                    $message = "error";
                }                
            }
            echo json_encode($message);
        }
    }

    
}





