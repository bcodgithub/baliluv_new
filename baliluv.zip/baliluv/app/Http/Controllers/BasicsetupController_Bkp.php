<?php

namespace Soulfy\Http\Controllers;

use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Soulfy\Http\Controllers\Controller;
use Soulfy\Http\helper\BaseimgHelper;
use Soulfy\Pages;
use Soulfy\Setting;
use Soulfy\TestPopup;
use Soulfy\Timeline;
use Soulfy\User;
use Soulfy\UserProfile;
use Soulfy\Followers;


class BasicsetupController extends Controller
{
	public function getIndex(Request $request)
	{
		return view('basicsetup');
	}
/* ========== Step 1 Basic Info ========== */
    public function postBasicInfo(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();

        if ($user) {
            $fullname = $request->input("fullname");
            $profile = $request->input("profile");
            $background = $request->input("background");
            
            if (empty($fullname)) {
                $message = "error";
            } else {
                $pfimg = BaseimgHelper::profileimg($profile);
                $bkimg = BaseimgHelper::profileimg($background);
                $user->full_name = $fullname;
                $user->image_profile = "/uploads/user/$pfimg";
                $user->background_image = "/uploads/user/$bkimg";
                $act = $user->update();
                if ($act) {
                    $message = "success";
                } else {
                    $message = "error";
                }                
            }
            echo json_encode($message);
        }
    }

/* ========== Step 2 Contact ========== */
	public function postConInfo(Request $request)
	{
		$domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();

        if ($user) {
            $phone = $request->input("phone");
            $email = $request->input("email");
            $address = $request->input("address");

            if (empty($phone)) {
                $message = "error";
            } else {
                $user->phone = $phone;
                $user->contact_email = $email;
                $user->address = $address;
                $act = $user->update();
                if ($act) {
                    $message = "success";
                } else {
                    $message = "error";
                }                
            }
            echo json_encode($message);
        }
	}

/* ========== Step 3 Social Media Info ========== */
    public function postSocialInfo(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $user_profile = UserProfile::where('user_id', $user->id)->first();
        $user_setting = Setting::where('user_id',$user->id)->first();
        
        if ($user) {
            $facebook = $request->input("facebook");
            $twitter = $request->input("twitter");
            $instagram = $request->input("instagram");
            $linkedin = $request->input("linkedin");

            $user_profile->ig_url = $instagram;
            $user_profile->update();

            if (empty($instagram)) {
                $user_setting->instagram_enable = '0';
            } else {
                $user_setting->instagram_enable = '1';
            }
            
            if (empty($facebook)) {
                $user_setting->custom_facebook_enable = '0';
            } else {
                $user_setting->custom_facebook_enable = '1';
            }

            if (empty($twitter)) {
                $user_setting->custom_twitter_enable = '0';
            } else {
                $user_setting->custom_twitter_enable = '1';
            }

            if (empty($linkedin)) {
                $user_setting->custom_linkedin_enable = '0';
            } else {
                $user_setting->custom_linkedin_enable = '1';
            }
            
            $user_setting->custom_linkedin_link = 'https://www.linkedin.com/'.$linkedin;
            $user_setting->custom_twitter_link = 'https://twitter.com/'.$twitter;
            $user_setting->custom_facebook_link = 'https://facebook.com/'.$facebook;    
            $act = $user_setting->update();

            if ($act) {
                $message = "success";
            } else {
                $message = "error";
            }                
            //echo json_encode($message);
        }
    }

/* ========== Step 4 Post your first Youtube Url ========== */
    public function postNavcolor(Request $request)
    {   
       $domain = $_SERVER['SERVER_NAME'];
       $user = User::where('domain', $domain)->first();

       $user_id = $user->id;

       $nav_color = $request->get('navcolor');

       $pages = Pages::where('user_id', $user->id)->get();

       DB::table('user_profile')->where('user_id', $user_id)
                                ->update(['nav_color' => $nav_color]);
    }

    public function postFollow(Request $request)
    {   
       $domain = $_SERVER['SERVER_NAME'];
       $user = User::where('domain', $domain)->first();
       $follow = $request->input('follow');
       $fol = new Followers;
       $fol->follower_id = $user->id;
       $fol->following_id = $follow;
       $fol->save();
    }

    public function postGallery(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();

        if ($user) {
                $gBasetext = $request->input("galleryImage");
                $gimg = BaseimgHelper::socialimg($gBasetext);
                $gallery = new Timeline();
                $gallery->social_id = $user->id;
                $gallery->user_id = $user->id;
                $gallery->social = "gallery";
                $gallery->content = "$gimg";
                $gallery->status = "1";
                $gallery->date = date("d M Y H:i:s");
                $gallery->save();
        }
    }

    public function postCustommenu(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $setting = Setting::where('user_id',$user->id)->first();

        $imageCustom1 = $request->input("imageCustom1");
        $imageCustom2 = $request->input("imageCustom2");
        $imageCustom3 = $request->input("imageCustom3");

        $custom_menu1_link = $request->input("custom_menu1_link");
        $custom_menu2_link = $request->input("custom_menu2_link");
        $custom_menu3_link = $request->input("custom_menu3_link");

        $menu1_logo = BaseimgHelper::socialimg($imageCustom1);
        $menu2_logo = BaseimgHelper::socialimg($imageCustom2);
        $menu3_logo = BaseimgHelper::socialimg($imageCustom3);

        $setting->custom_menu1_link = $custom_menu1_link;
        $setting->custom_menu2_link = $custom_menu2_link;
        $setting->custom_menu3_link = $custom_menu3_link;

        if (empty($custom_menu1_link)) {
            $setting->custom_menu1_enable = '0';
        } else {
            $setting->custom_menu1_enable = '1';  
        }
        
        if (empty($custom_menu2_link)) {
            $setting->custom_menu1_enable = '0';
        } else {
            $setting->custom_menu1_enable = '1';
        }

        if (empty($custom_menu3_link)) {
            $setting->custom_menu1_enable = '0';
        } else {
            $setting->custom_menu1_enable = '1'; 
        }
        $setting->custom_menu1_logo = $menu1_logo;
        $setting->custom_menu2_logo = $menu2_logo;
        $setting->custom_menu3_logo = $menu3_logo;
        $act = $setting->update();
        if ($act) {
        $message = "success";
        } else {
            $message = "error";
        }                
        echo json_encode($message);
    }


    

/* ========== Step 18 Info ========== */
    public function postProfileInfo(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        if ($user) {
            $info = $request->input("info");
            if (empty($info)) {
                $message = "error";
            } else {
                $user_setting = Setting::where('user_id',$user->id)->first();
                $user_setting->info_profile = $info;
                $act = $user_setting->update();

                if ($act) {
                    $message = "success";
                } else {
                    $message = "error";
                }                
            }
            echo json_encode($message);
        }
    }
}

