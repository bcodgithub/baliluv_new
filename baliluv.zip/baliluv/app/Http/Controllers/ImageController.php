<?php

namespace Soulfy\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Soulfy\Http\Requests;
use Soulfy\Http\Controllers\Controller;
use Soulfy\User;
use Soulfy\UserProfile;
use Soulfy\WhatsApp;
use Soulfy\ImageClick;
use Soulfy\Setting;
use Soulfy\Like;
use Soulfy\ReturningVisitor;
use Response;
use DateTime;
use DB;
use Soulfy\Category;


class ImageController extends Controller
{
    public function getCategoryLevel1(Request $request)
    {
        $level1_id = DB::table("category")
        ->where("parent_id",$request->parent_id)->select('id','name')->get();
        return response()->json($level1_id);
    }

    public function getCategoryLevel2(Request $request)
    {
        $level2_id = DB::table("category")
        ->where("parent_id",$request->parent_id)->select('id','name')->get();
        return response()->json($level2_id);
    }
    public function getCategoryLevel3(Request $request)
    {
        $level3_id = DB::table("category")
        ->where("parent_id",$request->parent_id)->select('id','name')->get();
        return response()->json($level3_id);
    }

	public function postWadetails(Request $request)
	{
		$domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        if ($user) 
        {

        	$countryCode = $request->input('countryCode');
        	$imageId = $request->Input('imageId');
            $imagePrice = $request->Input('imgPrice');
        	$wAusernameLower = $request->Input('waUsername');
            $wAusername = strtolower($wAusernameLower);
        	$number = $request->Input('waNumber');
            $waNumber = $countryCode.$number;

        	$existUsername = WhatsApp::where('user_id',$user->id)->where('username',$wAusername)->pluck('username');
            $existNumber = WhatsApp::where('user_id',$user->id)->Where('number',$waNumber)->pluck('number');
            $count = WhatsApp::where('user_id',$user->id)->count();
            $imgprice = ImageClick::where('user_id',$user->id)->orderBy('id', 'DESC')->first();

            //echo $existNumber."--------".$waNumber."----------".$existUsername."-----".$wAusername;

        	if ($countryCode =='' OR $wAusername =='' OR $number == '') {
        		$arrResponse = array('message' =>'error');
        	}
            elseif(($existUsername == $wAusername) && ($existNumber == $waNumber)) {
                $wa_data = WhatsApp::where('user_id',$user->id)->where('number',$existNumber)->where('username',$wAusername)->first();
                $imageClickData = ImageClick::where('user_id',$user->id)->where('whatsap_id',$wa_data->id)->where('image_id',$imageId)->first();
                if($wa_data)
                {
                    $rVisitor = new ReturningVisitor;
                    $rVisitor->user_id = $user->id;
                    $rVisitor->whatsap_id = $wa_data->id;
                    $rVisitor->save(); 
                }
                if($imageClickData)
                {
                    $arrResponse = array('message' => 'success');
                }
                else
                {
                    $imageClick = new ImageClick;
                    $imageClick->user_id = $user->id;
                    $imageClick->whatsap_id = $wa_data->id;
                    $imageClick->image_id = $imageId;
                    $imageClick->virtual_price = $imagePrice;
                    $act = $imageClick->save();
                    $arrResponse = array('message' => 'success');
                }
            }
            elseif (isset($existNumber) && ($existNumber == $waNumber)) {
                 $arrResponse = array('message' => 'nexist');

            }elseif (isset($existUsername) && $existUsername == $wAusername) {
                $arrResponse = array('message' => 'uexist'); 
            }
            
        	else {
        		$wa = new WhatsApp;
        		$wa->user_id = $user->id;
        		$wa->username = $wAusername;
        		$wa->number = $waNumber;
                $wa->virtual_count = $count+1;
        		$wa->save();

                if($wa->id) {
                    $imageClick = new ImageClick;
                    $imageClick->user_id = $user->id;
                    $imageClick->whatsap_id = $wa->id;
                    $imageClick->image_id = $imageId;
                    $imageClick->virtual_price = $imagePrice;
                    $act = $imageClick->save(); 
                }
                if ($act) {
                    $arrResponse = array('message' => 'add'); 
                } else {
                     $arrResponse = array('message' => 'error'); 
                }
        	}
        	echo json_encode($arrResponse);
        }   
	}

    public function waDetails()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $user_setting = Setting::where('user_id', $user->id)->first();
        $title = UserProfile::where('user_id', $user->id)->first();
        $waData = WhatsApp::where('user_id', $user->id)->get();

        return view('washop.washop',compact(['domain','user','title','waData','user_setting']));
    }

    public function postRvdata(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $rvId = $request->input('rvId');
        //$rvData = ReturningVisitor::where('user_id', $user->id)->where('whatsap_id',$rvId)->get();
        $rvData = \DB::table('returning_visitors')
                ->join('whatsapp', 'returning_visitors.whatsap_id', '=','whatsapp.id')
                ->select('whatsapp.username as username','whatsapp.number as number','returning_visitors.created_at as rvdate')->where('returning_visitors.user_id',$user->id)
                ->where('returning_visitors.whatsap_id',$rvId)
                ->get();
        return $rvData;
    }

    public function waShop()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $user_setting = Setting::where('user_id', $user->id)->first();
        $title = UserProfile::where('user_id', $user->id)->first();
        $byimgData = \DB::table('image_click')
                ->join('whatsapp', 'image_click.whatsap_id', '=','whatsapp.id')
                ->join('timeline', 'image_click.image_id', '=','timeline.id')
                ->select('image_click.created_at as imgDate','whatsapp.username as username','whatsapp.number as number','timeline.tittle as title','timeline.price as price')
                ->where('image_click.user_id',$user->id)->orderBy('image_click.id','DESC')->get();
        return view('washop.washopimg',compact(['domain','user','title','byimgData','user_setting']));
    }

    public function exportcsv()
    { 
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        
        $inventoryData = \DB::table('image_click')
                ->join('whatsapp', 'image_click.whatsap_id', '=','whatsapp.id')
                ->join('timeline', 'image_click.image_id', '=','timeline.id')
                ->select('image_click.created_at','whatsapp.username','whatsapp.number','timeline.tittle','timeline.price')
                ->where('image_click.user_id',$user->id)->orderBy('image_click.id','DESC')->get();

        $filename = $domain.'_whatsapp_'.date('d_m_Y').'.csv';
        $handle = fopen($filename, 'w+');
        fputcsv($handle, array('Date','Username','Number','Title','Price'));

        foreach($inventoryData as $row) {
            fputcsv($handle, array(date_format(new DateTime($row->created_at), 'd-m-Y') , $row->username, strval($row->number), $row->tittle, $row->price ) );
        }
        fclose($handle);
        $headers = array(
            'Content-Type' => 'text/csv',
        );
        return Response::download($filename, $filename, $headers);
    }

    public function exportlikedata()
    { 
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        
        $inventoryData = WhatsApp::where('user_id', $user->id)->get();

        $filename = $domain.'_likes_'.date('d_m_Y').'.csv';
        $handle = fopen($filename, 'w+');
        fputcsv($handle, array('Date','Username','Number','R.V.'));

        foreach($inventoryData as $row) {
            $countdata = \DB::table('returning_visitors')->where('user_id',$user->id)->where('whatsap_id',$row->id)->count(); 
            fputcsv($handle, array(date_format(new DateTime($row->created_at), 'd-m-Y') , $row->username, strval($row->number), $countdata) );
        }
        fclose($handle);
        $headers = array(
            'Content-Type' => 'text/csv',
        );
        return Response::download($filename, $filename, $headers);
    }

    public function postLikedetails(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        if ($user) 
        {
            $countryCode = $request->input('countryCode');
            $timelineId = $request->Input('timelineId');
            $socialType = $request->Input('socialType');
            $wAusernameLower = $request->Input('waUsername');
            $wAusername = strtolower($wAusernameLower);
            $number = $request->Input('waNumber');
            $waNumber = $countryCode.$number;

            $existUsername = WhatsApp::where('user_id',$user->id)->where('username',$wAusername)->pluck('username');
            $existNumber = WhatsApp::where('user_id',$user->id)->where('number',$waNumber)->pluck('number');
            $count = WhatsApp::where('user_id',$user->id)->count();

            //echo $existNumber."--------".$waNumber."----------".$existUsername."-----".$wAusername;

            if ($countryCode =='' OR $wAusername =='' OR $number == '') {
                $arrResponse = array('message' =>'error');
            }
            elseif(($existUsername == $wAusername) && ($existNumber == $waNumber)) {
                $wa_data = WhatsApp::where('user_id',$user->id)->where('number',$existNumber)->where('username',$wAusername)->first();
                $likeData = Like::where('user_id',$user->id)->where('whatsap_id',$wa_data->id)->where('timeline_id',$timelineId)->first();

                if($likeData) {
                    $rVisitor = new ReturningVisitor;
                    $rVisitor->user_id = $user->id;
                    $rVisitor->whatsap_id = $wa_data->id;
                    $rVisitor->save(); 
                    $arrResponse = array('message' => 'liked');
                }
                else {
                    $lick = new Like;
                    $lick->user_id = $user->id;
                    $lick->whatsap_id = $wa_data->id;
                    $lick->timeline_id = $timelineId;
                    $lick->save(); 
                    $arrResponse = array('message' => 'success');
                }                
            }
            elseif (isset($existNumber) && ($existNumber == $waNumber)) {
                 $arrResponse = array('message' => 'nexist');

            }elseif (isset($existUsername) && $existUsername == $wAusername) {
                $arrResponse = array('message' => 'uexist'); 
            }
            else
            {
                $wa = new WhatsApp;
                $wa->user_id = $user->id;
                $wa->username = $wAusername;
                $wa->number = $waNumber;
                $wa->virtual_count = $count+1;
                $wa->save();

                if($wa->id) {
                    $lick = new Like;
                    $lick->user_id = $user->id;
                    $lick->whatsap_id = $wa->id;
                    $lick->timeline_id = $timelineId;
                    $act = $lick->save();
                }
                if ($act) {
                    $arrResponse = array('message' => 'add'); 
                } else {
                     $arrResponse = array('message' => 'error'); 
                }
            }
            echo json_encode($arrResponse);
        }   
    }

    public function postGetlike(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $id = $request->input('id');
        $likeCount = 0;
        $likeCount = Like::where('user_id',$user->id)->where('timeline_id',$id)->count();
        return $likeCount;
    }


    
}