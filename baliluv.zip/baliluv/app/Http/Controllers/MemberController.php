<?php

namespace Soulfy\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Soulfyst\Gallery;
use Soulfy\Http\Requests;
use Soulfy\Http\Controllers\Controller;
use Soulfy\Setting;
use Soulfy\Timeline;
use Soulfy\UserMail;
use Soulfy\User;

class MemberController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        // $this->middleware('mail.auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */

    public function index()

    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */

    public function create()
    {
        //
    }

    /**

     * Store a newly created resource in storage.
     *
     * @param  Request $request
     * @return Response
     */

    public function store(Request $request)
    {
        //
    }


    /**

     * Display the specified resource.
     *
     * @param  int $id
     * @return Response
     */

    public function show($id)
    {
        //
    }
    /**

     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return Response

     */

    public function edit($id)

    {
        //
    }

    /**

     * Update the specified resource in storage.
     *
     * @param  Request $request
     * @param  int $id
     * @return Response
     */

    public function update(Request $request, $id)
    {
        //
    }

    /**

     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return Response
     */

    public function destroy($id)
    {

    }

    public function getEmail() 
    {
    	$domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain',$domain)->first();
        if(Auth::check()) {
        	require_once(base_path() . "/vendor/cpanel_api/xmlapi.php");
        $ip = env("SERVER_IP", "127.0.0.1"); //your server's IP
		$xmlapi = new \xmlapi($ip);

		$xmlapi->password_auth(env("CPANEL_USER", "root"),env("CPANEL_PASSWORD", "")); //the server login info for the user you want to create the emails under
	        $xmlapi->set_output('json');
	        $xmlapi->set_debug(1);
	        $acct = json_decode($xmlapi->listaccts('domain', $domain), true);
	        if($acct && isset($acct['acct']) && count($acct['acct']) == 1) {
	        	$U = $acct['acct'][0]['user'];
	        	$params = array('domain'=>$domain);
	        	$email_accounts = json_decode($xmlapi->api2_query($U, "Email", "listpopswithdisk", $params), true);
	        	//return view('soulfy.email-manager',['user'=>$user,'emails'=>$email_accounts['cpanelresult']['data']]);
	        	return view('soulfy.partial.email',['user'=>$user,'emails'=>$email_accounts['cpanelresult']['data']]);
	        }
	        else {
	        	//return redirect('/');
	        }
        }
        else {
        	//return redirect('/');
        }
    }

    /*
    public function getEmail()
    {
        $user = User::with('userMails')->findOrFail(Auth::user()->id);
        return view('soulfy.partial.email',compact('user'));
    }*/

    public function postLogin(Request $request)
    {
        $hostname = '{'.$_SERVER['SERVER_NAME'].':143/notls}INBOX';
        $username = $request->email;
        $password = $request->password;
        $inbox = @imap_open($hostname, $username, $password,null,1);// or die('Cannot connect to mail: ' . imap_last_error());
        if($inbox){

            /*

            $um = UserMail::where('user_id',Auth::user()->id)

                ->where('email_account',explode('@',$requeat->email)[0])->first();
            session([

                'userMail'=>['id'=>$um->id,'email'=>$um->email_account,'password'=>$password,'fname'=>$um->firstname,'lname'=>$um->lastname]

            ]);*/
            $email_username = explode("@", $request->email);
            $email_username = $email_username[0];
            session([
                'userMail'=>['email'=>$email_username,'password'=>$password,'fname'=>$email_username,'lname'=>$email_username]
            ]);
            return response()->json(['msg'=>'Success'],200);
        }
        else
            return response()->json(['msg'=>'Not Or Password Invalid'],400);

        /*        $um = UserMail::where('user_id',Auth::user()->id)->where('email_account',$request->email)->where('password',$request->password)->first();
        if($um){
            session([
                'userMail'=>['id'=>$um->id,'email'=>$um->email_account,'fname'=>$um->firstname,'lname'=>$um->lastname]
            ]);
            return response()->json(['msg'=>'Success'],200);
        }
        return response()->json(['msg'=>'Username Or Password Invalid'],400);*/
    }

    public function getCreateEmailSetting()
    {
        return view('soulfy.partial.create_email_setting');
    }

    public function getSetting()

    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        //$user = Auth::User();
        $setting = Setting::where('user_id',$user->id)->first();
        if($setting == null){
            $setting = new Setting();
            $setting->user_id =$user->id;
            $setting->save();
        }
        return view('soulfy.partial.setting',compact("user","setting"));
    }

    public function getCreateEmail()
    {
    }

    public function postUploadGallery(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $files = Input::file('imagesg');
        $file_count = $files ? count($files) : 0;
        $desc = Input::get('description');
        $id = Input::get('id');
        if ($file_count>0 OR $desc == '') 
        { 
            date_default_timezone_set("Asia/Jakarta");
            $domain = $_SERVER['SERVER_NAME'];
            $user = User::where('domain', $domain)->first();
            $uploadcount = 0;
            foreach ($files as $file) 
            {
                $rules = array(
                    'file' => 'required|between:1,3000',
                ); //'required|mimes:png,gif,jpeg,txt,pdf,doc'
                $validator = Validator::make(array('file' => $file), $rules);
                if ($validator->passes()) 
                {
                    $destinationPath = 'uploads';
                    $filename = $file->getClientOriginalName();
                    $ext = pathinfo($filename, PATHINFO_EXTENSION);
                    $filename = uniqid();
                    $upload_success = $file->move($destinationPath, $filename . ".$ext");
                    list($width, $height) = getimagesize($destinationPath . "/" . $filename . ".$ext");
                    if (empty($id)) {
                        $gallery = new Timeline();
                        $gallery->social_id = $user->id;
                        $gallery->user_id = $user->id;
                        $gallery->social = "gallery";
                        $gallery->content = "$filename.$ext";
                        $gallery->status = "1";
                        $gallery->description = $desc;
                        $gallery->date = date("d M Y H:i:s");
                        $gallery->save();
                    }
                    else {
                        $gallery = Timeline::where('id',$id)->first();
                        $gallery->social_id = $user->id;
                        $gallery->user_id = $user->id;
                        $gallery->social = "gallery";
                        $gallery->content = "$filename.$ext";
                        $gallery->status = "1";
                        $gallery->description = $desc;
                        $gallery->date = date("d M Y H:i:s");
                        $gallery->update();
                    }

                    $uploadcount++;
                    self::make_thumb($destinationPath."/$filename.$ext", $destinationPath."/$filename"."_thumb.$ext",150 );
                    //$img = Image::make($destinationPath ."/". $filename.".$ext")->resize($width*0.7, $height*0.7);
                    //$img->save($destinationPath ."/". $filename."_thumb.$ext");
                    //self::make_thumb($destinationPath . "/" . $filename . ".$ext", $destinationPath . "/" . $filename . "_thumb.$ext", $width * 0.7);
                }
                else
                {
                    $messages = $validator->errors();
                    Session::flash('error', $messages->first('file'));
                    return redirect('/')->with('message_', 'error');
                }
            }
            if ($uploadcount == $file_count) 
            {
                Session::flash('success', 'Upload successfully');
                return redirect('/')->with('message_', 'Upload successfully');
            }
        }
        elseif ($id != '') {
            $gallery = Timeline::where('id',$id)->first();
            $gallery->social_id = $user->id;
            $gallery->user_id = $user->id;
            $gallery->social = "gallery";
            $gallery->status = "1";
            $gallery->description = $desc;
            $gallery->date = date("d M Y H:i:s");
            $gallery->update();
            Session::flash('success', 'Upload successfully');
            return redirect('/home/gallery')->with('message_', 'Upload successfully');
        }
        Session::flash('error', 'Please choose the file');
        return redirect('/')->with('message_', 'error');
    }

    

    public function postUploadGalleryEcom()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $id = Input::get('id');
        $files = Input::file('images');
        $file_count = $files ? count($files) : 0;
        $price = Input::get('price');
        $title = Input::get('title');
        $desc = Input::get('description');
        if ($file_count>0) 
        {
            date_default_timezone_set("Asia/Jakarta");
            $domain = $_SERVER['SERVER_NAME'];
            $user = User::where('domain', $domain)->first();
            $uploadcount = 0;
            $i = 0;
            $parentId = 0;
            foreach ($files as $file) 
            {
                if($i == 0)
                {
                    $rules = array(
                        'file' => 'required|between:1,3000',
                    ); //'required|mimes:png,gif,jpeg,txt,pdf,doc'

                    $validator = Validator::make(array('file' => $file), $rules);
                    if ($validator->passes()) 
                    {
                        $destinationPath = 'uploads';
                        $filename = $file->getClientOriginalName();
                        $ext = pathinfo($filename, PATHINFO_EXTENSION);
                        $filename = uniqid();
                        $upload_success = $file->move($destinationPath, $filename . ".$ext");
                        list($width, $height) = getimagesize($destinationPath . "/" . $filename . ".$ext");
                        if (empty($id)) {
                            $gallery = new Timeline();
                            $gallery->social_id = $user->id;
                            $gallery->user_id = $user->id;
                            $gallery->social = "gallery";
                            $gallery->content = "$filename.$ext";
                            $gallery->status = "1";
                            $gallery->tittle = $title;
                            $gallery->price = $price;
                            $gallery->description = $desc;
                            $gallery->ecom = 1;
                            $gallery->date = date("d M Y H:i:s");
                            $gallery->save();
                            $parentId  = $gallery->id;                  
                        } else {
                            $gallery = Timeline::where('id',$id)->first();
                            $gallery->social_id = $user->id;
                            $gallery->user_id = $user->id;
                            $gallery->social = "gallery";
                            $gallery->content = "$filename.$ext";
                            $gallery->status = "1";
                            $gallery->tittle = $title;
                            $gallery->price = $price;
                            $gallery->description = $desc;
                            $gallery->ecom = 1;
                            $gallery->date = date("d M Y H:i:s");
                            $gallery->update();
                        }
                        
                        $uploadcount++;
                        self::make_thumb($destinationPath."/$filename.$ext", $destinationPath."/$filename"."_thumb.$ext",150 );

                        //$img = Image::make($destinationPath ."/". $filename.".$ext")->resize($width*0.7, $height*0.7);
                        //$img->save($destinationPath ."/". $filename."_thumb.$ext");
                        //self::make_thumb($destinationPath . "/" . $filename . ".$ext", $destinationPath . "/" . $filename . "_thumb.$ext", $width * 0.7);
                    }

                    else
                    {
                        $messages = $validator->errors();
                        Session::flash('error', $messages->first('file'));
                        return redirect('/home/gallery')->with('message_', 'error');
                    }
                }
                else
                {
                    $rules = array(
                        'file' => 'required|between:1,3000',
                    ); //'required|mimes:png,gif,jpeg,txt,pdf,doc'

                    $validator = Validator::make(array('file' => $file), $rules);
                    if ($validator->passes()) 
                    {
                        $destinationPath = 'uploads';
                        $filename = $file->getClientOriginalName();
                        $ext = pathinfo($filename, PATHINFO_EXTENSION);
                        $filename = uniqid();
                        $upload_success = $file->move($destinationPath, $filename . ".$ext");
                        list($width, $height) = getimagesize($destinationPath . "/" . $filename . ".$ext");
                        if (empty($id)) {
                            $gallery = new Timeline();
                            $gallery->social_id = $user->id;
                            $gallery->user_id = $user->id;
                            $gallery->social = "gallery";
                            $gallery->content = "$filename.$ext";
                            $gallery->status = "1";
                            $gallery->tittle = $title;
                            $gallery->price = $price;
                            $gallery->description = $desc;
                            $gallery->ecom = 1;
                            $gallery->parent_id = $parentId;
                            $gallery->date = date("d M Y H:i:s");
                            $gallery->save();

                        } else {
                            $gallery = Timeline::where('id',$id)->first();
                            $gallery->social_id = $user->id;
                            $gallery->user_id = $user->id;
                            $gallery->social = "gallery";
                            $gallery->content = "$filename.$ext";
                            $gallery->status = "1";
                            $gallery->tittle = $title;
                            $gallery->price = $price;
                            $gallery->description = $desc;
                            $gallery->ecom = 1;
                            $gallery->date = date("d M Y H:i:s");
                            $gallery->update();
                        }
                        
                        $uploadcount++;
                        self::make_thumb($destinationPath."/$filename.$ext", $destinationPath."/$filename"."_thumb.$ext",150 );

                        //$img = Image::make($destinationPath ."/". $filename.".$ext")->resize($width*0.7, $height*0.7);
                        //$img->save($destinationPath ."/". $filename."_thumb.$ext");
                        //self::make_thumb($destinationPath . "/" . $filename . ".$ext", $destinationPath . "/" . $filename . "_thumb.$ext", $width * 0.7);
                    }

                    else
                    {
                        $messages = $validator->errors();
                        Session::flash('error', $messages->first('file'));
                        return redirect('/home/gallery')->with('message_', 'error');
                    }
                }
                $i++;
            }
            if ($uploadcount == $file_count) 
            {
                Session::flash('success', 'Upload successfully');
                return redirect('/home/gallery')->with('message_', 'Upload successfully');
            }
        }
        $gallery = Timeline::where('id',$id)->first();
        $gallery->social_id = $user->id;
        $gallery->user_id = $user->id;
        $gallery->social = "gallery";
        $gallery->status = "1";
        $gallery->tittle = $title;
        $gallery->price = $price;
        $gallery->description = $desc;
        $gallery->ecom = 1;
        $gallery->date = date("d M Y H:i:s");
        $gallery->update();
        Session::flash('success', 'Upload successfully');
        return redirect('/home/gallery')->with('message_', 'Upload successfully');
    }

    //Make Thumbnail
    function make_thumb($src, $dest, $desired_width)
    {
        /* read the source image */
        $info = getimagesize($src);

        if ($info['mime'] == 'image/jpeg') $source_image = imagecreatefromjpeg($src);
        elseif ($info['mime'] == 'image/gif') $source_image = imagecreatefromgif($src);
        elseif ($info['mime'] == 'image/png') $source_image = imagecreatefrompng($src);

        $width = imagesx($source_image);
        $height = imagesy($source_image);

        /* find the "desired height" of this thumbnail, relative to the desired width  */
        $desired_height = floor($height * ($desired_width / $width));

        /* create a new, "virtual" image */
        $virtual_image = imagecreatetruecolor($desired_width, $desired_height);

        /* copy source image at a resized size */
        imagecopyresampled($virtual_image, $source_image, 0, 0, 0, 0, $desired_width, $desired_height, $width, $height);

        /* create the physical thumbnail image to its destination */
        imagejpeg($virtual_image, $dest,150);
    }

}