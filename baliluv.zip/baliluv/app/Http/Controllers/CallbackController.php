<?php

namespace Soulfy\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Soulfy\Http\Requests;
use Soulfy\Http\Controllers\Controller;
use Soulfy\TwitterProfile;
use Thujohn\Twitter\Facades\Twitter;

class CallbackController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }

    public function twitter_login(){
        // your SIGN IN WITH TWITTER  button should point to this route
        $sign_in_twitter = true;
        $force_login = false;

        Session::put('domain',$_GET['domain']);

        // Make sure we make this request w/o tokens, overwrite the default values in case of login.
        Twitter::reconfig(['token' => '', 'secret' => '']);
        $token = Twitter::getRequestToken('http://callback.soulfy.com/twitter/callback');

        if (isset($token['oauth_token_secret']))
        {
            $url = Twitter::getAuthorizeURL($token, $sign_in_twitter, $force_login);

            Session::put('oauth_state', 'start');
            Session::put('oauth_request_token', $token['oauth_token']);
            Session::put('oauth_request_token_secret', $token['oauth_token_secret']);

            return Redirect::to($url);
        }

        return Redirect::route('twitter.error');
    }

    public function twitter_callback(){
        // You should set this route on your Twitter Application settings as the callback
        // https://apps.twitter.com/app/YOUR-APP-ID/settings
        if (Session::has('oauth_request_token'))
        {
            $request_token = [
                'token'  => Session::get('oauth_request_token'),
                'secret' => Session::get('oauth_request_token_secret'),
            ];

            Twitter::reconfig($request_token);

            $oauth_verifier = false;

            if (Input::has('oauth_verifier'))
            {
                $oauth_verifier = Input::get('oauth_verifier');
            }

            // getAccessToken() will reset the token for you
            $token = Twitter::getAccessToken($oauth_verifier);

            if (!isset($token['oauth_token_secret']))
            {
                return Redirect::route('twitter.login')->with('flash_error', 'We could not log you in on Twitter.');
            }

            $credentials = Twitter::getCredentials();

            if (is_object($credentials) && !isset($credentials->error))
            {
                // $credentials contains the Twitter user object with all the info about the user.
                // Add here your own user logic, store profiles, create new users on your tables...you name it!
                // Typically you'll want to store at least, user id, name and access tokens
                // if you want to be able to call the API on behalf of your users.

                // This is also the moment to log in your users if you're using Laravel's Auth class
                // Auth::login($user) should do the trick.

                Session::put('access_token', $token);

                //var_dump($credentials);


                $domain = Session::get('domain');
                $user = \Soulfy\User::where('domain',$domain)->first();
                $user_token = \Soulfy\UserToken::where('user_id',$user->id)->first();
                $user_token->twitter_token = (string) $token['oauth_token'];
                $user_token->twitter_token_secret = (string) $token['oauth_token_secret'];
                $user_token->save();

                $profile = TwitterProfile::where('user_id',$user->id)->first();

                if($profile == null){
                    $profile = new TwitterProfile();

                }

                $profile->twitter_id = $credentials->id;
                $profile->user_id = $user->id;
                $profile->name = $credentials->name;
                $profile->screen_name = $credentials->screen_name;
                $profile->location = $credentials->location;
                $profile->description = $credentials->description;
                $profile->profile_image = str_replace("normal","400x400",$credentials->profile_image_url);
                $profile->background_image = $credentials->profile_background_image_url;
                $profile->url = $credentials->url;
                $profile->save();
                //exit;

                return Redirect::to("http://".$domain)->with('flash_notice', 'Congrats! You\'ve successfully signed in!');
            }

            return Redirect::route('twitter.error')->with('flash_error', 'Crab! Something went wrong while signing you up!');
        }
    }

    public function google_login(\Illuminate\Http\Request $request){
        $code = $request->get('code');
        // get google service
        $googleService = \OAuth::consumer('Google');

        // check if code is valid

        // if code is provided get user data and sign in
        if ( ! is_null($code))
        {
            // This was a callback request from google, get the token
            $token = $googleService->requestAccessToken($code);

            Session::put('google_token', $token->getAccessToken());

            //var_dump(Session::get('google_token'));

            $domain = Session::get('domain');
            $user = \Soulfy\User::where('domain',$domain)->first();
            $user_token = \Soulfy\UserToken::where('user_id',$user->id)->first();
            $user_token->google_token = (string) Session::get('google_token');
            $user_token->save();

            // Send a request with it
            $result = json_decode($googleService->request('https://www.googleapis.com/oauth2/v1/userinfo'), true);

            $message = 'Your unique Google user id is: ' . $result['id'] . ' and your name is ' . $result['name'];
           // echo $message. "<br/>";

            //Var_dump
            //display whole array.
           // dd($result);
           return redirect((string)"http://".$domain);
        }
        // if not ask for permission first
        else
        {
            Session::put('domain',$_GET['domain']);
            // get googleService authorization
            $url = $googleService->getAuthorizationUri();

            // return to google login url
            return redirect((string)$url);
        }
    }


}
