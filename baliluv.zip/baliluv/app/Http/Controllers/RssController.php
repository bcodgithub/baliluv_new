<?php

namespace Soulfy\Http\Controllers;

use Input;
use Soulfy\User;
use Soulfy\Timeline;
use Soulfy\RssConfig;
use Illuminate\Http\Request;
use Soulfy\Http\Controllers\Controller;

class RssController extends Controller
{
    public function rssIndex()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $rss = RssConfig::where('user_id',$user->id)->get();
    	return view('soulfy.rss',compact(['rss']));
    }

    public function rssFeed()
    {
    	$domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $rssfeeds = RssConfig::where('user_id', $user->id)->get();
        return view('soulfy.rssfeed', ['rssfeeds' => $rssfeeds]);
    }

    public function postCreateRssFeed(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        if ($user) {
            $tittle = $request->input("tittle");

            $url = $request->input("url");
            $blah = parse_url($url);
            $str=  $blah['path'];
            $subject = $str;
            $search = '/embed' ;
            $trimmed = str_replace($search, '', $subject) ;

            $title_ddl = $request->input("title_ddl");
            $desc_ddl = $request->input("desc_ddl");
            if (empty($tittle) || empty($url)) {
                $message = "error";
            } else {
                date_default_timezone_set("Asia/Jakarta");
                $rss = new RssConfig;
                $rss->user_id = $user['id'];
                $rss->tittle = $tittle;
                $rss->rss_title = $title_ddl;
                $rss->rss_link = $desc_ddl;
                $rss->rss_url = 'https://open.spotify.com/embed'.$trimmed;
                $rss->status = "1";
                $act = $rss->save();
                if ($act) {
                    $message = "success";
                } else {
                    $message = "error";
                }                
            }
            echo json_encode($message);
        }
    }

    public function postUpdateRssFeed(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        if ($user) {
            $domain = $_SERVER['SERVER_NAME'];
            $user = User::where('domain', $domain)->first();
            $id = $request->input("id");
            $tittle = $request->input("tittle");
            $url = $request->input("url");
            $blah = parse_url($url);
            $str=  $blah['path'];
            $subject = $str;
            $search = '/embed' ;
            $trimmed = str_replace($search, '', $subject) ;

            $title_ddl = $request->input("title_ddl");
            $desc_ddl = $request->input("desc_ddl");
            date_default_timezone_set("Asia/Jakarta");
            $rss = RssConfig::where('user_id', $user->id)->where('id', $id)->first();
            $rss->tittle = $tittle;
            $rss->rss_title = $title_ddl;
            $rss->rss_link = $desc_ddl;
            $rss->rss_url = 'https://open.spotify.com/embed'.$trimmed;
            $rss->updated_at = date("Y-m-d H:i:s");
            $act = $rss->save();
            if ($act) {
                $message = "success";
            } else {
                $message = "error";
            } 
            echo json_encode($message);   
        }
    }

    public function postDeleteRssFeed(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $id = $request->input("id");
        $data = RssConfig::find($id);
        $act = $data->delete();
        if ($act) {
            $message = "success";
        } else {
            $message = "error";
        }
        echo json_encode($message);
    }

    public function postXmlnode(Request $request)
    {
        $feed_url = $request->reqURL;
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $feed_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return  $err;
        } else {
            return $response;
        } 
    }
}
