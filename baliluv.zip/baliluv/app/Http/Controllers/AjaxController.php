<?php

namespace Soulfy\Http\Controllers;

use DB;
use File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Soulfy\Article;
use Soulfy\Http\Controllers\Controller;
use Soulfy\Http\Requests;
use Soulfy\Followers;
use Soulfy\Gallery;
use Soulfy\Meta;
use Soulfy\RssConfig;
use Soulfy\Setting;
use Soulfy\Timeline;
use Soulfy\User;
use Soulfy\UserMail;
use Soulfy\UserProfile;
use Soulfy\Youtube;
use Storage;

class AjaxController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request $request
     * @param  int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }
    
    public function getIslogin(Request $request) {
        if (Auth::User()) {
            die('1');
        }
        
        die('0');
    }

    public function postForgotPassword()
    {
        // khusus untuk password pake id selectnya
        $email = $_POST['email'];
        $domain = $_SERVER['SERVER_NAME'];
        //$user = User::where('id', Auth::user()->id)->where('email', $email)->first();
        $user = User::where('domain', $domain)->where('email', $email)->first();

        if ($user) {
        	$new_pwd = rand(100000, 999999);

            $password = Hash::make($new_pwd);

            $user->password = $password;

            $user->save();

            ## Send Email

            $to = $email;

            $subject = "New Password Requested {$domain}";

            $headers = "MIME-Version: 1.0" . "\r\n";

            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";



            $message = "Hi {$user->full_name}<br><br>A new Password is generated for your website www.{$domain}.<br><br><b>{$new_pwd}</b><br><br>If you didn't request a new password, Please login with the new password and change your login Email Address and password. you may also conatct us at admin@soulfy.com";

            mail($to, $subject, $message, $headers);



            return response()->json(

                array(

                    'status' => "success",

                    'message' => "Email sent! If the email address you entered is registered with this account, you'll receive an email within 5 minutes with a new password, Please check your inbox or spam folder.",

                    'token' => csrf_token()

                ), 200

            );

        }else{

            return response()->json(

                array(

                    'status' => "error",

                    'message' => "User is not found, please check your email",

                    'token' => csrf_token()

                ), 200

            );

        }

    }



    public function postUploadProfile()

    {



        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();

        

        if ($user) {

            $data = $_POST['data'];



            list($type, $data) = explode(';', $data);

            list(, $data) = explode(',', $data);

            $data = base64_decode($data);



            $id = uniqid();

            file_put_contents("uploads/user/$id.png", $data);



            $user->background_image = "/uploads/user/$id.png";

            $user->save();



            return response()->json(

                array(

                    'status' => "success",

                    'url' => "/uploads/user/$id.png",

                    'filename' => "$id.png",

                    'token' => csrf_token()

                ), 200

            );

        }

    }



    public function postUploadimage()

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        

        if ($user) {

            $imagePath = "uploads/";

            @mkdir($imagePath);

            $imagePath = "uploads/user/";

            @mkdir($imagePath);



            $allowedExts = array("gif", "jpeg", "jpg", "png", "GIF", "JPEG", "JPG", "PNG");

            $temp = explode(".", $_FILES["img"]["name"]);

            $extension = end($temp);



            //Check write Access to Directory



            if (!is_writable($imagePath)) {

                $response = Array(

                    "status" => 'error',

                    "message" => 'Can`t upload File; no write Access'

                );

                print json_encode($response);

                return;

            }



            if (in_array($extension, $allowedExts)) {

                if ($_FILES["img"]["error"] > 0) {

                    $response = array(

                        "status" => 'error',

                        "message" => 'ERROR Return Code: ' . $_FILES["img"]["error"],

                    );

                } else {



                    $filename = $_FILES["img"]["tmp_name"];

                    list($width, $height) = getimagesize($filename);



                    move_uploaded_file($filename, $imagePath . $_FILES["img"]["name"]);





                    $response = array(

                        "status" => 'success',

                        "url" => url('.') . '/' . $imagePath . $_FILES["img"]["name"],

                        "width" => $width,

                        "height" => $height

                    );



                }

            } else {

                $response = array(

                    "status" => 'error',

                    "message" => 'something went wrong, most likely file is to large for upload. check upload_max_filesize, post_max_size and memory_limit in you php.ini',

                );

            }



            print json_encode($response);

        }

    }



    public function postCropimage()

    {



        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if ($user) {



            $imgUrl = str_replace(" ", "%20", $_POST['imgUrl']);



            // original sizes

            $imgInitW = $_POST['imgInitW'];

            $imgInitH = $_POST['imgInitH'];

            // resized sizes

            $imgW = $_POST['imgW'];

            $imgH = $_POST['imgH'];

            // offsets

            $imgY1 = $_POST['imgY1'];

            $imgX1 = $_POST['imgX1'];

            // crop box

            $cropW = $_POST['cropW'];

            $cropH = $_POST['cropH'];

            // rotation angle

            $angle = $_POST['rotation'];



            $jpeg_quality = 100;



            $output_filename = "uploads/user/Img_" . rand();



            // uncomment line below to save the cropped image in the same location as the original image.

            //$output_filename = dirname($imgUrl). "/croppedImg_".rand();



            $what = getimagesize($imgUrl);



            switch (strtolower($what['mime'])) {

                case 'image/png':

                    $img_r = imagecreatefrompng($imgUrl);

                    $source_image = imagecreatefrompng($imgUrl);

                    $type = '.png';

                    break;

                case 'image/jpeg':

                    $img_r = imagecreatefromjpeg($imgUrl);

                    $source_image = imagecreatefromjpeg($imgUrl);

                    error_log("jpg");

                    $type = '.jpeg';

                    break;

                case 'image/gif':

                    $img_r = imagecreatefromgif($imgUrl);

                    $source_image = imagecreatefromgif($imgUrl);

                    $type = '.gif';

                    break;

                default:

                    die('image type not supported');

            }



            //Check write Access to Directory



            if (!is_writable(dirname($output_filename))) {

                $response = Array(

                    "status" => 'error',

                    "message" => 'Can`t write cropped File'

                );

            } else {



                // resize the original image to size of editor

                $resizedImage = imagecreatetruecolor($imgW, $imgH);

                imagecopyresampled($resizedImage, $source_image, 0, 0, 0, 0, $imgW, $imgH, $imgInitW, $imgInitH);

                // rotate the rezized image

                $rotated_image = imagerotate($resizedImage, -$angle, 0);

                // find new width & height of rotated image

                $rotated_width = imagesx($rotated_image);

                $rotated_height = imagesy($rotated_image);

                // diff between rotated & original sizes

                $dx = $rotated_width - $imgW;

                $dy = $rotated_height - $imgH;

                // crop rotated image to fit into original rezized rectangle

                $cropped_rotated_image = imagecreatetruecolor($imgW, $imgH);

                imagecolortransparent($cropped_rotated_image, imagecolorallocate($cropped_rotated_image, 0, 0, 0));

                imagecopyresampled($cropped_rotated_image, $rotated_image, 0, 0, $dx / 2, $dy / 2, $imgW, $imgH, $imgW, $imgH);

                // crop image into selected area

                $final_image = imagecreatetruecolor($cropW, $cropH);

                imagecolortransparent($final_image, imagecolorallocate($final_image, 0, 0, 0));

                imagecopyresampled($final_image, $cropped_rotated_image, 0, 0, $imgX1, $imgY1, $cropW, $cropH, $cropW, $cropH);

                // finally output png image

                //imagepng($final_image, $output_filename.$type, $png_quality);

                imagejpeg($final_image, $output_filename . $type, $jpeg_quality);



                $user->image_profile = $output_filename . $type;

                $user->save();



                $response = Array(

                    "status" => 'success',

                    "url" => url('.') . '/' . $output_filename . $type

                );

            }

            print json_encode($response);

        }

    }



    public function postUpdateskype(Request $request)

    {



        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if ($user) {



            $user_setting = Setting::where('user_id', $user->id)->first();

            $user_setting->skype_id = $request->input("skype");

            $user_setting->save();



            return response()->json(

                array(

                    'status' => "success",

                    'token' => csrf_token()

                ), 200

            );

        }

    }



    public function postUpdateprofileInfo(Request $request)

    {



        $domain = $_SERVER['SERVER_NAME'];

       	$user = User::where('domain', $domain)->first();



        if ($user) {

            $user_setting = Setting::where('user_id', $user->id)->first();

            $user_setting->info_profile = $request->input("profile_info");

            $act = $user_setting->save();

            if (!$act) {

                $message = "error";

            } else {



                $message = \Soulfy\Timeline::split_words($request->input("profile_info"), 2000, "...");

            }



            return response()->json($message);

        }

    }



    public function postTimeline(Request $request)

    {



        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        $type = $request->input("type");

        date_default_timezone_set("Asia/Jakarta");



         Log::info("nama type: $type");



        if ($type == "fb") {

            $home = new HomeController();

            $home->getFacebook($request);

        } else if ($type == "twitter") {

            $api = new ApiController();

            $api->getTwitter($request);



            Log::info("sukses masuk sini");

            

        } else if ($type == "google") {

            $api = new ApiController();

            $api->getGoogle($request);

        }



        if ($type == "article") {

            $timeline = Timeline::where('user_id', $user['id'])->where('social', 'article')->where('status', '1')->take(8)->orderBy('id', 'desc')->get();

            $data_check = Timeline::where('user_id', $user['id'])->where('social', 'article')->where('status', '1')->get();

        } else {

            $timeline = Timeline::where('user_id', $user['id'])->where('social', $type)->take(8)->orderBy('id', 'desc')->get();

            $data_check = Timeline::where('user_id', $user['id'])->where('social', $type)->get();

        }



        $data_array = array();

        foreach ($timeline as $data) {

            array_push($data_array, array(

                'id' => $data->id,

                'social_type' => $data->social,

                'social' => $data->social,

                'tittle' => htmlspecialchars($data->tittle),

                'data_count' => count($data_check),

                'data_content' => htmlspecialchars($data->content),

                'content' => \Soulfy\Timeline::split_words(strip_tags($data->content), 75, "..."),

                'date' => date("d M Y", strtotime($data->updated_at))

            ));

        }



        return response()->json(

            $data_array, 200

        );

    }



    public function postUploadImageProfile()

    {

       $domain = $_SERVER['SERVER_NAME'];

       $user = User::where('domain', $domain)->first();



        if ($user) {

            $imagePath = "uploads/";

            @mkdir($imagePath);

            $imagePath = "uploads/user/";

            @mkdir($imagePath);



            $allowedExts = array("gif", "jpeg", "jpg", "png", "GIF", "JPEG", "JPG", "PNG");

            $temp = explode(".", $_FILES["img"]["name"]);

            $extension = end($temp);



            //Check write Access to Directory



            if (!is_writable($imagePath)) {

                $response = Array(

                    "status" => 'error',

                    "message" => 'Can`t upload File; no write Access'

                );

                print json_encode($response);

                return;

            }



            if (in_array($extension, $allowedExts)) {

                if ($_FILES["img"]["error"] > 0) {

                    $response = array(

                        "status" => 'error',

                        "message" => 'ERROR Return Code: ' . $_FILES["img"]["error"],

                    );

                } else {



                    $filename = $_FILES["img"]["tmp_name"];

                    list($width, $height) = getimagesize($filename);

                    $new_file_name = "imgM_" . rand() . "." . $extension;

                    move_uploaded_file($filename, $imagePath . $new_file_name);



                    $user->image_profile = $imagePath . $new_file_name;

                    $user->save();



                    $response = array(

                        'message' => 'Upload image profile is successfully',

                        "status" => 'success',

                        "url" => url('.') . '/' . $imagePath . $new_file_name,

                        "width" => $width,

                        "height" => $height

                    );



                }

            } else {

                $response = array(

                    "status" => 'error',

                    "message" => 'something went wrong, most likely file is to large for upload. check upload_max_filesize, post_max_size and memory_limit in you php.ini',

                );

            }



            print json_encode($response);

        }

    }



    public function postUploadImageBackground()

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if ($user) {

            $imagePath = "uploads/";

            @mkdir($imagePath);

            $imagePath = "uploads/user/";

            @mkdir($imagePath);



            $allowedExts = array("gif", "jpeg", "jpg", "png", "GIF", "JPEG", "JPG", "PNG");

            $temp = explode(".", $_FILES["img"]["name"]);

            $extension = end($temp);



            //Check write Access to Directory



            if (!is_writable($imagePath)) {

                $response = Array(

                    "status" => 'error',

                    "message" => 'Can`t upload File; no write Access'

                );

                print json_encode($response);

                return;

            }



            if (in_array($extension, $allowedExts)) {

                if ($_FILES["img"]["error"] > 0) {

                    $response = array(

                        "status" => 'error',

                        "message" => 'ERROR Return Code: ' . $_FILES["img"]["error"],

                    );

                } else {



                    $filename = $_FILES["img"]["tmp_name"];

                    list($width, $height) = getimagesize($filename);

                    $new_file_name = "imgM_" . rand() . "." . $extension;

                    move_uploaded_file($filename, $imagePath . $new_file_name);



                    $user->background_image = $imagePath . $new_file_name;

                    $user->save();



                    $response = array(

                        'message' => 'Upload image profile is successfully',

                        "status" => 'success',

                        "url" => url('.') . '/' . $imagePath . $new_file_name,

                        "width" => $width,

                        "height" => $height

                    );



                }

            } else {

                $response = array(

                    "status" => 'error',

                    "message" => 'something went wrong, most likely file is to large for upload. check upload_max_filesize, post_max_size and memory_limit in you php.ini',

                );

            }



            print json_encode($response);

        }

    }



    public function postGettimeline(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        $social = $request->input("social_tipe");

        $offset = $request->input("offset");



        if ($social == "public") {

            $timeline = Timeline::skip($offset)->take(8)->where('user_id', $user['id'])->orderBy('created_at', 'desc')->get();

            $check = Timeline::where('user_id', $user['id'])->get();

            $data_array = array();

            foreach ($timeline as $data) {

                array_push($data_array, array(

                    'id' => $data->id,

                    'social_type' => $data->social,

                    'social' => $data->social,

                    'location' => $data->location,

                    'data_content' => htmlspecialchars($data->content),

                    'content' => \Soulfy\Timeline::split_words(strip_tags($data->content), 75, "..."),

                    'date' => date("d M Y", strtotime($data->date))

                ));

            }

        } elseif ($social == "gallery") {

            $timeline = Gallery::skip($offset)->take(8)->where('user_id', $user['id'])->orderBy('created_at', 'desc')->get();

            $check = Gallery::where('user_id', $user['id'])->get();

            var_dump($timeline);

            $data_array = array();

            foreach ($timeline as $data) {

                array_push($data_array, array(

                    'id' => $data->id,

                    'social_type' => "gallery",

                    'social' => "gallery",

                    'data_content' => "$data->photo_id'_thumb'$data->extension",

                    'content' => "$data->photo_id'_thumb'$data->extension",

                    'date' => date("d M Y", strtotime($data->created_at))

                ));

            }

        } elseif ($social == "article") {

            $timeline = Article::skip($offset)->take(8)->where('user_id', $user['id'])->orderBy('created_at', 'desc')->where('status', '1')->get();

            $check = Article::where('user_id', $user['id'])->where('status', '1')->get();

            $data_array = array();

            foreach ($timeline as $data) {

                array_push($data_array, array(

                    'id' => $data->id,

                    'tittle' => $data->tittle,

                    'social_type' => 'article',

                    'social' => 'article',

                    'data_content' => htmlspecialchars($data->content),

                    'content' => \Soulfy\Article::split_words(strip_tags($data->content), 75, "..."),

                    'date' => date("d M Y", strtotime($data->created_at))

                ));

            }

        } else {

            $timeline = Timeline::skip($offset)->take(8)->where('user_id', $user['id'])->orderBy('created_at', 'desc')->where('social', $social)->get();

            $check = Timeline::where('user_id', $user['id'])->where('social', $social)->get();

            $data_array = array();

            foreach ($timeline as $data) {

                array_push($data_array, array(

                    'id' => $data->id,

                    'social_type' => $data->social,

                    'social' => $data->social,

                    'location' => $data->location,

                    'data_content' => htmlspecialchars($data->content),

                    'content' => \Soulfy\Timeline::split_words(strip_tags($data->content), 75, "..."),

                    'date' => date("d M Y", strtotime($data->created_at))

                ));

            }

        }



        $data_check = count($check);



        if ($data_check > $offset) {

            return response()->json(

                $data_array, 200

            );

        } else {

            echo json_encode("error");

        }

    }



    public function postArticle(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if ($user) {

            $domain = $_SERVER['SERVER_NAME'];

            $user = User::where('domain', $domain)->first();

            date_default_timezone_set("Asia/Jakarta");

            $id = $request->input("id");



            $article = Article::where('user_id', $user['id'])->orderBy('id', 'desc')->take(8)->get();

            $data_array = array();

            foreach ($article as $data) {

                array_push($data_array, array(

                    'id' => $data->id,

                    'tittle' => $data->tittle,

                    'social_type' => 'article',

                    'social' => 'article',

                    'data_content' => $data->content,

                    'content' => \Soulfy\Article::split_words($data->content, 20, "..."),

                    'date' => date("d M Y", strtotime($data->created_at))

                ));

            }



            return response()->json(

                $data_array, 200

            );

        }

    }



    public function postCreateArticle(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if ($user) {

            $domain = $_SERVER['SERVER_NAME'];

            $user = User::where('domain', $domain)->first();



            $tittle = $request->input("tittle");

            $content = $request->input("content");

            

            if (empty($tittle) || empty($content)) {

                $message = "error";

                

            } else {

            	

                date_default_timezone_set("Asia/Jakarta");



                $article = new Timeline;

                $article->user_id = $user['id'];

                $article->social_id = $user['id'];

                $article->tittle = $tittle;

                $article->content = $content;

                $article->status = "0";

                $article->updated_at = ("0000-00-00 00:00:00");

                $article->social = "article";

                $act = $article->save();



                if ($act) {

                    $message = "success";

                } else {

                    $message = "error";

                }                

            }

            echo json_encode($message);

        }

    }



    public function postArticlePublish(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if ($user) {

            $domain = $_SERVER['SERVER_NAME'];

            $user = User::where('domain', $domain)->first();



            $id = $request->input("id");

            $status = $request->input("status");

            date_default_timezone_set("Asia/Jakarta");

            $article = Timeline::where('user_id', $user['id'])->where('id', $id)->first();

            $article->status = $status;

            $article->updated_at = date("Y-m-d H:i:s");





            $act = $article->save();

            if ($act) {

                $message = "success";

            } else {

                $message = "error";

            }

            echo json_encode($message);

        }

    }



    public function postUpdateArticle(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if ($user) {

            $domain = $_SERVER['SERVER_NAME'];

            $user = User::where('domain', $domain)->first();



            $id = $request->input("id");



            $tittle = $request->input("tittle");

            $content = $request->input("content");



            date_default_timezone_set("Asia/Jakarta");

          

           if($request->file('file_edit'))

        		$path = $request->file('file_edit')->move(public_path('uploads'), $request->file('file_edit')->getClientOriginalName());

       // var_dump( public_path('images'));

        //. exit;



            $article = Timeline::where('user_id', $user->id)->where('id', $id)->first();



            $article->tittle = $tittle;

            if($request->file('file_edit'))

            	$article->attachment = $request->file('file_edit')->getClientOriginalName();

            $article->content = $content;

            $article->updated_at = date("Y-m-d H:i:s");



            $act = $article->save();

            if ($act) {

                $message = "success, attachment uploaded at " . 'http://localhost/framework_freshway/public_html/uploads/' . $article->attachment;

                echo $message;

            } else {

                $message = "error";

                echo json_encode($message);

            }    

        }

    }

	

	public function postUpdateSeo(Request $request)

    {	

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        $user_id = $user->id;

       

        if ($user) {

            $domain = $_SERVER['SERVER_NAME'];

            $user = User::where('domain', $domain)->first();



           	$meta_title = $request->input("meta_title");

            $meta_keyword = $request->input("meta_keyword");

            $meta_description = $request->input("meta_description");

            date_default_timezone_set("Asia/Jakarta");

            //$meta = User_profile::where('user_id', $user_id)->first();

            //$meta->meta_title = $meta_title;

            //$meta->meta_keyword = $meta_keyword;

            //$meta->meta_description = $meta_description;

         

            DB::statement("update user_profile set meta_title = '$meta_title', meta_keyword = '$meta_keyword', meta_description = '$meta_description' where user_id = '$user_id'");

            

			$message = "success";

			

            echo json_encode($message);

        }

    }



    public function postUpdateinfo(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if ($user != null) {

            $user->full_name = $request->input("full_name");

            $user->address = $request->input("address");

            $user->occupation = $request->input("occupation");

            $user->phone = $request->input("phone");

            $user->fax = $request->input("fax");

            $user->email = $request->input("website");

            $user->save();

        }



        return response()->json(

            array(

                'message' => "success",

                'token' => csrf_token()

            ), 200

        );

    }





    public function postUrlInstagram(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();

        $message = "success";

        $user_profile = UserProfile::where('user_id', $user->id)->first();

        if ($user != null) {

            $url_ig = $request->input("url_ig");

            if (empty($url_ig)) {

                $message = "No URL Provided";



            } else {

                                

                    $user_profile->ig_url = $url_ig;

                    $user_profile->save();

                    

                    $message = "success";

            }

            echo json_encode($message);

        }

    }

    

    public function postUrlYoutube(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        $user_setting = User::where('domain', $domain)->first();

        if ($user != null) {

            $url_video = $request->input("url_video");

            if (empty($url_video)) {

                $message = "No URL Provided";



            } else {



                if (preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $url_video, $match)) {

                    $url_video_id = $match[1];



                    $url = "https://www.youtube.com/embed/" . $url_video_id . "";

                    date_default_timezone_set("Asia/Jakarta");



                    $youtube = new Youtube;

                    $youtube->user_id = $user['id'];

                    $youtube->social_id = $user_setting['id'];

                    $youtube->content = $url;

                    $youtube->social = "youtube";

                    $youtube->date = date("d M Y H:i:s");

                    $youtube->status = "1";

                    $youtube->save();

                    $message = "success";



                } else {

                    $message = "error";

                }

            }

            echo json_encode($message);

        }

    }



    public function postStatus(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if ($user) {

            $user_setting = User::where('domain', $domain)->first();

            $status = $request->input("status");

            if (empty($status)) {

                $message = "null";

                echo json_encode($message);

            } else {

                if ($user != null) {

                    date_default_timezone_set("Asia/Jakarta");

                    $timeline = new Timeline;

                    $timeline->user_id = $user['id'];

                    $timeline->social_id = $user_setting['id'];

                    $timeline->content = $status;

                    $timeline->social = "soulfy";

                    if ($request->input("latitude") && $request->input("longitude")) {

                        $timeline->location = $this->getaddress($request->input("latitude"), $request->input("longitude"));

                    }

                    $timeline->date = date("d M Y H:i:s");

                    $timeline->status = "1";

                    $timeline->save();

					

					

					

					$followers = Followers::where('following_id', $user['id'])->get();

					foreach($followers as $follower) {

						$f = User::where('id', $follower->follower_id)->first();

						

						$to = $f->email;

						$subject = "Status Notification {$domain}";

						$headers = "MIME-Version: 1.0" . "\r\n";

						$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

						$message = "Hi {$f['full_name']}<br><br>A user you're following has posted a new status on his website {$domain}<br><br><b>Status</b>: {$status}";

						mail($to, $subject, $message, $headers);

					}

					

                    $message = "success";

                    echo json_encode($message);

                }

            }

        }

    }



    private function getaddress($lat, $lng)

    {

        $url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng=' . trim($lat) . ',' . trim($lng) . '&sensor=false';

        $json = @file_get_contents($url);

//        echo $json;

        $data = json_decode($json);

        $json_data = json_decode($json,true);

        $status = $data->status;

//        echo $status;

        if ($status == "OK") {

            $city = $this->google_getCity($json_data);

//            echo $city;

            return $city;

//            return $data->results[0]->formatted_address;

        } else {

            return false;

        }

    }



    private function google_getCity($jsondata)

    {

        return $this->Find_Long_Name_Given_Type("locality", $jsondata["results"]);

    }



    private function Find_Long_Name_Given_Type($type, $array, $short_name = false)

    {

//        var_dump($array);

        foreach ($array as $data){



            foreach ($data["address_components"] as $value) {

                if (in_array($type, $value["types"])) {

                    if ($short_name)

                        return $value["short_name"];

                    return $value["long_name"];

                }

            }

        }

        return "";

    }



    function Get_Address_From_Google_Maps($lat, $lon) {



		$url = "http://maps.googleapis.com/maps/api/geocode/json?latlng=$lat,$lon&sensor=false";



		// Make the HTTP request

		$data = @file_get_contents($url);

		// Parse the json response

		$jsondata = json_decode($data,true);



		// If the json data is invalid, return empty array

		

		$address = array(

		  

		    'formatted_address' => $this->google_getCity($jsondata),

		);



		return $address['formatted_address'];

	}



    public function getLocation(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if ($user) {

          

        

            $lat = $request->input("lat");

            $long = $request->input("long");

        

            $message = $this->Get_Address_From_Google_Maps($lat, $long);

            

            echo json_encode($message);

        }

    }



    public function postDeleteTimeline(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if ($user) {

            $domain = $_SERVER['SERVER_NAME'];

            $user_setting = User::where('domain', $domain)->first();

            $id_timeline = $request->input("id_timeline");

            $social_type = $request->input("social_type");

            if ($social_type == "gallery") {

                $data = Timeline::where('user_id', $user_setting['id'])->find($id_timeline);



                $photo = explode(".", $data->content);





                $photo_id = $photo[0];

                $extension = $photo[1];



                $img = "$photo_id.$extension";

                $img_thumb = $photo_id . "_thumb." . $extension;

                File::Delete('/uploads/' . $img);

                File::Delete('/uploads/' . $img_thumb);



            } else {

                $data = Timeline::where('user_id', $user_setting['id'])->find($id_timeline);

            }



            $act = $data->delete();

            if ($act) {

                $message = "success";

            } else {

                $message = "error";

            }

            echo json_encode($message);

        }

    }



    public function postEditSkype(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if ($user) {

            $user_setting = User::where('domain', $domain)->first();



            $user_id = $user_setting['id'];

            $skype_id = $request->input("skypeid");



            $data = Setting::where('user_id', $user_id)->first();



            $data->skype_id = $skype_id;





            $act = $data->save();



            if ($act) {

                $message = "success";

            } else {

                $message = "error";

            }

            echo json_encode($message);

        }

    }



    public function postDeleteEmailAccount(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if (Auth::User()) {

            $email_user = $request->input("user");



            require_once(base_path() . "/vendor/cpanel_api/xmlapi.php");



            $ip = env("SERVER_IP", "127.0.0.1"); //your server's IP

            $xmlapi = new \xmlapi($ip);



            $xmlapi->password_auth(env("CPANEL_USER", "root"), env("CPANEL_PASSWORD", "")); //the server login info for the user you want to create the emails under

            $xmlapi->set_output('json');

            $xmlapi->set_debug(1);



            $acct = json_decode($xmlapi->listaccts('domain', $domain), true);

            if ($acct && count($acct['acct']) == 1) {

                $U = $acct['acct'][0]['user'];



                $params = array('email' => $email_user, 'domain' => $domain);

                $result = json_decode($xmlapi->api2_query($U, "Email", "delpop", $params), true);



                if (isset($result['cpanelresult']['data'][0]['result']) && $result['cpanelresult']['data'][0]['result'] == 0) { // Error

                    $message = $result['cpanelresult']['error'];

                    $response = 400;

                } else {

                    UserMail::where('email_account', $email_user)->where('user_id', $user->id)->delete();

                    $message = "Email Account Deleted!";

                    $response = 200;

                }

            } else {

                $message = "System Error.";

                $response = 400;

            }

        } else {

            $message = "You're not logged in";

            $response = 400;

        }



        return response()->json(

            array(

                'error' => true,

                'message' => $message,

                'token' => csrf_token()),

            $response);

    }



    public function postUpdateEmailAccountPassword(Request $request)

    {

        $domain = $_SERVER['SERVER_NAME'];

        $user = User::where('domain', $domain)->first();



        if (Auth::User()) {

            $email_user = $request->input("user");

            $email_pass = $request->input("password");



            require_once(base_path() . "/vendor/cpanel_api/xmlapi.php");



            $ip = env("SERVER_IP", "127.0.0.1"); //your server's IP

            $xmlapi = new \xmlapi($ip);



            $xmlapi->password_auth(env("CPANEL_USER", "root"), env("CPANEL_PASSWORD", "")); //the server login info for the user you want to create the emails under

            $xmlapi->set_output('json');

            $xmlapi->set_debug(1);



            $acct = json_decode($xmlapi->listaccts('domain', $domain), true);

            if ($acct && count($acct['acct']) == 1) {

                $U = $acct['acct'][0]['user'];



                $params = array('email' => $email_user, 'domain' => $domain, 'password' => $email_pass);

                $result = json_decode($xmlapi->api2_query($U, "Email", "passwdpop", $params), true);



                if (isset($result['cpanelresult']['data'][0]['result']) && $result['cpanelresult']['data'][0]['result'] == 0) { // Error

                    $message = $result['cpanelresult']['error'];

                    $response = 400;



                    //print_r($result);die();

                } else {

                    $message = "Password Successfully changed!";

                    $response = 200;

                }

            } else {

                $message = "System Error.";

                $response = 400;

            }

        } else {

            $message = "You're not logged in";

            $response = 400;

        }



        return response()->json(

            array(

                'message' => $message,

                'token' => csrf_token()),

            $response);

    }



    public function postUpdatelink(Request $request)

    {

        $message = "System Error.";

        $response = 400;



        $link = $request->input("link");



        if ($link == "") {

            $message = "url cannot be empty";

        } else {

            $user = Auth::User();

            $user->bisnis_link = $link;

            $user->save();

            $message = "update link is success";

            $response = 200;

        }

        return response()->json(

            array(

                'message' => $message,

                'token' => csrf_token()),

            $response);

    }



    public function  getTestemail()
    {
    //        exit;
        $to = "daffigusti0890@gmail.com";
        $subject = "New Password Requested akma";
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $message = "Hi khadafi<br>" .
            "<br>A new Password is generated for your website www.amanah." .
            "<br><br><b>tesfdsdf</b><br><br>If you didn't request a new password, Please login with the new password and change your login Email Address and password. you may also conatct us at admin@soulfy.com";
        mail($to, $subject, $message, $headers);
    }

    public function postFollowWithLogin(Request $request)
    {
		$domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        if ($user) {
			$domain   = str_replace("www.", "", str_replace("http://", "", str_replace("https://", "", $request->input("domain"))));
			$email    = $request->input("email");
			$password = $request->input("password");
			$guest = User::where('domain', $domain)->where('email', $email)->first();

			if($guest && Hash::check($password, $guest->password) && $guest->id != $user->id) 
            {
				if(!Followers::where('follower_id', $guest->id)->where('following_id', $user->id)->first()) 
                {
					$follower = new Followers;
					$follower->follower_id = $guest->id;
					$follower->following_id = $user->id;
					$follower->save();
				}
				$guest->is_following = (Followers::where('follower_id', $guest->id)->where('following_id', $user->id)->first()) ? true : false;
				$request->session()->set('guest', $guest);
				return response()->json(
					array(
						'message' => "Guest Login Successful!",
						'success' => true,
						'token' => csrf_token()),
					200);
			}
		}

		return response()->json(
            array(
                'message' => "Authentication Failed!",
                'success' => false,
                'token' => csrf_token()),
            400);
    }

	public function postDoFollow(Request $request)
    {
		$domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
		$guest = $request->session()->get('guest');

        if ($user && $guest) {
			if(!Followers::where('follower_id', $guest->id)->where('following_id', $user->id)->first()) 
            {
				$follower = new Followers;
				$follower->follower_id = $guest->id;
				$follower->following_id = $user->id;
				$follower->save();
			}

			$guest->is_following = true;
			$request->session()->set('guest', $guest);
			return response()->json(
				array(
					'message' => "Follow Successful!",
					'success' => true,
					'token' => csrf_token()),
				200);
		}

		return response()->json(
            array(
                'message' => "Something went Wrong!",
                'success' => false,
                'token' => csrf_token()),
            400);
    }

	public function postDoUnfollow(Request $request)
    {
		$domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
		$guest = $request->session()->get('guest');
        if ($user && $guest) {
			Followers::where('follower_id', $guest->id)->where('following_id', $user->id)->delete();
			$guest->is_following = false;
			$request->session()->set('guest', $guest);
			return response()->json(
				array(
					'message' => "Unfollow Successful!",
					'success' => true,
					'token' => csrf_token()),
				200);
		}

		return response()->json(
            array(
                'message' => "Something went Wrong!",
                'success' => false,
                'token' => csrf_token()),
            400);
    }


    public function postUnfollow(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $following_id = $request->Input('id');
        $existFollow = Followers::where('follower_id',$user->id)->where('following_id',$following_id)->first();
        if($existFollow)
        {
            $bfaccounts = Followers::findOrFail($existFollow->id);
            $bfaccounts->delete();
            $message = array('flag' => 1, 'status' => 0);
        } 
        else {
            $fol = new Followers;
            $fol->follower_id = $user->id;
            $fol->following_id = $following_id;
            $fol->save();
            $message = array('flag' => 1, 'status' => 1);
        }
        echo json_encode($message);
    }


    public function postUnfollower(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $following_id = $request->Input('id');
        $existFollow = Followers::where('follower_id',$following_id)->where('following_id',$user->id)->first();
        if($existFollow)
        {
            $bfaccounts = Followers::findOrFail($existFollow->id);
            $bfaccounts->delete();
            $message = array('flag' => 1, 'status' => 0);
        } 
        echo json_encode($message);
    }
}
