<?php

namespace Soulfy\Http\Controllers;

use Illuminate\Http\Request;
use Soulfy\Http\Requests;
use Soulfy\Http\Controllers\Controller;
use Auth;
use Soulfy\Pages;
use Soulfy\User;

class PageController extends Controller
{
    public function index()
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();  
        $pages = Pages::where('user_id', $user->id)->get();
        return view('soulfy.apages', ['pages' => $pages]);
    }
    public function create()
    {
        return view('soulfy.add_pages');
    }
    public function store(Request $request)
    {
        // Store The New Page Info
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        $user_id = $user->id;
        $pages = new Pages();
        $pages->user_id = $user_id;
        $pages->pages_name = $request['pages_name'];
        $pages->pages_title = $request['pages_title'];
        $pages->pages_keyword = $request['pages_keyword'];
        $pages->pages_description = $request['pages_description'];
        $pages->pages_content = $request['pages_content'];
        $pages->save();
        session()->flash('status', 'Page has been added');
        return view('soulfy.add_pages'); 
    }
    public function show($id)
    {
        $pages = Pages::find($id);
        return view('soulfy.edit_pages', ['pages' => $pages]);
    }
    public function edit($id)
    {
        //
    }
    public function update(Request $request, $id)
    {
        $pages = Pages::find($id);
        $pages->pages_name = $request['pages_name'];
        $pages->pages_title = $request['pages_title'];
        $pages->pages_keyword = $request['pages_keyword'];
        $pages->pages_description = $request['pages_description'];
        $pages->pages_content = $request['pages_content'];
        $pages->update();
        session()->flash('status', 'Page has been updated');    
        return view('soulfy.edit_pages', ['pages' => $pages]);
    }
    public function destroy($id)
    {
        $pages = Pages::find($id);
        $pages->delete();
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();  
        $pages = Pages::where('user_id', $user->id)->get();
        session()->flash('status', 'Page has been deleted');
        return view('soulfy.apages', ['pages' => $pages]);
    }
    public function frontindex($id)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();  
        $pages = Pages::where('user_id', $user->id)->get();
        return view('soulfy.pages', ['pages' => $pages]);
    }
}
