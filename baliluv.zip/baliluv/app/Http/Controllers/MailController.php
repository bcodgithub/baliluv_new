<?php

namespace Soulfy\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Mail;
use Soulfy\Helper;
use Soulfy\Http\Requests;
use Soulfy\Http\Controllers\Controller;
use Soulfy\MailContent;
use Soulfy\User;
use Soulfy\UserMail;
use Input;
use Session;
use Validator;
use Redirect;

class MailController extends Controller
{

    public function __construct(){
        $this->middleware('mail.auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request $request
     * @param  int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }

    public function getCreate()
    {
		session(['draft_id' => 0]);
        return view("soulfy.email.create_email");
    }

    public function getInbox(Request $request)
    {
		$domain = $_SERVER['SERVER_NAME'];
        $domain = str_replace('www.','',$domain);
        $user = User::where('domain',$domain)->first();

        $hostname = '{mail.soulfy.com:143/novalidate-cert}INBOX';

        $username = session('userMail')['email']."@$domain";
        $password = session('userMail')['password'];

        /* try to connect */
        $inbox = imap_open($hostname, $username, $password)
                or die('Cannot connect to mail: ' . imap_last_error());

        /* grab emails */
        $emails = imap_search($inbox, 'ALL');
		$mail_content = array();
		
        /* if emails are returned, cycle through each... */
        if ($emails) {
            /* put the newest emails on top */
            rsort($emails);

            /* for every email... */
            foreach ($emails as $email_number) {

                $overview = imap_fetch_overview($inbox, $email_number, 0);

                $message = quoted_printable_decode(imap_fetchbody($inbox, $email_number, 1.2));
        
                if(!strlen($message)>0){
                    $message =imap_fetchbody($inbox, $email_number, 1);
                }

                //$message = imap_fetchbody($inbox, $email_number, 1);

                    $m = new \stdClass();
					$m->body = $message;
                    $m->mail_user = session('userMail')['email'];
                    $m->user_id = $user->id;
                    $m->status = ($overview[0]->seen ? 'read' : 'unread');
                    $m->from = $overview[0]->from;
                    $m->date = $overview[0]->date;
                    $m->uid = $overview[0]->uid;
					$m->msgno = $overview[0]->msgno;
//                    $m->subject = $overview[0]->subject;
                    $m->subject = property_exists($overview[0],"subject")?$overview[0]->subject:"";

					$mail_content[] = $m;
            }
        }


        /* close the connection */
        \imap_close($inbox);

        return view("soulfy.email.inbox",compact("mail_content"));
    }

    public function getSent(Request $request)
    {

        $mail = UserMail::find($request->input("mail"));

        if($mail==null){
            return "";
        }

        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain',$domain)->first();


        /* connect to mail */
        $hostname = '{mail.soulfy.com:143/novalidate-cert}INBOX.Sent';
        $username = "$mail->email_account@$domain";
        $password = $mail->password;

        /* try to connect */
        $inbox = imap_open($hostname, $username, $password) or die('Cannot connect to Mail: ' . imap_last_error());

        /* grab emails */
        $emails = imap_search($inbox, 'ALL');

        /* if emails are returned, cycle through each... */
        if ($emails) {

            /* begin output var */
            $output = '';

            /* put the newest emails on top */
            rsort($emails);

            /* for every email... */
            foreach ($emails as $email_number) {

                /* get information specific to this email */
                $overview = imap_fetch_overview($inbox, $email_number, 0);
                $message = imap_fetchbody($inbox, $email_number, 1);

                /* output the email header information */
                $output .= '<div class="toggler ' . ($overview[0]->seen ? 'read' : 'unread') . '">';
                $output .= '<span class="subject">' . $overview[0]->subject . '</span> ';
                $output .= '<span class="from">' . $overview[0]->from . '</span>';
                $output .= '<span class="date">on ' . $overview[0]->date . '</span>';
                $output .= '</div>';

                /* output the email body */
                $output .= '<div class="body">' . $message . '</div>';

                $mail_content = MailContent::where("date", $overview[0]->date)->first();

                if ($mail_content == null) {
                    $mail_content = new MailContent();
                    $mail_content->body = $message;
                    $mail_content->mail_user = session('userMail')['email'];
                    $mail_content->user_id = $user->id;
                    $mail_content->folder = "SENT";
                    $mail_content->status = ($overview[0]->seen ? 'read' : 'unread');
                    $mail_content->from = $overview[0]->from;
                    $mail_content->date = $overview[0]->date;
                    $mail_content->subject = $overview[0]->subject;
                    $mail_content->save();
                }
                // var_dump($mail_content);
            }

            // echo $output;
        }


        /* close the connection */
        \imap_close($inbox);

        $mail_content = MailContent::where("folder","SENT")
            ->where('mail_user',session('userMail')['email'])->get();

        return view("soulfy.email.sent",compact("mail_content"));
    }

    public function getDraft(Request $request)
    {
        $domain = $_SERVER['SERVER_NAME'];
        $domain = str_replace('www.','',$domain);
        $user = User::where('domain',$domain)->first();


        /* connect to mail */
        $hostname = '{mail.soulfy.com:143/novalidate-cert}INBOX.Drafts';

        $username = session('userMail')['email']."@$domain";
        $password = session('userMail')['password'];
        /*$username = "$mail->email_account@$domain";
        $password = $mail->password;*/

        /* try to connect */
        $inbox = imap_open($hostname, $username, $password)
        or die('Cannot connect to mail: ' . imap_last_error());

        /* grab emails */
        $emails = imap_search($inbox, 'ALL');
		$mail_content = array();
		
        /* if emails are returned, cycle through each... */
        if ($emails) {
            /* put the newest emails on top */
            rsort($emails);

            /* for every email... */
            foreach ($emails as $email_number) {

                /* get information specific to this email */
                $overview = imap_fetch_overview($inbox, $email_number, 0);
                $message = imap_fetchbody($inbox, $email_number, 1);

                    $m = new \stdClass();
					$m->body = $message;
                    $m->mail_user = session('userMail')['email'];
                    $m->user_id = $user->id;
                    $m->folder = "DRAFT";
                    $m->status = ($overview[0]->seen ? 'read' : 'unread');
                    $m->from = $overview[0]->to;
                    $m->date = $overview[0]->date;
                    $m->uid = $overview[0]->uid;
                    $m->msgno = $overview[0]->msgno;
                    $m->subject = $overview[0]->subject;
					
					$mail_content[] = $m;
            }
        }
        /* close the connection */
        \imap_close($inbox);

        //$mail_content = MailContent::where("folder","DRAFT")->where('mail_user',session('userMail')['email'])->get();

        return view("soulfy.email.draft",compact("mail_content"));
    }
    public function postSavedraft(Request $request){

        /*$mail = UserMail::where('email_account',session('userMail')['email'])->first();

        if($mail==null){
            return "";
        }*/
        $domain = $_SERVER['SERVER_NAME'];
        $domain = str_replace('www.','',$domain);


        /* connect to mail */
        $hostname = '{mail.soulfy.com:143/novalidate-cert}INBOX.Drafts';
        $username = session('userMail')['email']."@$domain";
        $password = session('userMail')['password'];

        /*$username = "$mail->email_account@$domain";
        $password = $mail->password;*/

        $msg = "From: ".$username."\r\n";
        $msg.="To: ".$request->to."\r\n";
        $msg.="Date: ".date("d-M-Y H:i:s")."\r\n";
        $msg.="Subject: ".$request->subject."\r\n";
        $msg.="X-IMP-Draft: Yes\r\n";
        $msg.="Content-Type: text/plain; charset=utf-8; format=flowed; DelSp=Yes\r\n";
        $msg.="MIME-Version: 1.0\r\n";
        $msg.="Content-Disposition: inline\r\n";
        //$msg.="Attachment: ".$request->file1."\r\n";
        $msg.="\r\n".$request->body."\r\n";

        /* try to connect */
        $inbox = imap_open($hostname, $username, $password) or die('Cannot connect to mail: ' . imap_last_error());

        $check = imap_check($inbox);
        echo "Msg Count before append: ". $check->Nmsgs . "\n";

        imap_append($inbox,$hostname,$msg);

        $check = imap_check($inbox);
        echo "Msg Count before append: ". $check->Nmsgs . "\n";

        \imap_close($inbox);

    }
    public function postSendmail(Request $request)
    {

        $domain = $_SERVER['SERVER_NAME'];
        $domain = str_replace('www.','',$domain);
        //$domain =  $request->input("domain");
        $to = $request->input("to");
        $body = $request->input("body");
        $subject = $request->input("subject");
        $bcc = $request->input('bcc','');
        $cc = $request->input('cc','');
        $attachment = $request->file('file1');

        $from = session('userMail')['email'].'@'.$domain;
        $password = session('userMail')['password'];
        $name = session('userMail')['fname'];

        $transport = Mail::getSwiftMailer()->getTransport();
        Mail::alwaysFrom($from,$name);
        $transport->setUsername($from);
        $transport->setPassword($password);

        try{
        Mail::raw($body, function($message) use($to,$subject,$from,$name,$bcc,$cc,$attachment){
            $message->from($from, $name);

            if(strlen($bcc)>0)
               $message->bcc($bcc);
            if(strlen($cc)>0)
               $message->cc($cc);

            $message->subject($subject);
            $message->to($to);
            if(strlen($attachment > 0)) {
                $message->attach($attachment->getRealPath(), array(
                    'as' => $attachment->getClientOriginalName(), // If you want you can chnage original name to custom name      
                    'mime' => $attachment->getMimeType())
                );
                
            }


        });}catch(\Exception $e){dd($e);}

		if(session('draft_id')){
            //$mc = MailContent::find(session('draft_id'));
			//if($mc) $mc->delete();
            $this->removeMail('.Drafts',session('draft_id'));
        }
    }
    private function removeMail($folder,$uid){
//die($folder.'@@@'.$uid);
        $domain = $_SERVER['SERVER_NAME'];
        $domain = str_replace('www.','',$domain);
        $mailUser = UserMail::where('email_account',session('userMail')['email'])->first();

        $hostname = '{mail.soulfy.com:143/novalidate-cert}INBOX'.$folder;
        $username = session('userMail')['email']."@$domain";
        $password = session('userMail')['password'];
		
        $iConnect = imap_open($hostname, $username, $password) or die('Cannot connect to mail: ' . imap_last_error());
        imap_delete($iConnect, $uid.':'.$uid, FT_UID);
        imap_expunge($iConnect);
        \imap_close($iConnect);
    }
    /*public function postSendEmail(Request $request){
        dd($request->all());

        $input = Input::only('name', 'email', 'msg');

          $validator = Validator::make($input,
              array(
                  'name' => 'required',
                  'email' => 'required|email',
                  'msg' => 'required',
              )
          );

          if ($validator->fails())
          {
              return Redirect::to('contact')->with('errors', $validator->messages());
          } else { // the validation has not failed, it has passed


           // Send the email with the contactemail view, the user input
           Mail::send('mail.contactemail', $input, function($message)
           {
               $message->from('daffi@dustroyer.com', 'Khadafi');
                $message->subject("[No-Reply] Email Report ");
               $message->to('daffi@dustroyer.com');
           });

          
           Session::flash('success', 'Upload successfully');
            return redirect('/')->with('message_', 'email has been sent');
          }

    }*/
    

    public function postRemoveMail(Request $request){
        //$mc = MailContent::findOrFail($request->id);
        $this->removeMail($request->folder,$request->id);
        //$mc->delete();
        session()->flash('msg_type','success');
        session()->flash('message','Email Successfully Removed');
        return (strlen($request->folder) >0 )?'tab_draft':'tab_inbox';
    }
    public function getMail(Request $request){
		$mail_content = $this->getSingleMail('', $request->msgno);
        return view('soulfy.email.view',compact('mail_content'));
    }
    public function getReply(Request $request){
		$to = $this->get_string_between($request->from, '<', '>');
        return view('soulfy.email.create_email',compact('to'));
    }
    public function getForward(Request $request){
        $mail_content = $this->getSingleMail('', $request->msgno);
        return view('soulfy.email.create_email',compact('mail_content'));
    }
    public function getCreatedraft(Request $request){
		$mail_content = $this->getSingleMail('.Drafts', $request->msgno);
		return view('soulfy.email.create_draft_email',compact('mail_content'));
    }
	
	private function getSingleMail($folder, $msgno) {
        $domain = $_SERVER['SERVER_NAME'];
        $domain = str_replace('www.','',$domain);
        $user = User::where('domain',$domain)->first();
		
        $hostname = '{mail.soulfy.com:143/novalidate-cert}INBOX'.$folder;
        $username = session('userMail')['email']."@$domain";
        $password = session('userMail')['password'];

        $drafts = imap_open($hostname, $username, $password) or die('Cannot connect to mail: ' . imap_last_error());
		
		$overview = imap_fetch_overview($drafts, $msgno, 0);

		//$message = quoted_printable_decode(imap_fetchbody($drafts, $msgno, 2));
        $message = quoted_printable_decode(imap_fetchbody($drafts, $msgno, 1.2));


        $file = $this->extract_attachments($drafts, $msgno);
		
        if(!strlen($message)>0){
            $message =imap_fetchbody($drafts, $msgno, 1);
        }
        
		
		
		$mail_content = new \stdClass();
		if($message) {
			$mail_content->body = $message;
			$mail_content->mail_user = session('userMail')['email'];
			$mail_content->user_id = $user->id;
			$mail_content->status = ($overview[0]->seen ? 'read' : 'unread');
			$mail_content->from = $overview[0]->from;
			$mail_content->date = $overview[0]->date;
			$mail_content->uid = $overview[0]->uid;
			$mail_content->msgno = $overview[0]->msgno;
			$mail_content->subject = $overview[0]->subject;
            $mail_content->files = $file;
		}
		return $mail_content;
	}

    function extract_attachments($connection, $message_number) 
    {
        $attachments = array();
        $structure = imap_fetchstructure($connection, $message_number);
   
        if(isset($structure->parts) && count($structure->parts)) {
   
            for($i = 0; $i < count($structure->parts); $i++) {
   
                $attachments[$i] = array(
                    'is_attachment' => false,
                    'filename' => '',
                    'name' => '',
                    'attachment' => ''
                );
               
                if($structure->parts[$i]->ifdparameters) {
                    foreach($structure->parts[$i]->dparameters as $object) {
                        if(strtolower($object->attribute) == 'filename') {
                            $attachments[$i]['is_attachment'] = true;
                            $attachments[$i]['filename'] = $object->value;
                        }
                    }
                }
           
                if($structure->parts[$i]->ifparameters) {
                    foreach($structure->parts[$i]->parameters as $object) {
                        if(strtolower($object->attribute) == 'name') {
                            $attachments[$i]['is_attachment'] = true;
                            $attachments[$i]['name'] = $object->value;
                        }
                    }
                }
           
                if($attachments[$i]['is_attachment']) {
                    $attachments[$i]['attachment'] = imap_fetchbody($connection, $message_number, $i+1);
                    if($structure->parts[$i]->encoding == 3) { // 3 = BASE64
                        $attachments[$i]['attachment'] = $attachments[$i]['attachment'];
                    }
                    elseif($structure->parts[$i]->encoding == 4) { // 4 = QUOTED-PRINTABLE
                        $attachments[$i]['attachment'] = quoted_printable_decode($attachments[$i]['attachment']);
                    }
                }
            }
        }
        return $attachments;
    }
	
	function get_string_between($string, $start, $end){
		$string = ' ' . $string;
		$ini = strpos($string, $start);
		if ($ini == 0) return '';
		$ini += strlen($start);
		$len = strpos($string, $end, $ini) - $ini;
		return substr($string, $ini, $len);
	}
}