<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// Intro
Route::get('/', 'HomeController@getHome')->name('index');
Route::get('/admin', 'HomeController@getAdmin')->name('admin');

// Article on seperate page
Route::get('/home/articles', 'HomeController@getWebArticles')->name('articles');

// New pages
Route::get('/home/pages/{pages}', 'PageController@frontindex')->name('pages.frontindex');

Route::get('/home/rss', 'RssController@rssIndex');

Route::group(['middleware' => 'auth'], function () {

    // Hal Pages
    Route::resource('pages', 'PageController');
    //pages.index, pages.create, pages.store, pages.show, pages.edit, pages.update, pages.destroy
    
    // HomeController
    Route::get('/home/users', 'HomeController@users');
    Route::post('/home/article', 'HomeController@postSeo');
    Route::get('/home/article', 'HomeController@showSeo');
    
    //Basic Setup
    $domain = $_SERVER['SERVER_NAME'];
    $user = \Soulfy\User::where('domain', $domain)->first();
    $basicCheck = \Soulfy\BasicConfig::where('user_id', $user->id)->get();
    if (count($basicCheck) > 0) {
    Route::get('/basicsetup/getform', 'BasicsetupController@getIndex');
	}

    // Rss Feed
    Route::get('/rss/rssfeed','RssController@rssFeed');
    
    Route::get('/home/barticles', 'HomeController@getArticles')->name('barticles');

    Route::get('/home/instagram', 'HomeController@getInstagram2');

    // SettingController
    Route::get('/home/navcolor', 'SettingController@getNavColor')->name('navcolor');
    Route::post('/home/setting', 'SettingController@postNewsletter');

    Route::post('/home/sendpic', 'SettingController@SendPicture');
    Route::get('/home/theme', 'SettingController@getBackgroundTheme');

    Route::post('/home/bgprofile', 'SettingController@getBackgroundProfile');
    Route::post('/home/upbprofile', 'SettingController@UploadBackgroundProfile');

    Route::post('/home/deletebgprofile/{id}', 'SettingController@DeleteBackgroundProfile');

    Route::post('/home/gallery', 'MemberController@postUploadGalleryEcom');

    Route::get('/home/wadetails','ImageController@waDetails');
    Route::get('/home/washop','ImageController@waShop');
    Route::get('/home/exportdata','ImageController@exportcsv');
    Route::get('/home/likedata','ImageController@exportlikedata');
    

});

Route::controllers([
    'auth' => 'Auth\AuthController',
    'password' => 'Auth\PasswordController',
    'home'=>'HomeController',
    'member'=>'MemberController',
    'mail'=>'MailController',
    'social'=>'SocialController',
    'ajax'=>'AjaxController',
    'rss' => 'RssController',
    'img' => 'ImageController',
    'api'=>'ApiController',
    'timeline'=>'TimelineController',
    'setting'=>'SettingController',
    'basic' => 'BasicsetupController',
//    'ecommerce'=>'EcommerceController',
    'test'=>'TestController',
]);



// Generate a login URL
Route::get('/facebook/login',['as'=>'fb.login', function(SammyK\LaravelFacebookSdk\LaravelFacebookSdk $fb)
{
    Session::put('domain',$_GET['domain']);

    // Send an array of permissions to request
    $login_url = $fb->getLoginUrl();

    // Obviously you'd do this in blade :)
    return redirect($login_url);
}]);

// Endpoint that is redirected to after an authentication attempt
Route::get('/facebook/callback', function(SammyK\LaravelFacebookSdk\LaravelFacebookSdk $fb)
{
    // Obtain an access token.
    try {
        $token = $fb->getAccessTokenFromRedirect();
    } catch (Facebook\Exceptions\FacebookSDKException $e) {
//        echo "tsdf";
        dd($e->getMessage());
    }

    // Access token will be null if the user denied the request
    // or if someone just hit this URL outside of the OAuth flow.
    if (! $token) {
        // Get the redirect helper
        $helper = $fb->getRedirectLoginHelper();

        if (! $helper->getError()) {
            abort(403, 'Unauthorized action.');
        }

        // User denied the request
        dd(
            $helper->getError(),
            $helper->getErrorCode(),
            $helper->getErrorReason(),
            $helper->getErrorDescription()
        );
    }

    if (! $token->isLongLived()) {
        // OAuth 2.0 client handler
        $oauth_client = $fb->getOAuth2Client();

        // Extend the access token.
        try {
            $token = $oauth_client->getLongLivedAccessToken($token);
        } catch (Facebook\Exceptions\FacebookSDKException $e) {
            dd($e->getMessage());
        }
    }

    $fb->setDefaultAccessToken($token);

    $domain = Session::get('domain');
    $user = \Soulfy\User::where('domain',$domain)->first();
    // Save for later
    Session::put('fb_user_access_token', (string) $token);
    $user_token = \Soulfy\UserToken::where('user_id',$user->id)->first();
    $user_token->fb_token = (string) $token;
    $user_token->save();

    // Get basic info on the user from Facebook.
    try {
        $response = $fb->get('/me?fields=id,name,first_name,last_name,email,picture,bio,gender,birthday,link,location,religion,website,hometown,work,education');
      
        $userNode = $response->getGraphUser();
      
        $uid = $userNode->getId();
        //printf('Hello, %s!', $userNode->getPicture()->getUrl());
        $image_url = 'https://graph.facebook.com/'.$uid.'/picture?type=normal';
        if($user->image_profile == null){
            $user->image_profile = $image_url;
        }
        if($user->name == null){
            $user->name = $userNode->getName();
        }

        $user_profile = \Soulfy\UserProfile::where('user_id',$user->id)->first();
        if($user_profile == null){
            $user_profile = new \Soulfy\UserProfile();
            $user_profile->user_id = $user->id;
        }
        $user_profile->name = $userNode->getName();
        $user_profile->type = "fb";
        $user_profile->first_name = $userNode->getField("first_name");
        $user_profile->last_name = $userNode->getField("last_name");
        $user_profile->email = $userNode->getField("email");
        $user_profile->profile_image = $image_url;
        $user_profile->url = $userNode->getField("link");
        $user_profile->about = $userNode->getField("about");
        $user_profile->gender = $userNode->getField("gender");
        $user_profile->location = $userNode->getField("location")["name"];
        $user_profile->birthday = $userNode->getField("birthday");
        $user_profile->hometown = $userNode->getField("hometown")["name"];
        $user_profile->work = $userNode->getField("work")[0]["employer"]["name"];
        $user_profile->education = $userNode->getField("education")[0]["school"]["name"];

        $user_profile->save();
        $user->save();
        //exit;
    } catch (Facebook\Exceptions\FacebookSDKException $e) {
        dd($e->getMessage());
    }

    // Convert the response to a `Facebook/GraphNodes/GraphUser` collection
    $facebook_user = $response->getGraphUser();

    // Create the user if it does not exist or update the existing entry.
    // This will only work if you've added the SyncableGraphNodeTrait to your User model.
    //$user = Soulfy\User::createOrUpdateGraphNode($facebook_user);

    // Log the user into Laravel
   // Auth::login($user);

//    var_dump($user_token);
//    exit;
    return redirect("http://".$domain)->with('message', 'Successfully logged in with Facebook');
});

Route::get('twitter/login', ['as' => 'twitter.login', 'uses'=>'CallbackController@twitter_login', function(){

}]);

Route::get('twitter/callback', ['as' => 'twitter.callback','uses'=>'CallbackController@twitter_callback', function() {


}]);

Route::get('twitter/error', ['as' => 'twitter.error', function(){
    // Something went wrong, add your own error handling here
}]);

Route::get('twitter/logout', ['as' => 'twitter.logout', function(){
    Session::forget('access_token');
    return Redirect::to('/')->with('flash_notice', 'You\'ve successfully logged out!');
}]);

Route::get('twitter/timeline', function()
{
    return Twitter::getHomeTimeline(['count' => 20, 'format' => 'json']);
});

Route::get('google/login', ['as' => 'google.login','uses'=>'CallbackController@google_login', function(\Illuminate\Http\Request $request){

}]);

Route::get('linkedin/login', ['as' => 'linkedin.login', function(\Illuminate\Http\Request $request){
    // get data from request
    $code = $request->get('code');

    $linkedinService = \OAuth::consumer('Linkedin');


    if ( ! is_null($code))
    {
        // This was a callback request from linkedin, get the token
        $token = $linkedinService->requestAccessToken($code);

        // Send a request with it. Please note that XML is the default format.
        $result = json_decode($linkedinService->request('/people/~?format=json'), true);

        // Show some of the resultant data
        echo 'Your linkedin first name is ' . $result['firstName'] . ' and your last name is ' . $result['lastName'];

        //Var_dump
        //display whole array.
        dd($result);

    }
    // if not ask for permission first
    else
    {
        // get linkedinService authorization
        $url = $linkedinService->getAuthorizationUri(['state'=>'DCEEFWF45453sdffef424']);

        // return to linkedin login url
        return redirect((string)$url);
    }
}]);

Route::get('flickr/login', ['as' => 'flickr.login', function(\Illuminate\Http\Request $request){
    // get data from request
    $step = isset($_GET['step']) ? (int)$_GET['step'] : null;

    $oauth_token = isset($_GET['oauth_token']) ? $_GET['oauth_token'] : null;
    $oauth_verifier = isset($_GET['oauth_verifier']) ? $_GET['oauth_verifier'] : null;

    if($oauth_token && $oauth_verifier){
        $step = 2;
    }

    $flickrService = \OAuth::consumer('Flickr');

    $storage = new \OAuth\Common\Storage\Session();

    if($oauth_token && $oauth_verifier){
        $step = 2;
    }
$url = route("flickr.login");
    switch($step){
        default:
            print "<a href='".route("flickr.login").'?step=1'."'>Login with Flickr!</a>";
            break;

        case 1:

            if($token = $flickrService->requestRequestToken()){
                $oauth_token = $token->getAccessToken();
                $secret = $token->getAccessTokenSecret();

                if($oauth_token && $secret){
                    $url = $flickrService->getAuthorizationUri(array('oauth_token' => $oauth_token, 'perms' => 'write'));
                    header('Location: '.$url);
                }
            }

            break;

        case 2:
            $token = $storage->retrieveAccessToken('Flickr');
            $secret = $token->getAccessTokenSecret();

            if($token = $flickrService->requestAccessToken($oauth_token, $oauth_verifier, $secret)){
                $oauth_token = $token->getAccessToken();
                $secret = $token->getAccessTokenSecret();

                $storage->storeAccessToken('Flickr', $token);

                header('Location: '.$url.'?step=3');
            }
            break;

        case 3:
            $xml = simplexml_load_string($flickrService->request('flickr.test.login'));
            print "status: ".(string)$xml->attributes()->stat."\n";
            break;
    }
}]);

Route::get('foursquare/login', ['as' => 'foursquare.login', function(\Illuminate\Http\Request $request){
    // get data from request
    $code = $request->get('code');

    $foursquareService = \OAuth::consumer('Foursquare');


    if ( ! is_null($code))
    {
        // This was a callback request from linkedin, get the token
        $token = $foursquareService->requestAccessToken($code);

        $result = json_decode($foursquareService->request('users/self'), true);

        // Show some of the resultant data
        echo 'Your unique foursquare user id is: ' . $result['response']['user']['id'] . ' and your name is ' . $result['response']['user']['firstName'] . $result['response']['user']['lastName'];


        //Var_dump
        //display whole array.
        dd($result);

    }
    // if not ask for permission first
    else
    {
        // get linkedinService authorization
        $url = $foursquareService->getAuthorizationUri();

        // return to linkedin login url
        return redirect((string)$url);
    }
}]);



//admin dashboard


//category
Route::get('/admin/category','adminController@category_page');
Route::get('category/add',function () {
    return view('soulfy.category_add_page');
});
Route::post('/category/add','adminController@category_page_add_submission');

//sub category
Route::get('/sub_category/add','adminController@sub_category_page');
Route::post('/sub_category/add', 'adminController@sub_category_page_submit');

//service
route::get('/admin/service','adminController@service_page');
//Route::get('/subcat','adminController@subcategory'); 
Route::get('/findProductName','adminController@findProductName');
Route::post('/admin/service','adminController@service_page_submit');

//email template
Route::get('admin/email-template','adminController@email_template');
Route::get('admin/email-template/add','adminController@email_template_add_page');
Route::post('admin/email-template/add','adminController@email_template_add_page_submit');


