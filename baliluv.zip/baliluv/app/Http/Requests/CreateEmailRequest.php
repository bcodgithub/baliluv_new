<?php

namespace Soulfy\Http\Requests;

use Soulfy\Http\Requests\Request;

class CreateEmailRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'first'=>'required|alpha|min:2|max:30',
            'last'=>'min:2|max:30|alpha',
            'account'=>'required|alpha_dash|min:1|max:40',//|unique:user_mail,email_account',
            'password'=>'required|regex:/^\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])\S*$/|between:8,40|confirmed',
            'password_confirmation'=>'',
        ];
    }
    public function messages(){
        return [
            'password.regex'=>"Password must contains at least \r\n one Numeric letter \r\n one Capital letter"
        ];
    }
}
