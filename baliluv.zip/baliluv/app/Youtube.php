<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class Youtube extends Model
{
    //
    protected $table = "timeline";
    
}
