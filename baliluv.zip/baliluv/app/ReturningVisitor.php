<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class ReturningVisitor extends Model
{
    protected $table = "returning_visitors";
     protected $fillable = [
    	'user_id' ,'whatsap_id'
    ];
}