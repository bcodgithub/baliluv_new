<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class UserbgProfile extends Model
{
    //
    protected $table = "user_bgprofile";
}
