<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class Followers extends Model {
    protected $table = "followers";
}
