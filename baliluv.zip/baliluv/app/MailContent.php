<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class MailContent extends Model
{
    //
    protected $table = 'mail_content';
}
