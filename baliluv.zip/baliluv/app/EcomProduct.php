<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class EcomProduct extends Model
{
    //
    protected $table = "ecom_product";

    public function images()
    {
        return $this->hasMany('Soulfy\EcomProductImage','product_id');
    }
}
