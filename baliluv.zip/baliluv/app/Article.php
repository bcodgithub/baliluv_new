<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
    //
    protected $table = "article";

    public static function split_words($string, $nb_caracs, $separator){
        $string = strip_tags(html_entity_decode($string));
        if( strlen($string) <= $nb_caracs ){
            $final_string = $string;
        } else {
            $final_string = "";
            $words = explode(" ", $string);
            foreach( $words as $value ){
                if( strlen($final_string . " " . $value) < $nb_caracs ){
                    if( !empty($final_string) ) $final_string .= " ";
                    $final_string .= $value;
                } else {
                    break;
                }
            }
            $final_string .= $separator;
        }
        $str = str_replace(array("\r\n","\r","\n","\\r","\\n","\\r\\n"),"<br/>",$final_string);
        return htmlspecialchars_decode($str);
    }

    function br2nl( $input ) {
        return preg_replace('/<br(\s+)?\/?>/i', "\n", $input);
    }
}
