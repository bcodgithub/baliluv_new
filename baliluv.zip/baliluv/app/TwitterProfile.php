<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class TwitterProfile extends Model
{
    //
    protected $table = "profile_twitter";
}
