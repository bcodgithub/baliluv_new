<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class TestPopup extends Model
{
    //
    protected $table = "test_table";

}
