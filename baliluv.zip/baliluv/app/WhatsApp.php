<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class WhatsApp extends Model
{
    protected $table = "whatsapp";
     protected $fillable = [
    	'username' ,'number'
    ];
}