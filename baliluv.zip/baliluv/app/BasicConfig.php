<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class BasicConfig extends Model
{
    //
    protected $table = "basicsetup_config";
}
