<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class ImageClick extends Model
{
    protected $table = "image_click";
    protected $fillable = [
    	'user_id' ,'whatsap_id','image_id','virtual_price'
    ];
}