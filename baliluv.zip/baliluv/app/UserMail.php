<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class UserMail extends Model
{
    //
    protected $table = "user_mail";
}
