<?php

namespace Soulfy;

use Illuminate\Database\Eloquent\Model;

class EcomProfile extends Model
{
    //
    protected $table = "ecom_profile";
}
