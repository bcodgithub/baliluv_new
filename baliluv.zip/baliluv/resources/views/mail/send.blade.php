<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 9/7/2015
 * Time: 10:39 AM
 */

        ?>


{!! $body !!}
