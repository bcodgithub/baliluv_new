<strong>Email address:</strong> {{ $email }} <br>
<strong>Subject:</strong> {{ $name }} <br>
<strong>Message:</strong><br>
{{ $msg }}
