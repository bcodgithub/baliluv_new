<?php

    use Soulfy\User;
    use Soulfy\UserProfile;
    use Illuminate\Http\Request;

    $domain = $_SERVER['SERVER_NAME'];
    $user = User::where('domain', $domain)->first();
    $settings = \Soulfy\Setting::where('user_id', $user->id)->get();

    if ($settings) $settings = $settings[0];
    $user_setting = \Soulfy\Setting::where('user_id', $user->id)->first();
    $user_profile = \Soulfy\UserProfile::where('user_id', $user->id)->first();
    $timelineYoutube = \Soulfy\Timeline::where('social','youtube')->where('user_id',$user->id)->get();
    $timelineGallery = \Soulfy\Timeline::where('social','gallery')->where('user_id',$user->id)->get();
    $timelineArticle = \Soulfy\Timeline::where('social','article')->where('user_id',$user->id)->get();
    $pages = \Soulfy\Pages::where('user_id',$user->id)->first();
    $menuColor = \Soulfy\UserProfile::where('user_id',$user->id)->first();
    $domains = \Soulfy\User::all();
    $follow = \Soulfy\Followers::where('follower_id',$user->id)->first();
    $basicEnabel = \Soulfy\BasicConfig::where('user_id',$user->id)->first();
    $countries = \DB::table('countries')->select('countries_name', 'countries_isd_code')->get();
    $fb_url = $user_setting->custom_facebook_link;
    $trfb_user = parse_url($fb_url);
    $fb_user = ltrim($trfb_user['path'], '/'); 
    $tt_url = $user_setting->custom_twitter_link;
    $trtt_user = parse_url($tt_url);
    $tt_user = ltrim($trtt_user['path'], '/'); 
    $ig_url = $user_profile->ig_url;
    $trig_user = parse_url($ig_url);
    $ig_user = ltrim($trig_user['path'], '/'); 
    $li_url = $user_setting->custom_linkedin_link;
    $trli_user = parse_url($li_url);
    $li_user = ltrim($trli_user['path'], '/');
    $webstatus = 1;
    // step 1 Basic Info
    if($user->full_name == '' OR $user->background_image == '') {
        Session::put('count',0);
    }
    //step 2 Contact
    elseif ($user->phone == '' OR 
        $user->contact_email == '' OR 
        $user->address == '') 
    {
        Session::put('count',1);
    }

    //step 3 whatsApp
    elseif ($user_setting->wa_username == '' OR 
        $user_setting->wa_number == '' ) 
    {
        Session::put('count',2);
    }

    // Step 4 Social Media Info
    elseif ($user_setting->custom_facebook_link == '' OR 
        $user_setting->custom_twitter_link == '' OR 
        $user_profile->ig_url == '' ) 
    {
        Session::put('count',3);
    }

    // Step 5 Profile info
    elseif ($user_setting->info_profile == '') {
        Session::put('count',4);
    }

    // Step 6 Post your first Youtube Url
    elseif (count($timelineYoutube) == 0) {
        Session::put('count',5);
    }
    // Step 7 Create your first Soulfy Page
    elseif (isset($pages->pages_name) == '') {
        Session::put('count',6);
    }

    // Step 8 Upload your first photos
    elseif (count($timelineGallery) == 0) {
        Session::put('count',7);
    }

    // Step 9 Create your first articles 
    elseif (count($timelineArticle) == 0 ) {
        Session::put('count',8);
    }

    // Step 10 Add your logo
    elseif ($user->image_profile == '') {
        Session::put('count',9);
    }

    // Step 11 Web status
    elseif ($webstatus == '') {
        Session::put('count',10);
    }

    // Step 12 Purchase your first Soulfy stock photo background -->
    elseif ($user_setting->stock_photo == '') {
        Session::put('count',11);
    }

    //step 13 Change your menu buttons color
    elseif ($menuColor->menu_color == '') {
        Session::put('count',12);
    }

    //step 14 Change your Page Section header Color
    elseif ($menuColor->nav_color == '') {
        Session::put('count',13);
    }

    // step 15 Add Your SSl certificate
    elseif ($user_setting->sslcertificate == '') {
        Session::put('count',14);
    }

    // step 16 Set your Cutsom Menu
    elseif ($user_setting->custom_menu1_link == '' 
        OR $user_setting->custom_menu2_link == '' 
        OR $user_setting->custom_menu3_link == '') 
    {
        Session::put('count',15);
    }

    //step 17 Follow other Soulfy Website
    elseif ($follow->follower_id == '' ) {
        Session::put('count',16);
    }
    // Step 18 SEO
    elseif ($menuColor->meta_title == '' OR 
        $menuColor->meta_keyword == '' OR 
        $menuColor->meta_description == '') 
    {
        Session::put('count',17);
    }

    //step 19 Activate your E-Commerce Store
    elseif ($user_setting->ecommerce_status != 'ACTIVE') {
        Session::put('count',18);
    }

    // step 21 Show successful fund raising 
    elseif ($user_setting->funding == '') {
        Session::put('count',19);
    }
?>

<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Setup</title>
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <link rel='shortcut icon' type='image/x-icon' href="{{url('')}}/images/favicon.ico"/>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" type="text/css" href="{{url('')}}/pop/css/style.css?v=1.1" />
    <link rel="stylesheet" type="text/css" href="{{url('')}}/pop/css/all.css" />
    <!-- <script src="{{url('')}}/pop/ckeditor.js"></script> -->
    <!-- <script src="{{url('')}}/pop/js/sample.js"></script> -->
</head>
<body background="{{url('')}}{{$user->background_image}}">
    <input type="hidden" name="sessioncount" id="sessioncount" data-value="<?php echo Session::get('count')?>">

    <div class="wrapper-container">

        <div class="overlay"></div>

        <form action="#" id="form" class="form">

            <a href="{{url('/')}}">

                <span class="close-icon">x</span>

            </a>

            <div class="steps clearfix">

                <ul>

                    <!-- step 1 Basic -->

                    @if($basicEnabel->background_img_enable || $basicEnabel->title_enable)

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!-- step 2 Contact -->

                    @if($basicEnabel->email_enable || $basicEnabel->address_enable || $basicEnabel->phone_enable)

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!-- step 3 WhasApp -->

                    @if($basicEnabel->whatsapp_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif





                    <!-- step 4 Social Media Info -->

                    @if($basicEnabel->facebook_enable || $basicEnabel->twitter_enable || $basicEnabel->instagram_enable || $basicEnabel->linkedin_enable)

                    <li class="step" id="step"><span></span></li>

                    @endif



                     <!-- Step 5 Profile info -->

                    @if($basicEnabel->profile_info_enable)

                    <li class="last step" id="step"><span></span></li>

                    @endif



                    <!-- Step 6 Post your first Youtube Url -->

                    @if($basicEnabel->youtube_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!-- Step 7 Create your first Soulfy Page -->

                    @if($basicEnabel->page_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!--  Step 8 Upload your first photos -->

                    @if($basicEnabel->gallery_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!--  step 9 Create your first articles -->

                    @if($basicEnabel->article_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!-- step 10 Add your logo -->

                    @if($basicEnabel->logo_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!-- Step 11 Web status -->

                    @if($basicEnabel->webstatus_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!-- step 12 Purchase your first Soulfy stock photo background -->

                    @if($basicEnabel->stock_photo_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!-- step 13 Change your menu buttons color -->

                    @if($basicEnabel->menu_color_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!-- step 14 Change your Page Section header Color -->

                    @if($basicEnabel->page_color_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!-- step 15 Add Your SSl certificate -->

                    @if($basicEnabel->ssl_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!-- step 16 Set your Cutsom Menu  -->

                    @if($basicEnabel->custom_menu1_enable || $basicEnabel->custom_menu2_enable || $basicEnabel->custom_menu3_enable)

                    <li class="step" id="step"><span></span></li>

                    @endif 



                    <!-- step 17 Follow other Soulfy Website -->

                    @if($basicEnabel->follow_website_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!-- Step 18 SEO -->

                    @if($basicEnabel->seo_title_enable || $basicEnabel->seo_keyword || $basicEnabel->seo_description )

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!-- step 19 Activate your E-Commerce Store  -->

                    @if($basicEnabel->ecom_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif



                    <!-- step 20 Create your first Facebook Ads  -->

                    <!-- @if($basicEnabel->fb_ads_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif -->



                    <!-- step 21 Create your first Instagram Ads  -->

                    <!-- @if($basicEnabel->ig_ads_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif -->



                    <!-- step 22 Show successful fund raising  -->

                    @if($basicEnabel->funding_enable )

                    <li class="step" id="step"><span></span></li>

                    @endif



                </ul>

            </div>

            <div class="inner-wrapper">

                <div class="image-left" id="image-show">

                    <img src="{{url('')}}/pop/images/form-left1.jpg" alt="">

                </div>

                <div class="form-content">

                    <div class="form-header">

                        <h3>Branding, Scaling, & Funding</h3>

                    </div>

                    <input type="hidden" name="_token" value="{{csrf_token()}}">

                    <div class="thank-you" id="thank-you" style="display: none;text-align: center;

                            font-size: 35px; font-weight: bold; color: #000; margin-top: 90px;">

                        Thank You<br>

                        <span style="font-size: 20px;">Branding, Scaling & Funding</span>

                    </div>

                    <!-- step 1 Basic Info -->

                    @if($basicEnabel->background_img_enable || $basicEnabel->title_enable)

                    <div class="tab" id="basic">

                        <p>Basic Info</p>

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <input type="text" class="form-input input-field input-field-effect" id="fullname" name="fullname" value="{{$user->full_name}}">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Full Name</span>

                                </label>

                            </div>

                        </div>

                        

                        @if($basicEnabel->background_img_enable )

                        <div class="form-row">

                            <div id="upload2" class="form-holder w-100 upload upload-effect">

                                <div class="uploadinput-block">

                                    <input id="uploadFile2" type="text" class="form-input input-field input-field-effect" value="">

                                    <label class="input-label input-label-effect">

                                        <span class="input-label-content input-label-content-effect">Background Image</span>

                                    </label>

                                </div>

                                <div class="file-upload file-upload2 btn btn-primary"><span>Upload</span>  

                                <input class="inputfile" name="uploadBtn2" id="uploadBtn2" type="file" onchange="encodeImageBkg(this)"/></div> 

                            </div>

                        </div>

                        @endif

                        <div class="actions clearfix">

                            <ul>

                                <li class="next-btn"><button type="button" id="basicinfo" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- step 2 Contact -->

                    @if($basicEnabel->email_enable || $basicEnabel->address_enable || $basicEnabel->phone_enable)

                    <div class="tab" id="contact">

                        <div class="trophy"></div>

                        <p>Contact</p>

                        @if($basicEnabel->email_enable )

                        <div class="form-row">

                            <div class="form-holder input input-effect">

                                <input type="email" class="form-input input-field input-field-effect" name="email" id="email" value="{{$user->contact_email}}">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Business Email</span>

                                </label>

                            </div>

                        </div>

                        @endif

                        @if($basicEnabel->phone_enable )

                        <div class="form-row">

                            <div class="form-holder input input-effect">

                                <input type="text" class="form-input input-field input-field-effect" id="phone" name="phone" value="{{$user->phone}}">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Phone Number</span>

                                </label>

                            </div>

                        </div>

                        @endif

                        @if($basicEnabel->address_enable )

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100 textarea">

                                <input type="text" class="form-input input-field input-field-effect" name="address" id="address" value="{{$user->address}}">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Address</span>

                                </label>

                            </div>

                        </div>

                        @endif

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="contactinfo" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- step 3 whatsapp -->

                    @if($basicEnabel->whatsapp_enable )

                    <div class="tab" id="whatsapp">

                        <div class="trophy"></div>

                        <p>WhatsApp Details</p>

                        <div class="form-row">

                          

                            <div class="form-holder input input-effect w-100">

                                <input type="text" class="form-input input-field input-field-effect" name="wa_username" id="wa_username" value="{{$user_setting->wa_username}}">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">User Name</span>

                                </label>

                            </div>

                        </div>

                        <div class="form-row">

                            <div class="form-holder input input-effect">

                                <label >Select Country Code

                                </label>

                                <select name="countryCode" class="w-100 form-control" id="countryCode">

                                    <option value="">Select Country Code</option>

                                    @foreach($countries as $cont)

                                    <option value="{{$cont->countries_isd_code}}">{{$cont->countries_name}}(+{{$cont->countries_isd_code}})</option>

                                    

                                    @endforeach



                                </select>

                            </div>

                            <div class="form-holder input input-effect">

                                <input type="text" class="form-input input-field input-field-effect" name="wa_number" id="wa_number" value="{{$user_setting->wa_number}}">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">WhatsApp Number</span>

                                </label>

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="whatsapp" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- step 4 Social Media Info -->

                    @if($basicEnabel->facebook_enable || $basicEnabel->twitter_enable || $basicEnabel->instagram_enable || $basicEnabel->linkedin_enable)

                    <div class="tab" id="social">

                        <div class="trophy"></div>

                        <p>Social Media Info</p>

                        @if($basicEnabel->facebook_enable )

                        <div class="form-row">

                            <div class="form-holder input input-effect">

                                <input type="text" class="form-input input-field input-field-effect" value="https://facebook.com/" readonly>

                            </div>

                            <div class="form-holder input input-effect">

                                <input type="text" class="form-input input-field input-field-effect" name="facebook" id="facebook" value="{{$fb_user}}">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Facebook username</span>

                                </label>

                            </div>

                        </div>

                        @endif

                        @if($basicEnabel->twitter_enable )

                        <div class="form-row">

                            <div class="form-holder input input-effect">

                                <input type="text" class="form-input input-field input-field-effect" value="https://twitter.com/" readonly>

                            </div>

                            <div class="form-holder input input-effect">

                                <input type="text" class="form-input input-field input-field-effect" name="twitter" id="twitter" value="{{$tt_user}}">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Twitter username</span>

                                </label>

                            </div>

                        </div>

                        @endif

                        @if($basicEnabel->instagram_enable )

                        <div class="form-row">

                            <div class="form-holder input input-effect">

                                <input type="text" class="form-input input-field input-field-effect" value="https://instagram.com/" readonly>

                            </div>

                            <div class="form-holder input input-effect">

                                <input type="text" class="form-input input-field input-field-effect" name="instagram" id="instagram" value="{{$ig_user}}">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Instagram username</span>

                                </label>

                            </div>

                        </div>

                        @endif

                        @if($basicEnabel->linkedin_enable )

                        <div class="form-row">

                            <div class="form-holder input input-effect">

                                <input type="text" class="form-input input-field input-field-effect" value=" https://www.linkedin.com/" readonly>

                            </div>

                            <div class="form-holder input input-effect">

                                <input type="text" class="form-input input-field input-field-effect" name="linkedin" id="linkedin" value="{{$li_user}}" >

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Linkedin username</span>

                                </label>

                            </div>

                        </div>

                        <!-- https://www.linkedin.com/in/anu-premi-50a86147/ -->                        

                        @endif

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="socialprofile" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- Step 5 Post profile info -->

                    @if($basicEnabel->profile_info_enable)

                    <div class="tab" >

                        <div class="trophy"></div>

                        <p>Profile Info</p>

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <textarea name="profile_info" id="profile_info" >{{ $user_setting->info_profile}}</textarea>

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                 <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="profileinfo" onclick="nextPrev(1)">Next</button></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- Step 6 Post your first Youtube Url -->

                    @if($basicEnabel->youtube_enable )

                    <div class="tab" id="yutube_url">

                        <div class="trophy"></div>

                        <p>Youtube</p>

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <input type="text" class="form-input input-field2 input-field-effect" name="url_video" id="url_video" >

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Post your first Youtube Url</span>

                                </label>

                            </div>

                        </div>                        

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="yutube" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- Step 7 Create your first Soulfy Page -->

                    @if($basicEnabel->page_enable)

                    <div class="tab" id="pages">

                        <div class="trophy"></div>

                        <p>Create your first Soulfy Page</p>

                        <div class="form-row">

                            <div class="form-holder input input-effect">

                                <input type="text" class=" input-field2 form-input input-field-effect" name="pages_name" id="pages_name" >

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Page Name</span>

                                </label>

                            </div>

                            <div class="form-holder input input-effect">

                                <input type="text" class=" input-field2 form-input input-field-effect" name="pages_title" id="pages_title" >

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Page Title</span>

                                </label>

                            </div>

                        </div>

                         <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <textarea class="form-input input-field-effect" name="pages_content" id="pages_content" ></textarea>

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="page" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- Step 8 Upload your first photos -->

                    @if($basicEnabel->gallery_enable)

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Upload your first photos</p>

                        <!-- { {action('MemberController@postUploadGallery')}} -->

                        <div class="form-row">

                            <div id="uploadGallery" class="form-holder w-100 upload upload-effect">

                                <div class="uploadinput-block">

                                    <input id="uploadFileGallery" type="text" class="form-input input-field-effect" value="">

                                    <label class="input-label input-label-effect">

                                        <span class="input-label-content input-label-content-effect">Gallery Image</span>

                                    </label>

                                </div>

                                <div class="file-upload file-uploadGallery btn btn-primary"><span>Upload</span>  

                                <input type="file"  name="uploadBtn" class="inputfile" id="uploadBtn" onchange="encodeImgGallery(this)"/></div> 

                            </div>

                        </div>



                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="gallery" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- step 9 Create your first  articles -->

                    @if($basicEnabel->article_enable)

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Create your first articles</p>

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <input type="text" class="form-input input-field2 input-field-effect" name="article_tittle" id="article_tittle">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Title</span>

                                </label>

                            </div>

                        </div>

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <textarea name="article_content" id="article_content" ></textarea>

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="article" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- step 10 Add your logo -->

                    @if($basicEnabel->logo_enable)

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Add your logo</p>

                        <div class="form-row">

                            <div id="upload1" class="form-holder w-100 upload upload-effect">

                                <div class="uploadinput-block">

                                    <input id="uploadFile" type="text" class="form-input input-field input-field-effect" value="">

                                    <label class="input-label input-label-effect">

                                        <span class="input-label-content input-label-content-effect">Profile</span>

                                    </label>

                                </div>

                                <div class="file-upload file-upload1 btn btn-primary"><span>Upload</span>  

                                <input type="file"  name="uploadBtn" class="inputfile" id="uploadBtn" onchange="encodeImageProfile(this)"/></div> 

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="logo" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- step 11 webstatus -->

                    @if($basicEnabel->webstatus_enable )

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Post your first web status</p>

                        <div class="form-row">

                            <div class="form-holder w-100">

                                <div class="form-body">

                                    <textarea name="update" id="txt_status" cols="40" placeholder="what's on your mind?"></textarea>

                                </div>

                                <div class="form-btm">

                                    <div class="input-group">

                                        <div class="checkbox-icon">

                                            <label>

                                                <input type="checkbox" {{$settings->fb_enable == true ? "" : "disabled"}} id="ck_fb"/>Facebook

                                                <span class="lbl padding-1" style="opacity: {{$settings->fb_enable == true ? '1' : '0.5'}};"></span>

                                            </label><br>

                                            <label>

                                                <input type="checkbox" {{$settings->twitter_enable == true ? "" : "disabled"}} id="ck_twitter"/>Twitter

                                                <span class="lbl padding-2"  style="opacity: {{$settings->twitter_enable == true ? '1' : '0.5'}};"></span>

                                            </label><br>

                                            <label>

                                                <input type="checkbox" {{$settings->google_enable == true ? "" : "disabled"}} id="ck_gplus"/>Google Plus

                                                <span class="lbl padding-3"  style="opacity: {{$settings->google_enable == true ? '1' : '0.5'}};"></span>

                                            </label>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="btn_post" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- step 12 Purchase your first Soulfy stock photo background -->

                    @if($basicEnabel->stock_photo_enable)

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Purchase your first Soulfy stock photo background</p>

                        <div class="form-row">

                            <div class="form-holder w-100">

                                <a href="{{action('HomeController@getSetting')}}" target="_blank" ><b>Click Here</b></a>

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="logo" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- step 13 Change your menu buttons color -->

                    @if($basicEnabel->menu_color_enable)

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Change your menu buttons color</p>

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <label >MENU COLOR

                                </label>

                                <select name="menu_color" class="w-100 form-control" id="menu_color">

                                    <option value="">None</option>
                                    <option value="1">Black(t)</option>
                                    <option value="ff0000">Red</option>

                                    <option value="39b54a">Green</option>

                                    <option value="f26522">Orange</option>

                                    <option value="FFC300">Yellow</option>

                                    <option value="0000ff">Blue</option>

                                    <option value="000000">Black</option>

                                    <option value="bec3c8">Grey</option>

                                </select>

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="menucolor" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif

                    

                    <!-- step 14 Change your Page Section header Color -->

                    @if($basicEnabel->page_color_enable)

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Change your Page Section header Color</p>

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <label >Select Pages Navigation Color :

                                </label>

                                <select name="navcolor" id="navcolor">

                                    <option value="ff0000">Red</option>

                                    <option value="39b54a">Green</option>

                                    <option value="f26522">Orange</option>

                                    <option value="FFC300">Yellow</option>

                                    <option value="0000ff">Blue</option>

                                    <option value="000000">Black</option>

                                    <option value="bec3c8">Grey</option>

                                    <option value="FF69B4">Pink</option>

                                    <option value="dd04f7">Purple</option>

                                    <option value="cba26c">Brown</option>

                                    <option value="42fbdf">Light Blue</option>

                                    <option value="E3DEDA">Light Gray</option>

                                </select>

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="pageColor" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- step 15 Add SSL Certificate to your domain -->

                    @if($basicEnabel->ssl_enable)

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Add SSL Certificate to your domain</p>

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <input type="checkbox" name="ssl" id="ssl" value="1">Add SSL Certificate to your domain

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="sslcertificate" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- step 16 Set your Cutsom Menu -->

                    @if($basicEnabel->custom_menu1_enable || $basicEnabel->custom_menu2_enable || $basicEnabel->custom_menu3_enable)

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Set your Cutsom Menu</p>

                        @if($basicEnabel->custom_menu1_enable)

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <input type="text" class="form-input input-field-effect" id="custom_menu1" name="custom_menu1" value="">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Set Cutsom Menu 1</span>

                                </label>

                            </div>

                            <div id="uploadCustom1" class="form-holder w-100 upload upload-effect">

                                <div class="uploadinput-block">

                                    <input id="uploadFileCustom1" type="text" class="form-input input-field-effect" value="">

                                    <label class="input-label input-label-effect">

                                        <span class="input-label-content input-label-content-effect">Image</span>

                                    </label>

                                </div>

                                <div class="file-upload file-uploadCustom1 btn btn-primary"><span>Upload</span>  

                                <input type="file"  name="uploadBtn" class="inputfile" id="uploadBtn" onchange="encodeImgCustom1(this)"></div> 

                            </div>

                        </div>

                        @endif



                        @if($basicEnabel->custom_menu2_enable)

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <input type="text" class="form-input input-field-effect" id="custom_menu2" name="custom_menu2" value="">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Set Cutsom Menu 2</span>

                                </label>

                            </div>

                            <div id="uploadCustom2" class="form-holder w-100 upload upload-effect">

                                <div class="uploadinput-block">

                                    <input id="uploadFileCustom2" type="text" class="form-input input-field-effect" value="">

                                    <label class="input-label input-label-effect">

                                        <span class="input-label-content input-label-content-effect">Image</span>

                                    </label>

                                </div>

                                <div class="file-upload file-uploadCustom2 btn btn-primary"><span>Upload</span>  

                                <input type="file"  name="uploadBtn" class="inputfile" id="uploadBtn" onchange="encodeImgCustom2(this)"/></div> 

                            </div>

                        </div>

                        @endif



                        @if($basicEnabel->custom_menu3_enable)

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <input type="text" class="form-input input-field-effect" id="custom_menu3" name="custom_menu3" value="">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Set Cutsom Menu 3</span>

                                </label>

                            </div>

                            <div id="uploadCustom3" class="form-holder w-100 upload upload-effect">

                                <div class="uploadinput-block">

                                    <input id="uploadFileCustom3" type="text" class="form-input input-field-effect" value="">

                                    <label class="input-label input-label-effect">

                                        <span class="input-label-content input-label-content-effect">Image</span>

                                    </label>

                                </div>

                                <div class="file-upload file-uploadCustom3 btn btn-primary"><span>Upload</span>  

                                <input type="file"  name="uploadBtn" class="inputfile" id="uploadBtn" onchange="encodeImgCustom3(this)"></div> 

                            </div>

                        </div>

                        @endif



                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="custommenu" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!--step 17 Follow other Soulfy Website -->

                    @if($basicEnabel->follow_website_enable)

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Follow other Soulfy Website</p>

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <label >Follow other Soulfy Website:

                                </label>

                                <select name="follow" id="follow">

                                    <option value="">Select</option>

                                    @foreach($domains as $domain)

                                    <option value="{{$domain->id}}">{{$domain->domain}}</option>

                                    @endforeach

                                </select>

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="followeb" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- Step 18 SEO -->

                    @if($basicEnabel->seo_title_enable || $basicEnabel->seo_keyword || $basicEnabel->seo_description )

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>SEO</p>

                        @if($basicEnabel->seo_title_enable)

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <input type="text" class="form-input input-field input-field-effect" id="meta_title" value="{{ \DB::table('user_profile')->where('user_id', $user->id)->first()->meta_title }}" name="meta_title">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">SEO Meta Title</span>

                                </label>

                            </div>

                        </div>

                        @endif



                        @if($basicEnabel->seo_keyword)

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <input type="text" class="form-input input-field input-field-effect" id="meta_keyword" value="{{ \DB::table('user_profile')->where('user_id', $user->id)->first()->meta_keyword }}" name="meta_keyword">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect"> SEO Keywords</span>

                                </label>

                            </div>

                        </div>

                        @endif



                        @if($basicEnabel->seo_description)

                        <div class="form-row">

                            <div class="form-holder w-100">

                                <label>SEO Description </label>

                                <textarea cols="55" rows="3" id="meta_description" name="meta_description">{{ \DB::table('user_profile')->where('user_id', $user->id)->first()->meta_description }}</textarea> 

                            </div>

                        </div>

                        @endif



                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="seo" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif

                    

                    <!-- step 19 Activate your E-Commerce Store  -->

                    @if($basicEnabel->ecom_enable)

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Activate your E-Commerce Store</p>

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <a onclick="set_ecommerce(this,'PROCESS')" href="#">

                                    <button class="setting-off" style="width:161px;  font-family: 'opensans-bold', sans-serif; background:#fff; height:25px; border-radius:5px;">OFF</button>

                                </a>

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="ecom" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif



                    <!-- step 20 Create your first Facebook Ads  -->

                    <!-- @if($basicEnabel->fb_ads_enable)

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Create your first Facebook Ads</p>

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <input type="text" class="form-input input-field input-field-effect" name="" id="" value="">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Post your first Youtube Url</span>

                                </label>

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="ecom" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="fb_ads" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif -->



                    <!-- step 21 Create your first Instagram Ads  -->

                    <!-- @if($basicEnabel->ig_ads_enable )

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Create your first Instagram Ads</p>

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <input type="text" class="form-input input-field input-field-effect" name="" id="" value="">

                                <label class="input-label input-label-effect">

                                    <span class="input-label-content input-label-content-effect">Post your first Youtube Url</span>

                                </label>

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                <li class="pre-btn"><button type="button" id="ecom" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="fb_ads" onclick="nextPrev(1)">Next</button><i class="fas fa-long-arrow-alt-right"></i></li>

                            </ul>

                        </div>

                    </div>

                    @endif -->



                    <!-- step 22 Show successful fund raising -->

                    @if($basicEnabel->funding_enable)

                    <div class="tab">

                        <div class="trophy"></div>

                        <p>Show successful fund raising ?</p>

                        <div class="form-row">

                            <div class="form-holder input input-effect w-100">

                                <input type="checkbox" name="fund" id="fund" value="1">Show successful fund raising

                            </div>

                        </div>

                        <div class="actions clearfix">

                            <ul>

                                 <li class="pre-btn"><button type="button" id="prevBtn" onclick="nextPrev(-1)" style="display:inline">Previous</button><i class="fas fa-long-arrow-alt-left"></i></li>

                                <li class="next-btn"><button type="button" id="nextBtn" onclick="nextPrev(1)">Submit</button></li>

                            </ul>

                        </div>

                    </div>

                    @endif

                </div>  

            </div>

        </form>

    </div>

    <script src="{{url('')}}/pop/js/jquery-3.4.1.min.js"></script>

    <!-- <script src="//cdn.ckeditor.com/4.13.0/standard/ckeditor.js"></script> -->

    <script src="//cdn.ckeditor.com/4.13.0/basic/ckeditor.js"></script>

    <script src="{{url('')}}/pop/js/form.js"></script>

    <script src="{{url('')}}/pop/js/classie.js"></script>

    <script>

        $(function() {

            CKEDITOR.replace('pages_content',{

            height: 150,

            allowedContent:true,

            extraAllowedContent: 'iframe[*]',

            extraAllowedContent: 'p[*] h1[*] h2[*] h3[*] h4[*] h5[*] h6[*] span[*] div[*] img[*] a[*]',

            extraAllowedContent: 'locationmap',

            extraAllowedContent : 'embed,embedsemantic,autoembed,autolink',

            });

        })

        $(function() {

            CKEDITOR.replace('article_content',{

            height: 150,

            allowedContent:true,

            extraAllowedContent: 'iframe[*]',

            extraAllowedContent: 'p[*] h1[*] h2[*] h3[*] h4[*] h5[*] h6[*] span[*] div[*] img[*] a[*]',

            extraAllowedContent: 'locationmap',

            extraAllowedContent : 'embed,embedsemantic,autoembed,autolink',

            });

        })



        $(function() {

            CKEDITOR.replace('profile_info',{

            height: 150,

            allowedContent:true,

            extraAllowedContent: 'iframe[*]',

            extraAllowedContent: 'p[*] h1[*] h2[*] h3[*] h4[*] h5[*] h6[*] span[*] div[*] img[*] a[*]',

            extraAllowedContent: 'locationmap',

            extraAllowedContent : 'embed,embedsemantic,autoembed,autolink',

            });

        })

    </script>

    <script>

        (function() {

            if (!String.prototype.trim) {

                (function() {

                    var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;

                    String.prototype.trim = function() {

                        return this.replace(rtrim, '');

                    };

                })();

            }

            [].slice.call( document.querySelectorAll( 'input.input-field, input.input-field2' ) ).forEach( function( inputEl ) {

                // in case the input is already filled..

                if( inputEl.value.trim() !== '' ) {

                    classie.add( inputEl.parentNode, 'input--filled' );

                }

                // events:

                inputEl.addEventListener( 'focus', onInputFocus );

                inputEl.addEventListener( 'blur', onInputBlur );

            } );

            function onInputFocus( ev ) {

                classie.add( ev.target.parentNode, 'input--filled' );

            }

            function onInputBlur( ev ) {

                if( ev.target.value.trim() === '' ) {

                    classie.remove( ev.target.parentNode, 'input--filled' );

                }

            }

        })();

                    

        $('#textarea-field').focus(function () {

           $(".textarea").addClass("input--filled");

        });

        $('.file-upload1').click(function () {

           $('#upload1').addClass("input--filled");

        });



        $('.file-upload2').click(function () {

           $('#upload2').addClass("input--filled");

        });



        $('.file-uploadGallery').click(function () {

           $('#uploadGallery').addClass("input--filled");

        });



        $('.file-uploadCustom1').click(function () {

           $('#uploadCustom1').addClass("input--filled");

        });



        $('.file-uploadCustom2').click(function () {

           $('#uploadCustom2').addClass("input--filled");

        });



        $('.file-uploadCustom3').click(function () {

           $('#uploadCustom3').addClass("input--filled");

        });

       

        $('#prevBtn').click(function () {

           $('.step.active').removeClass("finish").prev();

        });

        $('.close-icon').click(function () {

           $('#form').fadeOut( "slow" );

           $('.overlay').fadeOut( "slow" );

        });

    </script>



    <script type="text/javascript">

        //console.log('hi');



        $("#basicinfo").click(function(e){

            e.preventDefault();

            var fullname = $("#fullname").val();

            var background = bkimg;

            var profile = pfimg;

            $.ajax({

                method: "POST",

                url: '{{action("BasicsetupController@postBasicInfo")}}',

                data: { 

                    fullname : fullname , 

                    profile : profile, 

                    background : background,  

                    _token: '{{csrf_token()}}' 

                },

                success: function (response) {

                    if (response=='"error"') {

                        alert("Please enter all the details");

                    };

                },

            })   

        });



        $("#logo").click(function(e){

            e.preventDefault();

            var profile = pfimg;

            $.ajax({

                method: "POST",

                url: '{{action("BasicsetupController@postBasicLogo")}}',

                data: { 

                    profile : profile, 

                    _token: '{{csrf_token()}}' 

                },

                success: function (response) {

                    if (response=='"error"') {

                        alert("Please enter all the details");

                    };

                },

            })   

        });

        

        $("#contactinfo").click(function(e){

            e.preventDefault();

            var phone = $("#phone").val(),

            email = $("#email").val(),

            address = $("#address").val();

            $.ajax({

                method: "POST",

                url: '{{action("BasicsetupController@postConInfo")}}',

                data: { 

                    phone : phone , 

                    email : email, 

                    address : address , 

                    _token: '{{csrf_token()}}' 

                },

                success: function (response) {

                    if (response=='"error"') {

                        alert("Please enter all the details");

                    };

                },

            })

        });



        $("#whatsapp").click(function(e){

            e.preventDefault();

            var wa_username = $("#wa_username").val(),

            countryCode = $("#countryCode").val(),

            wa_number = $("#wa_number").val();

            $.ajax({

                method: "POST",

                url: '{{action("SettingController@postWhatsappapib")}}',

                data: { 

                    wa_username : wa_username , 

                    countryCode : countryCode, 

                    wa_number : wa_number , 

                    _token: '{{csrf_token()}}' 

                },

                success: function (response) {

                    if (response=='"error"') {

                        alert("Please enter all the details");

                    };

                },

            })

        });



        



        $("#socialprofile").click(function(e){

            e.preventDefault();

            var facebook = $("#facebook").val();

            var twitter = $("#twitter").val();

            var instagram = $("#instagram").val();

            $.ajax({

                method: "POST",

                url: '{{action("BasicsetupController@postSocialInfo")}}',

                data: { 

                    facebook : facebook , 

                    twitter : twitter , 

                    instagram : instagram ,

                    _token: '{{csrf_token()}}' 

                },

                success: function (response) {

                    if (response=='"error"') {

                        alert("please enter all the details");

                    };

                },

            })

        });



        $("#yutube").click(function (e) {

            e.preventDefault();

            var url_video = $("#url_video").val();

            $.ajax({

                type: "POST",

                url: '{{action("AjaxController@postUrlYoutube")}}',

                dataType: "text",

                data: {

                    url_video: url_video,

                    _token: '{{csrf_token()}}'

                },

                success: function (response) {

                    if (response == '"success"') {

                        alert("successfully updated");

                    } else if (response == '"error"') {

                        alert("the URL you entered is wrong");

                         location.reload();

                    } else if (response == '"null"') {

                        alert("Please type your URL");

                         location.reload();

                    };

                }

            })

        }),

        {{--$("#btn_post").click(function (e) {--}}

                {{--e.preventDefault();--}}



                {{--var status = $("#txt_status").val();--}}

                {{--if (status == "What is your mind?.") {--}}

                    {{--pesanErr("Please type your status");--}}

                {{--} else {--}}

                    {{--$.ajax({--}}

                        {{--type: "POST",--}}

                        {{--url: '{{action("AjaxController@postStatus")}}',--}}

                        {{--dataType: "text",--}}

                        {{--data: {--}}

                            {{--status: status,--}}

                        {{--},--}}

                        {{--success: function (response) {--}}



                            {{--if (response == '"success"') {--}}

                                {{--pesanOk("successfully update soulfy status");--}}

                                {{--setTimeout(function () {--}}

                                    {{--location.reload()--}}

                                {{--}, 1000);--}}

                            {{--} else if (response == '"error"') {--}}

                                {{--pesanErr("the URL you entered is wrong");--}}

                            {{--} else if (response == '"null"') {--}}

                                {{--pesanErr("Please type your status");--}}

                            {{--}--}}

                            {{--;--}}

                        {{--}--}}

                    {{--});--}}

                {{--}--}}



            {{--});--}}



        $("#btn_post").on("click", function () {

            var ck_fb = $("#ck_fb").prop("checked");

            var ck_twitter = $("#ck_twitter").prop("checked");

            var ck_path = $("#ck_path").prop("checked");

            var ck_gplus = $("#ck_gplus").prop("checked");



            $(this).button("loading");

            var button = this;

            var type = 0;

            if (ck_fb) {

                type = 1;

                updateStatus(button, type);

            } else if (ck_twitter) {

                type = 2;

                updateStatus(button, type);

            } else if (ck_path) {

                type = 3;

                updateStatus(button, type);

            } else if (ck_gplus) {

                type = 4;

                updateStatus(button, type);

            }else{

                postStatus(button);

            }

        });



        function updateStatus(button, type) {

            var jqxhr = $.post("{{action('SocialController@postPublishStatus')}}", {

                type: type,

                status: $("#txt_status").val()

            }, function (data) {

                alert("Successfully update status");

                $("#txt_status").val('');

                $(button).button("reset");

            }).fail(function () {

                alert("Publish status error");

                $("#txt_status").val('');

                $(button).button("reset");

            });

        }



        function postStatus(button){

            var status = $("#txt_status").val();

            if (status == "what's on your mind?") {

                alert("Please type your status");

            } else {

                $.ajax({

                    type: "POST",

                    url: '{{action("AjaxController@postStatus")}}',

                    dataType: "text",

                    data: {

                        status: status,

                        latitude : $("#latitude").val(),

                        longitude : $("#longitude").val(),

                         _token: '{{csrf_token()}}',

                    },

                    success: function (response) {

                        $(button).button("reset");

                        $("#txt_status").val('');

                        if (response == '"success"') {

                            alert("Soulfy status updated");

                            setTimeout(function () {

                            }, 1000);

                        } else if (response == '"error"') {

                            alert("the URL you entered is wrong");

                        } else if (response == '"null"') {

                            alert("Please type your status");

                        }

                        ;

                    },

                    error : function(){

                        $(button).button("reset");

                    }

                });

            }

        }



        $("#page").click(function (e) {

            e.preventDefault();

            var pages_name = $("#pages_name").val();

            var pages_title = $("#pages_title").val();

            var pages_content = CKEDITOR.instances['pages_content'].getData();

            let data = $('#editor').text();

            console.log(data);

            $.ajax({

                type: "POST",

                url: "{{ route('pages.store') }}",

                dataType: "text",

                data: {

                    pages_name : pages_name,

                    pages_title : pages_title,

                    pages_content : pages_content,

                    _token: '{{csrf_token()}}'

                },

                success: function (response) {

                    if (response=='"error"') {

                        alert("Please enter all the details");

                    };

                }

            })

        });



        $("#gallery").click(function(e){

            e.preventDefault();

             var galleryImage = galleryimg;

            $.ajax({

                method: "POST",

                url: '{{action("BasicsetupController@postGallery")}}',

                data: { 

                    galleryImage : galleryImage ,  

                    _token: '{{csrf_token()}}' 

                },

                success: function (response) {

                    if (response=='"error"') {

                        alert("Please enter all the details");

                    };

                },

            })   

        });



        $("#article").click(function(e){

            e.preventDefault();

            var tittle = $("#article_tittle").val(),

            content = $("#article_content").val();

            content = CKEDITOR.instances["article_content"].getData();



            $.ajax({

                method: "POST",

                url: '{{action("AjaxController@postCreateArticle")}}',

                data: { tittle : tittle, content : content, _token: '{{csrf_token()}}' },

                success: function (response) {

                    if (response=='"error"') {

                        alert("Please enter all the details");

                    };

                },

            })

        });



        $("#menucolor").click(function(e){

            e.preventDefault();

            var menu = $("#menu_color").val();

            $.ajax({

                method: "POST",

                url: '{{ action("SettingController@postMenu")}}',

                data: { menu : menu, _token: '{{csrf_token()}}' },

                success: function (response) {

                    if (response=='"error"') {

                        alert("Please enter all the details");

                    };

                },

            }) 

        });



        $("#pageColor").click(function(e){

            e.preventDefault();

            var navcolor = $("#navcolor").val();

            $.ajax({

                method: "POST",

                url: '{{ action("BasicsetupController@postNavcolor")}}',

                data: { navcolor : navcolor , _token: '{{csrf_token()}}' },

                success: function (response) {

                    if (response=='"error"') {

                        alert("Please enter all the details");

                    };

                },

            }) 

        });



        $("#custommenu").click(function(e){

            e.preventDefault();



            var custom_menu1_link = $("#custom_menu1").val();

            var custom_menu2_link = $("#custom_menu2").val();

            var custom_menu3_link = $("#custom_menu3").val();



            var imageCustom1 = imgcustom1;

            var imageCustom2 = imgcustom2;

            var imageCustom3 = imgcustom3;

            

            console.log(imageCustom1);

            $.ajax({

                method: "POST",

                url: '{{action("BasicsetupController@postCustommenu")}}',

                data: { 

                    imageCustom1 : imageCustom1 ,

                    imageCustom2 : imageCustom2 ,

                    imageCustom3 : imageCustom3 ,

                    custom_menu1_link : custom_menu1_link,

                    custom_menu2_link : custom_menu2_link,

                    custom_menu3_link : custom_menu3_link,  

                    _token: '{{csrf_token()}}' 

                },

                success: function (response) {

                    if (response=='"error"') {

                        alert("Please enter all the details");

                    };

                },

            })   

        });



        $("#followeb").click(function(e){

            e.preventDefault();

            var follow = $("#follow").val();

            $.ajax({

                method: "POST",

                url: '{{ action("BasicsetupController@postFollow")}}',

                data: { follow : follow , _token: '{{csrf_token()}}' },

                

                success: function (response) {

                    if (response=='"success"') {

                        alert("Follow Successfully");

                    };

                },

            }) 

        });



        $("#seo").click(function(e){

            var meta_title = $("#meta_title").val();

            var meta_keyword = $("#meta_keyword").val();

            var meta_description = $("#meta_description").val();            

            $.ajax({

                method: "POST",

                url: '{{action("AjaxController@postUpdateSeo")}}',

                data: { meta_title : meta_title, meta_keyword : meta_keyword, meta_description: meta_description, _token: '{{csrf_token()}}'},

                success: function (response) {

                    if (response=='"error"') {

                        alert("Please enter all the details");

                    };

                },

            })

            return false;

        });



        $("#sslcertificate").click(function(e){

            var ssl = $('#ssl').val();

            console.log(ssl);

            $.ajax({

                url: '{{ action("BasicsetupController@postSsl")}}',

                type: 'post',

                dataType: 'html',

                data: {

                  ssl : ssl,

                  _token: '{{csrf_token()}}'

                },

                success: function (response) {

                    if (response=='"error"') {

                        alert("Please enter all the details");

                    };

                },

            })

            return false;

        });



        function set_ecommerce(setting_el, setting) {

            var beforeText = $(setting_el).html();

            $.ajax({

                method: "POST",

                url: '{{action("SettingController@postReqEcommerce")}}',

                data: {

                  _token: '{{csrf_token()}}'

                },



                beforeSend: function () {

                    var loading_gif = "<img width='24px' src='{{url('')}}/images/loading.gif'/>"

                    $(setting_el).html(loading_gif);

                },

                success: function (response) {

                    if (response=='"error"') {

                        alert("please enter all the details");

                    }

                },

            })

        }



        $("#profileinfo").click(function(e){

            e.preventDefault();

            var info = CKEDITOR.instances['profile_info'].getData();

            console.log(info , 'info');

            $.ajax({

                method: "POST",

                url: '{{action("BasicsetupController@postProfileInfo")}}',

                data: { 

                    info : info ,

                    _token: '{{csrf_token()}}' 

                },

                success: function (response) {

                    if (response=='"error"') {

                        alert("please enter all the details");

                    }

                },

            });

        });



        $("#nextBtn").click(function(e){

            var funding = $('#fund').val();

            $.ajax({

                url: '{{ action("BasicsetupController@postFunding")}}',

                type: 'post',

                dataType: 'html',

                data: {

                  funding : funding,

                  _token: '{{csrf_token()}}'

                },

                success: function (response) {

                    if (response=='"error"') {

                        alert("Please enter all the details");

                    };

                },

            })

            return false;

        });





        $('#nextBtn').click(function(){

            $('#thank-you').show();

            setTimeout(function(){

               window.location.href='{{url("/")}}';

            }, 1000);

        });



        var pfimg = '';

        function encodeImageProfile(element) {  

            var filepf = element.files[0];

            document.getElementById("uploadFile").value = filepf.name;

            var readerpf = new FileReader();

            readerpf.onloadend = function() {

                //console.log('RESULT', readerpf.result);

                pfimg = readerpf.result;

            }

            readerpf.readAsDataURL(filepf);

        }

   

        var bkimg = '';

        function encodeImageBkg(element) {

            var filebk = element.files[0];

            document.getElementById("uploadFile2").value = filebk.name;

            var readerbk = new FileReader();

            readerbk.onloadend = function() {

                console.log('RESULT', readerbk.result);

                bkimg = readerbk.result;

            }

            readerbk.readAsDataURL(filebk);

        }



        var galleryimg = '';

        function encodeImgGallery(element) {

            var filegallery = element.files[0];

            document.getElementById("uploadFileGallery").value = filegallery.name;

            var readergallery = new FileReader();

            readergallery.onloadend = function() {

                

                galleryimg = readergallery.result;

                console.log('RESULT', galleryimg);

            }

            readergallery.readAsDataURL(filegallery);

        }



        var imgcustom1 = '';

        function encodeImgCustom1(element) {

            var filecustom1 = element.files[0];

            document.getElementById("uploadFileCustom1").value = filecustom1.name;

            var readercustom1 = new FileReader();

            readercustom1.onloadend = function() {

                

                imgcustom1 = readercustom1.result;

                console.log('RESULT', imgcustom1);

            }

            readercustom1.readAsDataURL(filecustom1);

        }



        var imgcustom2 = '';

        function encodeImgCustom2(element) {

            var filecustom2 = element.files[0];

            document.getElementById("uploadFileCustom2").value = filecustom2.name;

            var readercustom2 = new FileReader();

            readercustom2.onloadend = function() {

                

                imgcustom2 = readercustom2.result;

                console.log('RESULT', imgcustom2);

            }

            readercustom2.readAsDataURL(filecustom2);

        }



        var imgcustom3 = '';

        function encodeImgCustom3(element) {

            var filecustom3 = element.files[0];

            document.getElementById("uploadFileCustom3").value = filecustom3.name;

            var readercustom3 = new FileReader();

            readercustom3.onloadend = function() {

                

                imgcustom3 = readercustom3.result;

                console.log('RESULT', imgcustom3);

            }

            readercustom3.readAsDataURL(filecustom3);

        }



    </script>

</body>

</html>