<?php
/**
 * Created by PhpStorm.
 * User: khadafi
 * Date: 1/18/2017
 * Time: 7:36 AM
 */
?>

@extends('ecommerce.layouts.index')
@section('title', 'Home')
@section("content")

    <section id="content-desc" class="ecommerce">

        <div class="backend-box backend-box-email">
            <div class="backend-nav">
                <ul style="margin-top: 20px;height: 32px;overflow: auto" class="nav nav-tabs" role="tablist">
                    <li class="active"><a id="tab_setting" href="{{action("EcommerceController@getIndex")}}"
                        >All</a></li>
                    @foreach($category as $data)
                        <li><a id="category_{{$data->id}}"
                               href="{{action("EcommerceController@getCategory",['id'=>$data->id])}}">{{$data->category}}</a>
                        </li>
                    @endforeach
                    @if(Auth::check())
                        <li class="default"><a id="tab_setting" class="loadModal" href="javascript:void(0);"
                                               aria-controls="" role="tab"
                                               data-href="{{action('EcommerceController@anyAddCategory')}}"
                                               data-modal-id="add_category"
                                               data-toggle="tab">Add Category</a></li>
                    @endif
                </ul>
            </div>
            <div class="tab-content backend-detail slimScroll" style="clear:both;">
                @if(Auth::check())
                    <div class="form-btm">

                        <button type="submit" style="padding: 7px 14px;float: none" class="btn btn-bk loadModal"
                                data-href="{{action('EcommerceController@anyAddProduct')}}"
                                data-modal-id="add_product" id="btn_post">Add New Product
                        </button>

                        @if(count($products)<=0)
                            <h4>No products</h4>
                        @endif
                    </div>
                @endif

                <div class="col-md-12">
                    <ul class="widget-products">

                        @foreach($products as $product)
                            <li>
                                <a href="#" data-modal-id="add_product" class="loadModal"
                                   data-href="{{action('EcommerceController@getView',['id'=>$product->id])}}">
                     <span class="img">
                     @if(count($product->images)>0)
                             <img class="img-thumbnail" src="{{$product->images[0]->path}}" alt="">
                         @endif
                     </span>
                                    <span class="product clearfix">
                     <span class="name">
                   {{$product->product_name}}
                     </span>

                     <span class="price">
                     <i class="fa fa-money"></i> Rp {{number_format($product->price)}}
                     </span>
                              <span class="description">{{strlen($product->product_description)>100?substr($product->product_description,0,100)."...":$product->product_description}}</span>
                     </span>
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>

    </section>
@endsection
@endsection