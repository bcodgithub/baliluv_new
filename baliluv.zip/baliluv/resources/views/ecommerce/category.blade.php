<?php
/**
 * Created by PhpStorm.
 * User: khadafi
 * Date: 1/18/2017
 * Time: 7:36 AM
 */
?>

@extends('ecommerce.layouts.index')
@section('title', 'Home')
@section("content")
    <section id="content-desc" class="ecommerce">

        <div class="backend-box backend-box-email">
            <div class="backend-nav">
                <ul style="margin-top: 20px;height: 32px;overflow: auto" class="nav nav-tabs" role="tablist">
                    <li><a id="tab_setting" href="{{action("EcommerceController@getIndex")}}"
                        >All</a></li>
                    @foreach($category as $data)
                        <li class="{{$id==$data->id?'active':''}}"><a id="category_{{$data->id}}"
                                                                      href="{{action("EcommerceController@getCategory",['id'=>$data->id])}}">{{$data->category}}</a>
                        </li>
                    @endforeach
                    @if(Auth::check())
                        <li class="default"><a id="tab_setting" class="loadModal" href="javascript:void(0);"
                                               aria-controls="" role="tab"
                                               data-href="{{action('EcommerceController@anyAddCategory')}}"
                                               data-modal-id="add_category"
                                               data-toggle="tab">Add Category</a></li>
                    @endif
                </ul>
            </div>
            <div class="tab-content backend-detail slimScroll" style="clear:both;">

                @if(Auth::check())
                    <div class="form-btm">

                        <button type="submit" style="padding: 7px 14px;float: none" class="btn btn-bk loadModal"
                                data-href="{{action('EcommerceController@anyAddProduct')}}"
                                data-modal-id="add_product" id="btn_post">Add New Product
                        </button>
                        <a type="btn btn-danger" class="btn btn-danger" href="#" onclick="deleted(this,'{{$id}}')"
                           id="btn_post">Delete Category
                        </a>

                    </div>

                @endif
                <div class="col-md-12" style="margin-top:20px">
                    @if(count($products)<=0)
                        <h4 style="color: #ffffff; text-align: center;margin-top: 10px">No products</h4>
                    @endif
                    <ul class="widget-products">

                        @foreach($products as $product)
                            <li>
                                <a href="#" data-modal-id="add_product" class="loadModal"
                                   data-href="{{action('EcommerceController@getView',['id'=>$product->id])}}">
                     <span class="img">
                     @if(count($product->images)>0)
                             <img class="img-thumbnail" src="{{$product->images[0]->path}}" alt="">
                         @endif
                     </span>
                                    <span class="product clearfix">
                     <span class="name">
                   {{$product->product_name}}
                     </span>

                     <span class="price">
                     <i class="fa fa-money"></i> Rp {{number_format($product->price)}}
                     </span>
                              <span class="description">{{strlen($product->product_description)>100?substr($product->product_description,0,100)."...":$product->product_description}}</span>
                     </span>
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>

    </section>
@endsection
@endsection

@section("js")
    <script>
        function deleted(base, id) {
            var r = confirm("Apakah anda yakin akan menghapus Data ini?");
            if (r != true) {
                return;
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                method: "POST",
                url: "{{action("EcommerceController@postDelete",['id'=>''])}}/" + id,
                data: {id: id},
                beforeSend: function () {
                    $(base).button("loading");
                },
                error: function (msg) {
                    $(base).button("reset");
                    var data = $.parseJSON(msg.responseText);

                    $(base).closest("tr").remove();
                },
                success: function (data) {
                    $(base).button("reset");
                    alert(data.message);
                    window.location = "{{action("EcommerceController@getIndex")}}"
                }
            })

        }
    </script>
@endsection