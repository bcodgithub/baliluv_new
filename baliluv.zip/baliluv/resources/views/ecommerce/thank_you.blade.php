<?php
/**
 * Created by PhpStorm.
 * User: khadafi
 * Date: 2/9/2017
 * Time: 3:56 PM
 */

?>

@extends('ecommerce.layouts.index')
@section('title', 'Home')
@section("content")

    <section id="content-desc" class="profile_commerce">
        <div class="backend-box backend-box-email" style="margin-top: 20px">
            <div class="backend-nav">
               <h1 style="text-align: center;color:#ffffff">Thank you for your order.</h1>
                <p style="text-align: center;color:#ffffff">{{$profile->payment_description}}</p>
            </div>
        </div>
    </section>
@endsection
