<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 8/17/2015
 * Time: 4:00 PM
 */
use Soulfy\Timeline;
use Soulfy\Article;
use Soulfy\Gallery;

$domain = $_SERVER['SERVER_NAME'];

$uri = Request::path();
if ($uri == "home/video") {
    $timeline = Timeline::take(8)->orderBy('updated_at', 'desc')->where('user_id', $user['id'])->where('social', 'youtube')->get();
    $check = Timeline::where('user_id', $user['id'])->where('social', 'youtube')->get();

    for ($i = 0; $i < count($timeline); $i++) {
        $video_id[$i] = explode("/", $timeline[$i]->content);
        $img_url[$i] = "http://img.youtube.com/vi/" . $video_id[$i][4] . "/default.jpg";
    }

} elseif ($uri == "home/articles") {
    $timeline = Timeline::take(8)->orderBy('updated_at', 'desc')->where('user_id', $user['id'])->where('social', 'article')->where('status', '1')->get();
    $check = Timeline::where('user_id', $user['id'])->where('status', '1')->where('social', 'article')->get();


} elseif ($uri == "home/gallery") {
    $timeline = Timeline::take(8)->orderBy('updated_at', 'desc')->where('user_id', $user['id'])->where('social', 'gallery')->get();
    $check = Timeline::where('user_id', $user['id'])->where('social', 'gallery')->get();
} else {
    $timeline = Timeline::take(8)->orderBy('updated_at', 'desc')->where('user_id', $user['id'])->where('status', '1')->get();

    $check = Timeline::get();
    for ($i = 0; $i < count($timeline); $i++) {
        if ($timeline[$i]->social == "youtube") {
            $video_id[$i] = explode("/", $timeline[$i]->content);
            $img_url[$i] = "http://img.youtube.com/vi/" . $video_id[$i][4] . "/default.jpg";
        }
    }
}

$user_setting = \Soulfy\Setting::where('user_id', $user['id'])->join('user_theme', 'user_setting.themes_enable', '=', 'user_theme.themes_enable')->first();


if ($user->image_profile == null) {
    $image_url = $user->fb_profile_image;

} else {
    $image_url = url("") . '/' . $user->image_profile;
}
$fb_image_url = "";
$user_profile = \Soulfy\UserProfile::where('user_id', $user->id)->first();
if ($user_profile) {
    $fb_image_url = '<div id="fb_profile_image"><img onclick="showProfileInfo(this)" data-name="' . $user_profile->name . '"' . ' data-first_name="' . $user_profile->first_name . '" data-last_name="' . $user_profile->last_name . '" data-email="' . $user_profile->email . '" data-url="' . $user_profile->url . '" data-about="' . $user_profile->about . '" data-gender="' . $user_profile->gender . '" data-location="' . $user_profile->location . '" src="' . $user_profile->profile_image . '"/></div>';
}


$isNewVersionAvailable = \Soulfy\Setting::isNewVersionAvailable();

$gallery = Timeline::where('user_id', $user->id)
    ->where('social', 'gallery')
    ->orderBy('created_at', 'desc')
    ->first();

if ($gallery != null) {
    $first_image = url("uploads") . "/" . $gallery->content;
} else {
    $first_image = "http://soulfy.com/soulfy_logo.jpg";
}

$profile = \Soulfy\EcomProfile::where('user_id',$user->id)->first();
if($profile == null){
    $profile = new \Soulfy\EcomProfile();
    $profile->user_id = $user->id;
    $profile->store_image = "http://spasitelbg.com/uploads/no_img.jpg";
    $profile->store_name = "Your Store Name";
    $profile->store_description = "Your Store Description.";
    $profile->save();
}
?>


        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="{{ csrf_token() }}"/>
    <meta property="og:image" content="{{$image_url}}"/>

    <link rel='shortcut icon' type='image/x-icon' href="{{url("")}}/images/favicon.ico"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <title>{{$domain}}</title>
<!--<title>Soulfy - @yield('title')</title>-->
    <!-- Custom styles for this template -->

    <link rel="stylesheet" href="{{url("")}}/css/businesscard.css" media="screen" title="no title" charset="utf-8">
    <link rel="stylesheet" href="{{url("")}}/css/bootstrap.css">


    <!-- Optional theme -->
    <link rel="stylesheet" href="{{url("")}}/css/bootstrap-theme.min.css">
    {{--<link rel="stylesheet" href="{{url("")}}/css/bootstrap-modal.css">--}}

    <link href="{{url('')}}/css/style_2.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/ecommerce.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/dskype.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/demo.html5imageupload.css" rel="stylesheet"/>
    <link href="{{url('')}}/js/croppic/croppic.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/toastr.css" rel="stylesheet"/>

    <link href="{{url('')}}/css/nestednav.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/bootstrap3-wysihtml5.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/timeline.css" rel="stylesheet"/>
    <!--[if lt IE 9]>
    <link href="css/ie.css" rel="stylesheet"/>
    <script src="{{url('')}}/js/html5shiv.js" type="text/javascript"></script>
    <script src="{{url('')}}/js/respond.js" type="text/javascript"></script>
    <![endif]-->
    <!--[if lt IE 10]>
    <link href="css/ie.css" rel="stylesheet"/>
    <script src="{{url('')}}/js/html5shiv.js" type="text/javascript"></script>
    <script src="{{url('')}}/js/respond.js" type="text/javascript"></script>
    <![endif]-->
    @yield('css')
    <script type="text/javascript" src="{{url('')}}/js/jquery-1.10.2.min.js"></script>
    <script>
        $(window).load(function () {
            // Animate loader off screen
            $(".se-pre-con").fadeOut("slow");
            ;
        });
    </script>
    <link rel="stylesheet" href="{{url("")}}/js/perfect-scrollbar/css/perfect-scrollbar.css">
    <style>
        #container {
            position: relative;
            height: 100%; /* Or whatever you want (eg. 400px) */
        }

        .backend-box {
            background: rgba(56, 80, 68, 0.84);
        }

        .disabled:after {
            content: '\A';
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            background: rgba(0, 0, 0, 0.6);
            opacity: 0;
            transition: all 0.5s;
            -webkit-transition: all 0.5s;
            opacity: 1;
        }
    </style>

    <link href="{{url('')}}/css/jquery.filer.css" rel="stylesheet"/>
    <link href="{{url('')}}/js/fotomara/fotorama.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/themes/jquery.filer-dragdropbox-theme.css" rel="stylesheet"/>
</head>
<body id="home">
<div class="se-pre-con"></div>
<!-- BEGIN # MODAL LOGIN -->
<div class="modal_popup  fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
     aria-hidden="true" style="display: none; margin-top: 122px;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" align="center">
                <img class="img-circle" id="img_logo" src="{{asset('images/logo.png')}}" style="background:#67d508;">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                </button>
            </div>


            <!-- Begin # Login Form -->
            <form id="login-form" action="{{action('MemberController@postLogin')}}"
                  data-location="{{action('HomeController@getEmail')}}">
                <div class="modal-body">
                    <div id="div-login-msg">
                        <div id="icon-login-msg" class="glyphicon glyphicon-chevron-right"></div>
                        <span id="text-login-msg">Type your username and password.</span>
                    </div>
                    <input id="login_username" name="email" placeholder="Email" class="form-control" type="text"
                           placeholder="Username (type ERROR for error effect)" required>
                    <input id="login_password" name="password" placeholder="Password" class="form-control"
                           type="password" placeholder="Password" required>

                </div>
                <div class="modal-footer">
                    <div>
                        <button type="submit" class="btn btn-primary btn-lg btn-block" style="background:#67d508;">
                            Login
                        </button>
                    </div>
                </div>
            </form>
            <!-- End # Login Form -->
        </div>
    </div>
</div>
<!-- END # MODAL LOGIN -->


<nav id="w0" class="header navbar-default navbar-fixed-top navbar" role="navigation">
    <div class="menu" style="width: 97%;">

        <div id="w0-collapse" class="collapse- navbar-collapse-">
            <ul class="nav nav-header pull-left">
                <li class="logo-box">
                </li>
            </ul>

            <ul id="w1" class="navbar-nav pull-right nav">
                @if(Auth::check())

                    <li>
                        <h4 class="welcome-txt">Welcome <i class="welcome-username">{{$user['full_name']}} !</i></h4>
                    </li>
                    <li>
                         <span class="photo-profile"> <a id="drop1" href="#" class="dropdown-toggle"
                                                         data-toggle="dropdown">
                                 <img id="image_thumb" width="100%" height="100%"
                                      src="{{url("").'/'.$user->image_profile}}"/>
                                 <b class="caret"></b>

                             </a>
                             @if($isNewVersionAvailable)
                                 <span class="badge badge-danger badge-profile">1</span>
                             @endif
                             <ul id="w2" class="dropdown-menu with-arrow-v2-right">
                                  <li><a href="{{url()}}"><span class="glyphicon glyphicon-home"
                                                                aria-hidden="true"></span> Home</a></li>
                                  <li><a href="{{action('HomeController@getSetting')}}"><span
                                                  class="glyphicon glyphicon-cog"
                                                  aria-hidden="true"> </span> Settings</a>
                                  </li>
                                  <li><a href="#" id="change_background" data-toggle="modal"
                                         data-target="#upload_background_dialog"><span
                                                  class="fa fa-picture-o" aria-hidden="true"> </span> Change
                                          background</a></li>
                                  <li><a href="#" data-toggle="modal" data-target="#info_profile"><span
                                                  class="fa fa-edit" aria-hidden="true"> </span> Change
                                          profile info</a></li>
                                  <li role="separator" class="divider"></li>
                                  <li><a href="{{url("auth/logout")}}"><span class="glyphicon glyphicon-log-out"
                                                                             aria-hidden="true"></span> Logout</a></li>
                              </ul>

                         </span>

                    </li>
                    <li class="unhidden">
                        <a id="soulfy-logo" style="padding: 0"
                           href="http://soulfy.com"><img style="height: 41px; margin-top: 2px; margin-left: 14px;"
                                                         src="{{url('.')}}/images/logo.png"/></a>
                    </li>
                @else
                    <li class="unhidden pull-right">
                        <a id="soulfy-logo" style="padding: 0"
                           href="http://soulfy.com"><img style="height: 41px; margin-top: 2px; margin-left: 14px;"
                                                         src="{{url('.')}}/images/logo.png"/></a>
                    </li>
                    <form class="navbar-form navbar-right" id="form_login" method="post"
                          action="{{ url('/auth/login') }}">
                        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">

                        <div class="form-group">
                            <span class="control-header">Email</span>
                            <span><input type="text" name="email" placeholder="Email" required
                                         class="form-control"/></span>
                        </div>
                        <div class="form-group">
                            <span class="control-header">Password</span>
                            <span><input type="password" name="password" placeholder="Password" required
                                         class="form-control"/></span>
                            <input type="hidden" name="domain" required value="{{$domain}}"/>
                        </div>
                        <div class="form-group">
                            <h3 style="margin-top: 2px;">
                                <button type="submit" id="btn_login"><span class="glyphicon glyphicon-log-in"
                                                                           aria-hidden="true"></span> login
                                </button>
                            </h3>
                        </div>

                    </form>

                @endif
            </ul>
        </div>
    </div>
</nav>

<section class="bg">
    <style>
        .bg-pattern-sm.drop {
            @if($user['background_image'] == "")
             background: url({{url()}}/images/beach.jpg);
            @else
             background: url({{url()}}/{{$user['background_image']}}) no-repeat;
            @endif
             background-size: cover;
            background-attachment: inherit !important;
        }

        .bg-pattern {
            background: url({{url()}}{{$user_setting['source_themes']}}) no-repeat;
        }
    </style>
    <span class="bg-pattern">
      </span>
    <span class="bg-pattern-sm drop">
          <div id="dropzone-overlay" style="display:none;"></div>
      </span>
</section>
@if(Auth::check())
    <form>


        <div class="dropzone cover-upload">

            <div class="dropzone" id="drop-upload" data-resize="true" data-width="700" data-height="640"
                 data-url="{{action('AjaxController@postUploadProfile')}}" style="width: 100%;">
                <input type="file" name="thumb"/>
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
            </div>
            <div id="icon-cu" style="display: none;">
                <span class="glyphicon glyphicon-edit " aria-hidden="true"></span>
            </div>
        </div>


    </form>
@endif
<div id="content_body" style="position: static">
    <section id="content-desc" class="profile_commerce">
        <div class="backend-box backend-box-email" style="margin-top: 20px">
            <div class="backend-nav">
                <!--Card with Media-->
                <div class="media block-update-card">
                    <a class="pull-left" href="{{url('/ecommerce')}}">
                        <img class="media-object update-card-MDimentions" src="{{$profile->store_image}}" alt="...">
                    </a>
                    <div class="media-body update-card-body">
                        <h4 class="media-heading">{{$profile->store_name}}</h4>
                        <p>{{$profile->store_description}}</p>
                        {{--<p>{{$profile->payment_description}}</p>--}}
                    </div>
                    <button type="submit" style="padding: 7px 14px;float: none" class="btn btn-bk loadModal"
                            data-href="{{action('EcommerceController@anyEditProfile')}}"
                            data-modal-id="add_product" id="btn_post">Edit Profile
                    </button>
                </div>
            </div>
        </div>
    </section>

    @yield('content')

</div>

<!-- JavaScript
==================================================
<!-- Placed at the end of the document so the pages load faster -->
<script src="{{url('')}}/js/bootstrap.min.js"></script>
<script src="{{url('')}}/js/jquery.nestednav.js"></script>

<script src="{{url('')}}/js/jquery.form.min.js"></script>
<script src="{{url('')}}/js/jquery.bootstrap-growl.min.js"></script>
{{--<script type="text/javascript" src="{{url('')}}/js/jquery.scrollme.min.js"></script>--}}
<script type="text/javascript" src="{{url('')}}/js/html5imageupload.min.js"></script>
<script type="text/javascript" src="{{url('')}}/js/croppic/croppic.js"></script>
<script src="{{url('')}}/js/jquery.MultiFile.js"></script>
{{--<script src="{{url('')}}/js/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>--}}
<script src="{{url('')}}/js/jquery.slimscroll.min.js"></script>
<!--<script src="{{url('')}}/js/timeline_v1.js"></script>-->
<script src="{{url('')}}/js/bootstrap3-wysihtml5.all.min.js"></script>
<script src="{{url('')}}/js/toastr.min.js" type="text/javascript"></script>
<script src="{{url('')}}/js/jquery.filer.min.js"></script>
<script src="{{url('')}}/js/fotomara/fotorama.js"></script>
<script>
    /*
     * --------------------
     * Ajaxify those forms
     * --------------------
     *
     * All forms with the 'ajax' class will automatically handle showing errors etc.
     *
     */
    $('form.ajax').ajaxForm({
        delegation: true,
        beforeSubmit: function (formData, jqForm, options) {

            $(jqForm[0])
                .find('.error.help-block')
                .remove();
            $(jqForm[0]).find('.has-error')
                .removeClass('has-error');

            var $submitButton = $(jqForm[0]).find('button[type=submit]');
            toggleSubmitDisabled($submitButton);


        },
        uploadProgress: function (event, position, total, percentComplete) {
            $('.uploadProgress').show().html('Uploading Images - ' + percentComplete + '% Complete...    ');
        },
        error: function (data, statusText, xhr, $form) {

            // Form validation error.
            if (422 == data.status) {
                processFormErrors($form, $.parseJSON(data.responseText));
                return;
            }

            showMessage('Whoops!, it looks like the server returned an error.');

            var $submitButton = $form.find('input[type=submit]');
            toggleSubmitDisabled($submitButton);

            $('.uploadProgress').hide();
        },
        success: function (data, statusText, xhr, $form) {
//            TableManaged.refreshTable();

            switch (data.status) {
                case 'success':

                    if ($form.hasClass('reset')) {
                        $form.resetForm();
                    }

                    if ($form.hasClass('closeModalAfter')) {
                        // $('.modal, .modal-backdrop').fadeOut().remove();
                        $form.closest(".modal").modal("hide");
                    }

                    if ($form.hasClass('reload_page')) {
                        // $('.modal, .modal-backdrop').fadeOut().remove();
                       location.reload();
                    }

                    var $submitButton = $form.find('input[type=submit]');
                    toggleSubmitDisabled($submitButton);

                    if (typeof data.message !== 'undefined') {
                        showMessage(data.message);
                    }

                    if (typeof data.runThis !== 'undefined') {
                        eval(data.runThis);
                    }

                    if (typeof data.redirectUrl !== 'undefined') {

                        window.location.href = data.redirectUrl;
                    }

                    break;

                case 'error':
                    processFormErrors($form, data.messages);
                    break;

                default:
                    break;
            }

            $('.uploadProgress').hide();
        },
        dataType: 'json'
    });


    $(".loadModal, [data-invoke~=modal]").off('click');
    $(document.body).unbind(".loadModal, [data-invoke~=modal]");

    $(document.body).on('click', '.loadModal, [data-invoke~=modal]', function (e) {

        var button = this;
        $(this).button("loading");

        var loadUrl = $(this).data('href'),
            cacheResult = $(this).data('cache') === 'on',
            $button = $(this);

        var modal_id = $(this).data("modal-id");

        $('#' + modal_id).remove();

        //remove all modal with same id


        $("div[id^='" + modal_id + "']").each(function (i) {
            $(this).remove();
        });

        $('html').addClass('working');

        var $modal = $('#' + modal_id);

        $.ajax({
            url: loadUrl,
            data: {},
            localCache: cacheResult,
            dataType: 'html',
            success: function (data) {

                $(button).button("reset");

                data = data.replace("id_modal", modal_id);
                $('body').append(data);

                $modal = $('#' + modal_id);


                $modal.modal({
                    'backdrop': 'static'
                });

                $modal.modal('show');

                $modal.on('hidden.bs.modal', function (e) {
                    // window
                    location.hash = '';
                });

                $('html').removeClass('working');

                initApplication();
            }
        }).done().fail(function (data) {
            $(button).button("reset");
            $modal.modal("hide");
            $('html').removeClass('working');
            alert('Whoops!, something has gone wrong.<br><br>' + data.status + ' ' + data.statusText);
        });

        e.preventDefault();
    });

    function toggleSubmitDisabled($submitButton) {

        if ($submitButton.hasClass('disabled')) {
            $submitButton.attr('disabled', false)
                .removeClass('disabled')
                .val($submitButton.data('original-text'));
            return;
        }

        $submitButton.data('original-text', $submitButton.val())
            .attr('disabled', true)
            .addClass('disabled')
            .val('Working...');
    }

    function processFormErrors($form, errors) {
        $.each(errors, function (index, error) {
            var $input = $(':input[name=' + index + ']', $form);

            if ($input.prop('type') === 'file') {
                $('#input-' + $input.prop('name')).append('<div class="help-block error">' + error + '</div>')
                    .parent()
                    .addClass('has-error');
            } else {
                $input.after('<div class="help-block error">' + error + '</div>')
                    .parent()
                    .addClass('has-error');
            }

        });

        var $submitButton = $form.find('input[type=submit]');
        toggleSubmitDisabled($submitButton);
    }


    function showMessage(message) {
        alert(message);
//        location.reload();
    }

    function initSlimScroll() {


        $('.slimScroll').each(function () {
            var height, minus = 150, total = 1;

            if ($(this).attr("data-minus")) {
                minus = $(this).attr("data-minus");
            }

            if ($(this).attr("data-total")) {
                total = $(this).attr("data-total");
            }

            if ($(this).attr("data-height")) {
                height = $(this).attr("data-height");
            } /*else {
             height = $(this).css('height');
             }*/
            else {
                height = ($(window).height() - minus) * total; //$('.backend-box>.slimScrollDiv>.slimScroll').length;//$('.slimScroll').length;
            }

            $(this).slimScroll({
                height: height,
            });
        });
    }
    function initApplication() {
        try {
            $('#filer_input').filer({
                addMore: true,
                allowDuplicates: false,
                limit: 5,
                maxSize: 5,
                extensions: ["jpg", "png", "gif"],
                showThumbs: true
            });
        } catch (ec) {
        }

        try {
            var $fotoramaDiv = $('.fotorama').fotorama();
        } catch (ec) {
        }
    }

    $(document).ready(function () {

        initSlimScroll();

        $(document).on('change', '.btn-file :file', function () {
            var input = $(this),
                label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
            input.trigger('fileselect', [label]);
        });

        $('.btn-file :file').on('fileselect', function (event, label) {

            var input = $(this).parents('.input-group').find(':text'),
                log = label;

            if (input.length) {
                input.val(log);
            } else {
                if (log) alert(log);
            }

        });
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#img-upload').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imgInp").change(function () {
            readURL(this);
        });
    });
</script>
{{--<script type="text/javascript" src="{{url(".")}}/js/support6d23.js?version=7.135"></script>--}}
{{--<script type="text/javascript" src="{{url(".")}}/js/latest6d23.js?version=7.135"></script>--}}
@yield('js')

<div style="position: fixed; top: 50px; left: 50%; display: none; z-index: 9999;" id="notification">
    <div class="alert alert-danger alert-dismissible" style="left: -50%; position: relative; display: none;"
         id="new-update-available">
        <button class="close" data-dismiss="alert" type="button"><span aria-hidden="true">×</span><span class="sr-only">Close</span>
        </button>
        A New version is available. Please <a href="{{action('HomeController@getUpdateSystem')}}">Click here</a> to
        update your site.
    </div>
</div>

<div class="timeline-loader-lock tl-loader"></div>
<div class="timeline-loader tl-loader"></div>

</body>
</html>