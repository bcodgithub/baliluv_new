<div role="dialog" class="modal fade modal-lg " id="id_modal" style="display: none;background: #FFF;">
    <form role="form" id="" class="form-create" method="post"
          action="https://apps.myshortcart.com/payment/request-payment/">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <h4 class="modal-title">Pembelian untuk produk "{{$product->product_name}}"</h4>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Name</label>
                    <input type="text" name="CNAME" placeholder="Name" required
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Email</label>
                    <input type="text" name="CEMAIL" placeholder="Email" required
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Mobile Phone Number</label>
                    <input type="text" name="CWPHONE" placeholder="Mobile Phone Number" required
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Office Phone Number</label>
                    <input type="text" name="CHPHONE" placeholder="Office Phone Number" required
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Home Phone Number</label>
                    <input type="text" name="CMPHONE" placeholder="Home Phone Number" required
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Address</label>
                    <input type="text" name="CADDRESS" placeholder="Address" required
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Shipping Address</label>
                    <input type="text" name="SADDRESS" placeholder="Shipping Address" required
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Shipping Zip Code</label>
                    <input type="text" name="SZIPCODE" placeholder="Shipping Zip Code" required
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Shipping City</label>
                    <input type="text" name="SCITY" placeholder="Shipping City" required
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Shipping State</label>
                    <input type="text" name="SSTATE" placeholder="Shipping State" required
                           style="border: 1px solid #F1F1F1;"/>
                    <input type="hidden" name="SCOUNTRY" value="Indonesia">
                </div>
            </div>
        </div>
        <input type="hidden" name="WORD" value="{{sha1($product->price.".00l6R3W2g8S4k7"."0001")}}">
        <input type=hidden name="URL" value="http://www.soulfy.com/">
        <input type=hidden name="AMOUNT" value="{{$product->price}}.00">
        <input type=hidden name="TRANSIDMERCHANT" value="0001">
        <input type=hidden name="STOREID" value="00164876">
        <input type=hidden name="BASKET" value="{{$product->product_name}},{{$product->price}}.00,1,{{$product->price}}.00">
        <div class="modal-footer">
            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
            <button type="submit"  class="btn btn-danger">Continue</button>

        </div>
        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
    </form>
</div>