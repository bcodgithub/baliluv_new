<div role="dialog"  class="modal fade modal-xs " id="id_modal" style="display: none;background: #FFF;">
    <form role="form" id="" class="form-create ajax" method="post"
          action="{{action("EcommerceController@anyAddCategory")}}">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <h4 class="modal-title">Add New category</h4>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <div class="col-group">
                    <input type="text" name="category" placeholder="Category Name"
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
            <button type="submit" class="btn btn-success">Submit</button>
        </div>
        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
    </form>
</div>