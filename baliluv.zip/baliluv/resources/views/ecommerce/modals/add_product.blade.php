<div role="dialog"  class="modal fade modal-xs " id="id_modal" style="display: none;background: #FFF;">
    <form role="form" id="" class="form-create ajax" method="post"
          action="{{action("EcommerceController@anyAddProduct")}}">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <h4 class="modal-title">Add New Product</h4>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Product Name</label>
                    <input type="text" name="product_name" placeholder="Product Name" required
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Stock</label>
                    <input type="number" name="stock" placeholder="Stock" required
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>

            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Price</label>
                    <input type="text" name="price" placeholder="Price" required
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label ">Image</label>
                <div style="position:relative;">
                    <input type="file" name="files[]" id="filer_input" multiple="multiple">
                </div>
            </div>
            <div class="form-group">
                <div class="form-group">

                   <label class="control-label ">Category</label>
                    <select class="form-control" name="category_id" required>
                        <option> Pilih Category</option>
                      @foreach($categories as $category)
                            <option value="{{$category->id}}">{{$category->category}}</option>
                          @endforeach
                    </select>
                </div>
            </div>
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Description</label>
                    <textarea name="description" rows="5" style="border: 1px solid #F1F1F1;"></textarea>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
            <button type="submit" class="btn btn-success">Submit</button>
        </div>
        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
    </form>

</div>