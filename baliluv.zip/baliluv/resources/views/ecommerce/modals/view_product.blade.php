<div role="dialog" class="modal fade modal-lg " id="id_modal" style="display: none;background: #FFF;">
    <form role="form" id="" class="form-create ajax" method="post"
          action="{{action("EcommerceController@anyAddCategory")}}">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <h4 class="modal-title">{{$product->product_name}}</h4>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-6">

                    <div class="fotorama" data-nav="thumbs">

                        @foreach($product->images as $image)
                            <img src="{{$image->path}}">

                        @endforeach
                    </div>
                </div>
                <div class="col-md-6">
                    <p style="color: #000000">{{$product->product_description}}</p>

                    <label style="padding:5px" class="alert alert-success small">{{$product->qty}} In Stock</label>
                    <br>
                    <label style="font-size: 16px;font-weight: 600"> Rp {{number_format($product->price)}}</label>

                    <div class="form-group">
                        <label class="control-label ">Qty</label>
                        <input type="text" name="qty" placeholder="Quantity" required
                               style="border: 1px solid #F1F1F1;    height: 31px;width:150px"/>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
            <button type="button"  class="btn btn-danger loadModal"  data-href="{{action('EcommerceController@anyBuy',['id'=>$product->id])}}"
                    data-modal-id="buy_product">Buy now</button>

        </div>
        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
    </form>
</div>