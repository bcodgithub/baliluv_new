<div role="dialog"  class="modal fade modal-xs " id="id_modal" style="display: none;background: #FFF;">
    <form role="form" id="" class="form-create ajax reload_page" method="post" enctype="multipart/form-data"
          action="{{action("EcommerceController@anyEditProfile")}}">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <h4 class="modal-title">Payment Information</h4>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Store Name</label>
                    <input type="text" name="store_name" placeholder="Store Name" required value="{{$profile->store_name}}"
                           style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>

            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Description</label>
                    <textarea name="store_description" rows="5" required style="border: 1px solid #F1F1F1;" placeholder="Store Description">{{$profile->store_description}}</textarea>
                </div>
            </div>
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Payment Description</label>
                    <textarea name="store_payment" rows="5" required style="border: 1px solid #F1F1F1;" placeholder="Payment Description">{{$profile->payment_description}}</textarea>
                </div>
            </div>
            <div class="form-group">
                <div class="col-group">
                    <label class="control-label ">Current Store Profile Image</label>
                    <img width="100px" height="100px" class="media-object update-card-MDimentions" src="{{$profile->store_image}}" alt="...">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label ">Upload new Store Profile Image</label>
                <div style="position:relative;">
                    <input type="file" name="files" id="store_image_profile" multiple="multiple">
                </div>
            </div>


        </div>
        <div class="modal-footer">
            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>

        </div>
        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
    </form>

</div>

<script>
    $('#store_image_profile').filer({
        allowDuplicates: false,
        limit: 1,
        maxSize: 5,
        extensions: ["jpg", "png", "gif"],
        showThumbs: true
    });
</script>