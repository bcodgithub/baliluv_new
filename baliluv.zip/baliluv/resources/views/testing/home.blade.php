<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 10/19/2015
 * Time: 9:43 AM
 */

        ?>


@extends('testing.layout_bootstrap')

@section('title', 'Home')

@section('content')

@endsection
