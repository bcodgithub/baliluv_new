<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 8/17/2015
 * Time: 4:00 PM
 */

$domain = $_SERVER['SERVER_NAME'];
?>


        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="{{ csrf_token() }}"/>

    <title>Soulfy - @yield('title')</title>
    <!-- Custom styles for this template -->


    <link rel="stylesheet" href="{{url("")}}/css/bootstrap.min.css">

    <!-- Optional theme -->
    <link rel="stylesheet" href="{{url("")}}/css/bootstrap-theme.min.css">

    <link href="{{url('')}}/css/style_2.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/demo.html5imageupload.css" rel="stylesheet"/>
    <link href="{{url('')}}/js/croppic/croppic.css" rel="stylesheet"/>

    <link href="{{url('')}}/css/nestednav.css" rel="stylesheet"/>

    <!--[if lt IE 9]>
    <link href="css/ie.css" rel="stylesheet"/>
    <script src="{{url('')}}/js/html5shiv.js" type="text/javascript"></script>
    <script src="{{url('')}}/js/respond.js" type="text/javascript"></script>
    <![endif]-->
    <!--[if lt IE 10]>
    <link href="css/ie.css" rel="stylesheet"/>
    <script src="{{url('')}}/js/html5shiv.js" type="text/javascript"></script>
    <script src="{{url('')}}/js/respond.js" type="text/javascript"></script>
    <![endif]-->

</head>
<body id="home">

<header style="position: fixed; top: 0px; width: 100%; z-index: 100;">
    <div class="container">
        <div class="row">
            <div class="nav-header">

                @if(Auth::check())
                    <form class="form-inline" id="form_login" method="post" action="{{ url('/auth/login') }}">

                        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
                        <ul class="nav-right">
                            <li>
                                <span class="control-header">Welcome {{Auth::User()->full_name}}</span>
                            </li>

                            <li class="logo-box">
                                <a href="#"><img src="{{url(".")}}/images/logo.png"/></a>
                            </lI>
                        </ul>
                    </form>

                @else
                    <form class="form-inline" id="form_login" method="post" action="{{ url('/auth/login') }}">

                        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
                        <ul class="nav-right">
                            <li>
                                <div class="form-group">
                                    <span class="control-header">email</span>
                                    <span><input type="text" name="email" required class="form-control"/></span>
                                </div>
                            </li>
                            <li>
                                <div class="form-group">
                                    <span class="control-header">password</span>
                                    <span><input type="password" name="password" required class="form-control"/></span>
                                </div>
                            </li>
                            <li>
                                <h3>
                                    <button type="submit" id="btn_login">login</button>
                                </h3>
                            </li>
                            <li class="logo-box">
                                <a href="#"><img src="{{url(".")}}/images/logo.png"/></a>
                            </lI>
                        </ul>
                    </form>
                @endif


            </div>
        </div>
    </div>
</header>

@yield("content");

</body>

<!-- JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script type="text/javascript" src="{{url('')}}/js/jquery-1.10.2.min.js"></script>
<script src="{{url('')}}/js/bootstrap.min.js"></script>
<script src="{{url('')}}/js/jquery.nestednav.js"></script>

<script src="{{url('')}}/js/jquery.form.min.js"></script>
<script src="{{url('')}}/js/jquery.bootstrap-growl.min.js"></script>
<script type="text/javascript" src="{{url('')}}/js/jquery.scrollme.min.js"></script>
<script type="text/javascript" src="{{url('')}}/js/html5imageupload.min.js"></script>
<script type="text/javascript" src="{{url('')}}/js/croppic/croppic.js"></script>
<script src="{{url('')}}/js/query.multiFile.js"></script>
@yield('js')


</html>
