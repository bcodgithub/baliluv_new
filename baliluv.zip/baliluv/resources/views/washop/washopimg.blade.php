<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title->meta_title }}</title>
    <meta name="description" content="{{ $title->meta_description }}">
    <meta name="keywords" content="{{ $title->meta_keyword }}">
    <meta name="author" content="">
    <meta name="csrf-token" content="{{ csrf_token() }}"/>
    <link rel='shortcut icon' type='image/x-icon' href="{{url('')}}/images/favicon.ico"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <title>{{$domain}}</title>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/plug-ins/9dcbecd42ad/integration/jqueryui/dataTables.jqueryui.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
<body>
    
    <div class="container-fluid">
        <div class="row" style="padding-top: 20px;">
            <div class="col-md-4 col-xs-12 col-12">
                <label>Domain Name : </label>
                <label><b><i>{{$domain}}</i></b></label><hr>
            </div>
            <div class="col-md-4 col-xs-12 col-12">
                <label>Username : </label>
                <label><b>{{$user_setting->wa_username}}</b></label><hr>
            </div>
            <div class="col-md-4 col-xs-12 col-12">
                <label>WhatsApp Number : </label>
                <label><b>+{{$user_setting->wa_number}}</b></label><hr>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <a href="{{url('/home/wadetails')}}" style="text-decoration: none; "> VISITORS DATA </a>
            </div>
        </div><br>
        <div class="row">
            <div class="col-12" style="text-align: center;">
                <h2>WASHOP </h2> <a href="{{url('/home/exportdata')}}" class="btn btn-info">Download Data</a>
            </div>
        </div><br>
        <table id="table_id" class="table table-condensed table-striped table-hover">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Username</th>
                    <th>WhatsApp Number</th>
                    <th>Price</th>
                    <th>Title</th>
                </tr>
            </thead>
            <tbody>
                @foreach($byimgData as $surat)
                <tr>
                    <td>{{ date_format (new DateTime($surat->imgDate), 'd-F-Y')}}</td>
                    <td>{{$surat->username}}</td>
                    <td>+{{$surat->number}}</td>
                    <td>{{$surat->price}}</td>
                    <td>{{$surat->title}}</td>
                </tr>
                @endforeach
            </tbody>
            <tfoot>
                <th>Date</th>
                <th>Username</th>
                <th>WhatsApp Number</th>
                <th>Price</th>
                <th>Title</th>
            </tfoot>
        </table>
    </div>
    
    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/plug-ins/9dcbecd42ad/integration/jqueryui/dataTables.jqueryui.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    
    <script type="text/javascript">
        $(document).ready(function() {
            $('#table_id').DataTable( {
                "order": [[ 0, "desc" ]],
                "scrollX": true,
                "pageLength": 20,
                "columnDefs": [
                    { "width": "20%", "targets": 0 }
                ]
            });
        });
    </script>
</body>
</html>