<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title->meta_title }}</title>
    <meta name="description" content="{{ $title->meta_description }}">
    <meta name="keywords" content="{{ $title->meta_keyword }}">
    <meta name="author" content="">
    <meta name="csrf-token" content="{{ csrf_token() }}"/>
    <link rel='shortcut icon' type='image/x-icon' href="{{url('')}}/images/favicon.ico"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <title>{{$domain}}</title>

    <link rel="stylesheet" href="https://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/plug-ins/9dcbecd42ad/integration/jqueryui/dataTables.jqueryui.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style type="text/css">
        #rv_modal{
            text-align: center !important;
            opacity: 1;
            top: 10%;
            z-index: 999999;
        }
        #test{
            text-align: center;
            margin: auto;
            height: auto;
            top: 10%;
            width: 30%;
            background-color :#aaa;
        }
        

        @media (max-width: 640px){
            #test{
                width: 70%;
            }
        }
        @media (max-width: 480px) {
            #test{
                width: 100%;
            }
        }
    </style>
</head>
<body>
    
    <div class="container-fluid">
        <div class="row" style="padding-top: 20px;">
            <div class="col-md-4 col-xs-12 col-12">
                <label>Domain Name : </label>
                <label><b><i>{{$domain}}</i></b></label><hr>
            </div>
            <div class="col-md-4 col-xs-12 col-12">
                <label>Username : </label>
                <label><b>{{$user_setting->wa_username}}</b></label><hr>
            </div>
            <div class="col-md-4 col-xs-12 col-12">
                <label>WhatsApp Number : </label>
                <label><b>+{{$user_setting->wa_number}}</b></label><hr>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <a href="{{url('/home/washop')}}" style="text-decoration: none; ">WASHOP DATA</a>
            </div>
        </div><br>
        <div class="row">
            <div class="col-12" style="text-align: center;">
                <h2>Visitors Data </h2> <a href="{{url('/home/likedata')}}" class="btn btn-info">Download Data</a>
            </div>
        </div><br>
        <table id="table_id" class="table table-condensed table-striped table-hover">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Username</th>
                    <th>WhatsApp Number</th>
                    <th>R.V.</th>        
                </tr>
            </thead>
            <tbody>
                @foreach($waData as $surat)
                <tr>
                    <td>{{$surat->created_at}}</td>
                    <?php
                       $countdata = \DB::table('returning_visitors')->where('user_id',$user->id)->where('whatsap_id',$surat->id)->count(); 
                    ?>
                    <td>{{$surat->username}}</td>
                    <td>+{{$surat->number}}</td>
                    <td>{{$countdata}}</td>
                </tr>
                @endforeach
            </tbody>
            <tfoot>
                <th>Date</th>
                <th>Username</th>
                <th>WhatsApp Number</th>
                <th>R.V.</th>
            </tfoot>
        </table>
    </div>

    
    
    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/plug-ins/9dcbecd42ad/integration/jqueryui/dataTables.jqueryui.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    
    <script type="text/javascript">
        $(document).ready(function() {
            $('#table_id > tbody > tr:odd').removeClass('odd');
            $('#table_id > tbody > tr:even').removeClass('even');

            $('#table_id > tbody > tr > td').removeClass('sorting_1');
            
            $('#table_id').DataTable( {
                "bPaginate": true,
                "scrollX": true,
                "pageLength": 20,
                "columnDefs": [
                    { "width": "20%", "targets": 0 }
                ]
            });
        });
    </script>
    <script type="text/javascript">
        function rvData(rvId){
            document.getElementById("rv_modal").style.display = "block";
            $.ajax({
               method: "POST",
                url: '{{action("ImageController@postRvdata")}}',
                data: {
                    rvId : rvId ,
                    _token: '{{csrf_token()}}' 
                },
                success: function (response) {
                    $('#newData').empty();
                    for (var i = 0; i < response.length; i++) {
                        let readData = response[i];
                        newOption = $('<tr id='+rvId+'><td>'+readData.rvdate+'</td><td>'+readData.username+'</td><td>+'+readData.number+'</td></tr>');
                        $('#newData').append(newOption);
                    }
                }
            });
        }

        function rvclose(){
            $('#newData').empty();
            document.getElementById('rv_modal').style.display = 'none';
        }
    </script>
    <div aria-hidden="false" style="background-color: rgba(0,0,0,0);" id="rv_modal" class="modal fade in" tabindex="-1" data-focus-on="input:first">
        <div role="form" class="form-create" method="post" id='test'>
            <div class="modal-header">
                <h4 class="modal-title">Returning Visitor Data</h4>
                <span class="close cursor" onclick="rvclose()">&times;</span>
            </div>
            <input type="hidden" name="imgId" id="imgId">
            <input type="hidden" name="imgPrice" id="imgPrice">
            <div class="modal-body">
                <table id="rvtable" border="1">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Username</th>
                            <th>WhatsApp Number</th>
                        </tr>
                    </thead>
                    <tbody id="newData">
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>