<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 8/17/2015
 * Time: 4:00 PM
 */

$domain = $_SERVER['SERVER_NAME'];
?>


        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="{{ csrf_token() }}"/>

    <title>Soulfy - @yield('title')</title>
    <!-- Custom styles for this template -->


    <link rel="stylesheet" href="{{url("")}}/css/bootstrap.min.css">

    <!-- Optional theme -->
    <link rel="stylesheet" href="{{url("")}}/css/bootstrap-theme.min.css">

    <link href="{{url('')}}/css/style_2.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/demo.html5imageupload.css" rel="stylesheet"/>
    <link href="{{url('')}}/js/croppic/croppic.css" rel="stylesheet"/>

    <link href="{{url('')}}/css/nestednav.css" rel="stylesheet"/>

    <!--[if lt IE 9]>
    <link href="css/ie.css" rel="stylesheet"/>
    <script src="{{url('')}}/js/html5shiv.js" type="text/javascript"></script>
    <script src="{{url('')}}/js/respond.js" type="text/javascript"></script>
    <![endif]-->
    <!--[if lt IE 10]>
    <link href="css/ie.css" rel="stylesheet"/>
    <script src="{{url('')}}/js/html5shiv.js" type="text/javascript"></script>
    <script src="{{url('')}}/js/respond.js" type="text/javascript"></script>
    <![endif]-->

</head>
<body id="home">
<div id="main-nav">
    <ul class="nav navbar-nav">
        <li><a href="#">Google</a></li>
        <li><a href="#">Yahoo</a></li>
        <li class="dropdown">
            <a aria-expanded="false" role="button" data-toggle="hover" class="dropdown-toggle" href="#">Fruit</a>
            <ul class="dropdown-menu">
                <li><a href="#">Watermelon</a></li>
                <li><a href="#">Oranges</a></li>
                <li class="dropdown-submenu">
                    <a aria-expanded="false" role="button" data-toggle="dropdown" class="dropdown-toggle">Better
                        Fruit</a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Strawberries</a></li>
                        <li><a href="#">Bananas</a></li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</div>
<header style="position: fixed; top: 0px; width: 100%; z-index: 100;">
    <div class="" style="">
        <div class="row">

            <div class="nav-header">
                @if(Auth::check())

                    <ul class="nav-right">
                        <li>
                            <h4 class="welcome-txt">Welcome!</h4>
                        </li>
                        <li>
                         <span class="photo-profile"><a href="#">
                                 <img id="image_thumb" width="100%" height="100%"
                                      src="{{url("")}}/{{$user->image_profile}}"/>
                             </a></span>
                        </li>
                        <li class="logo-box">
                            <a href="#"><img src="{{url('.')}}/images/logo.png"/></a>


                        </lI>
                    </ul>
                @else
                    <form class="form-inline" id="form_login" method="post" action="{{ url('/auth/login') }}">

                        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
                        <ul class="nav-right">
                            <li>
                                <div class="form-group">
                                    <span class="control-header">email</span>
                                    <span><input type="text" name="email" required class="form-control"/></span>
                                </div>
                            </li>
                            <li>
                                <div class="form-group">
                                    <span class="control-header">password</span>
                                    <span><input type="password" name="password" required class="form-control"/></span>
                                </div>
                            </li>
                            <li>
                                <h3>
                                    <button type="submit" id="btn_login">login</button>
                                </h3>
                            </li>
                            <li class="logo-box">
                                <a href="#"><img src="{{url("")}}/images/logo.png"/></a>
                            </lI>
                        </ul>
                    </form>
                @endif
            </div>
        </div>
    </div>
</header>

<div id="content_body" style="position: static">


    @yield('content')

    <section id="content">
        <div class="container">
            <div class="row">
                <div class="selector">
                    <ul class="social-media-box">
                        <li>
                            <input id="c1" type="checkbox">
                            <label for="c1"><a href="#"><img src="{{url("")}}/images/button-01.png"/></a></label>
                        </li>
                        <li>
                            <input id="c2" type="checkbox">
                            <label for="c2"><a href="http://callback.soulfy.com/facebook/login?domain={{$domain}}"><img
                                            src="{{url("")}}/images/button-02.png"/></a></label>
                        </li>
                        <li>
                            <input id="c3" type="checkbox">
                            <label for="c3"><a href="http://callback.soulfy.com/twitter/login?domain={{$domain}}"><img
                                            src="{{url("")}}/images/button-03.png"/></a></label>
                        </li>
                        <li>
                            <input id="c4" type="checkbox">
                            <label for="c4"><a href="#"><img src="{{url("")}}/images/button-04.png"/></a></label>
                        </li>
                        <li>
                            <input id="c5" type="checkbox">
                            <label for="c5"><a href="#"><img src="{{url("")}}/images/button-05.png"/></a></label>
                        </li>
                        <li>
                            <input id="c6" type="checkbox">
                            <label for="c6"><a href="http://callback.soulfy.com/google/login?domain={{$domain}}"><img
                                            src="{{url("")}}/images/button-06.png"/></a></label>
                        </li>
                        <li>
                            <input id="c7" type="checkbox">
                            <label for="c7"><a href="#"><img src="{{url("")}}/images/button-07.png"/></a></label>
                        </li>
                        <li>
                            <input id="c8" type="checkbox">
                            <label for="c8"><a href="http://callback.soulfy.com/google/login?domain={{$domain}}"><img
                                            src="{{url("")}}/images/button-08.png"/></a></label>
                        </li>
                        <li>
                            <input id="c8" type="checkbox">
                            <label for="c8"><a href="{{action('HomeController@getGallery')}}"><img
                                            src="{{url("")}}/images/button-09.png"/></a></label>
                        </li>
                        <li>
                            <input id="c8" type="checkbox">
                            <label for="c8"><a href="{{action('HomeController@getEmail')}}"><img
                                            src="{{url("")}}/images/button-10.png"/></a></label>
                        </li>
                        <li>
                            <input id="c8" type="checkbox">
                            <label for="c8"><a href="{{action('HomeController@getSocial')}}"><img
                                            src="{{url("")}}/images/button-11.png"/></a></label>
                        </li>
                    </ul>
                    <div id="profile_image">
                        <button>
                            <span>
                               <div id="prossfile_pict">

                                   @if(Auth::check())
                                       <img id="profile_picture" src="{{url("")}}/{{$user->image_profile}}"/>
                                   @else
                                       <img id="profile_picture" src="{{url("")}}/{{$user->image_profile}}"/>
                                   @endif

                               </div>

                            </span>
                        </button>
                        {{--<div class="dropzone" id="edit_image" data-width="176" data-height="174" data-resize="true" data-url="{{action('AjaxController@postUploadProfile')}}" style="width: 176px;height: 174px;left: 0px;display: none;">--}}
                        {{--<input type="file" id="profilefileupload" name="thumb" />--}}
                        {{--</div>--}}
                        <div id="image_upload"></div>
                        <div id="profile_image_edit" style="display: none;">
                            <a href="#" id="btn_upload" onclick="javascript:editProfile();" class="btn btn-info btn-sm"><span
                                        class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                        </div>

                        {{--<div id="profile_pict" class="dropzone" data-resize="true" data-url="canvas.php">--}}
                        {{--<img src="{{url("")}}/images/user1.png"/>--}}
                        {{--<input type="file" id="profilefileupload" name="thumb" />--}}
                        {{--</div>--}}
                    </div>
                </div>
            </div>
        </div>
        {{--<div class="stats-box stats1">--}}
            {{--<div class="stats stats-fb">--}}
                {{--<p>--}}
                    {{--Hello World!!<br/>--}}
                    {{--Let the world know--}}
                {{--</p>--}}
                {{--<span class="left">Jakarta</span>--}}
                {{--<span class="right">2 Juni 2015</span>--}}

                {{--<div class="stats-nav">--}}
                    {{--<a href="#" class="btn-circle btn1">C</a>--}}
                    {{--<a href="#" class="btn-circle btn2">L</a>--}}
                {{--</div>--}}
            {{--</div>--}}
        {{--</div>--}}
        {{--<div class="stats-box stats2">--}}
            {{--<div class="stats stats-twitter">--}}
                {{--<p>--}}
                    {{--Apa Kabar Dunia<br/>--}}
                    {{--Hong Kong Hujan Nih--}}
                {{--</p>--}}
                {{--<span class="left">Jakarta</span>--}}
                {{--<span class="right">2 Juni 2015</span>--}}

                {{--<div class="stats-nav">--}}
                    {{--<a href="#" class="btn-circle btn1">C</a>--}}
                    {{--<a href="#" class="btn-circle btn2">L</a>--}}
                {{--</div>--}}
            {{--</div>--}}
        {{--</div>--}}
        <div id="status_container"></div>

    </section>
</div>


<!-- JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script type="text/javascript" src="{{url('')}}/js/jquery-1.10.2.min.js"></script>
<script src="{{url('')}}/js/bootstrap.min.js"></script>
<script src="{{url('')}}/js/jquery.nestednav.js"></script>

<script src="{{url('')}}/js/jquery.form.min.js"></script>
<script src="{{url('')}}/js/jquery.bootstrap-growl.min.js"></script>
<script type="text/javascript" src="{{url('')}}/js/jquery.scrollme.min.js"></script>
<script type="text/javascript" src="{{url('')}}/js/html5imageupload.min.js"></script>
<script type="text/javascript" src="{{url('')}}/js/croppic/croppic.js"></script>
<script src="{{url('')}}/js/jquery.MultiFile.js"></script>
@yield('js')

<script type="text/javascript">


    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var cropperOptions = {
        customUploadButtonId: 'btn_upload',
        outputImageId: 'profile_picture',
        outputImagetThumb: 'image_thumb',
        onBeforeImgUpload: function () {
            $("#image_upload").css('display', 'block');
        },
        onAfterImgUpload: function () {
            $("#image_upload").css('display', 'none');
        },
        onAfterImgCrop: function () {
            cropperHeader.reset()
        },

        modal: true,
        uploadUrl: '{{action('AjaxController@postUploadimage')}}',
        cropUrl: '{{action('AjaxController@postCropimage')}}',
        loaderHtml: '<div class="loader bubblingG"><span id="bubblingG_1"></span><span id="bubblingG_2"></span><span id="bubblingG_3"></span></div> ',
    }

    var cropperHeader = new Croppic('image_upload', cropperOptions);

    var nbOptions = 11; // number of menus
    var angleStart = -360; // start angle
    $('.dropzone').html5imageupload({
        onAfterProcessImage: function () {
            // $("#edit_image").css('display','none');
            $("#prossfile_pict img").attr("src", '{{url('')}}' + $(this.element).data('name'));
            $("#edit_image").css('display', 'none');
        },
        onAfterCancel: function () {
            $("#edit_image").css('display', 'none');
        }
    });
    // jquery rotate animation
    function rotate(li, d) {
        $({d: angleStart}).animate({d: d}, {
            step: function (now) {
                $(li)
                        .css({transform: 'rotate(' + now + 'deg)'})
                        .find('label')
                        .css({transform: 'rotate(' + (-now) + 'deg)'});
            }, duration: 0
        });
    }

    function editProfile() {
        $('#profilefileupload').click();
        $("#edit_image").css('display', 'inline-block');
    }

    drawStatus();

    //    $(window).scroll(function () {
    //        console.log(1);
    //        $('div[id^="status"]').each(function (index) {
    //           // alert(1);
    //        });
    //    });

    var scale = 0.1;  // scale of the image
    var xLast = 100;  // last x location on the screen
    var yLast = 20;  // last y location on the screen
    var xImage = 100; // last x location on the image
    var yImage = 20; // last y location on the image


    function drawStatus() {
        var height = 2000;
        var left =500;
        var top = 0;
        for (i = 0; i < 2; i++) {

            var template = '<div data-scroll="'+height+'" id="status_'+i+'" class="stats-box stats2 status" style="left:' + left + 'px;top: ' + top + 'px">' +
                    '<div class="stats stats-twitter">' +
                    '<p>Apa Kabar Dunia<br/>Hong Kong Hujan Nih</p>' +
                    '<span class="left">Jakarta</span>' +
                    '<span class="right">2 Juni 2015</span>' +
                    '<div class="stats-nav"><a href="#" class="btn-circle btn1">C</a>' +
                    '<a href="#" class="btn-circle btn2">L</a>' +
                    '</div>' +
                    '</div>' +
                    '</div>';
            $("#status_container").append(template);
            $("#status_container").css("height", height + "px");

            height += 2000;
            //top += 250;

        }
    }


    $(function () {
        var windows_height = ($(window).height());
        var object = ["#status_0","#status_1"];
        var index_obj = 0;
        var lastScrollTop = 0;
        $(window).scroll(function () {
            var $horizontal = $(object[index_obj]);
            var ele_height = $(object[index_obj]).height();
            var ele_scroll_limit = $(object[index_obj]).data("scroll");
            prev_limit = 0;

            var s = $(this).scrollTop(),
                    d = $(document).height(),
                    c = $(this).height();
            scrollPercent = (s / (d - c));

            var position = (scrollPercent * ($(window).width() - $horizontal.width()));
            console.log("Position :" + position +"; windows height : "+windows_height+"; Element Height : " + ele_height+"; Document Height : "+d);
            console.log("Document Height : "+ (scrollPercent*d));
            console.log("Current : "+ s);
            console.log("element : "+ object[index_obj]);
            console.log("Scroll limit : "+ ele_scroll_limit);
            if(index_obj>=1){
                var prev_limit = $(object[index_obj-1]).data("scroll");
            }
            var position_curr = ((scrollPercent*d)-prev_limit)/(ele_scroll_limit-prev_limit);
            position_curr = position_curr*(ele_scroll_limit-prev_limit);
            console.log("position percent : "+(position_curr/(d-c))*s);
            if(position>(windows_height-ele_height)){
                console.log(c);
            }
            if((scrollPercent*d) > ele_scroll_limit){
                index_obj=1;
            }


            $horizontal.css({
                'top': (position_curr/(d-c))*s
            });
        });
    });

    // show / hide the options
    function toggleOptions(s) {
        $(s).toggleClass('open');
        var li = $(s).find('li');
        var deg = $(s).hasClass('half') ? 180 / (li.length - 1) : 360 / li.length;
        for (var i = 0; i < li.length; i++) {
            var d = $(s).hasClass('half') ? (i * deg) - 90 : i * deg;
            $(s).hasClass('open') ? rotate(li[i], d) : rotate(li[i], angleStart);
        }
    }

    $('.selector button').click(function (e) {

        toggleOptions($(".selector"));
    });

    setTimeout(function () {
        toggleOptions('.selector');
    }, 100);
</script>

<script>
    @if(Auth::check())
        $(".selector button,#profile_image_edit").hover(
            function () {
                $("#profile_image_edit").css('display', 'block');
            }, function () {
                $("#profile_image_edit").css('display', 'none');
            }
    );
    @endif

    $('#main-nav').nestednav({
                menuButtonSelector: '.navbar-toggle',
                mainNavSelector: '.nav.navbar-nav',
                caretIconHtml: '<span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>',
                nestedBoxIconHtml: '<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>',
            });

</script>

<script type="text/javascript">
    $(function () {
        $(".social-media-box img")
                .mouseover(function () {

                    var src = $(this).attr("src").replace(".png", "-hover.png");

                    $(this).attr("src", src);
                })
                .mouseout(function () {
                    var src = $(this).attr("src").replace("-hover.png", ".png");
                    $(this).attr("src", src);
                });
    });
</script>
</body>
</html>


