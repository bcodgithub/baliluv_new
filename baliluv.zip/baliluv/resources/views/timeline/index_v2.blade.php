<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 8/18/2015
 * Time: 9:57 AM
 */

        ?>



@extends('timeline.home')

@section('title', 'Home')


@section('content')
    <section id="content-desc">
        <div class="container">
            <div class="row">
                <h3>{{$user->full_name}}</h3>

                <div class="content-about">
                    <p>
                        Before photography was created, people already knew the priciples of how it eventually got to
                        work.<br/>
                        They could process the image on the wall or piece of paper, however no printing was possible at
                        the
                        time.
                    </p>

                    <p>
                        As preserving light turned out to be a lot harder task than projecting it. The instrument that
                        people used for processing pictures was called the Camera Obscura (which is Latin for the Dark
                        Room)
                        and it was around for a few centuries before photography came along.
                    </p>
                </div>
            </div>
        </div>
    </section>
@endsection


@section('js')

    <script>

        var options = {
            beforeSubmit : function(){
                var loading_gif = "<img width='24px' src='{{url('')}}/images/ajax-loader.gif'/>"
                $("#btn_login").html(loading_gif +"<span> Loading...<span>");
            },
            success:    function() {
                $("#btn_login").html("Login");
                location.reload();
            },
            error : function(){
                $("#btn_login").html("Login");
                pesanErr("this is something error occured");
            }
        };

        $('#form_login').ajaxForm(options);
    </script>
@endsection