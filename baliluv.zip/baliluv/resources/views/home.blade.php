 <?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 8/17/2015
 * Time: 4:00 PM
 */
use Soulfy\Timeline;
use Soulfy\Article;
use Soulfy\Gallery;
use Soulfy\User;
use Soulfy\UserProfile;
use Soulfy\WhatsApp;
use Soulfy\ReturningVisitor;
use Soulfy\Announcement;
use Soulfy\BasicConfig;

$domain = $_SERVER['SERVER_NAME'];
$user = User::where('domain', $domain)->first();
$announcement = Announcement::orderBy('id','DESC')->first();
$uri = Request::path();
if ($uri == "home/video") {
    $timeline = Timeline::take(8)->orderBy('updated_at', 'desc')->where('user_id', $user['id'])->where('social', 'youtube')->get();
    $check = Timeline::where('user_id', $user['id'])->where('social', 'youtube')->get();

    for ($i = 0; $i < count($timeline); $i++) {
        $video_id[$i] = explode("/", $timeline[$i]->content);
        $img_url[$i] = "https://img.youtube.com/vi/" . $video_id[$i][4] . "/default.jpg";
    }
} 
elseif ($uri == "home/articles") {
    $timeline = Timeline::take(8)->orderBy('updated_at', 'desc')->where('user_id', $user['id'])->where('social', 'article')->where('status', '1')->get();
    $check = Timeline::where('user_id', $user['id'])->where('status', '1')->where('social', 'article')->get();
} 
elseif ($uri == "home/gallery") {
    $timeline = Timeline::take(8)->orderBy('updated_at', 'desc')->where('user_id', $user['id'])->where('social', 'gallery')->get();
    $check = Timeline::where('user_id', $user['id'])->where('social', 'gallery')->get();
} 
else {
    $timeline = Timeline::take(8)->orderBy('updated_at', 'desc')->where('user_id', $user['id'])->where('status', '1')->get();
    $check = Timeline::get();
    for ($i = 0; $i < count($timeline); $i++) {
        if ($timeline[$i]->social == "youtube") {
            $video_id[$i] = explode("/", $timeline[$i]->content);
            $img_url[$i] = "https://img.youtube.com/vi/" . $video_id[$i][4] . "/default.jpg";
        }
    }
}
$user_setting = \Soulfy\Setting::where('user_id', $user['id'])->join('user_theme', 'user_setting.themes_enable', '=', 'user_theme.themes_enable')->first();
if ($user->image_profile == null) { $image_url = $user->fb_profile_image; } 
else { $image_url = url("") . '/' . $user->image_profile; }

$fb_image_url = "";
$user_profile = \Soulfy\UserProfile::where('user_id', $user->id)->first();
if ($user_profile) {
    $fb_image_url = '<div id="fb_profile_image"><img onclick="showProfileInfo(this)" data-name="' . $user_profile->name . '"' . ' data-first_name="' . $user_profile->first_name . '" data-last_name="' . $user_profile->last_name . '" data-email="' . $user_profile->email . '" data-url="' . $user_profile->url . '" data-about="' . $user_profile->about . '" data-gender="' . $user_profile->gender . '" data-location="' . $user_profile->location . '" src="' . $user_profile->profile_image . '"/></div>';
}
$gallery = Timeline::where('user_id', $user->id)->where('social', 'gallery')->orderBy('created_at', 'desc')->first();

if ($gallery != null) { $first_image = url("uploads") . "/" . $gallery->content; } 
else { $first_image = "https://soulfy.com/soulfy_logo.jpg"; }

$pages = \Soulfy\Pages::where('user_id', $user->id)->first();
if($pages == null) { $pages_first_id = 0; }
else { $pages_first_id = $pages->id; }
$countries = \DB::table('countries')->select('countries_name', 'countries_isd_code')->get();
$basicsetup = BasicConfig::where('user_id', $user->id)->first();
$basicCheck = BasicConfig::where('user_id', $user->id)->get();
$google_analytics_settings = User::where('id', $user->id)->first();

//<=============== Start Chart Data ===============> 
$month = date('m');
$month_11 = date('m', strtotime("-1 month"));
$month_21 = date('m', strtotime("-2 month"));
$month_31 = date('m', strtotime("-3 month"));
$month_41 = date('m', strtotime("-4 month"));
$to_4 = date('Y-m', strtotime("-5 month"));

//WhatsApp Number Count Current Month
$wacount_data = WhatsApp::where('user_id',$user->id)->whereMonth('created_at', '=', $month)->count();
$wacount_data_1 = WhatsApp::where('user_id',$user->id)->whereMonth('created_at', '=', $month_11)->count();
$wacount_data_2 = WhatsApp::where('user_id',$user->id)->whereMonth('created_at', '=', $month_21)->count();
$wacount_data_3 = WhatsApp::where('user_id',$user->id)->whereMonth('created_at', '=', $month_31)->count();
$wacount_data_4 = WhatsApp::where('user_id',$user->id)->whereMonth('created_at', '=', $month_41)->count();

//WhatsApp Number Count One Year to date
$year_to_date_last = WhatsApp::where('user_id',$user->id)->whereBetween('created_at', ['0000-00-00' , $to_4 ])->count();

$year_to_date_4 = $wacount_data_4+$year_to_date_last;
$year_to_date_3 = $year_to_date_4+$wacount_data_3;
$year_to_date_2 = $year_to_date_3+$wacount_data_2;
$year_to_date_1 = $year_to_date_2+$wacount_data_1;
$year_to_date = $year_to_date_1+$wacount_data;

//Returning Visitors Count Current Month
$rv_count_data = ReturningVisitor::where('user_id',$user->id)->whereMonth('created_at', '=', $month)->count();
$rv_count_data_1 = ReturningVisitor::where('user_id',$user->id)->whereMonth('created_at', '=', $month_11)->count();
$rv_count_data_2 = ReturningVisitor::where('user_id',$user->id)->whereMonth('created_at', '=', $month_21)->count();
$rv_count_data_3 = ReturningVisitor::where('user_id',$user->id)->whereMonth('created_at', '=', $month_31)->count();
$rv_count_data_4 = ReturningVisitor::where('user_id',$user->id)->whereMonth('created_at', '=', $month_41)->count();

//Returning Visitors Count Count One Year to date
$rv_year_to_date_4 = $rv_count_data_4;
$rv_year_to_date_3 = $rv_count_data_3;
$rv_year_to_date_2 = $rv_count_data_2;
$rv_year_to_date_1 = $rv_count_data_1;
$rv_year_to_date = $rv_count_data;

// Postential sales
$sale_to_date_last = \DB::table('image_click')
            ->join('timeline', 'image_click.image_id', '=','timeline.id')
            ->select('image_click.created_at','timeline.price')
            ->where('image_click.user_id',$user->id)->whereBetween('image_click.created_at', ['0000-00-00' , $to_4 ])->get();
$price_to_date_last[]='';
foreach ($sale_to_date_last as $sale) {
    $price_to_date_last[] = $sale->price;
}
$total_sale_to_date_last = array_sum($price_to_date_last);

$sales = \DB::table('image_click')
            ->join('timeline', 'image_click.image_id', '=','timeline.id')
            ->select('image_click.created_at','timeline.price')
            ->where('image_click.user_id',$user->id)->whereMonth('image_click.created_at', '=', $month)->get();
$price[] = '';
foreach ($sales as $sale) { $price[] = $sale->price;}
$total_sale_month = array_sum($price);

$sales_1 = \DB::table('image_click')
            ->join('timeline', 'image_click.image_id', '=','timeline.id')
            ->select('image_click.created_at','timeline.price')
            ->where('image_click.user_id',$user->id)->whereMonth('image_click.created_at', '=', $month_11)->get();
$price_1[] = '';
foreach ($sales_1 as $sale) { $price_1[] = $sale->price; }
$total_sale_1_month = array_sum($price_1);

$sales_2 = \DB::table('image_click')
            ->join('timeline', 'image_click.image_id', '=','timeline.id')
            ->select('image_click.created_at','timeline.price')
            ->where('image_click.user_id',$user->id)->whereMonth('image_click.created_at', '=', $month_21)->get();
$price_2[] = '';
foreach ($sales_2 as $sale) { $price_2[] = $sale->price; }
$total_sale_2_month = array_sum($price_2);

$sales_3 = \DB::table('image_click')
            ->join('timeline', 'image_click.image_id', '=','timeline.id')
            ->select('image_click.created_at','timeline.price')
            ->where('image_click.user_id',$user->id)->whereMonth('image_click.created_at', '=', $month_31)->get();
$price_3[] ='';
foreach ($sales_3 as $sale) {$price_3[] = $sale->price; }
$total_sale_3_month = array_sum($price_3);

$sales_4 = \DB::table('image_click')
            ->join('timeline', 'image_click.image_id', '=','timeline.id')
            ->select('image_click.created_at','timeline.price')
            ->where('image_click.user_id',$user->id)->whereMonth('image_click.created_at', '=', $month_41)->get();
$price_4[] = '';
foreach ($sales_4 as $sale) { $price_4[] = $sale->price; }
$total_sale_4_month = array_sum($price_4);

$c_total = $total_sale_to_date_last;
$total_sale_4 = $total_sale_4_month+$c_total;
$total_sale_3 = $total_sale_3_month+$total_sale_4;
$total_sale_2 = $total_sale_2_month+$total_sale_3;
$total_sale_1 = $total_sale_1_month+$total_sale_2;
$total_sale = $total_sale_month+$total_sale_1;

//chart data 
$cmonth = date('M-y');
$month_1 = date('M-y', strtotime("-1 month"));
$month_2 = date('M-y', strtotime("-2 month"));
$month_3 = date('M-y', strtotime("-3 month"));
$month_4 = date('M-y', strtotime("-4 month"));

$dataMonthly = array(
    array("label"=> $cmonth, "y"=> $wacount_data),
    array("label"=> $month_1, "y"=> $wacount_data_1),
    array("label"=> $month_2, "y"=> $wacount_data_2),
    array("label"=> $month_3, "y"=> $wacount_data_3),
    array("label"=> $month_4, "y"=> $wacount_data_4)
);
$dataYTD = array(
    array("label"=> $cmonth, "y"=> $year_to_date),
    array("label"=> $month_1, "y"=> $year_to_date_1),
    array("label"=> $month_2, "y"=> $year_to_date_2),
    array("label"=> $month_3, "y"=> $year_to_date_3),
    array("label"=> $month_4, "y"=> $year_to_date_4)
);
$dataSales = array(
    array("label"=> $cmonth, "y"=> $total_sale),
    array("label"=> $month_1, "y"=> $total_sale_1),
    array("label"=> $month_2, "y"=> $total_sale_2),
    array("label"=> $month_3, "y"=> $total_sale_3),
    array("label"=> $month_4, "y"=> $total_sale_4)
);
$dataReturn = array(
    array("label"=> $cmonth, "y"=> $rv_year_to_date),
    array("label"=> $month_1, "y"=> $rv_year_to_date_1),
    array("label"=> $month_2, "y"=> $rv_year_to_date_2),
    array("label"=> $month_3, "y"=> $rv_year_to_date_3),
    array("label"=> $month_4, "y"=> $rv_year_to_date_4)
);
//<=============== End Chart Data ===============>

//For Currency Converson
$xml_string = file_get_contents("https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml");
$xml = new SimpleXMLElement($xml_string);
$cxml = $xml->xpath('//*[@currency]');
$usx = $xml->xpath('//*[@currency="IDR"]');
$base = floatval(strval($usx[0]['rate']));
$c_arr = array();
foreach ($cxml as $c) {
    $cur = strval($c['currency']);
    $rate = round(floatval(strval($c['rate']))/$base , 10);
    $c_arr[$cur] = $rate;
}
$c_arr['EUR'] = 1/$base;
$currency_json = json_encode($c_arr);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8 Content-Transfer-Encoding: base64">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" id="viewport" />
    <title>{{ \DB::table('user_profile')->where('user_id', $user->id)->first()->meta_title }}</title>
    <meta name="description" content="{{ \DB::table('user_profile')->where('user_id', $user->id)->first()->meta_description }}">
    <meta name="keywords" content="{{ \DB::table('user_profile')->where('user_id', $user->id)->first()->meta_keyword }}">
    <meta name="author" content="{{$user['full_name']}}">

    <meta property="og:type" content= "website" />
	<meta property="og:url" content="http://{{$domain}}/"/>
	<meta property="og:site_name" content="{{$user['full_name']}}" />
	<meta property="og:image" itemprop="image primaryImageOfPage" content="{{$image_url}}"/>
	<meta name="twitter:domain" content="{{$domain}}"/>
	<meta name="twitter:title" property="og:title" itemprop="name" content="{{$user['full_name']}} | {{ \DB::table('user_profile')->where('user_id', $user->id)->first()->meta_title }}" />
	<meta name="twitter:description" property="og:description" itemprop="description" content="{{$user['full_name']}} | {{ \DB::table('user_profile')->where('user_id', $user->id)->first()->meta_description }}" />
    
	<meta name="twitter:app:name:iphone" content="{{$user['full_name']}} iOS" />
    <meta name="twitter:app:url:iphone" content="http://{{$domain}}/" />
    <meta name="twitter:app:name:ipad" content="{{$user['full_name']}} iOS" />
    <meta name="twitter:app:url:ipad" content="http://{{$domain}}/" />

    <meta name="twitter:app:name:googleplay" content="{{$user['full_name']}} Android">
    <meta name="twitter:app:url:googleplay" content="http://{{$domain}}/">

    <meta name="csrf-token" content="{{ csrf_token() }}"/>
    
    <link rel='shortcut icon' type='image/x-icon' href="@if($user_setting->favicon != '')
                                                            {{url('')}}/uploads/{{$user_setting->favicon}}
                                                        @else 
                                                            {{url('')}}/images/favicon.ico 
                                                        @endif"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <title>{{$domain}}</title>

    <!-- Custom styles for this template -->
    <link rel="stylesheet" href="{{url('')}}/css/businesscard.css" media="screen" title="no title" charset="utf-8">
    <link rel="stylesheet" href="{{url('')}}/css/bootstrap.css">
    <!-- Optional theme -->
    <link rel="stylesheet" href="{{url('')}}/css/bootstrap-theme.min.css">
    {{--<link rel="stylesheet" href="{{url('')}}/css/bootstrap-modal.css">--}}

    <link href="{{url('')}}/css/style_2.css?0" rel="stylesheet"/>
    <link href="{{url('')}}/css/dskype.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/demo.html5imageupload.css" rel="stylesheet"/>
    <link href="{{url('')}}/js/croppic/croppic.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/toastr.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/nestednav.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/bootstrap3-wysihtml5.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/timeline.css" rel="stylesheet"/>
    
    <link rel="stylesheet" href="{{url('')}}/css/lightbox.min.css">
    <link rel="stylesheet" href="{{url('')}}/js/perfect-scrollbar/css/perfect-scrollbar.css">

    <script type="text/javascript" src="{{url('')}}/js/jquery-1.10.2.min.js"></script>
    <script src="{{url('')}}/js/lightbox-plus-jquery.min.js"></script>
    <script src="{{url('')}}/js/jquery-ui.js"></script>

    <!--[if lt IE 9]>
    <link href="css/ie.css" rel="stylesheet"/>
    <script src="{{url('')}}/js/html5shiv.js" type="text/javascript"></script>
    <script src="{{url('')}}/js/respond.js" type="text/javascript"></script>
    <![endif]-->
    <!--[if lt IE 10]>
    <link href="css/ie.css" rel="stylesheet"/>
    <script src="{{url('')}}/js/html5shiv.js" type="text/javascript"></script>
    <script src="{{url('')}}/js/respond.js" type="text/javascript"></script>
    <![endif]-->
    @yield('css')
    <script>
        $(window).load(function () {
            // Animate loader off screen
            $(".se-pre-con").fadeOut("slow");
        });
    </script>
    <style>
        .content-placeholder object{width:130%; height: 100%;}
        /*16-3-2021*/
        .content-placeholder img{ border-radius:20px; }
        .object-canvas canvas{ border-radius:13px; opacity:0.8}
        .disabled:after {
            content: '\A';
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            background: rgba(0, 0, 0, 0.6);
            opacity: 0;
            transition: all 0.5s;
            -webkit-transition: all 0.5s;
            opacity: 1;
        }
        .slimScrollBar { background: #ffffff none repeat scroll 0% 0% !important; }
        .chart-block { position: fixed; left: 30%; top: 56px; max-width: 400px; width: 90%; z-index: 999; }
        .currency { color: black; position: absolute; right: -25px; top: 10px; }
        .currency_home { color:black; position: absolute; right: 8px; top: 10px }

        @media (max-width: 800px){
            .content-placeholder object{ width:100%; height: 100%; /*margin-left: 31%;*/}
            .modal-dialog { width: 550px !important; }
            #upload_background_dialog { margin-top: 0px !important; z-index: 9999; }
            #modaldialog { height: 251px !important; }
        }
        @media (max-width: 640px){
            .content-placeholder object{ width:100%; height: 100%; /*margin-left: 22%;*/}
            .modal-dialog { width: 550px !important; }
            #upload_background_dialog { margin-top: 0px !important; z-index: 9999; }
            #modaldialog { height: 251px !important; }
        }
        @media (max-width: 480px) {
            .content-placeholder object{ width:78%; height: 100%;}
            .chart-block {position: fixed;left: 50%;top: 38%;transform: translate(-50%);z-index: 1;}
            .currency { color: black; position: absolute; right: 0px; top: 10px; }
            .currency_home { color: black; position: absolute; right: 10px; top: 10px; }
            .modal-dialog { width: 340px !important; }
            #upload_background_dialog{ margin-top: 0px !important; z-index: 9999; }
            #modaldialog { height: 200px !important; }
        }
    </style>
    <style>
        #btn-save-seo {background-color: #4CAF50;border: none;color: white;padding: 10px 30px;text-align: center;text-decoration: none;display: inline-block;font-size: 14px;}
        <?php 
        $color = "000000";
        $domain = $_SERVER['SERVER_NAME'];
        $user = User::where('domain', $domain)->first();
        if(Auth::user() != NULL){
            $data = \DB::table('user_profile')->where('user_id', $user->id)->first();
            if($data) $color = $data->menu_color;
        }
        else{
        	$data = \DB::table('users')->where('domain', $domain)->first();
        	if($data) {
        		$id = $data->id;
        		$data = \DB::table('user_profile')->where('user_id', $id)->first();
               if($data) $color = $data->menu_color;
        	}
        } 

        $user = User::where('domain', $domain)->first();
        $google_analytics = $user->google_analytics;
        ?>
        #circle1{
    		background-color: #{{$color}};
    		<!-- background-color: #9f7bfc; -->
    		width: 60px;
    		height: 60px;
    		border-radius: 50%;
    		text-align: center;
		}
        #circle2{
        	background-color: #{{ $color }};
        		<!-- background-color: #9f7bfc; -->
        		width: 60px;
        		height: 60px;
        		border-radius: 50%;
        		text-align: center;
        }
        #profile_picture {
            position: absolute;width: 75%;height: 75%;cursor: pointer;border-radius: 50%;
            border: 2px solid #;
            transition: all .1s;
        }
        /* Pages styling */
        #container{position: relative; height: 100%; z-index: 1;color: black;width: auto;border-top-left-radius: 10px;border-bottom-left-radius: 10px;}

        /* table untuk page */
        table#t01 th, tr, td { width: 100%; padding: 5px; }
        #soulfy-logo{position: fixed;bottom: 0;right: 10px;display: flex;padding-left:10px !important;}
		#soulfy-logo span{ padding-top: 7px; font-size: 14px; color: #808080; font-family: Arial;}
		#close { padding: 10px 0 0 0; }
        #close-top { padding: 10px 0 0 10px; }
        @if($color == 1)
        #navigation-menu a{color:#fff; }
        @elseif($color == 2)
        #navigation-menu a{color:#000; }
        @else
        #navigation-menu a{color:#{{$color}};  }
        @endif
    </style>
@if(Auth::check())
<script>
window.onload = function () {
    var chart = new CanvasJS.Chart("chartContainer", {
        animationEnabled: true,
        theme: "light2",
        title:{
            text: "Washop Contacts & Potential Sales"
        },
        legend:{
            cursor: "pointer",
            verticalAlign: "top",
            horizontalAlign: "center",
            itemclick: toggleDataSeries
        },
        data: [{
            type: "column",
            name: "Monthly",
            indexLabel: "{y}",
            yValueFormatString: "#",
            showInLegend: true,
            dataPoints: <?php echo json_encode($dataMonthly, JSON_NUMERIC_CHECK); ?>
        },{
            type: "column",
            name: "Year to date",
            indexLabel: "{y}",
            yValueFormatString: "#",
            showInLegend: true,
            dataPoints: <?php echo json_encode($dataYTD, JSON_NUMERIC_CHECK); ?>
        },{
            type: "column",
            name: "Potential Sales(YTD)",
            indexLabel: "{y}",
            yValueFormatString: "IDR-#",
            showInLegend: true,
            dataPoints: <?php echo json_encode($dataSales, JSON_NUMERIC_CHECK); ?>
        },{
            type: "column",
            name: "Returning Visitors",
            indexLabel: "{y}",
            yValueFormatString: "#",
            showInLegend: true,
            dataPoints: <?php echo json_encode($dataReturn, JSON_NUMERIC_CHECK); ?>
        }]
    });
    chart.render();
    function toggleDataSeries(e){
        if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
            e.dataSeries.visible = false;
        }
        else{
            e.dataSeries.visible = true;
        }
        chart.render();
    }
}
</script>
@endif
</head>

<body id="home">
<!-- Ini untuk comment di bawah article -->
<div id="fb-root"></div>
<script>
    (function(d, s, id) 
    {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "//connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v2.10";
      fjs.parentNode.insertBefore(js, fjs);
    }
    (document, 'script', 'facebook-jssdk'));
</script>

<div class="se-pre-con"></div>

<!-- BEGIN # MODAL LOGIN -->
<div class="modal_popup  fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
     aria-hidden="true" style="display: none; margin-top: 122px;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" align="center">
                <img class="img-circle" id="img_logo" src="{{asset('images/logo.png')}}" style="background:#67d508;">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                </button>
            </div>

            <!-- Begin # Login Form -->
            <form id="login-form" action="{{action('MemberController@postLogin')}}"
                  data-location="{{action('HomeController@getEmail')}}">
                <div class="modal-body">
                    <div id="div-login-msg">
                        <div id="icon-login-msg" class="glyphicon glyphicon-chevron-right"></div>
                        <span id="text-login-msg">Type your username and password.</span>
                    </div>
                    <input id="login_username" name="email" placeholder="Email" class="form-control" type="text"
                           placeholder="Username (type ERROR for error effect)" required>
                    <input id="login_password" name="password" placeholder="Password" class="form-control" type="password" placeholder="Password" required>
                </div>
                <div class="modal-footer">
                    <div>
                        <button type="submit" class="btn btn-primary btn-lg btn-block" style="background:#67d508;">Login</button>
                    </div>
                </div>
            </form>
            <!-- End # Login Form -->
        </div>
    </div>
</div>
<!-- END # MODAL LOGIN -->

<nav id="w0" class="header navbar-default navbar-fixed-top navbar" role="navigation" style="/*z-index: 100;*/">
    <div class="menu" style="width: 97%;">
        <div id="w0-collapse" class="collapse- navbar-collapse-">
            <ul class="nav nav-header pull-left">
                <li class="logo-box"></li>
            </ul>
            <a id="soulfy-logo" style="padding: 0; text-decoration: none;" href="https://soulfy.com">
                <img style="height: 35px; margin-top: 2px; display: none;" src="{{url('.')}}/images/logo.png"/> <span>Fired up with Soulfy</span>
            </a>
            
            @if($user->background_image == '' or 
            $user->full_name == '' or 
            $user->contact_email == '' or 
            $user->address == '' or 
            $user_setting->custom_facebook_link == '' or 
            $user_setting->custom_twitter_link == '' or 
            $user_profile->ig_url == '' or
            $user_setting->info_profile == '' )

                @if(Auth::check())
                <a href="{{url('/basicsetup/getform')}}">
                    <img src="{{url('')}}/pop/images/trophy-icon_grey.png" id="close-top">
                </a>
                @else
                    <img src="{{url('')}}/pop/images/trophy-icon_grey.png" id="close-top">
                @endif
            @else
                <img src="{{url('')}}/pop/images/trophy-icon.png" id="close-top">
            @endif

            <!-- @if($user_profile->meta_title == '' or $user_profile->meta_keyword == '' or $user_profile->meta_description == '')
            <a href="{{url('/basicsetup/getform')}}">
                <img src="{{url('')}}/pop/images/trophy-icon_grey.png" id="close-top">
            </a>
            @else
            <img src="{{url('')}}/pop/images/trophy-icon.png" id="close-top">
            @endif -->

            @if(Auth::check())
            <a href="{{url('/basicsetup/getform')}}">
                <img src="{{url('')}}/pop/images/trophy-icon_grey.png" id="close-top">
            </a>
            @else
                <img src="{{url('')}}/pop/images/trophy-icon_grey.png" id="close-top">
            @endif
            @if(count($basicCheck) > 0)
                @if($basicsetup->funding_complet == 0 )
                    @if(Auth::check())
                    <a href="{{url('/basicsetup/getform')}}">
                        <img src="{{url('')}}/pop/images/trophy-icon_grey.png" id="close-top">
                    </a>
                    @else
                        <img src="{{url('')}}/pop/images/trophy-icon_grey.png" id="close-top">
                    @endif
                @else
                    <img src="{{url('')}}/pop/images/trophy-icon.png" id="close-top">
                @endif
            @else
                <img src="{{url('')}}/pop/images/trophy-icon_grey.png" id="close-top">
            @endif

            <ul id="w1" class="navbar-nav pull-right nav">  
                @if(Auth::check())
                    <li>
                        <div class="announcement">
                            <center><img src="{{url('.')}}/images/announcement.jpg" class="hidden-xs" height="30px">
                                <div class="announcement-i">
                                    <span class="hidden-xs">Announcement </span>
                                    <?php date_default_timezone_set("Asia/Jakarta"); ?>
                                    @if($announcement->date > date('Y-m-d H:i:s'))
                                    <a href="{{action('HomeController@getUpdateNews')}}">
                                        <span class="badge  badge-danger">New</span>
                                    </a>
                                    @endif
                                </div>
                            </center><br>
                        </div>
                    </li>

                    <li>
                    </li>
                    <li>            
                        <h4 class="welcome-txt">Welcome <i class="welcome-username">{{$user['full_name']}} !</i> </h4>                       
                    </li>
                    <li>
                        <span class="photo-profile">
                            <a id="drop1" href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <img id="image_thumb" width="100%" height="100%" src="{{url('').'/'.$user->image_profile}}"/><b class="caret"></b>
                            </a>
                            <ul id="w2" class="dropdown-menu with-arrow-v2-right">
                                <li>
                                    <a href="{{url()}}"><span class="glyphicon glyphicon-home"aria-hidden="true"></span> Home
                                    </a>
                                </li>
                                <li>
                                    <a href="{{action('HomeController@getSetting')}}">
                                        <span class="glyphicon glyphicon-cog" aria-hidden="true"></span> Settings
                                    </a>
                                </li>
                                <li>
                                    <a href="{{action('HomeController@getCategory')}}"><span class="fa fa-list-alt" aria-hidden="true"> </span> Category
                                    </a>
                                </li>
                                <li>
                                    <a href="#" id="change_background" data-toggle="modal" data-target="#upload_background_dialog">
                                        <span class="fa fa-picture-o" aria-hidden="true"> 
                                        </span> Change background
                                    </a>
                                </li>
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#info_profile"><span class="fa fa-edit" aria-hidden="true"> </span> Change profile info
                                    </a>
                                </li>
                                <li role="separator" class="divider"></li>
                                <li>
                                    <a href="{{url('auth/logout')}}"> <span class="glyphicon glyphicon-log-out" aria-hidden="true"></span> Logout
                                    </a>
                                </li>
                            </ul>
                        </span>
                    </li>
                    <li>
                        <div class="currency">
                            <?php
                                if(!isset($_COOKIE['price'])){ $price_val = 1; }
                                else{ $price_val = $_COOKIE['price']; }
                            ?>
                            <select id="currency_key">
                                @foreach($c_arr as $key => $value)
                                <option value="{{$value}}" <?php if($value == $price_val){?> selected="selected" <?php }  ?>>{{$key}}</option>
                                @endforeach
                            </select>
                        </div>
                    </li>
                </ul>
                
                @else
                    <div class="currency_home">
                        <?php
                            if(!isset($_COOKIE['price'])){ $price_val = 1; }
                            else{ $price_val = $_COOKIE['price']; }
                        ?>
                        <select id="currency_key">
                            @foreach($c_arr as $key => $value)
                            <option value="{{$value}}" <?php if($value == $price_val){?> selected="selected" <?php }  ?>>{{$key}}</option>
                            @endforeach
                        </select>
                    </div>
                    <form class="navbar-form navbar-right" id="form_login" method="post"
                          action="{{ url('/auth/login') }}">
                        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
                        <div class="form-group">
                            <span class="control-header">Email</span>
                            <span>
                                <input type="text" name="email" placeholder="Email" required class="form-control"/>
                            </span>
                        </div>
                        <div class="form-group">
                            <span class="control-header">Password</span>
                            <span>
                                <input type="password" name="password" placeholder="Password" required class="form-control"/>
                            </span>
                            <input type="hidden" name="domain" required value="{{$domain}}"/>
                        </div>
                        <div class="form-group">
                            <h3 style="margin-top: 2px;">
                                <button type="submit" id="btn_login">
                                    <span class="glyphicon glyphicon-log-in" aria-hidden="true"> 
                                    </span> login
                                </button>
                            </h3>
                        </div>
                    </form>
                @endif    
        </div>
    </div>
</nav>

<section class="bg">
    <style>
        .bg-pattern-sm.drop {
            @if($user['background_image'] == "")
              background: url({{url()}}/images/beach.jpg);
            @else
              background: url({{url()}}{{$user['background_image']}});
              background-repeat: repeat;
            @endif
            background-size: cover;
            background-attachment: inherit !important;
        }
        .bg-pattern { background: url({{url()}}{{$user_setting['source_themes']}}) no-repeat;}
    </style>
    <span class="bg-pattern"></span>
    <span class="bg-pattern-sm drop">
          <div id="dropzone-overlay" style="display:none;"></div>
    </span>
</section>

@if(Auth::check())
    <form>
        <div class="dropzone cover-upload hidden-xs">
            <div class="dropzone" id="drop-upload" data-resize="true" data-width="700" data-height="640" data-url="{{action('AjaxController@postUploadProfile')}}" style="width: 100%;">
                <input type="file" name="thumb"/>
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
            </div>
            <div id="icon-cu" style="display: block;">
                <span class="glyphicon glyphicon-edit " aria-hidden="true"></span>
            </div>
        </div>
    </form>
@endif

<div id="content_body" style="position: static">
    
    @yield('content')

    @if(Auth::check())
    <section class="chart-block ">
        <div id="chartContainer" class="object-canvas" style="height: 260px; width: 100%;"></div>
    </section>
    @endif

    <section id="content">
        <div class="container">
            <div class="row">
                @if(Auth::check())
                    <form>
                        <div class="dropzone cover-upload visible-xs">
                            <div class="dropzone" id="drop-upload" data-resize="true"  data-url=" {{action('AjaxController@postUploadProfile')}}" style="width: 100%;">
                                <input type="file" name="thumb"/>
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            </div>
                            <div id="icon-cu" style="display: block;">
                                <span class="glyphicon glyphicon-edit icon-pp" aria-hidden="true"></span>
                            </div>
                        </div>
                    </form>
                @endif

                @if($user_setting->menu_list == 0)
                <div class="selector">
                    <ul class="social-media-box">
                        <!-- tambahan arifin -->
                        <!-- end arifin -->
                        <li>
                            <input id="c12" type="checkbox">
                            <label for="c12">
                                <a href="{{url()}}">
                                    <div>
                                        <div style="margin: 0px 0 0 0px; ">
                                            <div style="margin: -4px 0 0 -5px; ">
                                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/home.png @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/home.png  @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/home.png @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/home.png @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/home.png @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/home.png @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/home.png @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/home.png @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/home.png @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/home.png 
                                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/home.png
                                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/home.png 
                                                @else {{url('')}}/images/white/home.png @endif " width="35px" />
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </label>
                        </li>

                        <li>
                            <input id="c1" type="checkbox">
                            <label for="c1">
                                @if(Auth::check())
                                <a href="{{action('HomeController@getEmail')}}">
                                @else
                                <a href="#" class="btn-placeholder email" data-tipe="email" data-target="#content_desc">
                                @endif
                                    @if($uri=="home/email")
                                    <div>
                                        <div style="margin: -8px 0 0 0 !important;">
                                    @else
                                    <div>
                                        <div style="margin: -8px 0 0 0; ">
                                    @endif
                                            <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/email.png 
                                            @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/email.png 
                                            @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/email.png 
                                            @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/email.png 
                                            @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/email.png 
                                            @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/email.png 
                                            @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/email.png 
                                            @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/email.png 
                                            @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/email.png 
                                            @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/email.png
                                            @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/email.png
                                            @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/email.png 
                                            @else {{url('')}}/images/white/email.png @endif " width="35px" />
                                        </div>
                                    </div>
                                </a>
                            </label>
                        </li>
                        @if($user_setting->fb_enable)
                        <!--<li>
                            <input id="c2" type="checkbox">
                            <label for="c2">
                                @if(Auth::check())
                                    <a href="#" onclick="loadtimeline(this,'fb')">
                                        <!-- <img src="{{url("")}}/images/button-02.png"/> -- >
                                        <div>
                                            <div style="margin: 0 0 0 3px; ">
                                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/fb.png 
                                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/fb.png 
                                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/fb.png 
                                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/fb.png 
                                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/fb.png 
                                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/fb.png 
                                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/fb.png 
                                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/fb.png 
                                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/fb.png 
                                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/fb.png
                                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/fb.png
                                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/fb.png  
                                                @else {{url('')}}/images/white/fb.png @endif " width="35px" />
                                            </div>
                                        </div>
                                    </a>
                                @else
                                    <a href="#" onclick="loadtimeline(this,'fb')">
                                        <div>
                                            <div style="margin: 0 0 0 3px; ">
                                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/fb.png 
                                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/fb.png 
                                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/fb.png 
                                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/fb.png 
                                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/fb.png 
                                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/fb.png 
                                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/fb.png 
                                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/fb.png 
                                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/fb.png 
                                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/fb.png  
                                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/fb.png
                                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/fb.png 
                                                @else {{url('')}}/images/white/fb.png @endif " width="35px" />
                                            </div>
                                        </div>
                                    </a>
                                @endif
                            </label>
                        </li>-->
                        @endif
                        @if($user_setting->custom_facebook_enable)
                        <li>
                            <input id="c1000" type="checkbox">
                            <label for="c1000">
                                <a href="{{$user_setting->custom_facebook_link}}" target="_blank">
                                    <div>
                                        <div style="margin: 0 0 0 3px; ">
                                            <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/fb.png 
                                            @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/fb.png 
                                            @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/fb.png 
                                            @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/fb.png 
                                            @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/fb.png 
                                            @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/fb.png 
                                            @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/fb.png 
                                            @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/fb.png 
                                            @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/fb.png 
                                            @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/fb.png  
                                            @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/fb.png
                                            @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/fb.png 
                                            @else {{url('')}}/images/white/fb.png @endif " width="35px" />
                                        </div>
                                    </div>
                                </a>
                            </label>
                        </li>
                        @endif
                        @if($user_setting->twitter_enable)
                        <!--<li>
                            <input id="c3" type="checkbox">
                            <label for="c3">
                                @if(Auth::check())
                                <a href="#" onclick="loadtimeline(this,'twitter')">
                                    <!-- <img src="{{url("")}}/images/button-03.png"/> -- >
                                    <div>
                                        <div style="margin-left: -7px; ">
                                            <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/twt.png 
                                            @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/twt.png 
                                            @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/twt.png 
                                            @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/twt.png 
                                            @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/twt.png 
                                            @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/twt.png 
                                            @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/twt.png 
                                            @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/twt.png 
                                            @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/twt.png 
                                            @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/twt.png  
                                            @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/twt.png
                                            @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/twt.png 
                                            @else {{url('')}}/images/white/twt.png @endif " width="35px" />
                                        </div>
                                    </div>
                                </a>
                                @else
                                <a href="#" onclick="loadtimeline(this,'twitter')">
                                    <!-- <img src="{{url("")}}/images/button-03.png"/> -- >
                                    <div>
                                        <div style="margin-left: -7px; ">
                                            <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/twt.png 
                                            @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/twt.png 
                                            @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/twt.png 
                                            @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/twt.png 
                                            @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/twt.png 
                                            @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/twt.png 
                                            @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/twt.png 
                                            @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/twt.png 
                                            @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/twt.png 
                                            @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/twt.png  
                                            @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/twt.png
                                            @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/twt.png 
                                            @else {{url('')}}/images/white/twt.png @endif " width="35px" />
                                        </div>
                                    </div>
                                </a>
                                @endif
                            </label>
                        </li>-->
                        @endif
                        @if($user_setting->custom_twitter_enable)
                        <li>
                            <input id="c1001" type="checkbox">
                            <label for="c1001">
                                <a href="{{$user_setting->custom_twitter_link}}" target="_blank">
                                    <div>
                                        <div style="margin-left: 0;">
                                            <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/twt.png 
                                            @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/twt.png 
                                            @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/twt.png 
                                            @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/twt.png 
                                            @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/twt.png 
                                            @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/twt.png 
                                            @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/twt.png 
                                            @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/twt.png 
                                            @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/twt.png 
                                            @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/twt.png  
                                            @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/twt.png
                                            @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/twt.png 
                                            @else {{url('')}}/images/white/twt.png @endif " width="35px" />
                                        </div>
                                    </div>
                                </a>
                            </label>
                        </li>
                        @endif
                        @if($user_setting->ecommerce_status == 'ACTIVE')
                            <li>
                                <input id="c4" type="checkbox">
                                <label for="c4">
                                    @if(!Auth::check())
                                    <a href="{{$user->bisnis_link}}" target="_blank">
                                    @else
                                    <a href="{{$user_setting->ecommerce_admin_url}}" target="_blank">
                                    @endif
                                        <div>
                                            <div style="margin: -5px 0 0 0; ">
                                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/cart.png 
                                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/cart.png 
                                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/cart.png 
                                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/cart.png 
                                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/cart.png 
                                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/cart.png 
                                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/cart.png 
                                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/cart.png 
                                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/cart.png 
                                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/cart.png  
                                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/cart.png
                                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/cart.png 
                                                @else {{url('')}}/images/white/cart.png @endif " width="35px" />
                                            </div>
                                        </div>
                                    </a>                            
                                </label>
                            </li>
                        @endif

                        @if($user_setting->youtube_enable)
                        <li>
                            <input id="c6" type="checkbox">
                            <label for="c6">
                                @if($uri=="home/video")
                                <a id="video-btn" href="{{action('HomeController@getVideo')}}"
                                   data-menu="video">
                                @else
                                <a id="video-btn" href="{{action('HomeController@getVideo')}}" data-menu="video">
                                @endif
                                    <div>
                                        <div style="margin: -4px 0 0 4px; ">
                                            <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/yt.png 
                                            @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/yt.png 
                                            @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/yt.png 
                                            @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/yt.png 
                                            @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/yt.png 
                                            @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/yt.png 
                                            @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/yt.png 
                                            @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/yt.png 
                                            @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/yt.png 
                                            @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/yt.png  
                                            @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/yt.png
                                            @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/yt.png 
                                            @else {{url('')}}/images/white/yt.png @endif " width="35px" />
                                        </div>
                                    </div>
                                </a>                                            
                            </label>
                        </li>
                        @endif

                        @if($user_setting->rssfeed_enable)
                        <li>
                            <input id="c14" type="checkbox">
                            <label for="c14">
                                @if(auth::check())
                                <a href="{{url('rss/rssfeed')}}">
                                @else
                                <a href="{{ url('/home/rss') }}">
                                @endif
                                    <div>
                                        <div style="margin: -5px 0 0 0; ">
                                            <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/rss.png 
                                            @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/rss.png 
                                            @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/rss.png 
                                            @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/rss.png 
                                            @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/rss.png 
                                            @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/rss.png 
                                            @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/rss.png 
                                            @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/rss.png 
                                            @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/rss.png 
                                            @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/rss.png  
                                            @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/rss.png
                                            @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/rss.png 
                                            @else {{url('')}}/images/white/rss.png @endif " width="35px" />
                                        </div>
                                    </div>
                                </a>
                            </label>
                        </li>
                        @endif
                        {{--<li>--}}
                        {{--<input id="c7" type="checkbox">--}}
                        {{--<label for="c7">--}}
                        {{--<a href="http://online.soulfy.com" class="btn-placeholder">--}}
                        {{--<img src="{{url('')}}/images/online_soulfy.png"/></a>--}}
                        {{--</label>--}}
                        {{--</li>--}}

                        @if($user_setting->instagram_enable)
                        <li>
                            <input id="c7" type="checkbox">
                            <label for="c7">
                                <?php 
                                if(Auth::check()){ $url_link = Url('home/instagram'); }
                                else{
                                    $domain = $_SERVER['SERVER_NAME'];
                                    $user = User::where('domain', $domain)->first();       
                                    $user_profile = UserProfile::where('user_id', $user->id)->first();
                                    $url_link = "http://www.instagram.com/".$user_profile->ig_url;
                                }
                                ?>
                                <a href=<?php echo $url_link; ?> data-tipe="instagram" data-content="" data-target="#content_desc" target="<?php if(Auth::check()) echo ''; else echo '_blank';?>">
                                    <div>
                                        <div style="margin: -5px 0 0 4px; ">
                                            <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/ig.png 
                                            @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/ig.png 
                                            @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/ig.png 
                                            @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/ig.png 
                                            @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/ig.png 
                                            @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/ig.png 
                                            @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/ig.png 
                                            @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/ig.png 
                                            @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/ig.png 
                                            @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/ig.png  
                                            @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/ig.png
                                            @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/ig.png 
                                            @else {{url('')}}/images/white/ig.png @endif " width="35px" />
                                        </div>
                                    </div>
                                </a>
                            </label>
                        </li>
                        @endif
                        <li>
                            <input id="c8" type="checkbox">
                            <label for="c8">
                                @if(auth::check())
                                <a href="{{ route('pages.index') }}">
                                @else
                                <a href="{{ route('pages.frontindex', $pages_first_id) }}">
                                @endif
                                    <div>
                                        <div style="margin: -5px 0 0 0; ">
                                            <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/pages.png 
                                            @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/pages.png 
                                            @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/pages.png 
                                            @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/pages.png 
                                            @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/pages.png 
                                            @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/pages.png 
                                            @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/pages.png 
                                            @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/pages.png 
                                            @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/pages.png 
                                            @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/pages.png  
                                            @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/pages.png
                                            @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/pages.png 
                                            @else {{url('')}}/images/white/pages.png @endif " width="35px" />
                                        </div>
                                    </div>
                                </a>
                            </label>
                        </li>

                        <li>
                            <input id="c9" type="checkbox">
                            <label for="c9">
                                <a href="{{action('HomeController@getGallery')}}">
                                    <div>
                                        <div style="margin: -4px 0 0 0; ">
                                            <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/gallery.png 
                                            @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/gallery.png 
                                            @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/gallery.png 
                                            @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/gallery.png 
                                            @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/gallery.png 
                                            @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/gallery.png 
                                            @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/gallery.png 
                                            @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/gallery.png 
                                            @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/gallery.png 
                                            @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/gallery.png  
                                            @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/gallery.png
                                            @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/gallery.png 
                                            @else {{url('')}}/images/white/gallery.png @endif " width="35px"/>
                                        </div>
                                    </div>
                                </a>
                            </label>
                        </li>
                        <li>
                            <input id="c10" type="checkbox">
                            <label for="c10">
                                @if(Auth::check())
                                <a href="{{ route('barticles') }}">
                                @else
                                <a href="{{ route('articles') }}">
                                @endif
                                    <div>
                                        <div style="margin: -4px 0 0 0;">
                                            <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/article.png 
                                            @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/article.png 
                                            @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/article.png 
                                            @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/article.png 
                                            @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/article.png 
                                            @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/article.png 
                                            @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/article.png 
                                            @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/article.png 
                                            @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/article.png 
                                            @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/article.png  
                                            @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/article.png
                                            @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/article.png 
                                            @else {{url('')}}/images/white/article.png @endif " width="35px"/>
                                        </div>
                                    </div>
                                </a>
                            </label>
                        </li>

                        <li>
                            <input id="c11" type="checkbox">
                            <label for="c11">
                                @if(Auth::check())
                                <a href="{{action('HomeController@getBussinesscard')}}">
                                @else
                                <a href="#" class="btn-placeholder" data-tipe="businesscard" data-target="#content_desc">
                                @endif
                                    <div>
                                        <div style="margin: -4px 0 0 0;">
                                            <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/businesscard.png 
                                            @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/businesscard.png 
                                            @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/businesscard.png 
                                            @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/businesscard.png 
                                            @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/businesscard.png 
                                            @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/businesscard.png 
                                            @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/businesscard.png 
                                            @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/businesscard.png 
                                            @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/businesscard.png 
                                            @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/businesscard.png  
                                            @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/businesscard.png
                                            @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/businesscard.png 
                                            @else {{url('')}}/images/white/businesscard.png @endif " width="35px" />
                                        </div>
                                    </div> 
                                </a>
                            </label>
                        </li>
                        
                        @if($user_setting->custom_linkedin_enable)
                        <li>
                            <input id="c1002" type="checkbox">
                            <label for="c1002">
                                <a href="{{$user_setting->custom_linkedin_link}}" target="_blank">
                                    <div>
                                        <div style="margin-left: 0;">
                                            <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/linkedin.png 
                                            @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/linkedin.png 
                                            @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/linkedin.png 
                                            @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/linkedin.png 
                                            @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/linkedin.png 
                                            @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/linkedin.png 
                                            @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/linkedin.png 
                                            @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/linkedin.png 
                                            @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/linkedin.png 
                                            @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/linkedin.png  
                                            @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/linkedin.png
                                            @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/linkedin.png 
                                            @else {{url('')}}/images/white/linkedin.png @endif " width="35px" />
                                        </div>
                                    </div>
                                </a>
                            </label>
                        </li>
                        @endif
                        
                        @if($user_setting->custom_menu1_enable)
                        <li>
                            <input id="c100" type="checkbox">
                            <label for="c100">
                                <a href="{{$user_setting->custom_menu1_link}}" data-tipe="Link 1" target="_blank">
                                    <div>
                                        <div style="margin: -5px 0 0 4px; ">
                                            <img src="@if($user_setting->custom_menu1_logo != '') @if($user_setting->custom_menu1_logo == 'line.png') {{url('')}}/images/line.png @elseif($user_setting->custom_menu1_logo == 'fbmsg.png') {{url('')}}/images/fbmsg.png @elseif($user_setting->custom_menu1_logo == 'telegram.png') {{url('')}}/images/telegram.png @elseif($user_setting->custom_menu1_logo == 'wechat.png') {{url('')}}/images/wechat.png @elseif($user_setting->custom_menu1_logo == 'whatsapp.png') {{url('')}}/images/whatsapp.png @else {{url('')}}/uploads/{{$user_setting->custom_menu1_logo}} @endif @else {{url('')}}/images/add/default_icon.png @endif" width="35px" />
                                        </div>
                                    </div>
                                </a>
                            </label>
                        </li>
                        @endif
                        @if($user_setting->custom_menu2_enable)
                        <li>
                            <input id="c102" type="checkbox">
                            <label for="c102">
                                <a href="{{$user_setting->custom_menu2_link}}" data-tipe="Link 2" target="_blank">
                                    <div>
                                        <div style="margin: -5px 0 0 4px; ">
                                            <img src=" @if($user_setting->custom_menu2_logo != '') @if($user_setting->custom_menu2_logo == 'line.png') {{url('')}}/images/line.png @elseif($user_setting->custom_menu2_logo == 'fbmsg.png') {{url('')}}/images/fbmsg.png @elseif($user_setting->custom_menu2_logo == 'telegram.png') {{url('')}}/images/telegram.png @elseif($user_setting->custom_menu2_logo == 'wechat.png') {{url('')}}/images/wechat.png @elseif($user_setting->custom_menu2_logo == 'whatsapp.png') {{url('')}}/images/whatsapp.png @else {{url('')}}/uploads/{{$user_setting->custom_menu2_logo}} @endif @else {{url('')}}/images/add/default_icon.png @endif" width="35px" />
                                        </div>
                                    </div>
                                </a>
                            </label>
                        </li>
                        @endif
                        @if($user_setting->custom_menu3_enable)
                        <li>
                            <input id="c103" type="checkbox">
                            <label for="c103">
                                <a href="{{$user_setting->custom_menu3_link}}" data-tipe="Link 1" target="_blank">
                                    <div>
                                        <div style="margin: -5px 0 0 4px; ">
                                            <img src="@if($user_setting->custom_menu3_logo != '') @if($user_setting->custom_menu3_logo == 'line.png') {{url('')}}/images/line.png @elseif($user_setting->custom_menu3_logo == 'fbmsg.png') {{url('')}}/images/fbmsg.png @elseif($user_setting->custom_menu3_logo == 'telegram.png') {{url('')}}/images/telegram.png @elseif($user_setting->custom_menu3_logo == 'wechat.png') {{url('')}}/images/wechat.png @elseif($user_setting->custom_menu3_logo == 'whatsapp.png') {{url('')}}/images/whatsapp.png @else {{url('')}}/uploads/{{$user_setting->custom_menu3_logo}} @endif @else {{url('')}}/images/add/default_icon.png @endif" width="35px" />
                                        </div>
                                    </div>
                                </a>
                            </label>
                        </li>
                        @endif
                    </ul>
                    <div id="profile_image">
                        <img id="profile_picture" src="{{url("").'/'.$user->image_profile}}"/>
                        {{--<div class="dropzone" id="edit_image" data-width="176" data-height="174" data-resize="true" data-url="{{action('AjaxController@postUploadProfile')}}" style="width: 176px;height: 174px;left: 0px;display: none;">--}}
                        {{--<input type="file" id="profilefileupload" name="thumb" />--}}
                        {{--</div>--}}
                        <div id="image_upload"></div>
                        <div id="profile_image_edit" style="display: none;">
                            <a href="#" id="btn_upload" onclick="javascript:editProfile();">
                                <span class="glyphicon glyphicon-edit icon-pp" aria-hidden="true"></span>
                            </a>
                        </div>
                        {{--<div id="profile_pict" class="dropzone" data-resize="true" data-url="canvas.php">--}}
                        {{--<img src="{{url('')}}/images/user1.png"/>--}}
                        {{--<input type="file" id="profilefileupload" name="thumb" />--}}
                        {{--</div>--}}
                    </div>
                </div>
                @endif
                @if($user_setting->menu_list == 1)
                <div class="selector-menu">
                    <div id="profile_image">
                        <img id="profile_picture" src="{{url("").'/'.$user->image_profile}}"/>
                        {{--<div class="dropzone" id="edit_image" data-width="176" data-height="174" data-resize="true" data-url="{{action('AjaxController@postUploadProfile')}}" style="width: 176px;height: 174px;left: 0px;display: none;">--}}
                        {{--<input type="file" id="profilefileupload" name="thumb" />--}}
                        {{--</div>--}}
                        <div id="image_upload"></div>
                        <div id="profile_image_edit" style="display: none;">
                            <a href="#" id="btn_upload" onclick="javascript:editProfile();">
                                <span class="glyphicon glyphicon-edit icon-pp" aria-hidden="true"></span>
                            </a>
                        </div>
                        {{--<div id="profile_pict" class="dropzone" data-resize="true" data-url="canvas.php">--}}
                        {{--<img src="{{url('')}}/images/user1.png"/>--}}
                        {{--<input type="file" id="profilefileupload" name="thumb" />--}}
                        {{--</div>--}}
                    </div>
                </div>                    
                <div id="navigation-menu" style="display: none;">
                    <ul>
                        <li>
                            <a href="{{url()}}">
                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/home.png @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/home.png @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/home.png @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/home.png @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/home.png @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/home.png @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/home.png @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/home.png @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/home.png @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/home.png @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/home.png @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/home.png @else {{url('')}}/images/white/home.png @endif " width="35px" /> Home
                            </a>
                        </li>

                        <li>
                            @if(Auth::check())
                            <a href="{{action('HomeController@getEmail')}}">
                            @else
                            <a href="#" class="btn-placeholder email" data-tipe="email"
                                   data-target="#content_desc">
                            @endif
                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/email.png 
                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/email.png 
                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/email.png 
                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/email.png 
                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/email.png 
                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/email.png 
                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/email.png 
                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/email.png 
                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/email.png 
                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/email.png
                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/email.png 
                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/email.png
                                @else {{url('')}}/images/white/email.png @endif " width="35px" /> Email
                            </a>
                        </li>

                        @if($user_setting->custom_facebook_enable)
                        <li>
                            <a href="{{$user_setting->custom_facebook_link}}" target="_blank">
                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/fb.png 
                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/fb.png 
                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/fb.png 
                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/fb.png 
                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/fb.png 
                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/fb.png 
                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/fb.png 
                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/fb.png 
                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/fb.png 
                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/fb.png 
                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/fb.png 
                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/fb.png
                                @else {{url('')}}/images/white/fb.png @endif " width="35px" /> Facebook
                            </a>
                        </li>
                        @endif

                        @if($user_setting->custom_twitter_enable)
                        <li>
                            <a href="{{$user_setting->custom_twitter_link}}" target="_blank">
                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/twt.png 
                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/twt.png 
                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/twt.png 
                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/twt.png 
                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/twt.png 
                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/twt.png 
                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/twt.png 
                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/twt.png 
                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/twt.png 
                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/twt.png  
                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/twt.png 
                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/twt.png
                                @else {{url('')}}/images/white/twt.png @endif " width="35px" /> Twitter
                            </a>
                        </li>
                        @endif

                        @if($user_setting->ecommerce_status == 'ACTIVE')
                        <li>
                            @if(!Auth::check())
                            <a href="{{$user->bisnis_link}}" target="_blank">
                            @else
                            <a href="{{$user_setting->ecommerce_admin_url}}" target="_blank">
                            @endif
                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/cart.png 
                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/cart.png 
                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/cart.png 
                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/cart.png 
                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/cart.png 
                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/cart.png 
                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/cart.png 
                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/cart.png 
                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/cart.png 
                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/cart.png  
                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/cart.png 
                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/cart.png
                                @else {{url('')}}/images/white/cart.png @endif " width="35px" /> Ecommerce
                            </a>
                        </li>
                        @endif

                        @if($user_setting->youtube_enable)
                        <li>
                            <a href="{{action('HomeController@getVideo')}}">
                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/yt.png 
                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/yt.png 
                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/yt.png 
                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/yt.png 
                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/yt.png 
                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/yt.png 
                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/yt.png 
                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/yt.png 
                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/yt.png 
                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/yt.png 
                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/yt.png 
                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/yt.png 
                                @else {{url('')}}/images/white/yt.png @endif " width="35px" /> YouTube
                            </a>                                            
                        </li>
                        @endif

                        @if($user_setting->rssfeed_enable)
                        <li>
                            @if(auth::check())
                            <a href="{{url('rss/rssfeed')}}">
                            @else
                            <a href="{{ url('/home/rss') }}">
                            @endif        
                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/rss.png 
                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/rss.png 
                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/rss.png 
                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/rss.png 
                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/rss.png 
                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/rss.png 
                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/rss.png 
                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/rss.png 
                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/rss.png 
                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/rss.png 
                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/rss.png 
                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/rss.png 
                                @else {{url('')}}/images/white/rss.png @endif " width="35px" /> RSS
                            </a>
                        </li>
                        @endif

                        @if($user_setting->instagram_enable)
                        <li>
                            <?php 
                                if(Auth::check()) {$url_link = Url('home/instagram');}
                                else {
                                    $domain = $_SERVER['SERVER_NAME'];
                                    $user = User::where('domain', $domain)->first();       
                                    $user_profile = UserProfile::where('user_id', $user->id)->first();
                                    $url_link = "http://www.instagram.com/".$user_profile->ig_url;
                                }
                            ?>
                            <a href=<?php echo $url_link; ?> data-tipe="instagram" data-content="" data-target="#content_desc" target="<?php if(Auth::check()) echo ''; else echo '_blank';?>">
                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/ig.png 
                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/ig.png 
                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/ig.png 
                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/ig.png 
                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/ig.png 
                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/ig.png 
                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/ig.png 
                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/ig.png 
                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/ig.png 
                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/ig.png 
                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/ig.png 
                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/ig.png 
                                @else {{url('')}}/images/white/ig.png @endif " width="35px" /> Instagram 
                            </a>
                        </li>
                        @endif

                        <li>
                            @if(auth::check())
                            <a href="{{ route('pages.index') }}">
                            @else
                            <a href="{{ route('pages.frontindex', $pages_first_id) }}"> 
                            @endif
                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/pages.png 
                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/pages.png 
                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/pages.png 
                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/pages.png 
                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/pages.png 
                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/pages.png 
                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/pages.png 
                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/pages.png 
                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/pages.png 
                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/pages.png 
                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/pages.png 
                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/pages.png 
                                @else {{url('')}}/images/white/pages.png @endif " width="35px" /> Pages
                            </a>     
                        </li>

                        <li>
                            <a href="{{action('HomeController@getGallery')}}">
                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/gallery.png 
                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/gallery.png 
                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/gallery.png 
                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/gallery.png 
                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/gallery.png 
                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/gallery.png 
                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/gallery.png 
                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/gallery.png 
                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/gallery.png 
                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/gallery.png  
                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/gallery.png 
                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/gallery.png
                                @else {{url('')}}/images/white/gallery.png @endif " width="35px" /> Gallery
                            </a>
                        </li>
                        
                        <li>
                            @if(Auth::check())
                            <a href="{{ route('barticles') }}">
                            @else
                            <a href="{{ route('articles') }}">
                            @endif
                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/article.png 
                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/article.png 
                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/article.png 
                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/article.png 
                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/article.png 
                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/article.png 
                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/article.png 
                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/article.png 
                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/article.png 
                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/article.png  
                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/article.png 
                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/article.png
                                @else {{url('')}}/images/white/article.png @endif " width="35px" /> Article           
                            </a>
                        </li>

                        <li>
                            @if(Auth::check())
                            <a href="{{action('HomeController@getBussinesscard')}}">
                            @else
                            <a href="#" class="btn-placeholder" data-tipe="businesscard" data-target="#content_desc">
                            @endif
                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/businesscard.png 
                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/businesscard.png 
                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/businesscard.png 
                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/businesscard.png 
                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/businesscard.png 
                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/businesscard.png 
                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/businesscard.png 
                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/businesscard.png 
                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/businesscard.png 
                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/businesscard.png  
                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/businesscard.png 
                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/businesscard.png
                                @else {{url('')}}/images/white/businesscard.png @endif " width="35px" /> Business Card
                            </a>
                        </li>
                        
                        @if($user_setting->custom_linkedin_enable)
                        <li>
                            <a href="{{$user_setting->custom_linkedin_link}}" target="_blank">
                                <img src="@if($user_profile->menu_color == 'ff0000') {{url('')}}/images/red/linkedin.png 
                                @elseif($user_profile->menu_color == '39b54a') {{url('')}}/images/green/linkedin.png 
                                @elseif($user_profile->menu_color == 'faaf2c') {{url('')}}/images/orange/linkedin.png 
                                @elseif($user_profile->menu_color == '0000ff') {{url('')}}/images/blue/linkedin.png 
                                @elseif($user_profile->menu_color == '000000') {{url('')}}/images/black/linkedin.png 
                                @elseif($user_profile->menu_color == '5e5f5f') {{url('')}}/images/grey/linkedin.png 
                                @elseif($user_profile->menu_color == '000080') {{url('')}}/images/navy/linkedin.png 
                                @elseif($user_profile->menu_color == '800000') {{url('')}}/images/maroon/linkedin.png 
                                @elseif($user_profile->menu_color == '800080') {{url('')}}/images/purple/linkedin.png 
                                @elseif($user_profile->menu_color == '824221') {{url('')}}/images/brown/linkedin.png  
                                @elseif($user_profile->menu_color == '1') {{url('')}}/images/white(o)/linkedin.png 
                                @elseif($user_profile->menu_color == '2') {{url('')}}/images/black(t)/linkedin.png
                                @else {{url('')}}/images/white/linkedin.png @endif " width="35px" /> Linkedin
                            </a>
                        </li>
                        @endif
                        
                        @if($user_setting->custom_menu1_enable)
                        <li>
                            <a href="{{$user_setting->custom_menu1_link}}" data-tipe="Link 1" target="_blank">
                                @if($user_setting->custom_menu1_logo != '')
                                <img src="@if($user_setting->custom_menu1_logo == 'line.png') {{url('')}}/images/line.png @elseif($user_setting->custom_menu1_logo == 'fbmsg.png') {{url('')}}/images/fbmsg.png @elseif($user_setting->custom_menu1_logo == 'telegram.png') {{url('')}}/images/telegram.png @elseif($user_setting->custom_menu1_logo == 'wechat.png') {{url('')}}/images/wechat.png @elseif($user_setting->custom_menu1_logo == 'whatsapp.png') {{url('')}}/images/whatsapp.png @else {{url('')}}/uploads/{{$user_setting->custom_menu1_logo}} @endif" width="30px" />
                                @else
                                <i class="fa fa-external-link-square"></i> 
                                @endif
                                @if($user_setting->custom_menu1_name != '')
                                    {{$user_setting->custom_menu1_name}}
                                @else
                                    Custome 1
                                @endif
                            </a>
                        </li>
                        @endif
                        @if($user_setting->custom_menu2_enable)
                        <li>
                            <a href="{{$user_setting->custom_menu2_link}}" data-tipe="Link 2" target="_blank">
                                @if($user_setting->custom_menu2_logo != '')
                                <img src="@if($user_setting->custom_menu2_logo == 'line.png') {{url('')}}/images/line.png @elseif($user_setting->custom_menu2_logo == 'fbmsg.png') {{url('')}}/images/fbmsg.png @elseif($user_setting->custom_menu2_logo == 'telegram.png') {{url('')}}/images/telegram.png @elseif($user_setting->custom_menu2_logo == 'wechat.png') {{url('')}}/images/wechat.png @elseif($user_setting->custom_menu2_logo == 'whatsapp.png') {{url('')}}/images/whatsapp.png @else {{url('')}}/uploads/{{$user_setting->custom_menu2_logo}} @endif" width="30px" />
                                @else
                                <i class="fa fa-external-link-square"></i> 
                                @endif
                                @if($user_setting->custom_menu2_name != '')
                                    {{$user_setting->custom_menu2_name}}
                                @else
                                    Custome 2
                                @endif
                            </a>
                        </li>
                        @endif
                        @if($user_setting->custom_menu3_enable)
                        <li>
                            <a href="{{$user_setting->custom_menu3_link}}" data-tipe="Link 1" target="_blank">
                                @if($user_setting->custom_menu3_logo != '')
                                <img src="@if($user_setting->custom_menu3_logo == 'line.png') {{url('')}}/images/line.png @elseif($user_setting->custom_menu3_logo == 'fbmsg.png') {{url('')}}/images/fbmsg.png @elseif($user_setting->custom_menu3_logo == 'telegram.png') {{url('')}}/images/telegram.png @elseif($user_setting->custom_menu3_logo == 'wechat.png') {{url('')}}/images/wechat.png @elseif($user_setting->custom_menu3_logo == 'whatsapp.png') {{url('')}}/images/whatsapp.png @else {{url('')}}/uploads/{{$user_setting->custom_menu3_logo}} @endif" width="30px" />
                                @else
                                <i class="fa fa-external-link-square"></i> 
                                @endif
                                @if($user_setting->custom_menu3_name != '')
                                    {{$user_setting->custom_menu3_name}}
                                @else
                                    Custome 3
                                @endif
                            </a>
                        </li>
                        @endif
                    </ul>
                </div>                
                @endif
            </div>
        </div>
        <div class="image_road">
            <img src="{{url()}}/images/hover.png" style="opacity: 0.6;">
        </div>
        <div id="status_container"></div>
    </section>
</div>

@include("soulfy.partial.modal",['user'=>$user,'user_setting'=>$user_setting])
@include("soulfy.partial.like")
<!-- JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="{{url('')}}/js/bootstrap.min.js"></script>
<script src="{{url('')}}/js/jquery.nestednav.js"></script>

<script src="{{url('')}}/js/jquery.form.min.js"></script>
<script src="{{url('')}}/js/jquery.bootstrap-growl.min.js"></script>
{{--<script type="text/javascript" src="{{url('')}}/js/jquery.scrollme.min.js"></script>--}}
<script type="text/javascript" src="{{url('')}}/js/html5imageupload.min.js"></script>
<script type="text/javascript" src="{{url('')}}/js/croppic/croppic.js"></script>
<script src="{{url('')}}/js/jquery.MultiFile.js"></script>
{{--<script src="{{url('')}}/js/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>--}}
<script src="{{url('')}}/js/jquery.slimscroll.min.js"></script>
<!--<script src="{{url('')}}/js/timeline_v1.js"></script>-->
<script src="{{url('')}}/js/bootstrap3-wysihtml5.all.min.js"></script>
<script src="{{url('')}}/js/toastr.min.js" type="text/javascript"></script>

{{--<script type="text/javascript" src="{{url('.')}}/js/support6d23.js?version=7.135"></script>--}}
{{--<script type="text/javascript" src="{{url('.')}}/js/latest6d23.js?version=7.135"></script>--}}
<script src="{{url('')}}/ckeditor/ckeditor.js"></script>
@if(Auth::check())
<script src="{{url('')}}/js/chart.js"></script>
@endif

@yield('js')

<script type="text/javascript">

    function timelineShowLoading() {
        $('.tl-loader').fadeIn();
        $('.placeholder-header').css('margin-left', '0');
        $('.content-placeholder').css('margin-left', '20px');
        $('.placeholder-footer').css('margin-left', '0');
        $("#status_img_profile").hide();
        //  $('.placeholder-footer').hide();
        $('.placeholder-footer .second').html("");
        $("#placeholder-first").hide();
    }
    function timelineHideLoading() {
        $('.tl-loader').fadeOut();
    }

    var TIMELINE_LOADING = false;
    //SET POSITION SCROLL BUBBLE
    $(window).load(function () {
        var bubbleHeight = $("#status_container").height();
        var scrollPercent = Math.round(bubbleHeight * 0.125);
        $("body").animate({scrollTop: scrollPercent});
    });
    //INISIALISASI OFFSET DAN TIPE SOSMED
    var skip = 0;
    var social_tipe = "public";
    @if($uri=="home/gallery")
        social_tipe = "gallery";
    @elseif($uri=="home/video")
        social_tipe = "youtube";
    @elseif($uri=="home/articles")
        social_tipe = "article";
    @endif

    $('#upload_background_dialog').on('shown.bs.modal', function (e) {
        $('#modaldialog').html5imageupload({
            onAfterProcessImage: function () {
                $("#background_picture").attr("src", '{{url('')}}' + $(this.element).data('name'));
                pesanOk("Successfully change cover photo");
                setTimeout(function () {
                    location.reload();
                }, 1500);
            },
            onAfterCancel: function () {
                $('#upload_background_dialog').modal("hide");
            }
        });
    });

    $("#btn_change_background").on("click", function () {
        $('#upload_background').click();
        $("#content_body").css('display', 'none');
    });

    function initSlimScroll() {
        $('.slimScroll').each(function () {
            var height, minus = 150, total = 1;

            if ($(this).attr("data-minus")) {
                minus = $(this).attr("data-minus");
            }
            if ($(this).attr("data-total")) {
                total = $(this).attr("data-total");
            }
            if ($(this).attr("data-height")) {
                height = $(this).attr("data-height");
            } /*else {
             height = $(this).css('height');
             }*/
            else {
                height = ($(window).height() - minus) * total; //$('.backend-box>.slimScrollDiv>.slimScroll').length;//$('.slimScroll').length;
            }
            $(this).slimScroll({
                height: height,
            });
        });
    }

    function pesanOk(s) {
        $.bootstrapGrowl(s, {
            type: 'success'
            , allowdismiss: 'true'
            , align: 'center'
        });
    }

    function pesanErr(s) {
        $.bootstrapGrowl(s, {
            type: 'danger'
            , allowdismiss: 'true'
            , delay: 4000
            , align: 'center'
        });
    }
</script>

<script type="text/javascript">
    //$('#status_container').perfectScrollbar();
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var cropperOptions = {
        customUploadButtonId: 'btn_upload',
        outputImageId: 'profile_picture',
        outputImagetThumb: '',
        onBeforeImgUpload: function () {
            $("#image_upload").css('display', 'block');
        },
        onAfterImgUpload: function () {
            $("#image_upload").css('display', 'none');
        },
        onAfterImgCrop: function () {
            cropperHeader.reset()
            location.reload();
        },
        modal: true,
        uploadUrl: '{{action('AjaxController@postUploadimage')}}',
        cropUrl: '{{action('AjaxController@postCropimage')}}',
        loaderHtml: '<div class="loader bubblingG"><span id="bubblingG_1"></span><span id="bubblingG_2"></span><span id="bubblingG_3"></span></div> ',
    }

    var cropperHeader = new Croppic('image_upload', cropperOptions);

    var cropperOptions2 = {
        customUploadButtonId: 'btn_upload_background',
        outputImageId: 'background_picture',
        outputImagetThumb: 'image_thumb',
        onBeforeImgUpload: function () {
            $("#background_upload").css('display', 'block');
        },
        onAfterImgUpload: function () {
            $("#background_upload").css('display', 'none');
        },
        onAfterImgCrop: function () {
            cropperHeader.reset()
        },

        modal: true,
        uploadUrl: '{{action('AjaxController@postUploadimage')}}',
        cropUrl: '{{action('AjaxController@postCropimage')}}',
        loaderHtml: '<div class="loader bubblingG"><span id="bubblingG_1"></span><span id="bubblingG_2"></span><span id="bubblingG_3"></span></div> ',
    }

    var cropperHeader2 = new Croppic('background_upload', cropperOptions2);
    var nbOptions = 11; // number of menus
    var angleStart = -360; // start angle
    $('.dropzone').html5imageupload({
        onAfterProcessImage: function () {
            // $("#edit_image").css('display','none');
            $("#background_picture").attr("src", '{{url('')}}' + $(this.element).data('name'));
            $("#prossfile_pict img").attr("src", '{{url('')}}' + $(this.element).data('name'));
            $("#edit_image").css('display', 'none');
            pesanOk("Successfully change cover photo");
            setTimeout(function () {
                location.reload();
            }, 1500);
        },
        onAfterCancel: function () {
            $("#edit_image").css('display', 'none');
        }
    });
    // $('#modaldialog').html5imageupload({
    //         onAfterProcessImage: function () {
    //             $("#background_picture").attr("src", '{{url('')}}' + $(this.element).data('name'));
    //         },
    //         onAfterCancel: function () {
    //             $('#upload_background_dialog').modal("hide");
    //         }
    //     });
    // jquery rotate animation
    function rotate(li, d) {
        $({d: angleStart}).animate({d: d}, {
            step: function (now) {
                $(li)
                    .css({transform: 'rotate(' + now + 'deg)'})
                    .find('label')
                    .css({transform: 'rotate(' + (-now) + 'deg)'});
            }, duration: 0
        });
    }

    function editProfile() {
        $('#profilefileupload').click();
        $("#edit_image").css('display', 'inline-block');
    }

    drawStatus();
    //
    // var scale = 0.1;  // scale of the image
    // var xLast = 100;  // last x location on the screen
    // var yLast = 20;  // last y location on the screen
    // var xImage = 100; // last x location on the image
    // var yImage = 20; // last y location on the image
    $(function () {
        var total = $('div[id="status"]').length;
        var window_width = $(window).height() - $('#status').height();
        var document_height = $(document).height() - $(window).height();
        $(window).scroll(function () {
            var scroll_position = $(window).scrollTop();
            var myArray = [];
            $('div[id="status"]').each(function (index) {
                // var object_position_left = window_width * (scroll_position/ document_height) * total;
                //var left = $(this).css("left");
                var hitung = (scroll_position);
                var scale = scroll_position / document_height * total * 10;
                scale = scale / 50;
                scale = scale + index * 0.60;
                scale = scale - index * 0.9;
                // scale = scale /  4 * 0.9;
                var data = {};
                // data.left = ((object_position_left - 310 ) / (total - index)) + (index*1.2) * 175;
                // data.left = object_position_left*1.7;
                // // data.top = ((object_position_left - 100) / (total - index)) + (index*0.6) * 180;
                // data.top = object_position_left/2;
                data.scale = scale;
                myArray.push(data);
            });

            $('div[id="status"]').each(function (index) {
                //var left = myArray[index].left;
                var scale = myArray[index].scale;
                //var top =  myArray[index].top;
                //var tes = scale*1.2;
                // $(this).css({
                //     // 'left': left,
                //     // 'top': top,
                //     // transform: 'translate('+left+'px,'+top+'px)'
                // });

                var diagonalYOffset = $(window).height() * 0.2 * 2 * 1.1;
                var diagonalX = scale * $(window).width();
                //if($(window).width()>$(window).height() && $(window).width() <= 700) diagonalX *= 1.7
                //else if($(window).width()>$(window).height()) diagonalX-=diagonalX*($(window).height()/$(window).width())*scale*0.9;
                //else diagonalX-=diagonalX*($(window).width()/$(window).height())*scale*0.8;
                var diagonalY = scale * ($(window).height() + 200) / 0.95;
                var w = $(window).width();
                var h = $(window).height();
                if (diagonalX > 0) {
                    $(this).css({
                        transform: 'translate(' + (540 + diagonalX) + 'px,' + (diagonalYOffset + diagonalY) + 'px) scale(' + scale * 1.9 + ')',
                        opacity: scale > 1.5 ? 0 : scale * 2.1
                    });
                } else {
                    $(this).css({
                        transform: 'translate(' + 500 + 'px,' + 0 + 'px) scale(' + 0 + ',' + 0 + ')',
                        opacity: scale > 1.3 ? 0 : scale
                    });
                }
            });
        });
    });

    function drawStatus() {
                @if(count($timeline)>0)
        var id = [
                    @for ( $i = count($timeline)-1; $i >= 0; $i--)
                        "{{$timeline[$i]->id}}",
                    @endfor];
                @if ($uri=="home/gallery")
        var content = [
                    @for ( $i = count($timeline)-1; $i >= 0; $i--)
                        "{{htmlspecialchars(str_replace("\n","", str_replace("\r","",$timeline[$i]->content)))}}",
                    @endfor];
        var data_content = [
            @for ( $i = count($timeline)-1; $i >= 0; $i--)
                "{{ htmlspecialchars(str_replace("\n","<br>", str_replace("\r","",$timeline[$i]->content))) }}",
            @endfor];
                @else
        var content = [
                    @for ( $i = count($timeline)-1; $i >= 0; $i--)
                        "{!! str_replace("\"", '\\"', str_replace("\n","", str_replace("\r","", strip_tags(Soulfy\Timeline::split_words(strip_tags($timeline[$i]->content),75,"...") )))) !!}",
                    @endfor];
        var data_content = [
            @for ( $i = count($timeline)-1; $i >= 0; $i--)
                "{{ str_replace("\n","<br>", str_replace("\r","",$timeline[$i]->content)) }}",
            @endfor];
                @endif
        var tanggal = [
                    @for ( $i = count($timeline)-1; $i >= 0; $i--)
                        "{{ date("d M Y",strtotime($timeline[$i]->created_at))  }}",
                    @endfor];

        var jenis_sosmed = [
            @for ( $i = count($timeline)-1; $i >= 0; $i--)
                "{{$timeline[$i]->social}}",
            @endfor];
        var id = [
            @for ( $i = count($timeline)-1; $i >= 0; $i--)
                "{{$timeline[$i]->id}}",
            @endfor];
        var data_tittle = [
            @for ( $i = count($timeline)-1; $i >= 0; $i--)
                "{{str_replace("\n","<br>", str_replace("\r","", $timeline[$i]->tittle))}}",
            @endfor];

                @if($uri=="home/articles")
        var data_tittle = [
                    @for ( $i = count($timeline)-1; $i >= 0; $i--)
                        "{{str_replace("\n","<br>", str_replace("\r","", $timeline[$i]->tittle))}}",
                    @endfor],
            content = [
                @for ( $i = count($timeline)-1; $i >= 0; $i--)
                    "{{ str_replace("\n","<br>", str_replace("\r","", \Soulfy\Timeline::split_words($timeline[$i]->tittle,20,"...")))}}",
                @endfor];
                @else
                @endif
        var height = 2000;
        var profile_image = "";
        var style = "";
        
        for (i = 0; i < tanggal.length; i++) {
            if (jenis_sosmed[i] == "fb") {
                var icon = "fb";
                profile_image = '{!! $fb_image_url !!}';
                style = "height: 100%;text-align: left;margin: 10px 22px 0px 57px;";
            } else if (jenis_sosmed[i] == "twitter") {
                var icon = "twitter";
            } else if (jenis_sosmed[i] == "google") {
                var icon = "google";
            } else if (jenis_sosmed[i] == "soulfy") {
                var icon = "soulfy";
            } else if (jenis_sosmed[i] == "article") {
                var icon = "article";
            } else if (jenis_sosmed[i] == "youtube") {
                var icon = "youtube";
                content[i] = data_content[i].split("/");
                content[i] = content[i][4];
                content[i] = "<img src ='https://img.youtube.com/vi/" + content[i] + "/default.jpg'>";
            } else if (jenis_sosmed[i] == "gallery") {
                var icon = "gallery-icon";
                content[i] = "<img class='img-gallery' src ='{{url("")}}/uploads/" + content[i] + "' >";
            };
            if (jenis_sosmed[i] == "twitter") {
                var btna = "R";
            } else {
                var btna = "C";
            };

            var left = 0 - i * 150;
            var top = 0;
            var template =
                '<a  id="read" class="btn-placeholder status-box" data-id="' + id[i] + '" data-tipe="' + jenis_sosmed[i] + '" ' +
                'data-tittle="' + data_tittle[i] + '" ' +
                ' data-url="{{url('')}}" data-content="' + data_content[i] + '" data-date="' + tanggal[i] + '" data-profile="{{$user_profile->profile_image}}" data-target="#content_desc" >' +
                '<div id="status" class="stats-box stats2" style="transform: translate(' + left + 'px,' + top + 'px)">' +
                '<div class="stats stats-twitter">' +
                profile_image +

                '<p id="status_content" style="' + style + '" disabled="true">' + content[i] + '</p>' +

                '<span id="status_location" class="left">' + '</span>' +
                '<span id="status_date" class="right">' + tanggal[i] + '</span>' +
                '<div class="stats-nav">' +
                {{--'<a id="btn-act" class="btn-circle btn1 btn-placeholder" data-id="'+id[i]+'" '+--}}
                        {{--@if($uri=="home/articles")--}}
                        {{--'data-tittle="'+data_tittle[i]+'" '+--}}
                        {{--@endif--}}
                        {{--' data-tipe="'+ jenis_sosmed[i]+'" data-url="{{url('')}}" data-content="'+data_content[i]+'" data-date="'+tanggal[i]+'" data-target="#content_desc">'+btna+'</a>'+--}}

                        @if(Auth::check())

                    '<a id="btn-act-delete"  onclick="deleteTimeLine(this)" data-id=' + id[i] + ' data-type=' + jenis_sosmed[i] + ' class="btn-circle btn1 btn-act-delete"><span class="glyphicon glyphicon-trash"></span></a>' +
                @endif
                    '</div>' +
                '</div>' +
                '</div>' +
                '</a>';
            $("#status_container").prepend(template);
            $("#status_container").css("height", height + "px");
            height += 2000;
        }
        @endif
    }
    // show / hide the options
    function toggleOptions(s) {
        $(s).toggleClass('open');
        var li = $(s).find('li');
        var deg = $(s).hasClass('half') ? 180 / (li.length - 1) : 360 / li.length;
        for (var i = 0; i < li.length; i++) {
            var d = $(s).hasClass('half') ? (i * deg) - 90 : i * deg;
            $(s).hasClass('open') ? rotate(li[i], d) : rotate(li[i], angleStart);
        }
    }

    $('#profile_picture').click(function (e) {
        toggleOptions($(".selector"));
    });

    setTimeout(function () {
        toggleOptions('.selector');
    }, 100);
</script>

<!-- script to manipulate menu -->
<script type="text/javascript">
    var home = "not activated";
    var article = "not activated";
    var email = "not activated";
    var fb = "not activated";
    var twitter = "not activated";
    var flickr = "not activated";
    var youtube = "not activated";
    var skype = "not activated";
    var google = "not activated";
    var gallery = "not activated";
    var article = "not activated";
    var businesscard = "not activated";
    @if($uri == "home/video")
        youtube = "activated";
    @elseif($uri == "home/articles")
        article = "activated";
    @elseif($uri == "home/gallery")
        gallery = "activated";
    @elseif($uri = "home/bussinesscard")
        businesscard = "activated";
    @else
            @if(Auth::check())
        article = "activated";
    @endif
    @endif
</script>

<!-- GET DATA TO BUBBLE -->
<script src="{{url('')}}/js/soulfy.js"></script>
<!-- END OF GET DATA TO BUBBLE -->
<script>
    @if(Auth::check())
        $('nav#w0').bind('mouseover click', function () {
        $('ul#w1 > li:not(.unhidden), ul#w1>form').show();
        $('nav#w0').css('background', 'url("../images/header-nav.png") no-repeat 0 0 / cover transparent')
            .css('border', '1');
    });
    $('nav#w0').mouseleave(function () {
        headerMouseLeave();
    });
    @endif
    function headerMouseLeave() {
        $('ul#w1 > li:not(.unhidden), ul#w1>form').hide();
        $('nav#w0').css('background', 'transparent')
            .css('border', '0');
    }

    headerMouseLeave();
    @if(Auth::check())
        $(".selector #profile_image").hover(
            function () {
                $("#profile_image_edit").css('display', 'block');
            }, function () {
                $("#profile_image_edit").css('display', 'none');
            }
        );
        $(".selector-menu #profile_image").hover(
            function () {
                $("#profile_image_edit").css('display', 'block');
            }, function () {
                $("#profile_image_edit").css('display', 'none');
            }
        );

    $(".dropzone.cover-upload").hover(
        function () {
            $("#drop-upload").css('width', '50');
            $("#drop-upload").css('height', '50');
            $("#drop-upload").css('margin-top', '100px');
            $("#drop-upload").css('margin-left', '313px');
            $("#icon-cu").css('display', 'block');
        }, function () {
            $("#drop-upload").css('width', '50');
            $("#drop-upload").css('height', '50');
            $("#drop-upload").css('margin-top', '100px');
            $("#drop-upload").css('margin-left', '313px');

            $("#icon-cu").css('display', 'none');
        }
    );

    var inputfile = $(".dropzone.cover-upload");
    inputfile.on("change click", function (ev) {
        $("#change_background").trigger("click");
        if(true) return false;
        if (ev.originalEvent != null) {
            $("#drop-upload").css('width', '920');
            $("#drop-upload").css('height', '640');
            $("#drop-upload").css('margin-top', '0px');
            $("#drop-upload").css('margin-left', '0px');
            $("#icon-cu").css('display', 'none');
        }
        document.body.onfocus = function () {
            document.body.onfocus = null;
            if (inputfile.val().length != 0)
                $("#drop-upload").css('width', '920');
            $("#drop-upload").css('height', '640');
            $("#drop-upload").css('margin-top', '0px');
            $("#drop-upload").css('margin-left', '0px');
            $("#icon-cu").css('display', 'none');
            if (inputfile.val().length === 0)
                $("#drop-upload").css('width', '50');
            $("#drop-upload").css('height', '50');
            $("#drop-upload").css('margin-top', '100px');
            $("#drop-upload").css('margin-left', '313px');
            $("#icon-cu").css('display', 'none');
        };
        document.body.onfocus = function () {
            document.body.onfocus = null;
            if (inputfile.val().length > 0)
                $("#drop-upload").css('width', '920');
            $("#drop-upload").css('height', '640');
            $("#drop-upload").css('margin-top', '0px');
            $("#drop-upload").css('margin-left', '0px');
            $("#icon-cu").css('display', 'none');
        };
    });

    $(".dropzone.cover-upload").hover(
        function () {
            $("#dropzone-overlay").css('display', 'block');
        }, function () {
            $("#dropzone-overlay").css('display', 'none');
        }
    );
    @endif

    $('#main-nav').nestednav({
        menuButtonSelector: '.navbar-toggle',
        mainNavSelector: '.nav.navbar-nav',
        caretIconHtml: '<span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>',
        nestedBoxIconHtml: '<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>',
    });
</script>

<!-- script menu hover -->
<script type="text/javascript">
    $(function () {
        $(".social-media-box img")
            .mouseover(function () {
                var src = $(this).attr("src").replace(".png", "-hover.png");
                $(this).attr("src", src);
            })
            .mouseout(function () {
                var src = $(this).attr("src").replace("-hover.png", ".png");
                $(this).attr("src", src);
            });
    });

    $(document).ready(function () {
        // $('#status_container').slimScroll(
        //         {
        //             height: '5650px'
        //         }
        // );
        $('[data-toggle="tooltip"]').tooltip();

        setInterval(function () {
            //$.get("{{action("HomeController@getFacebook")}}?user_id={{$user['id']}}", function (data) {
            //$("#setting").html(data);
            //});
        }, 5000);

        initSlimScroll();
        $("#profile_info").wysihtml5({
            toolbar: {
                "font-styles": true, //Font styling, e.g. h1, h2, etc. Default true
                "emphasis": true, //Italics, bold, etc. Default true
                "lists": true, //(Un)ordered lists, e.g. Bullets, Numbers. Default true
                "html": true, //Button which allows you to edit the generated HTML. Default false
                "link": false, //Button to insert a link. Default true
                "image": false, //Button to insert an image. Default true,
                "color": false, //Button to change color of font
                "blockquote": false, //Blockquote
            }
        });

        var options = {
            beforeSubmit: function () {
                $("#btn_save_profile_info").button("loading");
            },
            success: function (data) {
                $("#btn_save_profile_info").button("reset");
                pesanOk(data.message);
                location.reload();
            },
            error: function (data) {
                $("#btn_save_profile_info").button("reset");
                try {
                    var message = JSON.parse(data.responseText);
                    if (message.message != "") {
                        pesanErr(message.message);
                    }
                } catch (ec) {
                    pesanErr("Oops try again.");
                }
            }
        };

        $("#form_update_profile_info").ajaxForm(options);
    });
</script>
<!-- script load timeline activate menu -->
<script>
    function loadtimeline(base, type) {
        $("#status_img_profile").hide();
        if (TIMELINE_LOADING) return;
        TIMELINE_LOADING = true;
        timelineShowLoading();
        skip = 0;
        social_tipe = type;

        if (type == "article") {
            $('.placeholder-second').hide();
            $('.placeholder-first').hide();
            $(".backend-box").hide();
            $(".content-gallery ").hide();
            $("#artikel_placeholder").show();
            $(".placeholder-third").hide();
//            alert(1);
            $(".plus-minus-toggeler:not(.dont-hide)").hide();
        }

        if (type == "path") {
            pesanErr("Sorry, we are not yet available");
        }
        else {
            if($('label[for=c10] a img').length > 0) {
                var src = $('label[for=c10] a img').attr("src").replace("-hover.png", ".png");
                $('label[for=c10] a img').attr("src", src);
            }

            if (type == "fb") {
                showProfileInfo('{{$user_profile->name}}', '{{$user_profile->birthday!=null ?date("Y-m-d",strtotime($user_profile->birthday)):""}}', '{{$user_profile->hometown}}', '{{$user_profile->gender}}', '{{$user_profile->location}}', '{{$user_profile->education}}', '{{$user_profile->work}}', '{{$user_profile->profile_image}}');
            }
            // @ if (auth::check()){
            /*if (type == "twitter") {
                showProfileInfoTwitter("{ {$user->twitter->name}}", "{ {$user->twitter->screen_name}}", "{ {$user->twitter->profile_image}}", "{ {$user->twitter->description}}", 0, 0);
            } */
            // @ endif
        }
            //pesanOk("Loading "+type+" timeline.....");
            $("#status_container").html('');
            $.ajax({
                type: "POST",
                url: '{{action("AjaxController@postTimeline")}}',
                data: {
                    type: type,
                },
                success: function (data) {
                    //pesanOk("Load successfully");
                    /*$('div[id="status"]').each(function (i, e) {
                     if(data[i]!=undefined){*/
                    var height = 2000;
                    if (type == "article") {

                        if (data.length <= 0) {
                            $("#artikel_placeholder").hide();
                        }
                    }
                    for (i = data.length - 1; i >= 0; i--) {

                        var social_icon = '<span id="icon" class="' + data[i].social_type + '"></span>';

                        @if ($image_url != null)
                        // social_icon = '<img class="fb_profile" src="{{$image_url}}">';
                        @endif

                        if (data[i].social_type == "twitter") {

                            var btna = "R";
                        } else {
                            var btna = "C";
                        };

                        var btn_delete_style = "";
                        if (data[i].social_type == "twitter" || data[i].social_type == "fb") {
                            btn_delete_style = "display:none";
                        }
                        var profile_image = "";
                        var style = "";
                        if (data[i].social_type == "fb") {
                            profile_image = '{!! $fb_image_url !!}';
                            style = "height: 100%;text-align: left;margin: 10px 22px 0px 57px;";
                        }
                        var left = 0 - i * 150;
                        var top = 0;
                        var template =
                            '<a  id="read" class="btn-placeholder status-box" data-id=' + data[i].id + ' data-tipe="' + data[i].social_type + '" ' +
                            'data-tittle="' + data[i].tittle + '" ' +
                            ' data-url="{{url('')}}" data-content="' + data[i].data_content + '" data-date="' + data[i].date + '" data-profile="{{$user_profile->profile_image}}" data-target="#content_desc" >' +
                            '<div id="status" class="stats-box stats2" style="transform: translate(' + left + 'px,' + top + 'px)">' +
                            '<div class="stats stats-twitter">' +
                            social_icon +
                            profile_image +
                            '<p id="status_content" style="' + style + '" disabled="true">' + data[i].content + '</p>' +

                            '<span id="status_location" class="left">' + data[i].location + '</span>' +
                            '<span id="status_date" class="right">' + data[i].date + '</span>' +
                            '<div class="stats-nav">' +
                            {{--'<a id="btn-act" class="btn-circle btn1 btn-placeholder" '+--}}
                            {{--' data-tipe="'+ data[i].social_type+'" data-id='+data[i].id+' data-url="{{url('')}}" data-content="'+data[i].data_content+'" data-date="'+data[i].date+'" data-target="#content_desc">'+btna+'</a>'+--}}
                            // '<a id="btn-act-delete" data-id='+data[i].id+' data-type='+data[i].social_type+' class="btn-circle btn3 btn-act-delete"><span class="glyphicon glyphicon-trash"></span></a>'+
                            // '<a style="background:white" class="btn-circle btn1 btn-act-delete"><span id="icon" class="' + data[i].social_type +'"></span></a>'+
                            @if(Auth::check())

                                '<a id="btn-act-delete" style="' + btn_delete_style + '"  onclick="deleteTimeLine(this)" data-id=' + data[i].id + ' data-type=' + data[i].social_type + ' class="btn-circle btn1 btn-act-delete"><span class="glyphicon glyphicon-trash"></span></a>' +

                            @endif
                                '</div>' +
                            '</div>' +
                            '</div>' +
                            '</a>';
                        $("#status_container").prepend(template);
                        $("#status_container").css("height", height + "px");
                        height += 2000;
                    }
                    /*}
                     });*/
                    //document.body.scrollTop = document.documentElement.scrollTop = $(document).height()*0.125;
                },
                error: function () {
                    pesanErr("Oops try again.");
                },
                complete: function () {
                    TIMELINE_LOADING = false;
                    timelineHideLoading();
                }
            });

            if (type == 'fb') {
                // aktifkan menu fb
                setTimeout(function () {
                    if($('label[for=c2] a img').length > 0) {
                        var src = $('label[for=c2] a img').attr("src").replace("button-02.png", "button-02-hover.png");
                        $('label[for=c2] a img').attr("src", src);
                    }
                }, 300);

                if (fb !== "activated") {

                    // activate menu fb
                    fb = "activated";
                    article = "not activated";
                    home = "not activated";
                    email = "not activated";
                    twitter = "not activated";
                    flickr = "not activated";
                    youtube = "not activated";
                    skype = "not activated";
                    google = "not activated";
                    gallery = "not activated";
                    article = "not activated";
                    businesscard = "not activated";
                }

                // non aktifkan menu bcard
                if($('label[for=c11] a img').length > 0) {
                    var src = $('label[for=c11] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c11] a img').attr("src", src);
                }
                // non aktifkan menu home
                if($('label[for=c12] a img').length > 0) {
                    var src = $('label[for=c12] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c12] a img').attr("src", src);
                }
                // non aktifkan menu email
                if($('label[for=c1] a img').length > 0) {
                    var src = $('label[for=c1] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c1] a img').attr("src", src);
                }
                // non aktifkan menu twitter
                if($('label[for=c3] a img').length > 0) {
                    var src = $('label[for=c3] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c3] a img').attr("src", src);
                }
                // non aktifkan menu flickr
                //var src = $('label[for=c5] a img').attr("src").replace("-hover.png", ".png");
                //$('label[for=c5] a img').attr("src", src);

                // non aktifkan menu youtube
                if($('label[for=c6] a img').length > 0) {
                    var src = $('label[for=c6] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c6] a img').attr("src", src);
                }
                // non aktifkan menu skype
//                var src = $('label[for=c7] a img').attr("src").replace("-hover.png", ".png");
//                $('label[for=c7] a img').attr("src", src);

                // non aktifkan menu google
                if($('label[for=c8] a img').length > 0) {
                    var src = $('label[for=c8] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c8] a img').attr("src", src);
                }
                // non aktifkan menu gallery
                if($('label[for=c9] a img').length > 0) {
                    var src = $('label[for=c9] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c9] a img').attr("src", src);
                }
                // non aktifkan menu article
                if($('label[for=c10] a img').length > 0) {
                    var src = $('label[for=c10] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c10] a img').attr("src", src);
                }
            }
            else if (type == 'twitter') {
                // aktifkan menu twitter
                if (twitter !== "activated") {
                    // activate twitter menu
                    if($('label[for=c3] a img').length > 0) {
                        var src = $('label[for=c3] a img').attr("src").replace(".png", "-hover.png");
                        $('label[for=c3] a img').attr("src", src);
                    }
                    twitter = "activated";
                    article = "not activated";
                    home = "not activated";
                    email = "not activated";
                    fb = "not activated";
                    flickr = "not activated";
                    youtube = "not activated";
                    skype = "not activated";
                    google = "not activated";
                    gallery = "not activated";
                    article = "not activated";
                    businesscard = "not activated";
                }
                // non aktifkan menu bcard
                if($('label[for=c11] a img').length > 0) {
                    var src = $('label[for=c11] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c11] a img').attr("src", src);
                }
                // non aktifkan menu home
                if($('label[for=c12] a img').length > 0) {
                    var src = $('label[for=c12] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c12] a img').attr("src", src);
                }
                // non aktifkan menu email
                if($('label[for=c1] a img').length > 0) {
                    var src = $('label[for=c1] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c1] a img').attr("src", src);
                }
                // non aktifkan menu fb
                if($('label[for=c2] a img').length > 0) {
                    var src = $('label[for=c2] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c2] a img').attr("src", src);
                }
                // non aktifkan menu flickr
                //var src = $('label[for=c5] a img').attr("src").replace("-hover.png", ".png");
                //$('label[for=c5] a img').attr("src", src);

                // non aktifkan menu youtube
                if($('label[for=c6] a img').length > 0) {
                    var src = $('label[for=c6] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c6] a img').attr("src", src);
                }
                // non aktifkan menu skype
//                var src = $('label[for=c7] a img').attr("src").replace("-hover.png", ".png");
//                $('label[for=c7] a img').attr("src", src);
                // non aktifkan menu google
                if($('label[for=c8] a img').length > 0) {
                    var src = $('label[for=c8] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c8] a img').attr("src", src);
                }
                // non aktifkan menu gallery
                if($('label[for=c9] a img').length > 0) {
                    var src = $('label[for=c9] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c9] a img').attr("src", src);
                }
                // non aktifkan menu article
                if($('label[for=c10] a img').length > 0) {
                    var src = $('label[for=c10] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c10] a img').attr("src", src);
                }
            }
            else if (type == 'google') {
                // aktifkan menu google
                if (google !== "activated") {
                    // activate google menu
                    if($('label[for=c8] a img').length > 0) {
                        var src = $('label[for=c8] a img').attr("src").replace(".png", "-hover.png");
                        $('label[for=c8] a img').attr("src", src);
                    }
                    google = "activated";
                    article = "not activated";
                    home = "not activated";
                    email = "not activated";
                    fb = "not activated";
                    twitter = "not activated";
                    flickr = "not activated";
                    youtube = "not activated";
                    skype = "not activated";
                    google = "not activated";
                    gallery = "not activated";
                    article = "not activated";
                    businesscard = "not activated";
                }
                // non aktifkan menu bcard
                if($('label[for=c11] a img').length > 0) {
                    var src = $('label[for=c11] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c11] a img').attr("src", src);
                }
                // non aktifkan menu home
                if($('label[for=c12] a img').length > 0) {
                    var src = $('label[for=c12] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c12] a img').attr("src", src);
                }
                // non aktifkan menu email
                if($('label[for=c1] a img').length > 0) {
                    var src = $('label[for=c1] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c1] a img').attr("src", src);
                }
                // non aktifkan menu fb
                if($('label[for=c2] a img').length > 0) {
                    var src = $('label[for=c2] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c2] a img').attr("src", src);
                }
                // non aktifkan menu twitter
                if($('label[for=c3] a img').length > 0) {
                    var src = $('label[for=c3] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c3] a img').attr("src", src);
                }
                // non aktifkan menu flickr
                //var src = $('label[for=c5] a img').attr("src").replace("-hover.png", ".png");
                //$('label[for=c5] a img').attr("src", src);

                // non aktifkan menu youtube
                if($('label[for=c6] a img').length > 0) {
                    var src = $('label[for=c6] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c6] a img').attr("src", src);
                }
                // non aktifkan menu skype
//                var src = $('label[for=c7] a img').attr("src").replace("-hover.png", ".png");
//                $('label[for=c7] a img').attr("src", src);
                // non aktifkan menu gallery
                if($('label[for=c9] a img').length > 0) {
                    var src = $('label[for=c9] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c9] a img').attr("src", src);
                }
                // non aktifkan menu article
                if($('label[for=c10] a img').length > 0) {
                    var src = $('label[for=c10] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c10] a img').attr("src", src);
                }
            }
            else if (type == 'article') {
                $("#content-profile").css('width', '465px');
                // aktifkan menu article
                if (article !== "activated") {
                    // activate article menu
                    if($('label[for=c10] a img').length > 0) {
                        var src = $('label[for=c10] a img').attr("src").replace(".png", "-hover.png");
                        $('label[for=c10] a img').attr("src", src);
                    }
                    google = "not activated";
                    article = "not activated";
                    home = "not activated";
                    email = "not activated";
                    fb = "not activated";
                    twitter = "not activated";
                    flickr = "not activated";
                    youtube = "not activated";
                    skype = "not activated";
                    google = "not activated";
                    gallery = "not activated";
                    article = "activated";
                    businesscard = "not activated";
                }
                // non aktifkan menu bcard
                if($('label[for=c11] a img').length > 0) {
                    var src = $('label[for=c11] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c11] a img').attr("src", src);
                }
                // non aktifkan menu home
                if($('label[for=c12] a img').length > 0) {
                    var src = $('label[for=c12] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c12] a img').attr("src", src);
                }
                // non aktifkan menu email
                if($('label[for=c1] a img').length > 0) {
                    var src = $('label[for=c1] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c1] a img').attr("src", src);
                }
                // non aktifkan menu fb
                if($('label[for=c2] a img').length > 0) {
                    var src = $('label[for=c2] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c2] a img').attr("src", src);
                }
                // non aktifkan menu flickr
                //var src = $('label[for=c5] a img').attr("src").replace("-hover.png", ".png");
                //$('label[for=c5] a img').attr("src", src);
                // non aktifkan menu youtube
                if($('label[for=c6] a img').length > 0) {
                    var src = $('label[for=c6] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c6] a img').attr("src", src);
                }
                // non aktifkan menu skype
//                var src = $('label[for=c7] a img').attr("src").replace("-hover.png", ".png");
//                $('label[for=c7] a img').attr("src", src);
                // non aktifkan menu google
                if($('label[for=c8] a img').length > 0) {
                    var src = $('label[for=c8] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c8] a img').attr("src", src);
                }
                // non aktifkan menu gallery
                if($('label[for=c9] a img').length > 0) {
                    var src = $('label[for=c9] a img').attr("src").replace("-hover.png", ".png");
                    $('label[for=c9] a img').attr("src", src);
                }
                // non aktifkan menu skype
                if($('label[for=c10] a img').length > 0) {
                    var src = $('label[for=c10] a img').attr("src").replace(".png", "-hover.png");
                    $('label[for=c10] a img').attr("src", src);
                }
            }
        }
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $('.input_soulfy-checkbox').each(function () {
            $(this).hide().after('<div class="soulfy-checkbox" />');
        });

        $('.soulfy-checkbox').on('click', function () {
            $(this).toggleClass('checked').prev().prop('checked', $(this).is('.checked'))
        });
    });
</script>
<script>
    {{--//fungsi hapus timeline--}}
    {{--$(".btn-act-delete").click(function(){--}}
    {{--var id_timeline = $(this).attr('data-id'),--}}
    {{--social_type = $(this).attr('data-type');--}}
    {{--if (confirm("Anda yakin ingin menghapus posting ini?")) {--}}
    {{--$.ajax({--}}
    {{--type: "POST",--}}
    {{--url: '{{action("AjaxController@postDeleteTimeline")}}',--}}
    {{--dataType : "text",--}}
    {{--data : {--}}
    {{--id_timeline : id_timeline,--}}
    {{--social_type : social_type,--}}
    {{--},--}}
    {{--success: function (response) {--}}

    {{--if (response=='"success"') {--}}
    {{--pesanOk("successfully deleted");--}}
    {{--setTimeout(function(){location.reload()},1000);--}}
    {{--}else if(response=='"error"'){--}}
    {{--pesanErr("the URL you entered is wrong");--}}
    {{--};--}}
    {{--}--}}
    {{--});--}}
    {{--}--}}

    {{--});--}}

    function deleteTimeLine(obj) {
        var id_timeline = $(obj).attr('data-id'),
            social_type = $(obj).attr('data-type');
        if (confirm("Anda yakin ingin menghapus posting ini?")) {
            $.ajax({
                type: "POST",
                url: '{{action("AjaxController@postDeleteTimeline")}}',
                dataType: "text",
                data: {
                    id_timeline: id_timeline,
                    social_type: social_type,
                },
                success: function (response) {
                    if (response == '"success"') {
                        pesanOk("successfully deleted");
                        setTimeout(function () {
                            location.reload()
                        }, 1000);
                    } else if (response == '"error"') {
                        pesanErr("the URL you entered is wrong");
                    };
                }
            });
        }
    }
            @if (Session::has('message_'))
    var message = "{{ Session::get('message_') }}";
    if (message == "error") {
        pesanErr("Please choose the file");
    } else {
        pesanOk(message);
    }
    @endif

    $(window).scroll(function () {
        if ($(window).scrollTop() + $(window).height() > $(document).height() - 100 && !TIMELINE_LOADING) {
            var offset = skip + 8;
            TIMELINE_LOADING = true;
            timelineShowLoading();
            //pesanOk("Loading timeline.....");
            $.ajax({
                type: "POST",
                url: '{{action("AjaxController@postGettimeline")}}',
                data: {
                    offset: offset,
                    social_tipe: social_tipe,
                },
                success: function (data) {
                    if (data == '"error"') {
                        pesanErr("No more data");
                    } else {
                        //pesanOk("Load successfully");

                        /*$('div[id="status"]').each(function (i, e) {
                         if(data[i]!=undefined){*/
                        //data.reverse();
                        var height = $('div[id="status"]').length * 2000;
                        for (i = data.length - 1; i >= 0; i--) {
                            if (data[i].social_type == "youtube") {

                                var content = data[i].data_content;
                                content = content.split("/");
                                content = content[4];
                                content = "<img src ='https://img.youtube.com/vi/" + content + "/default.jpg'>";
                            } else {
                                var content = data[i].content;
                            };

                            if (data[i].social_type == "twitter") {
                                var btna = "R";
                            } else {
                                var btna = "C";
                            };

                            if (data[i].social_type != "youtube") {
                                var content = data[i].content;
                            }

                            var btn_delete_style = "";
                            if (data[i].social_type == "twitter" || data[i].social_type == "fb") {
                                btn_delete_style = "display:none";
                            }
                            var profile_image = "";
                            var style = "";
                            if (data[i].social_type == "fb") {
                                profile_image = '{!! $fb_image_url !!}';
                                style = "height: 100%;text-align: left;margin: 10px 22px 0px 57px;";
                            }

                            var left = 0 - i * 150;
                            var top = 0;
                            var template =
                                '<a  id="read" class="btn-placeholder status-box" data-id=' + data[i].id + ' data-tipe="' + data[i].social_type + '" ' +
                                ' data-url="{{url('')}}" data-content="' + data[i].data_content + '" data-date="' + data[i].date + '" data-profile="{{$user_profile->profile_image}}" data-target="#content_desc" >' +
                                '<div id="status" class="stats-box stats2" style="transform: translate(' + left + 'px,' + top + 'px)">' +
                                '<div class="stats stats-twitter">' +
                                '<span id="icon" class="' + data[i].social_type + '"></span>' +
                                profile_image +
                                '<p id="status_content" style="' + style + '" disabled="true">' + content + '</p>' +

                                '<span id="status_location" class="left">' + data[i].location + '</span>' +
                                '<span id="status_date" class="right">' + data[i].date + '</span>' +
                                '<div class="stats-nav">' +
                                {{--'<a id="btn-act" class="btn-circle btn1 btn-placeholder" '+--}}
                                        {{--' data-tipe="'+ data[i].social_type+'" data-id='+data[i].id+' data-url="{{url('')}}" data-content="'+data[i].data_content+'" data-date="'+data[i].date+'" data-target="#content_desc">'+btna+'</a>'+--}}

                                        @if(Auth::check())

                                    '<a id="btn-act-delete" style="' + btn_delete_style + '" onclick="deleteTimeLine(this)" data-id=' + data[i].id + ' data-type=' + data[i].social_type + ' class="btn-circle btn1 btn-act-delete"><span class="glyphicon glyphicon-trash"></span></a>' +

                                @endif
                                    '</div>' +
                                '</div>' +
                                '</div>' +
                                '</a>';
                            //$("#status_container").append(template);
                            //$("#status_container").css("height", height + "px");
                            //height += 2000;
                        }
                        /*}
                         });*/
                        skip = skip + 8;
                    };
                },
                error: function () {
                    pesanErr("Oops try again.");
                },
                complete: function () {
                    TIMELINE_LOADING = false;
                    timelineHideLoading();
                }
            });
            //document.body.scrollTop = document.documentElement.scrollTop = $(document).height()*0.125;
        }
    });
    $(window).scroll(function () {
        if ($(window).scrollTop() < 300 && !TIMELINE_LOADING) {
            if (skip > 0) {
                TIMELINE_LOADING = true;
                timelineShowLoading();
                var offset = skip - 8;
                //pesanOk("Loading timeline.....");
                $.ajax({
                    type: "POST",
                    url: '{{action("AjaxController@postGettimeline")}}',
                    data: {
                        offset: offset,
                        social_tipe: social_tipe,
                    },
                    success: function (data) {
                        var tot_height = 2000 * data.length;
                        //pesanOk("Load successfully");
                        $('div[id="status"]').each(function (i, e) {
                            if (data[i] != undefined) {
                                var height = $('div[id="status"]').length * 2000;
                                for (i = data.length - 1; i >= 0; i--) {
                                    if (data[i].social_type == "youtube") {
                                        var content = data[i].data_content;
                                        content = content.split("/");
                                        content = content[4];
                                        content = "<img src ='https://img.youtube.com/vi/" + content + "/default.jpg'>";
                                    } else {
                                        var content = data[i].content;
                                    };

                                    if (data[i].social_type == "twitter") {
                                        var btna = "R";
                                    } else {
                                        var btna = "C";
                                    };

                                    var profile_image = "";
                                    var style = "";
                                    if (data[i].social_type == "fb") {
                                        profile_image = '{!! $fb_image_url !!}';
                                        style = "margin-left: 46px;margin-right: 22px;height: 100%;margin-top: 6px;text-align: left;";
                                    }
                                    var left = 0 - i * 150;
                                    var top = 0;
                                    var template =
                                        '<a  id="read" class="btn-placeholder status-box" data-id=' + data[i].id + ' data-tipe="' + data[i].social_type + '" ' +
                                        ' data-url="{{url('')}}" data-content="' + data[i].data_content + '" data-date="' + data[i].date + '" data-profile="{{$user_profile->profile_image}}" data-target="#content_desc" >' +
                                        '<div id="status" class="stats-box stats2" style="transform: translate(' + left + 'px,' + top + 'px)">' +
                                        '<div class="stats stats-twitter">' +
                                        '<span id="icon" class="' + data[i].social_type + '"></span>' +

                                        '<p id="status_content" style="' + style + '" disabled="true">' + content + '</p>' +

                                        '<span id="status_location" class="left">' + data[i].location + '</span>' +
                                        '<span id="status_date" class="right">' + data[i].date + '</span>' +
                                        '<div class="stats-nav">' +
                                        {{--'<a id="btn-act" class="btn-circle btn1 btn-placeholder" '+--}}
                                                {{--' data-tipe="'+ data[i].social_type+'" data-id='+data[i].id+' data-url="{{url('')}}" data-content="'+data[i].data_content+'" data-date="'+data[i].date+'" data-target="#content_desc">'+btna+'</a>'+--}}

                                                @if(Auth::check())
                                            '<a id="btn-act-delete"  onclick="deleteTimeLine(this)" data-id=' + data[i].id + ' data-type=' + data[i].social_type + ' class="btn-circle btn1 btn-act-delete"><span class="glyphicon glyphicon-trash"></span></a>' +
                                        @endif
                                            '</div>' +
                                        '</div>' +
                                        '</div>' +
                                        '</a>';
                                    $("#status_container").prepend(template);
                                    $("#status_container").css("height", height + "px");
                                    height += 2000;
                                }
                            }
                        });
                        document.body.scrollTop = document.documentElement.scrollTop = tot_height - 2000;
                    },
                    error: function () {
                        pesanErr("Oops try again.");
                    },
                    complete: function () {
                        TIMELINE_LOADING = false;
                        timelineHideLoading();
                    }
                });
                skip = skip - 8;
            };
        }
    });

    $(document).ready(function () {
        $(".dropdown-menu").mouseleave(function () {
            $(".photo-profile").removeClass("open");
        });

        $('.nullable').click(function (e) {
            e.preventDefault();
        })

        $('#contact-form').submit(function (e) {
            e.preventDefault();
            var btn_before = $('#btn-submit');
            $('#btn-submit').html('<img style="width: 26px;" src="{{url('')}}/images/ajax-loader.gif"/>');
            $.post($(this).attr('action'), $(this).serialize(), function (data) {
                pesanOk("Email Successfully Sent");
                $('#btn-submit').html(btn_before);
                $('#contact-form').reset();
            }).fail(function (data) {
                $('#btn-submit').html(btn_before);
                try {
                    var message = JSON.parse(data.responseText);

                    $('#mail-error').empty();
                    $.each(message, function (k, v) {
                        $('#mail-error').append($('<li>').append($('<span class="label label-danger">').text(v)));
                    });
                    /*if (message.message != "") {
                     pesanErr(message.message);
                     }*/
                } catch (ec) {
                    console.log(data);
                    pesanErr("Ooops, there is something error when submitting the data");
                }
            });
        });
    });

    $('#currency_key').on('change', function() {
        var r  = this.value;
        //var fr = parseFloat(r).toFixed(3);
        let currencyName=$("#currency_key option:selected").text();
        document.cookie ="price="+r+"; path=/";
        document.cookie ="price="+r+"; path=/home";
        document.cookie ="currency="+currencyName+"; path=/";
        document.cookie ="currency="+currencyName+"; path=/home";
        //location.reload();
        window.location = "/home/gallery";
    });
</script>

<script type="text/javascript">
   $(".btn-placeholder").click(function () {
        var id = $(this).attr('data-id');
        $.ajax({
            method: "POST",
            url: '{{action("ImageController@postGetlike")}}',
            data: {
                id : id ,
            },
            success: function (response) {
                console.log(response);
                $('#timline_count').html(response);
                $('#timline_count').css("font-size","10px");
            }
        });
    });
</script>
@if($google_analytics_settings->google_analytics)
<script async src="https://www.googletagmanager.com/gtag/js?id={{$google_analytics_settings->google_analytics_id}}"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '{{$google_analytics_settings->google_analytics_id}}');
</script>
@endif

</body>
</html> <!-- 3233 -->
