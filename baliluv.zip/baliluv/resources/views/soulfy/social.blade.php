<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 8/18/2015
 * Time: 10:01 AM
 */

?>


@extends('home')

@section('title', 'Home')



@section('content')
@if(Auth::check())
    <section id="content-desc">
     

                <div class="backend-box backend-box-email">
                    <div class="backend-nav">
                        <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs" role="tablist">
                            <li class="active"><a id="tab_social" href="#social" aria-controls="social" role="tab"
                                                  data-toggle="tab">social</a></li>
                            <li><a id="tab_email" href="#email" aria-controls="email" role="tab"
                                   data-toggle="tab">email</a></li>
                            <li><a id="tab_setting" href="#setting" aria-controls="setting" role="tab"
                                   data-toggle="tab">setting</a></li>
                        </ul>
                    </div>
                    <div class="tab-content backend-detail slimScroll">
                        <div role="tabpanel" class="tab-pane active" id="social" style="height: 100%">
                            @include("soulfy/partial/social")
                        </div>
                        <div role="tabpanel" class="tab-pane" id="email" style="height: 100%">
                            {{--@include("soulfy/partial/email")--}}
                        </div>
                        <div role="tabpanel" class="tab-pane" id="setting" style="height: 100%">
                            {{--@include("soulfy/partial/setting")--}}

                        </div>

                 
            </div>
        </div>
    </section>
@endif
@endsection


@section('js')

    <link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css"
          rel="stylesheet"/>
    <script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/js/bootstrap-editable.min.js"></script>

    <script type="text/javascript">
        $.fn.editable.defaults.mode = 'inline';
        $(document).ready(function () {
            $('#txt_name').editable();
        });

        $("#tab_setting").on("click", function () {
            $("#setting").html(' <div id="loader"><img src="{{url()}}/images/loader.png"></div>');

            $.get("{{action('MemberController@getSetting')}}", function (data) {
                $("#setting").html(data);
            });
        });

        $("#tab_email").on("click", function () {
            $("#email").html(' <div id="loader"><img src="{{url()}}/images/loader.png"></div>');

            $.get("{{action('MemberController@getEmail')}}", function (data) {
                $("#email").html(data);
            });
        });

    </script>

    {{--Social module js--}}
    <script>
        $("#btn_post").on("click", function () {
            var ck_fb = $("#ck_fb").prop("checked");
            var ck_twitter = $("#ck_twitter").prop("checked");
            var ck_path = $("#ck_path").prop("checked");
            var ck_gplus = $("#ck_gplus").prop("checked");

            $(this).button("loading");
            var button = this;


            var type = 0;
            if (ck_fb) {
                type = 1;
                updateStatus(button, type);
            } else if (ck_twitter) {
                type = 2;
                updateStatus(button, type);
            } else if (ck_path) {
                type = 3;
                updateStatus(button, type);
            } else if (ck_gplus) {
                type = 4;
                updateStatus(button, type);
            }

        });

        function updateStatus(button, type) {
            var jqxhr = $.post("{{action('SocialController@postPublishStatus')}}", {
                type: type,
                status: $("#txt_status").val(),
                latitude : $("#latitude").val(),
                longitude : $("#longitude").val(),

            }, function (data) {
                alert("Publish status sukses");
                $(button).button("reset");
                $("#txt_status").val("");
            }).fail(function () {
                alert("Publish status error");
                $(button).button("reset");
                $("#txt_status").val("");
            });
        }
    </script>

    {{--Setting module js--}}

    <script>
        //        $("#btn_add_gallery").on("click",function()
        //        {
        //            var obj = $( "#btn_upload_gall input" ).last();
        //            $(obj).click();
        //        });

        function onAddclick(base) {

            var obj = $("#btn_upload_gall input").last();
            $(obj).click();
        }

        $("#btn_upload_gall").MultiFile({
            preview: true,
            list: '#upload_list',
            STRING: {
                file: '<em title="Click to remove" onclick="$(this).parent().prev().click()"></em>',
                remove: '<span class="glyphicon glyphicon-remove" style="" aria-hidden="true"></span>',

            },
            afterFileAppend: function (element, value, master_element) {

            },
        });

        var options = {
            beforeSubmit: function () {
                $("#btn_upload_img").button("loading");
            },
            success: function () {
                $("#btn_upload_img").button("reset");
                $(".MultiFile-remove").each(function () {
                    $(this).click();
                });
                pesanOk("Album photos uploaded");
            },
            error: function () {
                $("#btn_upload_img").button("reset");
                pesanErr("Oops try again");
            }
        };

        $('#form_upload_img_gallery').ajaxForm(options);

        var options = {
            beforeSubmit: function () {
                $("#btn_upload_video").button("loading");
            },
            success: function () {
                $("#btn_upload_video").button("reset");

                pesanOk("Album photos uploaded");
            },
            error: function () {
                $("#btn_upload_video").button("reset");
                pesanErr("Oops try again");
            }
        };

        $('#form_upload_video').ajaxForm(options);

        var options = {
            beforeSubmit: function () {
                $("#btn_update_skype").button("loading");
            },
            success: function () {
                $("#btn_update_skype").button("reset");

                pesanOk("Skype ID updated");
            },
            error: function () {
                $("#btn_update_skype").button("reset");
                pesanErr("Oops try again");
            }
        };

        $('#form_update_skype').ajaxForm(options);

        var options = {
            beforeSubmit: function () {
                $("#btn_update_skype").button("loading");
            },
            success: function () {
                $("#btn_update_business_card").button("reset");

                pesanOk("Business card updated");
            },
            error: function () {
                $("#btn_update_business_card").button("reset");
                pesanErr("Oops try again");
            }
        };

        $('#form_update_business_card').ajaxForm(options);

    </script>


    {{--setting jquery --}}
    

@endsection