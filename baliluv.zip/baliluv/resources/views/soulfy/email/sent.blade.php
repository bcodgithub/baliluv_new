<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 9/6/2015
 * Time: 10:28 PM
 */
$mail_content = \Soulfy\MailContent::where("folder","SENT")->get();
        ?>

<div class="backend-list" >
    <ul>
        @foreach($mail_content as $data)
            <li>
                <h5>{{$data->from}}</h5>
                <a href="#">{{$data->subject}}</a>
                <p>
                    {{$data->body}}<br><br>
                </p>
                <a href="#" class="delete"><img src="{{url('')}}/images/icon-trash-bk.png"/></a>
            </li>
            {{--<pre><div class="body">{!!html_entity_decode($data->body)!!}</div></pre>--}}
        @endforeach

        {{--<li>--}}
            {{--<h5>ZALORA.COM</h5>--}}
            {{--<a href="#">Selamat anda mendapat kejutan</a>--}}
            {{--<p>--}}
                {{--Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in dapibussapien.--}}
                {{--Integer pellentesque efficitur magan ac dictum. Pellentesque ornare eu diam ut--}}
            {{--</p>--}}
            {{--<a href="#" class="delete"><img src="{{url('')}}/images/icon-trash-bk.png"/></a>--}}
        {{--</li>--}}
        {{--<li>--}}
            {{--<h5>Mr. Ong</h5>--}}
            {{--<a href="#">Selamat anda mendapat kejutan</a>--}}
            {{--<p>--}}
                {{--Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in dapibussapien.--}}
                {{--Integer pellentesque efficitur magan ac dictum. Pellentesque ornare eu diam ut--}}
            {{--</p>--}}
            {{--<a href="#" class="delete"><img src="{{url('')}}/images/icon-trash-bk.png"/></a>--}}
        {{--</li>--}}
        {{--<li>--}}
            {{--<h5>Ray Nainggolan</h5>--}}
            {{--<a href="#">Selamat anda mendapat kejutan</a>--}}
            {{--<p>--}}
                {{--Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in dapibussapien.--}}
                {{--Integer pellentesque efficitur magan ac dictum. Pellentesque ornare eu diam ut--}}
            {{--</p>--}}
            {{--<a href="#" class="delete"><img src="{{url('')}}/images/icon-trash-bk.png"/></a>--}}
        {{--</li>--}}
        {{--<li>--}}
            {{--<h5>Eric Nainggolan</h5>--}}
            {{--<a href="#">Selamat anda mendapat kejutan</a>--}}
            {{--<p>--}}
                {{--Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in dapibussapien.--}}
                {{--Integer pellentesque efficitur magan ac dictum. Pellentesque ornare eu diam ut--}}
            {{--</p>--}}
            {{--<a href="#" class="delete"><img src="{{url('')}}/images/icon-trash-bk.png"/></a>--}}
        {{--</li>--}}
    </ul>
</div>
