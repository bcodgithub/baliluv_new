<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 9/6/2015
 * Time: 8:37 PM
 */

?>

<style type="text/css">
    textarea:focus, input:focus{
        outline: none;
    }
</style>
<div class="backend-form">
    <form id='creatForm' enctype="multipart/form-data">
        <input type="hidden" name="_token" value="{!! csrf_token() !!}" id="_token">
        <div class="form-top">
            <div class="form-left">
                <a href="#"  id='upfile1'><img src="{{url('')}}/images/attachment.png"/></a>
                <input type="file" id="file1"  name="file1" style="display:none" />
            </div>
            <div class="form-right">
                <a href="#" id="btn_save_draft" title="Save Draft"><span class="glyphicon glyphicon-edit fa-2x" style="color: white;"></span></a>
                <a href="#" id="btn_send_mail" title="Send Email"><img src="{{url('')}}/images/send.png"/></a>
            </div>
        </div>
        <div class="form-body">
            <div class="form-group">
                <input type="email" name="to" id="to" style="border:none;" value="{{$mail_content->from}}" placeholder="To" required/>

                <div class="form-link">
                    <a onclick="$(this).hide(); $('#cc').parent().removeClass('hidden'); $('#cc').focus();" href="javascript:;">Cc</a>
                    <a onclick="$(this).hide(); $('#bcc').parent().removeClass('hidden'); $('#bcc').focus();" href="javascript:;">Bcc</a>
                </div>
            </div>
            <div class="form-group hidden">
                <input type="text" tabindex="2" id="cc" name="cc" class="form-control" placeholder='Cc'>
            </div>
            <div class="form-group hidden">
                <input type="text" tabindex="2" id="bcc" name="bcc" class="form-control" placeholder='Bcc'>
            </div>
            <div class="form-group">
                <input type="text" id="subject" name="subject" value="{{$mail_content->subject}}" placeholder="Subject" />
            </div>
            <textarea rows="50" id="body" name="body" class="form-control">{{$mail_content->body}}<?php ?></textarea>
        </div>
    </form>
</div>

<script>
    $("#upfile1").click(function (e) {
        e.preventDefault();
        $("#file1:hidden").trigger('click');
    });
    $("#btn_send_mail").on("click",function(){
        var button = this;
        var before = $(this).html();
        $(this).html('<img style="width: 26px;" src="{{url('')}}/images/ajax-loader.gif"/>');

        if( !($("#to").val().length > 0) ){
            $(button).html(before);
            return false;
        }

        var formData = new FormData($('#creatForm')[0]);
        $.ajax({
            method : 'POST',
            url : "{{action('MailController@postSendmail')}}",
            data : formData,
            processData: false,
            contentType: false,
            success:function(response){
                 alert("sent mail success");
                $(button).html(before);
                $("#tab_sent").trigger("click");
            },
            error:function(){
                alert("sent mail error");
                $(button).html(before);
            },
        });

        /*var jqxhr = $.post("{{action('MailController@postSendmail')}}", {
            to: $("#to").val(),
            body: $("#body").val(),
            subject: $("#subject").val(),
            cc: $("#cc").val(),
            bcc: $("#bcc").val()
        }, function (data) {
            alert("sent mail success");
            $(button).html(before);
            $("#tab_sent").trigger("click");
        }).fail(function () {
            alert("sent mail error");
            $(button).html(before);
        });*/
    });
    $("#btn_save_draft").on("click",function(){
        var button = this;
        var before = $(this).html();
        $(this).html('<img style="width: 26px;" src="{{url('')}}/images/ajax-loader.gif"/>');

        if( !($("#to").val().length > 0) ){
            $(button).html(before);
            return false;
        }


        var jqxhr = $.post("{{action('MailController@postSavedraft')}}", {
            to: $("#to").val(),
            body: $("#body").val(),
            subject: $("#subject").val(),
            cc: $("#cc").val(),
            bcc: $("#bcc").val()
        }, function (data) {
            alert("Save mail success");
            $(button).html(before);
            $("#tab_sent").trigger("click");
        }).fail(function () {
            alert("Save mail error");
            $(button).html(before);
        });
    });
</script>
