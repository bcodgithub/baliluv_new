<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 9/6/2015
 * Time: 10:28 PM
 */
/* 
$domain = $_SERVER['SERVER_NAME'];
$user = User::where('domain', $domain)->first();

$mail_content = \Soulfy\MailContent->where("folder","INBOX")->where("user_id", $user->id)->get();
*/
?>

<div class="backend-list" >
    {{-- <ul>

        @foreach($mail_content as $data)
            <li>
                <h6>{{$data->from}}</h6>
                <a href="#">{{$data->subject}}</a>
                <p>
                    {{$data->body}}<br><br>
                </p>
                <a href="#" class="delete"><img src="{{url('')}}/images/icon-trash-bk.png"/></a>
            </li>
            {{--<pre><div class="body">{!!html_entity_decode($data->body)!!}</div></pre>}}
        @endforeach
    </ul> --}}
    <table class="table hover">
        @foreach($mail_content as $data)
        <tr data-href="{{action('MailController@getMail')}}?msgno={{$data->msgno}}" class="tr-color">
            <td class="col-md-4 clickable">
                <b>{{substr(explode('<', $data->from)[0],0,10)}}</b>
            </td>
            <td class="clickable">
                <p>{{substr($data->subject,0,20)}}<br>{!! substr($data->body,0,20) !!}</p>
            </td>
            <td>
                <a href="#" data-href="{{action('MailController@postRemoveMail')}}" data-id="{{$data->uid}}" class="delete"><img src="{{url('')}}/images/icon-trash-bk.png"/></a>
            </td>

        </tr>
        @endforeach    
    </table>
</div>

<script type="text/javascript">
    $(function(){
        toastr.options = {
            "closeButton": false,
            "positionClass": "toast-top-right",
            "onclick": null,
            "showDuration": "1000",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        };
        @if(session()->has('msg_type'))
        var type = "{{session()->get('msg_type')}}";
        $toast = toastr[type]("{{session()->get('message')}}",type.toUpperCase());
        @endif

        $('.clickable').click(function(e) {
            e.preventDefault();
            $.get($(this).parent().attr('data-href'),function(data){
                $('.backend-list').html(data);
            });
        });
        /*$('td a.delete').click(function(e) {
            e.preventDefault();
            $.post($(this).attr('data-href'), {id: $(this).attr('data-id'), folder: ''} ,function(data) {console.log(data);
                if(data == "1") {
                	alert("Email Successfully moved to Trash");
                	location.reload();
                }
                else {
                	alert("Error occur while deleting the E-Mail");
                }
            });
        });*/
        $('td a.delete').click(function(e) {
            e.preventDefault();
            $.post($(this).attr('data-href'), {id: $(this).attr('data-id'), folder: ''} ,function(data){
                $('#'+data).trigger('click');
            });
        });
    });
</script>