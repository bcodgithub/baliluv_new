
<!-- <div class="backend-list" > -->
	<table class="table">
		<tr class="tr-color">
			<td style="width: 50% !important"><b>From : {{$mail_content->from}}</b></td>
		</tr>
		<tr class="tr-color">
			<td>Date : {{$mail_content->date}}</td>
		</tr>
		<tr colspan="2" class="tr-color">
			<td><b>Subject : </b>{{$mail_content->subject}}</td>
		</tr>
		<tr colspan="2" class="tr-color">
			<td>
				<pre>{!! $mail_content->body !!}<br>
				</pre>
				<?php
			foreach ($mail_content->files as $key) {
			/*echo '<img src="'.$key["attachment"].'">';*/
			if($key['attachment']!='')
			{
			?>

			<img src="data:image/png;base64,<?php echo $key['attachment'] ?? ''; ?>" alt="<?php echo $key['name']; ?>" width='100px'/>
			<?php

			}}
			?> 
			</td>
		</tr>
	</table>

<!-- </div> -->
<div class="container-fluid">
	Click here to <a href="{{action('MailController@getReply')}}?from={{$mail_content->from}}">Reply</a> or <a href="{{action('MailController@getForward')}}?msgno={{$mail_content->msgno}}">Forward</a>
</div>

<script type="text/javascript">
	$(function(){
		$('.container-fluid a').click(function(e){
			e.preventDefault();
			$.get($(this).attr('href'),function(data){
				$('.backend-list').html(data);
			});
		});
	});
</script>