<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 9/6/2015
 * Time: 10:28 PM
 */
//$mail_content = \Soulfy\MailContent::where("folder","DRAFT")->get();
        ?>

<div class="backend-list" >
    <ul>
        @foreach($mail_content as $data)
            <li class="clickable table hover" data-href="{{action('MailController@getCreatedraft')}}?msgno={{$data->msgno}}">
                <h5>{{$data->from}}</h5>
                <p>{{$data->subject}}</p>
                <p>{{$data->body}}</p>
                <a href="#" data-href="{{action('MailController@postRemoveMail')}}" data-id="{{$data->uid}}" class="delete"><img src="{{url('')}}/images/icon-trash-bk.png"/></a>
            </li>
            {{--<pre><div class="body">{!!html_entity_decode($data->body)!!}</div></pre>--}}
        @endforeach

        {{--<li>--}}
            {{--<h5>ZALORA.COM</h5>--}}
            {{--<a href="#">Selamat anda mendapat kejutan</a>--}}
            {{--<p>--}}
                {{--Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in dapibussapien.--}}
                {{--Integer pellentesque efficitur magan ac dictum. Pellentesque ornare eu diam ut--}}
            {{--</p>--}}
            {{--<a href="#" class="delete"><img src="{{url('')}}/images/icon-trash-bk.png"/></a>--}}
        {{--</li>--}}
        {{--<li>--}}
            {{--<h5>Mr. Ong</h5>--}}
            {{--<a href="#">Selamat anda mendapat kejutan</a>--}}
            {{--<p>--}}
                {{--Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in dapibussapien.--}}
                {{--Integer pellentesque efficitur magan ac dictum. Pellentesque ornare eu diam ut--}}
            {{--</p>--}}
            {{--<a href="#" class="delete"><img src="{{url('')}}/images/icon-trash-bk.png"/></a>--}}
        {{--</li>--}}
        {{--<li>--}}
            {{--<h5>Ray Nainggolan</h5>--}}
            {{--<a href="#">Selamat anda mendapat kejutan</a>--}}
            {{--<p>--}}
                {{--Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in dapibussapien.--}}
                {{--Integer pellentesque efficitur magan ac dictum. Pellentesque ornare eu diam ut--}}
            {{--</p>--}}
            {{--<a href="#" class="delete"><img src="{{url('')}}/images/icon-trash-bk.png"/></a>--}}
        {{--</li>--}}
        {{--<li>--}}
            {{--<h5>Eric Nainggolan</h5>--}}
            {{--<a href="#">Selamat anda mendapat kejutan</a>--}}
            {{--<p>--}}
                {{--Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in dapibussapien.--}}
                {{--Integer pellentesque efficitur magan ac dictum. Pellentesque ornare eu diam ut--}}
            {{--</p>--}}
            {{--<a href="#" class="delete"><img src="{{url('')}}/images/icon-trash-bk.png"/></a>--}}
        {{--</li>--}}
    </ul>
</div>
<script>
    $(function(){
        toastr.options = {
            "closeButton": false,
            "positionClass": "toast-top-right",
            "onclick": null,
            "showDuration": "1000",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        };
                @if(session()->has('msg_type'))
        var type = "{{session()->get('msg_type')}}";
        $toast = toastr[type]("{{session()->get('message')}}",type.toUpperCase());
        @endif

        $('.clickable').click(function(e) {
            e.preventDefault();
            $.get($(this).attr('data-href'),function(data){
                console.log(data);
                $('.backend-list').html(data);
            });
        });
        $('.delete').click(function(e) {
            e.preventDefault();
            $.post($(this).attr('data-href'), {id: $(this).attr('data-id'), folder: '.Drafts'} ,function(data){
                $('#'+data).trigger('click');
            });
        });
    });
</script>