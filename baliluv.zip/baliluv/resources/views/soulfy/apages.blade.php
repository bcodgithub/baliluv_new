<?php

use Soulfy\User;
$domain = $_SERVER['SERVER_NAME'];
$user = User::where('domain', $domain)->first();
$user_setting = \Soulfy\Setting::where('user_id',$user->id)->first();
$no = "1";
?>

@extends('home')

@section('title', 'Home')

@section('content')

    <section id="content-desc" class="inner-section-container">
        <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>
        <div class="backend-box _grey backend-box-email">
            <div class="backend-nav">
                <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs" role="tablist">
                    <li class="active"><a id="tab_articles" href="#articles" aria-controls="articles" role="tab" data-toggle="tab">PAGES</a></li>
                </ul>
            </div>
            <div class="tab-content backend-detail slimScroll">
                <div role="tabpanel" class="tab-pane active" id="articles" style="height: 100%">
                    <br><br>
                    <div class="form-body  create-article">
                        @if(session()->has('status'))
                        <div class="alert alert-success"><em> {{ session('status') }}</em></div>
                        @endif
                        <form action="{{ route('navcolor') }}" method="get">    
                            <div style="color: white;">Select Pages Navigation Color :</div>
                            {{ csrf_field() }}          
                            <select name="navcolor">
                                <option value="ff0000">Red</option>
                                <option value="39b54a">Green</option>
                                <option value="f26522">Orange</option>
                                <option value="FFC300">Yellow</option>
                                <option value="0000ff">Blue</option>
                                <option value="000000">Black</option>
                                <option value="bec3c8">Grey</option>
                                <option value="FF69B4">Pink</option>
                                <option value="dd04f7">Purple</option>
                                <option value="cba26c">Brown</option>
                                <option value="42fbdf">Light Blue</option>
                                <option value="E3DEDA">Light Gray</option>
                            </select>
                            <input type="submit" value="Submit" style="background-color: #3fef08; color: white; height: 30px;"><br><br>
                        </form>
                        <a href="{{ route('pages.create')}}" class="btn btn-green" data-id="" data-tittle="" data-content="">Add Pages</a>
                        <div style="color: white;"><br><br>
                            <table width="250px" id="t01">    
                                <tr>
                                    <th>Page Name</th>
                                    <th>Action</th>
                                    <th></th>
                                </tr>
                                @foreach($pages as $page)
                                <tr>
                                    <td>{{ $page->pages_name }}</td>
                                    <td><a href="{{ route('pages.show', $page->id) }}" class="btn btn-green" data-id="" data-tittle="" data-content="">Edit</a></td>
                                    <td>
                                        <form action="{{ route('pages.destroy', $page->id) }}"  method="POST">
                                        {{ csrf_field() }}
                                        {{ method_field('DELETE') }}
                                        <input type="submit" class="btn-green" data-id="" data-tittle="" data-content="" value="Delete" style="width: 60px; height: 30px; background-color: #2ce04c; color: white;" />
                                        </form></td>
                                </tr>
                                @endforeach
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>           
        <div class="placeholder _grey" id="backend-placeholder">

                <div class="placeholder-first backend-first" style="display:none">

                    <div class="placeholder-header">



                            <h3 ></h3>

                            <a class="btn-cancels"><span class="glyphicon glyphicon-remove"></span></a>

                    </div>



                              <div class="content-placeholder">

                                        <p>

                                           

                                        </p>

                             </div>

                             @if(Auth::check())

                             <div class="skype-box">

                                    <div class="image-skype logged">

                                        <img src="{{url()}}/images/skype-logo.png" alt="">

                                    </div>

                                    <div class="skype-id">

                                         Skype ID : <p class="skype-info">{{$user_setting['skype_id']}}</p> 

                                         <div class="skype-act">

                                         <input type="text"   class="form-control skype_form" value="{{$user_setting['skype_id']}}" required>

                                         <a class="btn-skype-edit"><i class="fa fa-pencil-square-o"></i></a>

                                         <a class="btn-skype-save"><i class="fa fa-floppy-o"></i></a>

                                         <a class="btn-skype-cancel"><i class="fa fa-times"></i></a>

                                         </div>

                                         

                                    </div>

                             </div>

                             @else

                             <div class="skype-box">

                                    <div class="image-skype">

                                        <img src="{{url('')}}/images/skype-logo.png" alt="">

                                    </div>

                                    <div class="skype-id">

                                         Skype ID : {{$user_setting['skype_id']}}

                                    </div>

                             </div>

                             @endif

                    <p class="date-article"><i class='fa fa-user'></i> Published by <i>{{$user->full_name}}</i><i class='user'></i> | <i class='fa fa-calendar'></i></p>



                    



                    <div style="clear:both;"></div>



                    <div class="placeholder-footer action">

                                            <a class="first btn-act-like" onclick="likeTimeLine(this)">
                        <span class="glyphicon glyphicon-thumps-up"></span>
                    </a>

                                            <a  class="second"></a>

                                            @if(Auth::check())

                                            <a class="third btn-act-delete" onclick="deleteTimeLine(this)"><span class="glyphicon glyphicon-trash"></span> </a>

                                            @endif

                            

                            <div style="clear:both;"></div>

                    </div>







                    



                    </div>

                    

            </div>

    </section>



@endsection





@section('js')



<script> 

$(document).ready(function() {

    if($(#content-edit).length > 0)

    CKEDITOR.replace( 'content-edit' ,{ 

	    filebrowserBrowseUrl : '{{url('')}}/filemanager/dialog.php?type=2&editor=ckeditor&fldr=', filebrowserUploadUrl : '{{url('')}}/filemanager/dialog.php?type=2&editor=ckeditor&fldr=', filebrowserImageBrowseUrl : '{{url('')}}/filemanager/dialog.php?type=1&editor=ckeditor&fldr='

	}); 

	

    if($(#content).length > 0)

    CKEDITOR.replace( 'content' ,{ 

	    filebrowserBrowseUrl : '{{url('')}}/filemanager/dialog.php?type=2&editor=ckeditor&fldr=', filebrowserUploadUrl : '{{url('')}}/filemanager/dialog.php?type=2&editor=ckeditor&fldr=', filebrowserImageBrowseUrl : '{{url('')}}/filemanager/dialog.php?type=1&editor=ckeditor&fldr='

    });

});

</script>





<script>



	// auto close flash message after 5 sec

    $('div.alert').delay(5000).slideUp(300);



 

    $(document).ready(function(){

/*

         $("#content").wysihtml5({

            toolbar: {

                "font-styles": true, //Font styling, e.g. h1, h2, etc. Default true

                "emphasis": true, //Italics, bold, etc. Default true

                "lists": true, //(Un)ordered lists, e.g. Bullets, Numbers. Default true

                "html": true, //Button which allows you to edit the generated HTML. Default false

                "link": false, //Button to insert a link. Default true

                "image": true, //Button to insert an image. Default true,

                "color": false, //Button to change color of font

                "blockquote": true, //Blockquote

        }

    });

         $("#content-edit").wysihtml5({

            toolbar: {

                "font-styles": true, //Font styling, e.g. h1, h2, etc. Default true

                "emphasis": true, //Italics, bold, etc. Default true

                "lists": true, //(Un)ordered lists, e.g. Bullets, Numbers. Default true

                "html": true, //Button which allows you to edit the generated HTML. Default false

                "link": false, //Button to insert a link. Default true

                "image": true, //Button to insert an image. Default true,

                "color": false, //Button to change color of font

                "blockquote": true, //Blockquote

        }

    });

*/         



        $(".edit-article-form").hide();

        $(".create-article-form").hide();



        $(".new-article").click(function(e){

            e.preventDefault();

            $(".create-article").hide();

            $(".create-article-form").fadeIn();

         //   $(' iframe').contents().find('.ckeditor').html('');

            CKEDITOR.instances["content"].setData(content);

        });

        $(".btn-cancel-article").click(function(e){

            e.preventDefault();

            $(".edit-article-form").hide();

            $(".create-article").fadeIn();

            $(".create-article-form").hide();

        });

        $(".btn-act-edit").click(function(e){

            e.preventDefault();

            var id = $(this).attr("data-id"),

            tittle = $(this).attr("data-tittle"),

            attachment = $(this).attr("data-attachment"),

            content = $(this).attr("data-content");            

            $(".create-article").hide();

            $(".edit-article-form").fadeIn();

            $(".id-edit").val(id);

            $(".tittle-edit").val(tittle);



           // $(".content-edit").val(content);

          



            CKEDITOR.instances["content-edit"].setData(content);

            $("#download-edit").attr("href", attachment);

            $("#download-edit").text("download");

           

        // $(' iframe').contents().find('.ckeditor').html(content);

        });

        $(".btn-save-article").click(function(e){

            e.preventDefault();

            var tittle = $("#tittle").val(),

            content = $("#content").val();

            content = CKEDITOR.instances["content"].getData();



            $.ajax({

                method: "POST",

                url: '{{action("AjaxController@postCreateArticle")}}',

                data: { tittle : tittle, content : content },

                

                success: function (response) {

                    if (response=='"error"') {

                        pesanErr("please fill the title and content article");

                    }else{ 

                    pesanOk("Article created");

                    setTimeout(function(){location.reload()},1000);

                    };

                },

            })

             

        });

        $(".btn-save-edit-article").click(function(e){

            e.preventDefault();

            var id_edit = $("#id-edit").val(),

            tittle_edit = $("#tittle-edit").val(),

            content_edit = $("#content-edit").val();

            content_edit = CKEDITOR.instances["content-edit"].getData();





           // alert(new FormData($("#form-edit")[0]));

            $.ajax({

                method: "POST",

                //processData: false,

    			//contentType: false,	

                url: '{{action("AjaxController@postUpdateArticle")}}',

                //data: { id : id_edit, tittle : tittle_edit, location: location_edit, content : content_edit, },

                //data:new FormData($("#form-edit")[0]),

                  data: { id : id_edit, tittle : tittle_edit, content : content_edit },

                success: function (response) {

                //    alert(response);

                    pesanOk("Article updated");

                   setTimeout(function(){location.reload()},1000);

                },

                error:function()

                {

                	pesanErr("Fail");

                }

            })





        });

		

		 $("#btn-save-seo").click(function(e){

         

            var meta_title = $("#meta_title").val();

            meta_keyword = $("#meta_keyword").val();

            meta_description = $("#meta_description").val();            

            $.ajax({

                method: "POST",

                url: '{{action("AjaxController@postUpdateSeo")}}',

                data: { meta_title : meta_title, meta_keyword : meta_keyword, meta_description: meta_description, },

                success: function (response) {

                    

                    pesanOk("SEO updated");

                   setTimeout(function(){location.reload()},c1000);

                },

				error:function()

				{

					pesanErr("SEO failed");

				}

            })



			return false;

        });

		

        $(".btn-publish").click(function(e){

            e.preventDefault();

            var id = $(this).attr("data-id"),

            status = $(this).attr("data-status");

            $.ajax({

                method: "POST",

                url: '{{action("AjaxController@postArticlePublish")}}',

                data: { id : id, status : status, },

                success: function (response) {

                    

                    pesanOk("Status changed");

                    setTimeout(function(){location.reload()},1000);

                },

            })



        });

    });

    $(function () {

      $('[data-toggle="tooltip"]').tooltip()

    });

    

        $('.form-body textarea').keyup(function() {

            var len = this.value.length;

                if (len >= 1000) {

                this.value = this.value.substring(0, 1000);

                alert("Max input");

                }

            $('.form-body span.char-info').text(1000 - len);

        });



        $(".skype_form").hide();

            $(".btn-skype-save").hide();

            $(".btn-skype-cancel").hide();

            $(".btn-skype-edit").click(function(e){

                e.preventDefault();

                $(".btn-skype-cancel").show();

                $(this).hide();

                $(".btn-skype-save").show();

                $(".skype-info").hide();

                $(".skype_form").show();

            });

            $(".btn-skype-cancel").click(function(e){

                e.preventDefault();

                $(".skype_form").hide();

                 $(".skype-info").show();

                 $(this).hide();

                 $(".btn-skype-save").hide();

                 $(".btn-skype-edit").show();

            });

            $(".btn-skype-save").click(function(e){

                e.preventDefault();

                var skypeid = $(".skype_form").val();

                var id_user = {{$user_setting['id']}};

                $.ajax({

                type: "POST",

                url: '{{action("AjaxController@postEditSkype")}}',

                data : {

                    id_user : id_user,

                     skypeid : skypeid,

                },



                success: function (response) {

                    if (response=='"success"') {

                        pesanOk("success");

                        $(".skype-info").html(skypeid);

                        $(".skype_form").hide();

                         $(".skype-info").show();

                         $(".btn-skype-save").hide();

                         $(".btn-skype-cancel").hide();

                         $(".btn-skype-edit").show();

                    }else{

                        pesanErr("failed");

                    };

                }

            });

            });





 

</script>

@endsection

