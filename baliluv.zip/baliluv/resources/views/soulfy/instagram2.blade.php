<?php

/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 8/18/2015
 * Time: 5:04 PM
 */
$user_setting = \Soulfy\Setting::where('user_id', $user['id'])->first();
?>
@extends('home')

@section('title', 'Home')

@section('css')
    <link href="{{url('')}}/js/flex_image/jquery.flex-images.css" rel="stylesheet"/>
    <link type="text/css" rel="stylesheet" href="{{url('')}}/js/gallery/css/lightgallery.css"/>
    <link rel="stylesheet" href="{{url('')}}/js/justified/css/justifiedGallery.css"/>
@endsection

@section('content')
    <section id="content-desc">
        <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>
        <div class="content-gallery  video" style="clear:both;">
            <div class="panel-gallery-header">
                <h3 class="content-placeholder-tittle">{{$user['full_name']}} Instagram </h3>
            </div>
            <div class="gallery-box slimScroll" data-minus="150">
                @if(Auth::check())
                    <div class="youtube-form">
                    <form action="" method="post">
						{{ csrf_field() }}		
                        <div class="form-top">
                            <label><span><img src="{{url('')}}/images//instagram.png" height="40px"/></span>Instagram Channel</label>
                        </div>
                        <div class="form-body">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            <input required size="40" type="text" id="url_ig" name="url_ig"
                                   placeholder="www.instagram.com/ Paste Instagram ID Here"/>
                        </div>
                        <div class="form-btm">
                            <input type="submit" value="submit" class="btn btn-bk" id="btn_submit_instagram">
                        </div>
                    </form>    
                    </div>
                @endif
            </div>
        </div>

        <div class="placeholder video placeholder-first" style="display:none">
            <div class="placeholder-header">
                <h3></h3>
                <a class="btn-cancel-video"><span class="glyphicon glyphicon-remove"></span></a>
            </div>
            <div class="content-placeholder">
                <p>
                </p>
            </div>
            @if(Auth::check())
                <div class="skype-box">
                    <div class="image-skype logged">
                        <img src="{{url()}}/images/skype-logo.png" alt="">
                    </div>
                    <div class="skype-id">
                        Skype ID : <p class="skype-info">{{$user_setting['skype_id']}}</p>
                        <div class="skype-act">
                            <input type="text" class="form-control skype_form" value="{{$user_setting['skype_id']}}"
                                   required>
                            <a class="btn-skype-edit"><i class="fa fa-pencil-square-o"></i></a>
                            <a class="btn-skype-save"><i class="fa fa-floppy-o"></i></a>
                            <a class="btn-skype-cancel"><i class="fa fa-times"></i></a>
                        </div>
                    </div>
                </div>
            @else
                <div class='skype-box'>
                    <div class='image-pp'>
                        <img src="{{url()}}/{{$user['image_profile']}}"/>
                    </div>
                    <div class='skype-infos'>
                        <div class='image-skype'>
                            <img src="{{url('')}}/images/skype-logo.png" alt=''/>
                        </div>
                        <div class='skype-id'>
                            Skype ID : {{$user_setting['skype_id']}}
                        </div>
                    </div>
                </div>
            @endif

            <p class="date-article"></p>

            <div style="clear:both;"></div>

            <div class="placeholder-footer action">

                <a class="first btn-act-like" onclick="likeTimeLine(this)">
                        <span class="glyphicon glyphicon-thumps-up"></span>
                    </a>

                <a class="second"></a>

                @if(Auth::check())

                    <a class="third btn-act-delete" onclick="deleteTimeLine(this)"><span class="glyphicon glyphicon-trash"></span> </a>

                @endif

                <div class="fb-comment form-group"></div>

                <div style="clear:both;"></div>

            </div>

        </div>

        <div class="placeholder placeholder-second" style="display:none">

            <div class="placeholder-header-email">

                <h3>Email Us</h3>

                <a class="btn-cancel-video"><span class="glyphicon glyphicon-remove"></span></a>

            </div>

            @include("soulfy/partial/placeholder_email")

        </div>

        <div class="placeholder-third" style="display:none">

            <div class="card-box">

                <a class="btn-cancel-video"><span class="glyphicon glyphicon-remove"></span></a>

                @include("soulfy/partial/bcard")

            </div>

            <div class="footer">



            </div>

        </div>

        </div>



        </div>

    <!-- <div class="placeholder-advert">

            <div class="placeholder-header-advert">



                    <h3 >Event</h3>

            </div>



                      <div class="content-placeholder-advert">

                                <img src="{{url('')}}/images/adverts/advert.gif">



                     </div>

                     <div class="placeholder-footer-advert"></div>

</div> -->

    </section>

@endsection



@section('js')

    <script type="text/javascript" src="{{url('')}}/js/flex_image/jquery.flex-images.min.js"></script>

    <script src="{{url()}}/js/gallery/js/lightgallery.js"></script>

    <script src="{{url()}}/js/justified/js/jquery.justifiedGallery.js"></script>



    <!-- lightgallery plugins -->

    <script src="{{url()}}/js/gallery/js/lg-thumbnail.js"></script>

    <script src="{{url()}}/js/gallery/js/lg-fullscreen.js"></script>

    <script src="{{url()}}/js/gallery/js/lg-zoom.js"></script>

    <script src="{{url()}}/js/gallery/js/lg-video.js"></script>

    <script src="{{url()}}/js/gallery/js/lg-autoplay.js"></script>



    <script type="text/javascript">

        $(document).ready(function () {

//            $('.gallery-box').slimScroll({

//                height: '500px'

//            });



//             $('.flex-images').flexImages({rowHeight: 140});

//            $("#foto").lightGallery({

//                thumbnail:true

//            });



            //$("#foto").justifiedGallery();



//            var $animThumb = $('#foto');

//            if ($animThumb.length) {

//                $animThumb.justifiedGallery({

//                    border: 6,

//                    margins : 10,

//                    captions :true

//                }).on('jg.complete', function() {

//                    $animThumb.lightGallery({

//                        thumbnail: true

//                    });

//                });

//            };

            $('#video-gallery').lightGallery();





            // $('#demo6').flexImages({ truncate: 1 });

            // $('.fancybox').fancybox();

        });

    </script>

    <script src="{{url('')}}/js/lightslider.min.js"></script>

    

    <script>



    	// set instagram



            $(document).ready(function () {

         

            $("#btn_submit_instagram").click(function (e) {

                e.preventDefault();



                var url_ig = $("#url_ig").val();

                $.ajax({

                    type: "POST",

                    url: '{{action("AjaxController@postUrlInstagram")}}',

                    data: {

                        url_ig: url_ig,

                    	},

                    success: function (response) {



                        if (response == '"success"') {

                            pesanOk("successfully updated");

                            setTimeout(function () {

                                location.reload()

                            }, 1000);

                        } else if (response == '"error"') {

                            pesanErr("the URL you entered is wrong");

                        } else if (response == '"null"') {

                            pesanErr("Please type your URL");

                        }                        

                    }

                });



                return false;



            });

        });



    </script>





    <script>



    	



        $(document).ready(function () {

            $("#btn_upload_video").click(function (e) {

                e.preventDefault();



                var url_video = $("input#url_video").val();

                $.ajax({

                    type: "POST",

                    url: '{{action("AjaxController@postUrlYoutube")}}',

                    dataType: "text",

                    data: {

                        url_video: url_video,

                    },

                    success: function (response) {



                        if (response == '"success"') {

                            pesanOk("successfully updated");

                            setTimeout(function () {

                                location.reload()

                            }, 1500);

                        } else if (response == '"error"') {

                            pesanErr("the URL you entered is wrong");

                        } else if (response == '"null"') {

                            pesanErr("Please type your URL");

                        }

                        

                    }

                });



            });



     

            //skype edit



            $(".skype_form").hide();

            $(".btn-skype-save").hide();

            $(".btn-skype-cancel").hide();

            $(".btn-skype-edit").click(function (e) {

                e.preventDefault();

                $(".btn-skype-cancel").show();

                $(this).hide();

                $(".btn-skype-save").show();

                $(".skype-info").hide();

                $(".skype_form").show();

            });

            $(".btn-skype-cancel").click(function (e) {

                e.preventDefault();

                $(".skype_form").hide();

                $(".skype-info").show();

                $(this).hide();

                $(".btn-skype-save").hide();

                $(".btn-skype-edit").show();

            });

            $(".btn-skype-save").click(function (e) {

                e.preventDefault();

                var skypeid = $(".skype_form").val();

                var id_user = {{$user_setting['id']}};

                $.ajax({

                    type: "POST",

                    url: '{{action("AjaxController@postEditSkype")}}',

                    data: {

                        id_user: id_user,

                        skypeid: skypeid,

                    },



                    success: function (response) {

                        if (response == '"success"') {

                            pesanOk("success");

                            $(".skype-info").html(skypeid);

                            $(".skype_form").hide();

                            $(".skype-info").show();

                            $(".btn-skype-save").hide();

                            $(".btn-skype-cancel").hide();

                            $(".btn-skype-edit").show();

                        } else {

                            pesanErr("failed");

                        }

                        ;

                    }

                });

            });

        });





			



    </script>

    {{--<script type="text/javascript">--}}



    {{--$(document).ready(function() {--}}

    {{--$('.gallery1').lightSlider({--}}

    {{--keyPress:false,--}}

    {{--item:5,--}}

    {{--loop:true,--}}

    {{--pager:false,--}}

    {{--slideMargin: 0,--}}

    {{--onSliderLoad: function() {--}}

    {{--$('.gallery1').removeClass('cS-hidden');--}}

    {{--}--}}

    {{--});--}}

    {{--$('.gallery2').lightSlider({--}}

    {{--keyPress:false,--}}

    {{--item:5,--}}

    {{--loop:true,--}}

    {{--pager:false,--}}

    {{--slideMargin: 0,--}}

    {{--onSliderLoad: function() {--}}

    {{--$('.gallery2').removeClass('cS-hidden');--}}

    {{--}--}}

    {{--});--}}

    {{--$('.gallery3').lightSlider({--}}

    {{--keyPress:false,--}}

    {{--item:5,--}}

    {{--loop:true,--}}

    {{--pager:false,--}}

    {{--slideMargin: 0,--}}

    {{--onSliderLoad: function() {--}}

    {{--$('.gallery3').removeClass('cS-hidden');--}}

    {{--}--}}

    {{--});--}}

    {{--$('.gallery4').lightSlider({--}}

    {{--keyPress:false,--}}

    {{--item:5,--}}

    {{--loop:true,--}}

    {{--pager:false,--}}

    {{--slideMargin: 0,--}}

    {{--onSliderLoad: function() {--}}

    {{--$('.gallery4').removeClass('cS-hidden');--}}

    {{--}--}}

    {{--});--}}

    {{--$('.gallery5').lightSlider({--}}

    {{--keyPress:false,--}}

    {{--item:5,--}}

    {{--loop:true,--}}

    {{--pager:false,--}}

    {{--slideMargin: 0,--}}

    {{--onSliderLoad: function() {--}}

    {{--$('.gallery5').removeClass('cS-hidden');--}}

    {{--}--}}

    {{--});--}}

    {{--});--}}



    {{--</script>--}}







@endsection