<?php
 $no = "1";  
?>

@extends('home')
@section('title', 'Home')

@section('content')

<section id="content-desc" class="inner-section-container">
    <a class="plus-minus-toggeler">
        <span class="glyphicon glyphicon-minus"></span>
    </a>
    <div class="backend-box _grey backend-box-email">
        <div class="backend-nav">
            <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs" role="tablist">
                <li class="active">
                    <a id="tab_articles" href="#articles" aria-controls="articles" role="tab" data-toggle="tab">RSS FEED
                    </a>
                </li>   
            </ul>
        </div>

        <div class="tab-content backend-detail slimScroll">
            <div role="tabpanel" class="tab-pane active" id="articles" style="height: 100%">
                <div class="form-top create-article">
                    <label>Rss Feed</label>
                    <ul class="form-nav">
                        <li><a href="#" class="new-article">
                            <img src="{{url('')}}/images//nav3.png"/></a>
                        </li>
                    </ul>
                </div>
                <div class="form-body  create-article">
                    <div class="notes-box">
                        <ul>
                        @foreach($rssfeeds as $data)
                            <li>
                                <div class="notes-desc">
                                    <p><b>{{$no++}}.
                                        @if(strlen($data->tittle)>=10)
                                            {{substr($data->tittle,0,15)}}....
                                        @else
                                            {{$data->tittle}}
                                        @endif
                                    </b></p>
                                    <p class="date">
                                       @if(date("Y",strtotime($data->updated_at))=="1970") 
                                        <i class="fa fa-calendar"></i> {{date("d M Y H:i",strtotime($data->created_at))}}
                                       @else
                                        <i class="fa fa-calendar-plus-o"></i> {{date("d M Y H:i",strtotime($data->updated_at))}}
                                       @endif
                                    </p>
                                </div>
                                <div class="notes-nav">
                                    <a href="#" class="btn btn-green btn-act-delete" onclick="deleteRssfeed({{$data->id}})">
                                        <img src="{{url('')}}/images//icon-trash.png"/>

                                    </a>

                                    <a href="#" class="btn btn-green btn-act-edit" data-id="{{$data->id}}" data-tittle="{{$data->tittle}}" data-url="{{$data->rss_url}}" data-ttl="{{$data->rss_title}}" data-dsc="{{$data->rss_link}}">

                                        <i class="fa fa-pencil"></i>
                                    </a>

                                    <!-- @if($data->status=="0")

                                    <a href="#" class="btn btn-green btn-publish" data-toggle="tooltip" data-placement="top" title="publish?" data-id="{{$data->id}}" data-status="1"><span class="glyphicon glyphicon-ok"></span></a>

                                    @else

                                    <a href="#" class="btn btn-green btn-publish" data-toggle="tooltip" data-placement="top" title="cancel publish" data-id="{{$data->id}}" data-status="0"><span class="glyphicon glyphicon-minus"></span></a>

                                    @endif -->
                                </div>
                            </li>
                        @endforeach
                        </ul>
                    </div>
                </div>
                <div class="backend-form create-article-form" style="display:none;">
                    <div class="form-top">
                        <div class="form-left">
                            <h4>Create Rss Feed</h4>
                        </div>
                        <div class="form-right">
                            <a href="#" class="btn-save-article setting_save"></a>
                            <a href="#" class="btn-cancel-article setting_cancel"></a>
                        </div>
                    </div>
                    <div class="form-body">
                        <div class="form-group">
                            <span>Title</span><input type="text" name="tittle" id="tittle" class="tittle" required/>
                        </div> 
                        <div class="form-group">
                            <span>RSS URL</span><input type="url" name="url" id="url" class="tittle" required/>
                        </div>
                        <div class="setting-box">
                            <ul> 
                                <li>
                                    <span class="setting-name">Title</span>
                                    <span class="setting-value center">
                                        <select name="title_ddl" id="title_ddl">
                                        </select>
                                    </span>
                                </li>
                                <br><br>
                                <li>
                                    <span class="setting-name">Link</span>
                                    <span class="setting-value center">
                                        <select name="desc_ddl" id="desc_ddl">
                                        </select>
                                    </span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="backend-form edit-article-form" style="display:none;">
                    <div class="form-top">
                        <div class="form-left">
                            <h4>Edit Rss Feed</h4>
                        </div>
                        <div class="form-right">
                            <a href="#" class="btn-save-edit-article setting_save"></a>
                            <a href="#" class="btn-cancel-article setting_cancel"></a>
                        </div>
                    </div>
                    <div class="form-body">
                        <!-- <form id="form-edit"> -->
                        <div class="form-group">
                            <input type="hidden" id="id-edit" name="id-edit" class="id-edit">
                            <span>Title</span><input type="text" name="tittle" id="tittle-edit" class="tittle"/>
                        </div>
                        <div class="form-group">
                            <span style="width: 16%">RSS URL</span><input type="text" name="url-edit" id="url-edit" class="tittle-edit"/>
                        </div>
                        <div class="setting-box">
                            <ul> 
                                <li>
                                    <span class="setting-name">Title</span>
                                    <span class="setting-value center">
                                        <select name="title_ddl1" id="title_ddl1">
                                        </select>
                                    </span>
                                </li>
                                <br><br>
                                <li>
                                    <span class="setting-name">Link</span>
                                    <span class="setting-value center">
                                        <select name="desc_ddl1" id="desc_ddl1">
                                        </select>
                                    </span>
                                </li>
                            </ul>
                        </div>
                        <!-- </form>  -->
                    </div>   
                </div>
            </div>
        </div>
    </div> 
</section>

@endsection

@section('js')
<script type="text/javascript">

    $(document).ready(function(){ 
        $('#url-edit').on('blur',function(e)
        {
            e.preventDefault();
            $('#title_ddl1,#desc_ddl1').empty();
            var reqURL = $('#url-edit').val();
            $.ajax(
            {
                method:'POST',
                url:'{{action("RssController@postXmlnode")}}',
                data:'{"reqURL":"'+reqURL+'"}',
                contentType:'application/json',
                datatype:'xml',
                success:function(result)
                {
                    console.log('result',reqURL);
                    var xml=$.parseXML(result);
                    var x1 = xml.getElementsByTagName("item")[0].children;
                    var array = ['link','website','url'];
                    for (var i = 0; i < x1.length; i++) {
                        newOption = $('<option value="'+x1[i].nodeName+'">'+x1[i].nodeName+'</option>');
                        $('#title_ddl1,#desc_ddl1').append(newOption);
                        for(var j=0; j<=array.length; j++)
                        {
                            if(x1[i].nodeName == array[j])
                            {
                                 $('#desc_ddl1').val(array[j]);
                            }
                        }
                    }
                    $('#title_ddl1').val('title');
                },
                error:function(error,xhr)
                {
                    console.log(error);
                    console.log(xhr);
                },
                complete:function()
                {
                    console.log("complete");
                }
            });
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function(){ 
        $('#url').on('blur',function(e)
        {
            e.preventDefault();
            $('#title_ddl,#desc_ddl').empty();
            var reqURL = $('#url').val();
            $.ajax(
            {
                method:'POST',
                url:'{{action("RssController@postXmlnode")}}',
                data:'{"reqURL":"'+reqURL+'"}',
                contentType:'application/json',
                datatype:'xml',
                success:function(result)
                {
                    console.log('result',reqURL);
                    var xml=$.parseXML(result);
                    var x1 = xml.getElementsByTagName("item")[0].children;
                    var array = ['link','website','url'];
                    for (var i = 0; i < x1.length; i++) {
                        newOption = $('<option value="'+x1[i].nodeName+'">'+x1[i].nodeName+'</option>');
                        $('#title_ddl,#desc_ddl').append(newOption);
                        for(var j=0; j<=array.length; j++)
                        {
                            if(x1[i].nodeName == array[j])
                            {
                                 $('#desc_ddl').val(array[j]);
                            }
                        }
                    }
                    $('#title_ddl').val('title');
                },
                error:function(error,xhr)
                {
                    console.log(error);
                    console.log(xhr);
                },
                complete:function()
                {
                    console.log("complete");
                }
            });
        });
    });
</script>
<script>

    $(document).ready(function(){  
        $(".edit-article-form").hide();
        $(".create-article-form").hide();
        $(".new-article").click(function(e){
            e.preventDefault();
            $(".create-article").hide();
            $(".create-article-form").fadeIn();

         //   $(' iframe').contents().find('.ckeditor').html('');
            if(!content) content = "";
        });

        $(".btn-cancel-article").click(function(e){
            e.preventDefault();
            $(".edit-article-form").hide();
            $(".create-article").fadeIn();
            $(".create-article-form").hide();
        });

        //Edit Rss
        $(".btn-act-edit").click(function(e){
            e.preventDefault();
            var id = $(this).attr("data-id"),
            tittle = $(this).attr("data-tittle"),
            datattl = $(this).attr("data-ttl"),
            datadsc = $(this).attr("data-dsc"),
            content = $(this).attr("data-url"),

            datattlOption = $('<option value="'+datattl+'">'+datattl+'</option>');
            datadscOption = $('<option value="'+datadsc+'">'+datadsc+'</option>');

            $(".create-article").hide();
            $(".edit-article-form").fadeIn();
            $(".id-edit").val(id);
            $("#tittle-edit").val(tittle);
            $("#url-edit").val(content);
            $('#title_ddl1').append(datattlOption);
            $('#desc_ddl1').append(datadscOption);
        });



        //Save Rss
        $(".btn-save-article").click(function(e){
            e.preventDefault();
            var tittle = $("#tittle").val(),
            desc_ddl = $("#desc_ddl").val(),
            title_ddl = $("#title_ddl").val(),
            url = $("#url").val();
            $.ajax({
                method: "POST",
                url: '{{action("RssController@postCreateRssFeed")}}',
                data: { tittle : tittle, url : url, desc_ddl:desc_ddl, title_ddl:title_ddl},
                success: function (response) {
                    if (response=='"error"') {
                        pesanErr("please fill the title and Rss Url");
                    }else{ 
                    pesanOk("Rss Feed add Successfully");
                    setTimeout(function(){location.reload()},1000);
                    };
                },
            })
        });

        // Upadate Rss
        $(".btn-save-edit-article").click(function(e){
            e.preventDefault();
            var id_edit = $("#id-edit").val(),
            tittle_edit = $("#tittle-edit").val(),
            url_edit = $("#url-edit").val(),
            title_ddl = $('#title_ddl1').val(),
            desc_ddl = $("#desc_ddl1").val();
            $.ajax({
                method: "POST",
                url: '{{action("RssController@postUpdateRssFeed")}}',
                data: { id : id_edit, tittle : tittle_edit, url : url_edit,  title_ddl : title_ddl, desc_ddl:desc_ddl},
                success: function (response) {
                //    alert(response);
                    pesanOk("Rss updated");
                   setTimeout(function(){location.reload()},1000);
                },
                error:function()
                {
                	pesanErr("Fail");
                }
            })
        });
        // publish Rss
        

    });



    $(function () {

      $('[data-toggle="tooltip"]').tooltip()

    });

    const deleteRssfeed = (id)=>
        {
            $.ajax({
                url:'{{action("RssController@postDeleteRssFeed")}}',
                data:'id='+id,
                method:'POST',
                success: function (response) {
                //    alert(response);
                    pesanOk("Delete");
                   setTimeout(function(){location.reload()},1000);
                },
                error:function()
                {
                    pesanErr("Fail");
                }
            })
        }



</script>

@endsection

