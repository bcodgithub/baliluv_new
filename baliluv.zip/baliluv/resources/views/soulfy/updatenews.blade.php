
@extends('home')

@section('title', 'Home')

@section('content')

    <section id="content-desc">
        <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>
        <div class="backend-box backend-box-email">
            <div class="backend-nav">
                <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs" role="tablist">
                    <li  class="active"><a id="tab_email" href="#email" aria-controls="setting" role="tab" data-toggle="tab">News</a></li>
                </ul>
            </div>
            <div class="tab-content backend-detail slimScroll">
                <div role="tabpanel" class="tab-pane active" id="email" style="height: 100%; padding: 20px;">
                    <p> <b>Title : </b> {{$announcement->version}}</p>
                    <p> <b>Release Date and Time : </b> {{$announcement->date}} <br>
                        Time zone in Jakarta, Indonesia (GMT+7)
                        <?php 
                            date_default_timezone_set("Asia/Jakarta");
                        ?>
                    <p> <b>Time Left : </b><span id="time-left"></span></p>
                    </p>
                        <b style="color: white;">Topic : </b>
                        <br>
                        <pre class="fixes">{{$announcement->news}}</pre>
                        <br>
                     	<b style="color: white;">Details : </b>
                     	<br>
                     	<pre class="fixes">{{$announcement->fixes}}</pre>
                     	<br>
                </div>
            </div>
        </div>
        <div class="placeholder" id="backend-placeholder">
            <div class="placeholder-first backend-first" style="display:none">
                <div class="placeholder-header">
                    <h3></h3>
                    <a class="btn-cancels"><span class="glyphicon glyphicon-remove"></span></a>
                </div>
                <div class="content-placeholder"><p></p></div>
                @if(Auth::check())
                    <div class="skype-box">
                        <div class="image-skype logged">
                            <img src="{{url()}}/images/skype-logo.png" alt="">
                        </div>
                        <div class="skype-id">
                            Skype ID : <p class="skype-info">{{$user_setting['skype_id']}}</p> 
                            <div class="skype-act">
                                <input type="text"   class="form-control skype_form" value="{{$user_setting['skype_id']}}" required>
                                <a class="btn-skype-edit"><i class="fa fa-pencil-square-o"></i></a>
                                <a class="btn-skype-save"><i class="fa fa-floppy-o"></i></a>
                                <a class="btn-skype-cancel"><i class="fa fa-times"></i></a>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="skype-box">
                        <div class="image-skype">
                            <img src="{{url('')}}/images/skype-logo.png" alt="">
                        </div>
                        <div class="skype-id">
                             Skype ID : {{$user_setting['skype_id']}}
                        </div>
                    </div>
                @endif
                <p class="date-article">
                    <i class='fa fa-user'></i> Published by {{--$user->full_name--}} <i class='user'></i> | <i class='fa fa-calendar'></i>
                </p>
                <div style="clear:both;"></div>
                <div class="placeholder-footer action">
                    <a class="first btn-act-like" onclick="likeTimeLine(this)">
                        <span class="glyphicon glyphicon-thumps-up"></span>
                    </a>
                    <a  class="second"></a>
                    @if(Auth::check())
                        <a class="third btn-act-delete"><span class="glyphicon glyphicon-trash"></span> </a>
                    @endif
                    <div class="fb-comment form-group"></div>
                    <div style="clear:both;"></div>
                </div>
            </div>
        </div>
    </section>

@endsection

@section('js')

<script>
    // Set the date we're counting down to
    // 1. JavaScript
    // var countDownDate = new Date("Sep 5, 2018 15:37:25").getTime();
    // 2. PHP
    <?php date_default_timezone_set("Asia/Jakarta"); ?>
    var countDownDate = <?php echo strtotime($announcement->date) ?> * 1000;
    var now = <?php echo time() ?> * 1000;

    // Update the count down every 1 second
    var x = setInterval(function() {

        // Get todays date and time
        // 1. JavaScript
        // var now = new Date().getTime();
        // 2. PHP
        now = now + 1000;

        // Find the distance between now an the count down date
        var distance = countDownDate - now;

        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Output the result in an element with id="demo"
        document.getElementById("time-left").innerHTML = days + "d " + hours + "h " +
            minutes + "m " + seconds + "s ";

        // If the count down is over, write some text 
        if (distance < 0) {
            clearInterval(x);
            document.getElementById("time-left").innerHTML = "Congratulation..!!! new version release Please refresh website";
        }
    }, 1000);
    </script>
    <link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>
    <script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/js/bootstrap-editable.min.js"></script>
    {{--setting jquery --}}
    <script>
        $('#do-update').click(function(e) {
            e.preventDefault();
            if(confirm("Update may take several minutes to complete So, don not refresh page during updating. Do you want to continue Now?")) {
                $(this).hide();
                $('#do-update-loader').show();
                location.href="{{action('HomeController@getDoUpdateSystem')}}";
            }
        });

        $(".skype_form").hide();
        $(".btn-skype-save").hide();
        $(".btn-skype-cancel").hide();
        $(".btn-skype-edit").click(function(e){
            e.preventDefault();
            $(".btn-skype-cancel").show();
            $(this).hide();
            $(".btn-skype-save").show();
            $(".skype-info").hide();
            $(".skype_form").show();
        });

        $(".btn-skype-cancel").click(function(e){
            e.preventDefault();
            $(".skype_form").hide();
            $(".skype-info").show();
            $(this).hide();
            $(".btn-skype-save").hide();
            $(".btn-skype-edit").show();
        });

        $(".btn-skype-save").click(function(e){
            e.preventDefault();
            var skypeid = $(".skype_form").val();
            var id_user = {{$user_setting['id']}};
            $.ajax({
                type: "POST",
                url: '{{action("AjaxController@postEditSkype")}}',
                data : {
                    id_user : id_user,
                    skypeid : skypeid,
                },
                success: function (response) {
                    if (response=='"success"') {
                        pesanOk("success");
                        $(".skype-info").html(skypeid);
                        $(".skype_form").hide();
                        $(".skype-info").show();
                        $(".btn-skype-save").hide();
                        $(".btn-skype-cancel").hide();
                        $(".btn-skype-edit").show();
                    }else{
                        pesanErr("failed");
                    };
                }
            });
        });
        $("#tab_email").trigger("click");
    </script>
@endsection