<!DOCTYPE html>
  <html lang="en">
    <head>
        <title>Bootstrap Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <style>
          /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
          .row.content {height: 1500px}
          /* Set gray background color and 100% height */
          .sidenav {
          background-color: #f1f1f1;
          height: 100%;
          }
          /* Set black background color, white text and some padding */
          footer {
          background-color: #555;
          color: white;
          padding: 15px;
          }
          /* On small screens, set height to 'auto' for sidenav and grid */
          @media screen and (max-width: 767px) {
          .sidenav {
          height: auto;
          padding: 15px;
          }
          .row.content {height: auto;} 
          }
        </style>
    </head>
    <body>
        <div class="container-fluid">
          <div class="row content">
            <div class="col-sm-3 sidenav">
              <ul class="nav nav-pills nav-stacked">
                  <li class="active" style="text-align: left;display: block;float:unset;"><a id="tab_social" href="#social" aria-controls="social" role="tab" data-toggle="tab">dashboard</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="followers" role="tab" data-toggle="tab" class="capitalized">calender</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Appointments</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">services</a></li>
                  <ul>
                    <li style="text-align: left;display: block;float:unset;"><a href="admin/category" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Category Master</a></li>
                    <li style="text-align: left;display: block;float:unset;"><a href="admin/service" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Services Master</a></li>
                  </ul>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Agents</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Coupons</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Email & reminder</a></li>
                  <ul>
                    <li style="text-align: left;display: block;float:unset;"><a href="admin/email-template" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Email Templates</a></li>
                    <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Remainders</a></li>
                  </ul>
              </ul>
              <br>
            </div>

            <div class="tab-content common-tab-section min-height-480">

            <form method="POST" id="templateForm" >
            <meta name="csrf-token" content="{{ csrf_token() }}"> 
                        
                        <!-- <input type="hidden" name="page_id" value=""> -->
                        <div class="customize-add-section">

                        <!-- validation part-->
                        <div class="alert alert-danger print-error-msg" style="display:none">
                        <ul></ul>
                        </div>

                            <div class="row">
                                <div class="col-sm-7 customize-add-inner-sec">
                                    <!--<label for="title">Email Code *</label>
                                    <input class="form-control" type="text" name="title" id="title" value=""
                                        placeholder="Enter Page Title here" required="">-->
                                      
                                        
                                    <label for="title">Email Code *</span></label>
                                    <input type="text" id="email_code" name="email_code" class="form-control" placeholder="Enter Email Code here" required="" >
                                </div><!-- col-sm-6 -->

                                <div class="col-sm-6 customize-add-inner-sec">
                                    <label for="meta_title">Email Title</label>
                                    <input class="form-control" type="text" name="title" id="title"
                                        placeholder="Enter Email Title here" required="">
                                </div><!-- col-sm-6 -->

                                <div class="col-sm-6 customize-add-inner-sec">
                                    <label for="meta_keyword">Email Subject</label>
                                    <input class="form-control" type="subject" name="subject" id="subject"
                                        placeholder="Meta Keyword" required="">
                                </div><!-- col-sm-6 -->

                                <div class="col-sm-6 customize-add-inner-sec page-content-textarea">
                                    <label for="page_content">Email Content *</label>
                                    <textarea class="form-control" name="content" id="content"
                                    ></textarea>
                                   
                                </div><!-- col-sm-6 -->
                                <div class="col-sm-6 download-discard-small ">

                                  <!--<button class="white-btn" type="reset">Discard</button>-->
                                  <button class="white-btn" type="submit" id="templatesubmit">Save</button>
                                </div><!-- download-discard-small  -->

                            </div><!-- row -->
                        </div><!-- customize-add-section -->
                    </form>

</div>
          </div>
        </div>
      </div>
    </body>
  </html>
  @section('extra_js')
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script>
    $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
    }
    });
    
    $('#templatesubmit').click(function(e){ 
    
    e.preventDefault();  
    //var formData =  new FormData(document.getElementById("templateForm"));
    
    var _token = $("input[name='_token']").val();
    var email_code = $("input[name='email_code']").val();
    var title = $("input[name='title']").val();
    var subject = $("input[name='subject']").val();
    //var content = $("input[name='content']").val();
    var content = $('textarea#content').val();
    alert(email_code);
    
    
    //let email_code = $('#email_code').val();
    //let title = $('#title').val();
    //let subject = $('#subject').val();
    //let content = $('#content').val();
    $.ajax({
        url: "admin/email-template/add",
        //data: formData,
    
        data:{
            _token:_token,
            email_code:email_code,
            title:title,
            subject:subject,
            content:content,
          },
        processData: false,
        contentType: false,
        dataType: 'json',
        type: $('#templateForm').attr('method'),
        success: function(data)
        
          {
            alert(data);
            if($.isEmptyObject(data.error)){
                    alert(data.success);
                }else{
                    printErrorMsg(data.error);
                }
    
            //alert(response);
    
            // console.log(response.msg.password[0]);
          
            /*if(response.flag == 1) {
                        swal({
                            text: response.msg,
                            button: false,
                            icon: 'success'
                          }) 
            }
            else {
                        swal({                            
                            text: response.msg,
                            button: false,
                            icon: 'error'
                          })
                          return false;
                }
            */
        },
        /* error: function (response) {
                      console.log(response);
        } */
    })
        
    });
    
    
    function printErrorMsg (msg) {
        $(".print-error-msg").find("ul").html('');
        $(".print-error-msg").css('display','block');
        $.each( msg, function( key, value ) {
            $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
    });

    };
  </script>

  
  <!--</div>-->