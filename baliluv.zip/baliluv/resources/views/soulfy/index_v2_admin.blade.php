<?php

/**

 * Created by PhpStorm.

 * User: FID_KHADAFI

 * Date: 8/18/2015

 * Time: 9:57 AM

 */

use Soulfy\Followers;

$user_setting = \Soulfy\Setting::where('user_id', $user['id'])->first();

$no = 1;

$guest = session()->get('guest');

$followers  = \Soulfy\Followers::leftjoin('users', 'users.id', '=', 'follower_id')->where('following_id', $user->id)->get();

$followings = \Soulfy\Followers::leftjoin('users', 'users.id', '=', 'following_id')->where('follower_id', $user->id)->get();

?>

@extends('home_admin')

@section('title', 'Home')

@section('css')
    <!-- page css here -->
@endsection



@section('content')

    @if(Auth::check())
        
        <section id="content-desc" style="position:fixed;top:50px;">
            <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>
            <div class="backend-box backend-box-email">
                <div class="backend-nav">

                    <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs" role="tablist">

                        <li class="active"><a id="tab_social" href="#social" aria-controls="social" role="tab" data-toggle="tab">social</a></li>

						<li><a href="#followers" aria-controls="followers" role="tab" data-toggle="tab" class="capitalized">{{count($followers)}} Followers</a></li>

                        <li><a href="#following" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">{{count($followings)}} Following</a></li>

                    </ul>

                </div>

                <div class="tab-content backend-detail slimScroll">

                    <div role="tabpanel" class="tab-pane active" id="social">

                        @include("soulfy/partial/social")

                    </div>

                    <div role="tabpanel" class="tab-pane" id="followers">

                        @include("soulfy/partial/followers")

                    </div>

                    <div role="tabpanel" class="tab-pane" id="following">

                        @include("soulfy/partial/following")

                    </div>

                </div>

            </div>

            
        </section>
        <section id="content-desc" style="background: rgba(0, 0, 0, 0.0) !important;">
            <div class="placeholder" id="backend-placeholder">

                <div class="placeholder-first backend-first inner-section-container" style="display:none" id="grey-article">

                    <!-- <div class="placeholder-header">

                        <h3>{{$user['full_name']}} </h3>

                        
                        <br>
                    </div> -->
                    <a class="btn-cancels" id="btn-cancels"><span class="glyphicon glyphicon-remove"></span></a>
                    <div class="content-placeholder">
                        <p>

                            {!!$user_setting['info_profile']!!}

                        </p>

                    </div>

                    <div class="skype-box">

                        <div class="image-skype logged">

                            <img src="{{url('')}}/images/skype-logo.png" alt="">

                        </div>

                        <div class="skype-id">

                            Skype ID :

                            <p class="skype-info">{{$user_setting['skype_id']}}</p>

                            <div class="skype-act">

                                <input type="text" class="form-control skype_form" value="{{$user_setting['skype_id']}}"

                                       required>

                                <a class="btn-skype-edit"><i class="fa fa-pencil-square-o"></i></a>

                                <a class="btn-skype-save"><i class="fa fa-floppy-o"></i></a>

                                <a class="btn-skype-cancel"><i class="fa fa-times"></i></a>

                            </div>
                        </div>
                    </div>

                    <p class="date-article"><i class='fa fa-user'></i> Published by {{$user['full_name']}}
                        <i class='user'></i> | <i class='fa fa-calendar'></i></p>

                    <div style="clear:both;"></div>
                    <div class="placeholder-footer action" >

                        <a class="first btn-act-like" onclick="likeTimeLine(this)">
                                <span class="glyphicon glyphicon-thumps-up"></span>
                                <span id="timline_count" style='font-size: 10px !important;'></span>
                            </a>

                        <a class="second"></a>

                        <a class="third btn-act-delete" onclick="deleteTimeLine(this)">
                            <span class="glyphicon glyphicon-trash"></span>
                        </a>

                        <div class="fb-comment form-group"></div>

                        <div style="clear:both;"></div>

                    </div>

                </div>
            </div>
        </section>

    @else
        <section id="content-profile">
            <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>

            <div class="backend-box _grey backend-box-email">

                <div class="slimScroll" data-total="0.60" data-minus="150">

                    <div class="placeholder-header-email" style="font-size: 17px; float: left;">

                        <div class="pull-left">{{$user['full_name']}} </div><br>

                        @if(!$guest)

							<div class="pull-left" style="background: #288a1d;padding: 0px 10px;border-radius: 5px;"><a style=" color: #FFFFFF !important; text-decoration: none;" href="#follower_login" id="follower_login_open">Follow</a></div>

						@elseif(!$guest->is_following)

							<div class="pull-left" style="margin-left: 20px;background: #288a1d;padding: 0px 10px;border-radius: 5px;"><a style=" color: #FFFFFF !important; text-decoration: none;" href="#" data-url="{{action("AjaxController@postDoFollow")}}" id="do_follow">Follow</a></div>

						@else

							<div class="pull-left" style="margin-left: 20px;background: #288a1d;padding: 0px 10px;border-radius: 5px;"><a style=" color: #FFFFFF !important; text-decoration: none;" href="#" data-url="{{action("AjaxController@postDoUnfollow")}}" id="do_unfollow">Unfollow</a></div>

						@endif

                        <div class="pull-left" style="margin-left: 20px;">{{count($followers)}} Followers</div>

                        <div class="pull-left" style="margin-left: 20px;">{{count($followings)}} Following</div>

                    </div>

                    <div class="content-placeholder-email">

                        <?php
                            $mystring = $user_setting['info_profile'];
                            $findme   = '<ifram';
                            $pos = strpos($mystring, $findme);

                            if ($pos === false) { ?>
                            <p>
                                {!!$user_setting['info_profile']!!}
                            </p>
                        <?php } else { ?>
                            <p class="videoWrapper">
                                {!!$user_setting['info_profile']!!}
                            </p>
                        <?php } ?>

                    </div>

                </div>

            </div>

            

            <div class="backend-box backend-box-email" style="min-height: 50px; background: none; margin-top: 50px;">

                <a class="plus-minus-toggeler dont-hide">

                    <span class="glyphicon glyphicon-chevron-down"></span>

                </a>

                <div class="placeholder-advert _grey">

                    <div class="slimScroll" data-total="0.33" data-minus="150">

                        <div class="placeholder-header-advert">

                            <!--<h3>Event</h3>-->

                        </div>

                        <div class="content-placeholder-advert">

                        <!--<img src="{{url('')}}/images/adverts/advert.gif">-->

                            <div class="form-body  create-article">

                                <div class="notes-box" id="articles_container">

                                    <ul>
                                        @foreach($articles as $data)

                                            <li>
                                                <div class="notes-desc" style="width: 100%;">

                                                    <p class="btn-placeholder" data-id="{{$data->id}}"

                                                       data-tipe="article" data-tittle="{{$data->tittle}}" data-url="#"

                                                       data-content="{{$data->content}}"

                                                       data-date="{{date('d M Y',strtotime($data->updated_at))}}"

                                                       data-target="#content_desc"><b>{{$no++}}.

                                                            @if(strlen($data->tittle)>=10)

                                                                {{substr($data->tittle,0,15)}}....

                                                            @else

                                                                {{$data->tittle}}

                                                            @endif

                                                        </b></p>

                                                    <p>

                                                        @if(strlen(strip_tags($data->content))>=40)

                                                            {{substr(strip_tags($data->content),0,45)}}....

                                                        @else

                                                            {{strip_tags($data->content)}}

                                                        @endif

                                                    </p>

                                                    <p class="date">

                                                        @if(date("Y",strtotime($data->updated_at))=="1970")

                                                            <i class="fa fa-calendar"></i> {{date("d M Y H:i",strtotime($data->created_at))}}

                                                        @else

                                                            <i class="fa fa-calendar-plus-o"></i> {{date("d M Y H:i",strtotime($data->updated_at))}}

                                                        @endif

                                                    </p>

                                                </div>

                                            </li>

                                        @endforeach

                                    </ul>

                                </div>

                            </div>

                            <div class="placeholder-footer-advert"></div>

                        </div>

                    </div>

                </div>

            </div>

            <div class="placeholder transparent inner-section-container" id="backend-placeholder">

                <div class="tab-content backend-detail slimScroll" data-minus="150">

                    <div class="placeholder-first placeholder-header" id="grey-article">

                        <!-- <div class="placeholder-header">

                            <h3>{{$user['full_name']}} </h3>
                            
                            <br>

                        </div>
 -->
                        <a class="btn-cancels" id="btn-cancels"><span class="glyphicon glyphicon-remove"></span></a>

                        <!--<div class="clrbth"></div><div class="tab-content backend-detail slimScroll" data-total="2" data-minus="270">-->

                        <div class="content-placeholder object-video">

                            <p>

                                {!!$user_setting['info_profile']!!}

                            </p>

                        </div>

                        <div class='skype-box' style="display:none;">

                            <div class='image-pp'>

                                <img src="{{url()}}/{{$user['image_profile']}}"/>

                            </div>

                            <div class='skype-infos'>

                                <div class='image-skype'>

                                    <img src="{{url('')}}/images/skype-logo.png" alt=''/>

                                </div>

                                <div class='skype-id'>

                                    Skype ID : {{$user_setting['skype_id']}}

                                </div>

                            </div>

                        </div>

                        <p class="date-article" style="display:none;">

                            <i class='fa fa-user'></i> Published by {{$user['full_name']}}

                            <i class='user'></i> |

                            <i class='fa fa-calendar'></i>

                        </p>

                        <div style="clear:both;"></div>

                        <div class="placeholder-footer action">

                            <a class="first btn-act-like" onclick="likeTimeLine(this)">
                                <span class="glyphicon glyphicon-thumps-up"></span>
                                <span id="timline_count" style='font-size: 10px !important;'></span>
                            </a>

                            <a class="second"></a>

                            <div class="fb-comment form-group"></div>

                            <div style="clear:both;"></div>

                        </div>

                    </div>

                    <div class="placeholder-second placeholder" style="display:none;">

                        <div class="placeholder-header-email">

                            <h3>Email Us</h3>

                            <a class="btn-cancel-video"><span class="glyphicon glyphicon-remove"></span></a>

                        </div>

                        @include("soulfy/partial/placeholder_email")



                    </div>

                    <div class="placeholder-third" style="display:none;">

                        <div class="card-box">

                            @include("soulfy/partial/bcard")

                        </div>

                        <div class="footer"></div>

                    </div>

                </div>

            </div>

        </section>

    @endif 


    <!--dashboard-->
    @if(Auth::check())
   
        <section id="content-desc" style="position:absolute;left:420px;max-width:500px;">
            <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>
            <div class="backend-box backend-box-email">
                <div class="backend-nav">

                    <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs admin-tabs" role="tablist">

                        <li class="active" style="text-align: left;display: block;float:unset;"><a id="tab_social" href="#social" aria-controls="social" role="tab" data-toggle="tab">dashboard</a></li>

						<li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="followers" role="tab" data-toggle="tab" class="capitalized">calender</a></li>

                        <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Appointments</a></li>

                        <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">services</a></li>

                        <ul>
                            <li style="text-align: left;display: block;float:unset;"><a href="admin/category" aria-controls="following" role="tab"  class="capitalized">Category Master</a></li>

                            <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Services Master</a></li>
                        </ul>

                        <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Agents</a></li>

                        <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Coupons</a></li>

                        <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Email & reminder</a></li>
                    </ul>

                </div>

 

            </div>

            
        </section>
        <section id="content-desc" style="background: rgba(0, 0, 0, 0.0) !important;">
            <div class="placeholder" id="backend-placeholder">

                <div class="placeholder-first backend-first inner-section-container" style="display:none" id="grey-article">

                    <!-- <div class="placeholder-header">

                        <h3>{{$user['full_name']}} </h3>

                        
                        <br>
                    </div> -->
                    <a class="btn-cancels" id="btn-cancels"><span class="glyphicon glyphicon-remove"></span></a>
                    <div class="content-placeholder">
                        <p>

                            {!!$user_setting['info_profile']!!}

                        </p>

                    </div>

                    <div class="skype-box">

                        <div class="image-skype logged">

                            <img src="{{url('')}}/images/skype-logo.png" alt="">

                        </div>

                        <div class="skype-id">

                            Skype ID :

                            <p class="skype-info">{{$user_setting['skype_id']}}</p>

                            <div class="skype-act">

                                <input type="text" class="form-control skype_form" value="{{$user_setting['skype_id']}}"

                                       required>

                                <a class="btn-skype-edit"><i class="fa fa-pencil-square-o"></i></a>

                                <a class="btn-skype-save"><i class="fa fa-floppy-o"></i></a>

                                <a class="btn-skype-cancel"><i class="fa fa-times"></i></a>

                            </div>
                        </div>
                    </div>

                    <p class="date-article"><i class='fa fa-user'></i> Published by {{$user['full_name']}}
                        <i class='user'></i> | <i class='fa fa-calendar'></i></p>

                    <div style="clear:both;"></div>
                    <div class="placeholder-footer action" >

                        <a class="first btn-act-like" onclick="likeTimeLine(this)">
                                <span class="glyphicon glyphicon-thumps-up"></span>
                                <span id="timline_count" style='font-size: 10px !important;'></span>
                            </a>

                        <a class="second"></a>

                        <a class="third btn-act-delete" onclick="deleteTimeLine(this)">
                            <span class="glyphicon glyphicon-trash"></span>
                        </a>

                        <div class="fb-comment form-group"></div>

                        <div style="clear:both;"></div>

                    </div>

                </div>
            </div>
        </section>

    @else
        <section id="content-profile">
            <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>

            <div class="backend-box _grey backend-box-email">

                <div class="slimScroll" data-total="0.60" data-minus="150">

                    <div class="placeholder-header-email" style="font-size: 17px; float: left;">

                        <div class="pull-left">{{$user['full_name']}} </div><br>

                        @if(!$guest)

							<div class="pull-left" style="background: #288a1d;padding: 0px 10px;border-radius: 5px;"><a style=" color: #FFFFFF !important; text-decoration: none;" href="#follower_login" id="follower_login_open">Follow</a></div>

						@elseif(!$guest->is_following)

							<div class="pull-left" style="margin-left: 20px;background: #288a1d;padding: 0px 10px;border-radius: 5px;"><a style=" color: #FFFFFF !important; text-decoration: none;" href="#" data-url="{{action("AjaxController@postDoFollow")}}" id="do_follow">Follow</a></div>

						@else

							<div class="pull-left" style="margin-left: 20px;background: #288a1d;padding: 0px 10px;border-radius: 5px;"><a style=" color: #FFFFFF !important; text-decoration: none;" href="#" data-url="{{action("AjaxController@postDoUnfollow")}}" id="do_unfollow">Unfollow</a></div>

						@endif

                        <div class="pull-left" style="margin-left: 20px;">{{count($followers)}} Followers</div>

                        <div class="pull-left" style="margin-left: 20px;">{{count($followings)}} Following</div>

                    </div>

                    <div class="content-placeholder-email">

                        <?php
                            $mystring = $user_setting['info_profile'];
                            $findme   = '<ifram';
                            $pos = strpos($mystring, $findme);

                            if ($pos === false) { ?>
                            <p>
                                {!!$user_setting['info_profile']!!}
                            </p>
                        <?php } else { ?>
                            <p class="videoWrapper">
                                {!!$user_setting['info_profile']!!}
                            </p>
                        <?php } ?>

                    </div>

                </div>

            </div>

            

            <div class="backend-box backend-box-email" style="min-height: 50px; background: none; margin-top: 50px;">

                <a class="plus-minus-toggeler dont-hide">

                    <span class="glyphicon glyphicon-chevron-down"></span>

                </a>

                <div class="placeholder-advert _grey">

                    <div class="slimScroll" data-total="0.33" data-minus="150">

                        <div class="placeholder-header-advert">

                            <!--<h3>Event</h3>-->

                        </div>

                        <div class="content-placeholder-advert">

                        <!--<img src="{{url('')}}/images/adverts/advert.gif">-->

                            <div class="form-body  create-article">

                                <div class="notes-box" id="articles_container">

                                    <ul>
                                        @foreach($articles as $data)

                                            <li>
                                                <div class="notes-desc" style="width: 100%;">

                                                    <p class="btn-placeholder" data-id="{{$data->id}}"

                                                       data-tipe="article" data-tittle="{{$data->tittle}}" data-url="#"

                                                       data-content="{{$data->content}}"

                                                       data-date="{{date('d M Y',strtotime($data->updated_at))}}"

                                                       data-target="#content_desc"><b>{{$no++}}.

                                                            @if(strlen($data->tittle)>=10)

                                                                {{substr($data->tittle,0,15)}}....

                                                            @else

                                                                {{$data->tittle}}

                                                            @endif

                                                        </b></p>

                                                    <p>

                                                        @if(strlen(strip_tags($data->content))>=40)

                                                            {{substr(strip_tags($data->content),0,45)}}....

                                                        @else

                                                            {{strip_tags($data->content)}}

                                                        @endif

                                                    </p>

                                                    <p class="date">

                                                        @if(date("Y",strtotime($data->updated_at))=="1970")

                                                            <i class="fa fa-calendar"></i> {{date("d M Y H:i",strtotime($data->created_at))}}

                                                        @else

                                                            <i class="fa fa-calendar-plus-o"></i> {{date("d M Y H:i",strtotime($data->updated_at))}}

                                                        @endif

                                                    </p>

                                                </div>

                                            </li>

                                        @endforeach

                                    </ul>

                                </div>

                            </div>

                            <div class="placeholder-footer-advert"></div>

                        </div>

                    </div>

                </div>

            </div>

            <div class="placeholder transparent inner-section-container" id="backend-placeholder">

                <div class="tab-content backend-detail slimScroll" data-minus="150">

                    <div class="placeholder-first placeholder-header" id="grey-article">

                        <!-- <div class="placeholder-header">

                            <h3>{{$user['full_name']}} </h3>
                            
                            <br>

                        </div>
 -->
                        <a class="btn-cancels" id="btn-cancels"><span class="glyphicon glyphicon-remove"></span></a>

                        <!--<div class="clrbth"></div><div class="tab-content backend-detail slimScroll" data-total="2" data-minus="270">-->

                        <div class="content-placeholder object-video">

                            <p>

                                {!!$user_setting['info_profile']!!}

                            </p>

                        </div>

                        <div class='skype-box' style="display:none;">

                            <div class='image-pp'>

                                <img src="{{url()}}/{{$user['image_profile']}}"/>

                            </div>

                            <div class='skype-infos'>

                                <div class='image-skype'>

                                    <img src="{{url('')}}/images/skype-logo.png" alt=''/>

                                </div>

                                <div class='skype-id'>

                                    Skype ID : {{$user_setting['skype_id']}}

                                </div>

                            </div>

                        </div>

                        <p class="date-article" style="display:none;">

                            <i class='fa fa-user'></i> Published by {{$user['full_name']}}

                            <i class='user'></i> |

                            <i class='fa fa-calendar'></i>

                        </p>

                        <div style="clear:both;"></div>

                        <div class="placeholder-footer action">

                            <a class="first btn-act-like" onclick="likeTimeLine(this)">
                                <span class="glyphicon glyphicon-thumps-up"></span>
                                <span id="timline_count" style='font-size: 10px !important;'></span>
                            </a>

                            <a class="second"></a>

                            <div class="fb-comment form-group"></div>

                            <div style="clear:both;"></div>

                        </div>

                    </div>

                    <div class="placeholder-second placeholder" style="display:none;">

                        <div class="placeholder-header-email">

                            <h3>Email Us</h3>

                            <a class="btn-cancel-video"><span class="glyphicon glyphicon-remove"></span></a>

                        </div>

                        @include("soulfy/partial/placeholder_email")



                    </div>

                    <div class="placeholder-third" style="display:none;">

                        <div class="card-box">

                            @include("soulfy/partial/bcard")

                        </div>

                        <div class="footer"></div>

                    </div>

                </div>

            </div>

        </section>

    @endif 




    @endsection 



@section('js')

    <script>

        <?PHP

            if($login_error = session()->get('login_error')) {

                echo "alert('".$login_error."');";

                session()->forget('login_error');
            }

        ?>

        var options = {

            beforeSubmit: function () {

                var loading_gif = "<img width='24px' src='{{url('')}}/images/ajax-loader.gif'/>"

                $("#btn_login").html(loading_gif + "<span> Loading...<span>");

            },

            success: function () {

                $("#btn_login").html("Login");

                location.reload();

            },

            error: function (response) {

                location.reload();

                $("#btn_login").html("Login");

                var data = jQuery.parseJSON(response.responseText);

                console.log(response);

                try {

                    pesanErr(data.message);

                } catch (err) {

                    pesanErr("An error occured. Please try again or contact us.");

                }
            }

        };

        $('#form_login').ajaxForm(options);

    </script>

    <script type="text/javascript">

        $(document).ready(function () {

            @if(!Auth::check())

                    $('.btn-placeholder, .btn-placeholder.email').click(function (e) {

                e.preventDefault();

                var obj = $('.plus-minus-toggeler.dont-hide').eq(0);

                var glyphicon = obj.find('span.glyphicon');

                if ($(glyphicon).hasClass('glyphicon-chevron-up')) {

                    $(glyphicon).addClass('glyphicon-chevron-down').removeClass('glyphicon-chevron-up');

                    obj.next().slideDown();

                }

            });

            @endif;

            $("#backend-placeholder").hide();

            $(".skype_form").hide();

            $(".btn-skype-save").hide();

            $(".btn-skype-cancel").hide();

            $(".btn-skype-edit").click(function (e) {

                e.preventDefault();

                $(".btn-skype-cancel").show();

                $(this).hide();

                $(".btn-skype-save").show();

                $(".skype-info").hide();

                $(".skype_form").show();

            });

            $(".btn-skype-cancel").click(function (e) {

                e.preventDefault();

                $(".skype_form").hide();

                $(".skype-info").show();

                $(this).hide();

                $(".btn-skype-save").hide();

                $(".btn-skype-edit").show();

            });

            $(".btn-skype-save").click(function (e) {

                e.preventDefault();

                var skypeid = $(".skype_form").val();

                var id_user = '{{$user_setting['id']}}';

                $.ajax({

                    type: "POST",

                    url: '{{action("AjaxController@postEditSkype")}}',

                    data: {

                        id_user: id_user,

                        skypeid: skypeid,

                    },



                    success: function (response) {

                        if (response == '"success"') {

                            pesanOk("success");

                            $(".skype-info").html(skypeid);

                            $(".skype_form").hide();

                            $(".skype-info").show();

                            $(".btn-skype-save").hide();

                            $(".btn-skype-cancel").hide();

                            $(".btn-skype-edit").show();

                        } else {

                            pesanErr("failed");

                        }

                        ;

                    }

                });

            });
            $('#btn-cancels').click(function(){
                $('#backend-placeholder').css('display','none');
                $('.backend-box').css('display','block');
                $('#info_profile').css('display','block');
                
            });

        });

    </script>

@endsection


