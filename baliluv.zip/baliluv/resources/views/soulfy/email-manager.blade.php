<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 8/18/2015
 * Time: 9:57 AM
 */
$user_setting = \Soulfy\Setting::where('user_id',$user['id'])->first();
 $no = "1";
?>



@extends('home')

@section('title', 'Home')


@section('content')

    <section id="content-desc">
     

                <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-minus"></span></a>
                <div class="backend-box backend-box-email">
                    <div class="backend-nav">
                        <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs" role="tablist">
                            <li class="active"><a id="email_manage" href="#email_manage" aria-controls="email_manage" role="tab"
                                                  data-toggle="tab">Manager</a></li>
                         
                            
                        </ul>
                    </div>
                    <div class="tab-content backend-detail slimScroll">
                        <div role="tabpanel" class="tab-pane active" id="email_manage" style="height: 100%">      
                                            <div class="form-top create-email">
                                                <label>Email Accounts</label>
                                            </div>
                                            <div class="form-body  create-email">

                                                <div class="notes-box">
                                                    <ul>
                                                    
                                                    @foreach($emails as $data)
                                                        <li>

                                                            <div class="notes-desc" style="width:100%;">
                                                                <p><b>{{$no++}}.
                                                                    {{$data['email']}}
                                                                </b></p>
                                                                <p class="date" style="float:left;">
                                                                    <i class="fa fa-floppy-o"></i><b> Quota: </b>{{$data['humandiskquota']}}<br>
                                                                    <i class="fa fa-floppy-o"></i><b> Used: </b>{{$data['diskusedpercent']}}%
                                                                </p>
                                                            
                                                                <div class="notes-nav">
                                                                    <a href="#" class="btn btn-green btn-delete-email-account" data-user="{{$data['user']}}"><img src="{{url('')}}/images/icon-trash.png"/></a>
                                                                    <a href="#" class="btn btn-green btn-edit-email-account" data-email="{{$data['email']}}" data-user="{{$data['user']}}"><i class="fa fa-pencil"></i></a>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    @endforeach
                                                    </ul>
                                                </div>
                                            </div>
                                
                 
            </div>
        </div>
        <div class="placeholder" id="backend-placeholder">
                <div class="placeholder-first backend-first" style="display:none">
                    <div class="placeholder-header">

                            <h3 ></h3>
                            <a class="btn-cancels"><span class="glyphicon glyphicon-remove"></span></a>
                    </div>

                              <div class="content-placeholder">
                                        <p>
                                           
                                        </p>
                             </div>
                             @if(Auth::check())
                             <div class="skype-box">
                                    <div class="image-skype logged">
                                        <img src="{{url()}}/images/skype-logo.png" alt="">
                                    </div>
                                    <div class="skype-id">
                                         Skype ID : <p class="skype-info">{{$user_setting['skype_id']}}</p> 
                                         <div class="skype-act">
                                         <input type="text"   class="form-control skype_form" value="{{$user_setting['skype_id']}}" required>
                                         <a class="btn-skype-edit"><i class="fa fa-pencil-square-o"></i></a>
                                         <a class="btn-skype-save"><i class="fa fa-floppy-o"></i></a>
                                         <a class="btn-skype-cancel"><i class="fa fa-times"></i></a>
                                         </div>
                                         
                                    </div>
                             </div>
                             @else
                             <div class="skype-box">
                                    <div class="image-skype">
                                        <img src="{{url('')}}/images/skype-logo.png" alt="">
                                    </div>
                                    <div class="skype-id">
                                         Skype ID : {{$user_setting['skype_id']}}
                                    </div>
                             </div>
                             @endif
                    <p class="date-article"><i class='fa fa-user'></i> Published by <i>{{$user->full_name}}</i><i class='user'></i> | <i class='fa fa-calendar'></i></p>
                    <div style="clear:both;"></div>

                    <div class="placeholder-footer action">
                                            <a  class="first"></a>
                                            <a  class="second"></a>
                                            @if(Auth::check())
                                            <a class="third btn-act-delete"><span class="glyphicon glyphicon-trash"></span> </a>
                                            @endif
                            <div class="fb-comment form-group"></div>
                            <div style="clear:both;"></div>
                    </div>
                    </div>
                    
            </div>
    </section>

@endsection


@section('js')

<script>

    $(document).ready(function(){

        $(".edit-article-form").hide();
        $(".create-email-form").hide();

	
	$('.btn-edit-email-account').click(function(e) {
		e.preventDefault();
		var user = $(this).attr('data-user');
		var email = $(this).attr('data-email');
		
		$('#modal_update_email_account_password').text(email);
		$('#modal_user_email_account_password').val(user);
		$('#change_password_modal').modal('show');
	});
	
	$('#form_update_email_password').submit(function(e) {
		e.preventDefault();
		if($('#change-password1').val() != $('#change-password2').val()) {
			pesanErr('Passwords Mismatched');
		}
		else {
			var url = $(this).attr('action');
			$.ajax({
		                method: "POST",
		                url: url,
		                data: { user : $('#modal_user_email_account_password').val(), password : $('#change-password1').val() },
		                dataType: 'json',
		                success: function (response) {
		                        pesanOk(response.message);
		                },
		                error: function(response) {
		                	pesanErr(response.responseJSON.message);
		                }
			});
		}
	});


        $(".new-email").click(function(e){
            e.preventDefault();
            $(".create-email").hide();
            $(".create-email-form").fadeIn();
        });
        $(".btn-cancel-email").click(function(e){
            e.preventDefault();
            $(".edit-email-form").hide();
            $(".create-email").fadeIn();
            $(".create-email-form").hide();
        });
        $(".btn-act-edit").click(function(e){
            e.preventDefault();
            var id = $(this).attr("data-id"),
            tittle = $(this).attr("data-tittle"),
            content = $(this).attr("data-content");
            $(".create-email").hide();
            $(".edit-email-form").fadeIn();
            $(".id-edit").val(id);
            $(".tittle-edit").val(tittle);
        });
        $(".btn-delete-email-account").click(function(e){
            e.preventDefault();
            
            if(confirm("This action is not undo able. You'll lose all the data in your mail account. Are you sure, do you want to delete this Account?")) {
	            $.ajax({
	                method: "POST",
	                url: '{{action("AjaxController@postDeleteEmailAccount")}}',
	                data: { user : $(this).attr('data-user') },
	                dataType: 'json',
	                success: function (response) {
	                    if (!response.error) {
	                        pesanErr(response.message);
	                    }else{
		                    pesanOk(response.message);
		                    setTimeout(function(){location.reload()},1000);
	                    };
	                },
	                error: function(response) {
	                	pesanErr(response.message);
	                }
	            });
            }
             
        });
        $(".btn-save-edit-article").click(function(e){
            e.preventDefault();
            var id_edit = $("#id-edit").val(),
            tittle_edit = $("#tittle-edit").val(),
            content_edit = $("#content-edit").val();
            $.ajax({
                method: "POST",
                url: '{{action("AjaxController@postUpdateArticle")}}',
                data: { id : id_edit, tittle : tittle_edit, content : content_edit, },
                success: function (response) {
                    
                    pesanOk("Article updated");
                   setTimeout(function(){location.reload()},1000);
                },
            })


        });
        $(".btn-publish").click(function(e){
            e.preventDefault();
            var id = $(this).attr("data-id"),
            status = $(this).attr("data-status");
            $.ajax({
                method: "POST",
                url: '{{action("AjaxController@postArticlePublish")}}',
                data: { id : id, status : status, },
                success: function (response) {
                    
                    pesanOk("Status changed");
                    setTimeout(function(){location.reload()},1000);
                },
            })

        });
    });
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    });
    
        $('.form-body textarea').keyup(function() {
            var len = this.value.length;
                if (len >= 1000) {
                this.value = this.value.substring(0, 1000);
                alert("Max input");
                }
            $('.form-body span.char-info').text(1000 - len);
        });

        $(".skype_form").hide();
            $(".btn-skype-save").hide();
            $(".btn-skype-cancel").hide();
            $(".btn-skype-edit").click(function(e){
                e.preventDefault();
                $(".btn-skype-cancel").show();
                $(this).hide();
                $(".btn-skype-save").show();
                $(".skype-info").hide();
                $(".skype_form").show();
            });
            $(".btn-skype-cancel").click(function(e){
                e.preventDefault();
                $(".skype_form").hide();
                 $(".skype-info").show();
                 $(this).hide();
                 $(".btn-skype-save").hide();
                 $(".btn-skype-edit").show();
            });
            $(".btn-skype-save").click(function(e){
                e.preventDefault();
                var skypeid = $(".skype_form").val();
                var id_user = {{$user_setting['id']}};
                $.ajax({
                type: "POST",
                url: '{{action("AjaxController@postEditSkype")}}',
                data : {
                    id_user : id_user,
                     skypeid : skypeid,
                },

                success: function (response) {
                    if (response=='"success"') {
                        pesanOk("success");
                        $(".skype-info").html(skypeid);
                        $(".skype_form").hide();
                         $(".skype-info").show();
                         $(".btn-skype-save").hide();
                         $(".btn-skype-cancel").hide();
                         $(".btn-skype-edit").show();
                    }else{
                        pesanErr("failed");
                    };
                }
            });
            });


 
</script>
@endsection