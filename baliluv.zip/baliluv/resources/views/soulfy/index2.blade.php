<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 7/30/2015
 * Time: 9:20 AM
 */
?>

        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="{{ \DB::table('meta')->where('meta_id', 1)->first()->meta_description }}">
    <meta name="author" content="">
    <title>Soulfy Web- Template</title>
    <!-- Custom styles for this template -->
    <link href="{{url(".")}}/css/style.css" rel="stylesheet"/>
    <link href="{{url(".")}}/css/latest6d23.css" rel="stylesheet"/>
    <link href="{{url(".")}}/css/user-controls6d23.css" rel="stylesheet"/>
    <!--[if lt IE 9]>
    <link href="{{url(" .")}}/css/ie.css" rel="stylesheet"/>
    <script src="{{url(" .")}}/js/html5shiv.js" type="text/javascript"></script>
    <script src="{{url('.')}}/js/respond.js" type="text/javascript"></script>
    <![endif]-->
    <!--[if lt IE 10]>
    <link href="{{url(".")}}/css/ie.css" rel="stylesheet"/>
    <script src="{{url(".")}}/js/html5shiv.js" type="text/javascript"></script>
    <script src="{{url(".")}}/js/respond.js" type="text/javascript"></script>
    <![endif]-->
</head>
<body id="home">
<header>
    <div class="container" style="position: absolute; width: 100%;">
        <div class="row">
            <div class="nav-header">
                <ul class="nav-right">
                    <li>
                        <div class="form-group">
                            <span class="control-header">email</span>
                            <span><input type="text" class="form-control"/></span>
                        </div>
                    </li>
                    <li>
                        <div class="form-group">
                            <span class="control-header">password</span>
                            <span><input type="password" class="form-control"/></span>
                        </div>
                    </li>
                    <li>
                        <h3><a href="#">login</a></h3>
                    </li>
                    <li class="logo-box">
                        <a href="#"><img src="{{url(".")}}/images/logo.png"/></a>
                    </lI>
                </ul>
            </div>
        </div>
    </div>
</header>

<section id="content-desc">
    <div class="container">
        <div class="row">
            <h3>Amie Lee Johnson</h3>
            <div class="content-about">
                <p>
                    Before photography was created, people already knew the priciples of how it eventually got to work.<br/>
                    They could process the image on the wall or piece of paper, however no printing was possible at the time.
                </p>
                <p>
                    As preserving light turned out to be a lot harder task than projecting it. The instrument that people used for processing pictures was called the Camera Obscura (which is Latin for the Dark Room) and it was around for a few centuries before photography came along.
                </p>
            </div>
        </div>
    </div>
</section>

<section id="content">
    <div class="container">
        <div class="row">
            <div class="selector">
                <ul class="social-media-box">
                    <li>
                        <input id="c1" type="checkbox">
                        <label for="c1"><a href="#"><img src="{{url(".")}}/images/button-green_01.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c2" type="checkbox">
                        <label for="c2"><a href="#"><img src="{{url(".")}}/images/button-green_02.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c3" type="checkbox">
                        <label for="c3"><a href="#"><img src="{{url(".")}}/images/button-green_3.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c4" type="checkbox">
                        <label for="c4"><a href="#"><img src="{{url(".")}}/images/button-green_4.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c5" type="checkbox">
                        <label for="c5"><a href="#"><img src="{{url(".")}}/images/button-green_5.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c6" type="checkbox">
                        <label for="c6"><a href="#"><img src="{{url(".")}}/images/button-green_6.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c7" type="checkbox">
                        <label for="c7"><a href="#"><img src="{{url(".")}}/images/button-green_7.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c8" type="checkbox">
                        <label for="c8"><a href="#"><img src="{{url(".")}}/images/button-green_8.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c8" type="checkbox">
                        <label for="c8"><a href="#"><img src="{{url(".")}}/images/button-green_9.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c8" type="checkbox">
                        <label for="c8"><a href="#"><img src="{{url(".")}}/images/button-green_10.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c8" type="checkbox">
                        <label for="c8"><a href="#"><img src="{{url(".")}}/images/button-green_11.resized.png"/></a></label>
                    </li>
                </ul>
                <button><span><img src="{{url(".")}}/images/user1.png"/></span></button>
            </div>
        </div>
    </div>
    <div class="stats-box stats1">
        <div class="stats stats-fb">
            <p>
                Hello World!!<br/>
                Let the world know
            </p>
            <span class="left">Jakarta</span>
            <span class="right">2 Juni 2015</span>
            <div class="stats-nav">
                <a href="#" class="btn-circle btn1">C</a>
                <a href="#" class="btn-circle btn2">L</a>
            </div>
        </div>
    </div>
    <div class="stats-box stats2">
        <div class="stats stats-twitter">
            <p>
                Apa Kabar Dunia<br/>
                Hong Kong Hujan Nih
            </p>
            <span class="left">Jakarta</span>
            <span class="right">2 Juni 2015</span>
            <div class="stats-nav">
                <a href="#" class="btn-circle btn1">C</a>
                <a href="#" class="btn-circle btn2">L</a>
            </div>
        </div>
    </div>
</section>

<div id="tl-container">


    <div class="tl-timeline-info">
        <h2>safasdfasdf</h2>

        <p class="tl-ah-about-text">asf</p>

    </div>


    <div id="tl-stage-holder" class="tl-font">
        <!--<img src="/assets/ui/empty-image2.gif" alt="" id="tl-stage-image" />-->
        <div id="tl-stage-main-photo-credit"></div>
        <div id="tl-stage-scale-blackener"></div>
        <div class="tl-stage"></div>
        <div class="tl-stage-fixed-position-content"></div>
        <canvas id="tl-3d-view-canvas" width="100" height="100"></canvas>

        <div id="tl-stage-date-displayer"></div>
        <div class="tl-stage-border-top"></div>
        <div class="tl-stage-border-bottom"></div>


        <div id="tl-uc-controls">

            <div id="tl-uc-panel">
                <div class="tl-ucp-top-right">
                    <div class="tl-ucp-top-left">
                        <div class="tl-ucp-content">

                            <div class="fp-carousel">
                                <div class="fp-stage">
                                    <div id="tl-uc-search-block" class="fp-block fp-block-0">
                                        <h3 id="uc-text-search">Search</h3>

                                        <div class="ft-p1-input-holder">
                                            <input id="ft-fch-sp-input" type="text" value="Enter search term"/>
                                            <a id="ft-fch-sp-button" href="#">Go</a>
                                        </div>
                                        <div id="ft-p1-filter-text">
                                            <h5 id="uc-text-displaying">Displaying:</h5> <span
                                                    id="ft-fch-sp-everyone-message">All stories</span><span
                                                    id="ft-fch-sp-filter-message"><span id="ft-fch-sp-num-stories">X1 stories</span> <span
                                                        id="uc-text-matching">matching</span> '<strong
                                                        id="ft-fch-sp-filter"></strong>' (<a id="ft-fch-sp-clear"
                                                                                             href="#">clear</a>)</span>
                                        </div>
                                        <a href="#" class="close-panel">Close</a>
                                    </div>
                                    <div id="tl-uc-view-filter-block" class="fp-block fp-block-1 ajk-content-scroller">
                                        <h3 id="uc-text-category-filter">Category Filter</h3>

                                        <div class="ajk-cs-carousel">
                                            <div class="ajk-cs-carousel-stage">
                                                <ul class="tl-colour-checkbox-list"></ul>
                                            </div>
                                            <div class="ajk-cs-carousel-scroll-holder">
                                                <a href="#" class="ajk-cs-up-arrow"></a>
                                                <a href="#" class="ajk-cs-down-arrow"></a>

                                                <div class="ajk-cs-scroll-bar">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <a href="#" class="close-panel">Close</a>
                                    </div>
                                    <div id="tl-uc-view-type-block" class="fp-block fp-block-2">
                                        <h3 id="uc-text-view-type">View Type</h3>
                                        <ul class="tl-image-select-list">
                                            <li class="tl-isl-standard" view="0">
                                                <div class="image-holder"><span></span></div>
                                                <p>Standard</p>
                                            </li>
                                            <li class="tl-isl-category" view="1">
                                                <div class="image-holder"><span></span></div>
                                                <p>Category Bands</p>
                                            </li>
                                            <li class="tl-isl-coloured" view="2">
                                                <div class="image-holder"><span></span></div>
                                                <p>Coloured Stories</p>
                                            </li>
                                            <li class="tl-isl-duration" view="3">
                                                <div class="image-holder"><span></span></div>
                                                <p>Duration</p>
                                            </li>
                                        </ul>
                                        <a href="#" class="close-panel">Close</a>
                                    </div>
                                    <div id="tl-uc-spacing-block" class="fp-block fp-block-3">
                                        <h3 id="uc-text-story-spacing">Story Spacing</h3>

                                        <select>
                                            <option value="0">Standard</option>
                                            <option value="1">Equal Spacing 1</option>
                                            <option value="2">Equal Spacing 2</option>
                                            <option value="3">Top to Bottom - 3 rows</option>
                                            <option value="4">Top to Bottom - 4 rows</option>
                                            <option value="5">Top to Bottom - 5 rows</option>
                                            <option value="6">Top to Bottom - 6 rows</option>
                                            <option value="7">Top to Bottom - 7 rows</option>
                                            <option value="8">Top to Bottom - 8 rows</option>
                                            <option value="9">Top to Bottom - 9 rows</option>
                                            <option value="10">Top to Bottom - 10 rows</option>
                                        </select>
                                        <a href="#" class="close-panel">Close</a>
                                    </div>
                                    <div id="tl-uc-zoom-block" class="fp-block fp-block-4">
                                        <h3 id="uc-text-zoom">Zoom</h3>
                                        <select>
                                            <option></option>
                                        </select>

                                        <div class="zoom-buttons">
                                            <a href="#" class="zoom-in">+</a>
                                            <a href="#" class="zoom-out">-</a>
                                        </div>
                                        <a href="#" class="close-panel">Close</a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="tl-ucp-bottom-right">
                    <div class="tl-ucp-bottom-left"></div>
                </div>
            </div>

            <div class="menu-holder">
                <ul>
                    <li class="selected" fppos="0"><a href="#">Search</a></li>
                    <li fppos="1"><a href="#">Categories</a></li>
                    <li fppos="2"><a href="#">View Type</a></li>
                    <li fppos="3"><a href="#">Spacing</a></li>
                    <li fppos="4"><a href="#">Zoom</a></li>
                </ul>
            </div>
            <a href="#" class="launch">Launch</a>
        </div>




    </div>
    <div id="tl-slider-holder" class="tl-font">
        <div id="tl-slider-scale-holder">
            <div id="tl-slider-scale">
                <canvas class="tl-scale-canvas" width="5000" height="52"></canvas>
                <div id="tl-slider-scale-times-holder">
                </div>
                <div id="tl-slider-markers-holder">
                </div>
            </div>
        </div>
        <div id="tl-slider-dragger">
            <div class="tlsd-inner">
                <div class="tlsd-inner-inner">
                    <div class="tlsd-corner tlsd-c-tl"></div>
                    <div class="tlsd-corner tlsd-c-tr"></div>
                    <div class="tlsd-corner tlsd-c-bl"></div>
                    <div class="tlsd-corner tlsd-c-br"></div>
                </div>
            </div>
        </div>
        <div id="tl-slider-interaction-preventer"></div>
    </div>



    <div id="tl-cp-image-viewer">
        <div class="tl-cpiv-main-item"></div>
        <div class="tl-cpiv-caption-holder">
            <p></p>
        </div>
        <div class="tl-cpiv-content-mask">
            <div class="tl-cpiv-content-mask-inner"></div>
            <a href="#"></a>
        </div>
    </div>
</div>
<!-- JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script type="text/javascript" src="{{url(".")}}/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="{{url(".")}}/js/support6d23.js?version=7.135"></script>
<script type="text/javascript" src="{{url(".")}}/js/latest6d23.js?version=7.135"></script>
<script type="text/javascript">
    var nbOptions = 11; // number of menus
    var angleStart = -360; // start angle

    // jquery rotate animation
    function rotate(li,d) {
        $({d:angleStart}).animate({d:d}, {
            step: function(now) {
                $(li)
                        .css({ transform: 'rotate('+now+'deg)' })
                        .find('label')
                        .css({ transform: 'rotate('+(-now)+'deg)' });
            }, duration: 0
        });
    }

    // show / hide the options
    function toggleOptions(s) {
        $(s).toggleClass('open');
        var li = $(s).find('li');
        var deg = $(s).hasClass('half') ? 180/(li.length-1) : 360/li.length;
        for(var i=0; i<li.length; i++) {
            var d = $(s).hasClass('half') ? (i*deg)-90 : i*deg;
            $(s).hasClass('open') ? rotate(li[i],d) : rotate(li[i],angleStart);
        }
    }

    $('.selector button').click(function(e) {
        toggleOptions($(this).parent());
    });

    setTimeout(function() { toggleOptions('.selector'); }, 100);
</script>
<script id="timelinedata-script" type="text/javascript">
    var TLTimelineData = {
        host: "www.tiki-toki.com",
        homePage: false,
        showAdBlock: "false",
        id: 481827,
        title: "Test",
        urlFriendlyTitle: "Test",
        startDate: "2015-07-15 14:42:28",
        endDate: "2015-07-31 14:42:32",
        introText: "safasdfasdf",
        introImage: "",
        authorName: "daffi_gusti",
        "accountType": "Standard",
        backgroundImage: "",
        introImageCredit: "",
        backgroundImageCredit: "",
        feed: "",
        mainColour: "A879BE",
        zoom: "",
        initialFocus: "first",
        embedHash: "5687169190",
        embed: "true",
        secret: "false",
        public: "yes",
        dontDisplayIntroPanel: 0,
        openReadMoreLinks: 1,
        storyDateStatus: 0,
        storySpacing: 0,
        viewType: 0,
        showTitleBlock: 1,
        backgroundColour: "",
        storyDateFormat: "auto",
        topDateFormat: "auto",
        sliderDateFormat: "auto",
        language: "english",
        displayStripes: 1,
        htmlFormatting: 0,
        sliderBackgroundColour: "000000",
        sliderTextColour: "808080",
        sliderDetailsColour: "888888",
        sliderDraggerColour: "808080",
        headerBackgroundColour: "000000",
        headerTextColour: "808080",
        showGroupAuthorNames: "1",
        durHeadlineColour: "ffffff",
        cssFile: "",
        altFlickrImageUrl: "",
        fontBase: 'default',
        fontHead: 'default',
        fontBody: 'default',
        lightboxStyle: '0',
        showControls: '1',
        lazyLoading: '1',
        protection: "",
        expander: "2",
        copyable: "0",
        settings3d: "2,4D924D,0.23912,300,0.3116,0.2,2,3,0.25",

        bgStyle: 0,
        bgScale: 100,
        urlHashing: 1,
        categories: [],
        feeds: [],
        stories: [{
            id: 4972624,
            ownerId: "525275",
            ownerName: "",
            title: "New story 1",
            startDate: "2015-07-15 14:42:28",
            endDate: "2015-07-15 14:42:28",
            text: "Enter story info here",
            fullText: "none",
            category: "0",
            dateFormat: "auto",
            externalLink: "",
            media: []
        }, {
            id: 40,
            ownerId: "",
            ownerName: "",
            title: "Getting ready for launch",
            startDate: "2015-07-16 14:42:28",
            endDate: "2015-07-16 14:42:28",
            text: "We are beginning to get excited. Development work on TikiToki timeline software has finished. All but the most minor bugs have been sorted. All we need to do now is work up some marketing material and we'll be ready to launch. Wish us luck!",
            fullText: "none",
            category: "0",
            dateFormat: "auto",
            externalLink: "",
            media: []
        }, {
            id: 951,
            ownerId: "",
            ownerName: "",
            title: "Timeline of the Arab uprisings",
            startDate: "2015-07-16 14:44:28",
            endDate: "2015-07-16 14:46:28",
            text: "One of the things we hope our timeline software will be used for is to document events of great historic importance such as the revolutions taking place in the Arab world.",
            fullText: "",
            category: "74",
            dateFormat: "auto",
            externalLink: "",
            media: []
        }]
    }
</script>
</body>
</html>
