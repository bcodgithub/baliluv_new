<?php

/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 9/6/2015
 * Time: 9:38 PM
 */
$uri = Request::path();
$domain = $_SERVER['SERVER_NAME'];
$user = \Soulfy\User::where('domain', $domain)->first();
$setting = \Soulfy\Setting::where('user_id', $user->id)->first();
?>

@extends('home')

@section('title', 'Home')

@section('css')

<style>
    #editWashop {float: right;padding: 0px 4px 0px 0px;}
    .box .checkbox 
    {
        text-align: left;
        position: absolute;
        margin-left: -20px;
    }
</style>

@endsection

@section('content')

@if(Auth::check())

    <section id="content-desc">
        <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>
        <div class="backend-box backend-box-email">
            <div class="backend-nav">
                <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs" role="tablist">
                    <li id="t1" class="active tab tab1"><a id="tab_setting" href="#setting" aria-controls="setting" role="tab" data-toggle="tab">Profile</a></li>
                    <li id="t2" class="tab tab2" ><a id="tab_account" href="#account" aria-controls="setting" role="tab" data-toggle="tab">Account</a></li>
                    <li id="t3" class="tab tab3"><a id="tab_themes" href="#themes" aria-controls="setting" role="tab" data-toggle="tab">Themes</a></li>
                </ul>
            </div>
            <div class="tab-content backend-detail slimScroll" style="clear:both;">
                <div role="tabpanel" class="tab-pane active tab1" id="setting" style="height: 100%">
                     {{--@include("soulfy/partial/setting")--}}
                </div>
                <div role="tabpanel" class="tab-pane tab2" id="account" style="height: 100%">
                    <div class="form-top">
                        <label>Favicon Setup<div id="spiner"></div></label>
                    </div>
                    <div class="form-body" id="mail-section">
                        <div class="setting-box" >
                            <form id="favicon_form">
                                <div class="row">
                                    <label for="favicon" class="col-sm-2 col-form-label mt6">Icon</label>
                                    <div class="col-sm-10">
                                        <input type="file" id="favicon" name="favicon" accept="image/*"/>
                                        <img src="
                                            @if($setting['favicon'] != '')
                                                {{url('')}}/uploads/{{$setting['favicon']}}
                                            @else 
                                                {{url('')}}/images/favicon.ico 
                                            @endif" 
                                        width="20px" />
                                        <br>
                                        <small>Only upload .ico or .png file with 16 x 16 px</small>
                                    </div>
                                    <div class="col-xs-12">
                                        <button type="submit" id="favicon_form_save" class="btn btn-primary">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div class="form-top">
                        <label>Contact-us Email Setup<div id="spiner"></div></label>
                    </div>
                    <div class="form-body" id="mail-section">
                        <div class="setting-box" >
                            <form class=""  id="create_mail" style="display: none;">
                                <div class="row">
                                    <div class="col-xs-6">
                                        <input type="email" class="form-control" id="cemail" value="{{$user['contact_email']}}" placeholder="jane.doe@example.com">
                                        <ul id="mail-error" ></ul>
                                    </div>
                                    <div class="col-xs-6">
                                        <button type="submit" class="btn btn-success" id="btn-create-mail">Save</button>
                                        <button class="btn btn-danger" id="btn-edit-mail">Cancel</button>
                                    </div>
                                </div>
                            </form>
                            <div class="row" id="mailText">
                                <div class="col-xs-10">
                                    <span class="setting-name" id="mail-text">{{$user['contact_email']}}</span>
                                </div>
                                <div class="col-xs-2">
                                     <a href="#" id="editMail"><img src="{{asset('/images/nav-edit.png')}}"></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--<div role="tabpanel" class="tab-pane" id="account" style="height: 100%">-->

                    <div class="form-top">
                        <label>social media</label>
                    </div>
                    <div class="form-body">
                        <div class="setting-box">
                            <ul>
                                <!--
                                <li>
                                    <span class="setting-name">FACEBOOK</span>
                                    <span class="setting-value center">
                                        @if($setting['fb_enable'])
                                            <i class="setting-active">active</i>
                                        @else
                                            <i class="setting-off">off</i>
                                        @endif
                                    </span>
                                    <span class="setting-nav"><a href="#" onclick="javascript:onEditSocial(this,'fb');"></a></span>
                                </li>

                                <li>
                                    <span class="setting-name">TWITTER</span>
                                    <span class="setting-value center">
                                         @if($setting['twitter_enable'])
                                            <i class="setting-active">active</i>
                                        @else
                                            <i class="setting-off">off</i>
                                        @endif
                                    </span>
                                    <span class="setting-nav"><a href="#" onclick="javascript:onEditSocial(this,'twitter');"></a></span>
                                </li>

                                <li>
                                    <span class="setting-name">GOOGLE+</span>
                                    <span class="setting-value center">
                                          @if($setting['google_enable'])
                                            <i class="setting-active">active</i>
                                        @else
                                            <i class="setting-off">off</i>
                                        @endif
                                    </span>
                                    <span class="setting-nav"><a href="#" onclick="javascript:onEditSocial(this,'google');"></a></span>
                                </li>-->

                                <li>
                                    <span class="setting-name">YOUTUBE</span>
                                    <span class="setting-value center">
                                          @if($setting['youtube_enable'])
                                            <i class="setting-active">active</i>
                                        @else
                                            <i class="setting-off">off</i>
                                        @endif
                                    </span>
                                    <span class="setting-nav"><a href="#" onclick="javascript:onEditSocial(this,'youtube');"></a></span>
                                </li>
                                <li>
                                    <span class="setting-name">RSS FEED</span>
                                    <span class="setting-value center">
                                          @if($setting['rssfeed_enable'])
                                            <i class="setting-active">active</i>
                                        @else
                                            <i class="setting-off">off</i>
                                        @endif
                                    </span>
                                    <span class="setting-nav"><a href="#" onclick="javascript:onEditSocial(this,'rssfeed');"></a></span>
                                </li>

                                <li>
                                    <span class="setting-name">INSTAGRAM</span>
                                    <span class="setting-value center">
                                        @if($setting['instagram_enable'])
                                            <i class="setting-active">active</i>
                                        @else
                                            <i class="setting-off">off</i>
                                        @endif
                                    </span>
                                    <span class="setting-nav"><a href="#" onclick="javascript:onEditSocial(this,'instagram');"></a></span>
                                </li> 

                                <li>
                                    <span class="setting-name">MENU LIST</span>
                                    <span class="setting-value center">
                                        @if($setting['menu_list'])
                                            <i class="setting-active">active</i>
                                        @else
                                            <i class="setting-off">off</i>
                                        @endif
                                    </span>
                                    <span class="setting-nav"><a href="#" onclick="javascript:onEditSocial(this,'menulist');"></a></span>
                                </li> 

                                {{--<li>--}}
                                    {{--<span class="setting-name">FLICKR</span>--}}
                                    {{--<span class="setting-value center">--}}
                                          {{--@if($setting['flickr_enable'])--}}
                                            {{--<i class="setting-active">active</i>--}}
                                        {{--@else--}}
                                            {{--<i class="setting-off">off</i>--}}
                                        {{--@endif--}}
                                    {{--</span>--}}
                                    {{--<span class="setting-nav"><a href="#" onclick="javascript:onEditSocial(this,'flickr');"></a></span>--}}
                                {{--</li>--}}

                                {{--<li>--}}
                                    {{--<span class="setting-name">PATH</span>--}}
                                    {{--<span class="setting-value center">--}}
                                          {{--@if($setting['path_enable'])--}}
                                            {{--<i class="setting-active">active</i>--}}
                                        {{--@else--}}
                                            {{--<i class="setting-off">off</i>--}}
                                        {{--@endif--}}
                                    {{--</span>--}}
                                    {{--<span class="setting-nav"><a href="#" onclick="javascript:onEditSocial(this,'path');"></a></span>--}}
                                {{--</li>--}}
                            </ul>
                        </div>
                    </div>

                    <div class="form-top">
                        <label>WhatsApp Shop</label>
                    </div>
                    <div class="form-body">
                        <div class="setting-box">
                            <div id="create_washop" style="display: none;">
                                <div class="row">
                                    <ul id="washop-error" ></ul>
                                    <div class="col-xs-7">
                                        <input type="number" class="form-control" id="wa_number" value="{{$setting['wa_number']}}" placeholder="919876543210">
                                        <span>Country Code and WhatsApp Number Like : 919876543210</span>
                                        <!-- <ul id="washop-error" ></ul> -->                                    
                                    </div>
                                    <div class="col-xs-5">
                                        <input type="text" class="form-control" id="wa_username" value="{{$setting['wa_username']}}" placeholder="username">
                                        <span>Unique Username</span>
                                        <!-- <ul id="username-error" ></ul> -->  
                                    </div>
                                </div>
                                <div class="row text-center" >
                                    <div class="col-xs-12">
                                        <button type="submit" class="btn btn-success" id="create-washop-number">Save</button>
                                        <button class="btn btn-danger" id="btn-edit-washop">Cancel</button>
                                    </div>
                                </div>
                            </div><br>
                            <div class="row" id="washopText">
                                <div class="col-xs-5">
                                    <span class="setting-name">WhatsApp Username</span>
                                </div>
                                <div class="col-xs-5">   
                                    <span class="setting-name" id="username-text">
                                        @if($setting['wa_username'] == '')
                                        Enter Username
                                        @else
                                        <b>{{$setting['wa_username']}}</b>
                                        @endif
                                    </span>
                                </div>
                                <div class="col-xs-5">
                                    <span class="setting-name">WhatsApp Number</span>
                                </div>
                                <div class="col-xs-5">   
                                    <span class="setting-name" id="washop-text">
                                        @if($setting['wa_number'] == '')
                                        Enter WhatsApp Number
                                        @else
                                       <b>{{$setting['wa_number']}}</b>
                                        @endif
                                    </span>
                                </div>
                                <div class="col-xs-2">
                                    <a href="#" id="editWashop" sty><img src="{{asset('/images/nav-edit.png')}}"></a>
                                </div>
                            </div>
                            @if($setting->wa_number != '')
                            <ul>
                                <li>
                                    <span class="setting-name">WASHOP</span>
                                    <span class="setting-value center">
                                        @if($setting['washop_enable'])
                                            <i class="setting-active">active</i>
                                        @else
                                            <i class="setting-off">off</i>
                                        @endif
                                    </span>
                                    <span class="setting-nav"><a href="#" onclick="javascript:onEditSocial(this,'washop');"></a></span>
                                </li>
                            </ul>
                            @endif
                        </div>
                    </div>

                    <div class="form-top">
                        <label>custom menus</label>
                    </div>
                    <div class="form-body">
                        <div class="setting-box">
                            <form id="custom_menu_form" method="post" style="display: block;">
                                <h4>Facebook</h4>
                                <div class="form-group row">
                                    <label for="custom_facebook_link" class="col-sm-2 col-form-label mt6">Link</label>
                                    <div class="col-sm-10">
                                      <input type="url" class="form-control" id="custom_facebook_link" name="custom_facebook_link" value="{{$setting['custom_facebook_link']}}" placeholder="e.g: http://www.facebook.com/soulfy">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="custom_facebook_enable" class="col-sm-2 col-form-label mt6">Status</label>
                                    <div class="col-sm-10">
                                      <input type="checkbox" id="custom_facebook_enable" name="custom_facebook_enable" value="enable" @if($setting['custom_facebook_enable']) checked @endif class="mt6">
                                    </div>
                                </div>

                                <hr/>
                                <h4>Twitter</h4>
                                <div class="form-group row">
                                    <label for="custom_twitter_link" class="col-sm-2 col-form-label mt6">Link</label>
                                    <div class="col-sm-10">
                                      <input type="url" class="form-control" id="custom_twitter_link" name="custom_twitter_link" value="{{$setting['custom_twitter_link']}}" placeholder="e.g: http://www.twitter.com/soulfy">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="custom_twitter_enable" class="col-sm-2 col-form-label mt6">Status</label>
                                    <div class="col-sm-10">
                                      <input type="checkbox" id="custom_twitter_enable" name="custom_twitter_enable" value="enable" @if($setting['custom_twitter_enable']) checked @endif class="mt6">
                                    </div>
                                </div>
                                <hr/>

                                <h4>Linkedin</h4>
                                <div class="form-group row">
                                    <label for="custom_linkedin_link" class="col-sm-2 col-form-label mt6">Link</label>
                                    <div class="col-sm-10">
                                        <input type="url" class="form-control" id="custom_linkedin_link" name="custom_linkedin_link" value="{{$setting['custom_linkedin_link']}}" placeholder="e.g: http://www.linkedin.com">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="custom_linkedin_enable" class="col-sm-2 col-form-label mt6">Status</label>
                                    <div class="col-sm-10">
                                        <input type="checkbox" id="custom_linkedin_enable" name="custom_linkedin_enable" value="enable" @if($setting['custom_linkedin_enable']) checked @endif class="mt6">
                                    </div>
                                </div>
                                <br>
                                <hr/>
                                <h4>Menu 1</h4>
                                <div class="form-group row">
                                    <label for="custom_menu1_name" class="col-sm-2 col-form-label mt6">Menu Name</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="custom_menu1_name" id="custom_menu1_name" placeholder="Name" value="{{$setting['custom_menu1_name']}}">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="custom_menu1_link" class="col-sm-2 col-form-label mt6">Link</label>
                                    <div class="col-sm-10">
                                        <input type="url" class="form-control" id="custom_menu1_link" name="custom_menu1_link" value="{{$setting['custom_menu1_link']}}" placeholder="e.g: http://www.website.com">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="custom_menu1_logo" class="col-sm-2 col-form-label mt6">Icon</label>
                                    <div class="col-sm-10">
                                        <input type="file" id="custom_menu1_logo" name="custom_menu1_logo"/>
                                        <img src="
                                            @if($setting['custom_menu1_logo'] != '')
                                                @if($setting['custom_menu1_logo'] == 'line.png') {{url('')}}/images/line.png @elseif($setting->custom_menu1_logo == 'fbmsg.png') {{url('')}}/images/fbmsg.png @elseif($setting->custom_menu1_logo == 'telegram.png') {{url('')}}/images/telegram.png @elseif($setting->custom_menu1_logo == 'wechat.png') {{url('')}}/images/wechat.png @elseif($setting->custom_menu1_logo == 'whatsapp.png') {{url('')}}/images/whatsapp.png @else {{url('')}}/uploads/{{$setting['custom_menu1_logo']}} @endif
                                            @else 
                                                {{url('')}}/images/add/default_icon.png 
                                            @endif" 
                                        width="40px" />
                                    </div>
                                    <div class="col-sm-10">
                                        <?php $menucechk1= $setting['custom_menu1_logo']; ?>
                                        <input type="radio" name="menu1" value="line.png" <?php echo ($menucechk1== 'line.png') ?  "checked" : "" ;  ?> /> <img src='{{url("")}}/images/line.png'/>
                                        <input type="radio" name="menu1" value="fbmsg.png" <?php echo ($menucechk1== 'fbmsg.png') ?  "checked" : "" ;  ?> / ><img src='{{url("")}}/images/fbmsg.png'/>
                                        <input type="radio" name="menu1" value="telegram.png" <?php echo ($menucechk1== 'telegram.png') ?  "checked" : "" ;  ?> / ><img src='{{url("")}}/images/telegram.png'>
                                        <input type="radio" name="menu1" value="wechat.png" <?php echo ($menucechk1== 'wechat.png') ?  "checked" : "" ;  ?> / ><img src='{{url("")}}/images/wechat.png'>
                                        <input type="radio" name="menu1" value="whatsapp.png" <?php echo ($menucechk1== 'whatsapp.png') ?  "checked" : "" ;  ?> / ><img src='{{url("")}}/images/whatsapp.png'>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="custom_menu1_enable" class="col-sm-2 col-form-label mt6">Status</label>
                                    <div class="col-sm-10">
                                        <input type="checkbox" id="custom_menu1_enable" name="custom_menu1_enable" value="enable" @if($setting['custom_menu1_enable']) checked @endif class="mt6">
                                    </div>
                                </div>
                                <hr/>

                                <h4>Menu 2</h4>
                                <div class="form-group row">
                                    <label for="custom_menu2_name" class="col-sm-2 col-form-label mt6">Menu Name</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="custom_menu2_name" id="custom_menu2_name" value="{{$setting['custom_menu2_name']}}" placeholder="Name">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="custom_menu2_link" class="col-sm-2 col-form-label mt6">Link</label>
                                    <div class="col-sm-10">
                                        <input type="url" class="form-control" id="custom_menu2_link" name="custom_menu2_link" value="{{$setting['custom_menu2_link']}}" placeholder="e.g: http://www.website.com">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="custom_menu2_logo" class="col-sm-2 col-form-label mt6">Icon</label>
                                    <div class="col-sm-10">
                                        <input type="file" id="custom_menu2_logo" name="custom_menu2_logo"/>
                                        <img src="
                                            @if($setting['custom_menu2_logo'] != '')
                                                @if($setting['custom_menu2_logo'] == 'line.png') {{url('')}}/images/line.png @elseif($setting->custom_menu2_logo == 'fbmsg.png') {{url('')}}/images/fbmsg.png @elseif($setting->custom_menu2_logo == 'telegram.png') {{url('')}}/images/telegram.png @elseif($setting->custom_menu2_logo == 'wechat.png') {{url('')}}/images/wechat.png @elseif($setting->custom_menu2_logo == 'whatsapp.png') {{url('')}}/images/whatsapp.png @else {{url('')}}/uploads/{{$setting['custom_menu2_logo']}} @endif
                                            @else 
                                                {{url('')}}/images/add/default_icon.png 
                                            @endif" 
                                        width="40px" />
                                    </div>
                                    <div class="col-sm-10">
                                        <?php $menucechk2= $setting['custom_menu2_logo']; ?> 
                                        <input type="radio" name="menu2" value="line.png" <?php echo ($menucechk2== 'line.png') ?  "checked" : "" ;  ?> /> <img src='{{url("")}}/images/line.png'/>
                                        <input type="radio" name="menu2" value="fbmsg.png" <?php echo ($menucechk2== 'fbmsg.png') ?  "checked" : "" ;  ?> /><img src='{{url("")}}/images/fbmsg.png'/>
                                        <input type="radio" name="menu2" value="telegram.png" <?php echo ($menucechk2== 'telegram.png') ?  "checked" : "" ;  ?>/><img src='{{url("")}}/images/telegram.png'>
                                        <input type="radio" name="menu2" value="wechat.png" <?php echo ($menucechk2== 'wechat.png') ?  "checked" : "" ;  ?>/><img src='{{url("")}}/images/wechat.png'>
                                        <input type="radio" name="menu2" value="whatsapp.png" <?php echo ($menucechk2== 'whatsapp.png') ?  "checked" : "" ;  ?>/ ><img src='{{url("")}}/images/whatsapp.png'>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="custom_menu2_enable" class="col-sm-2 col-form-label mt6">Status</label>
                                    <div class="col-sm-10">
                                        <input type="checkbox" id="custom_menu2_enable" name="custom_menu2_enable" value="enable" @if($setting['custom_menu2_enable']) checked @endif class="mt6">
                                    </div>
                                </div>
                                <hr/>

                                <h4>Menu 3</h4>
                                <div class="form-group row">
                                    <label for="custom_menu3_name" class="col-sm-2 col-form-label mt6">Menu Name</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="custom_menu3_name" id="custom_menu3_name" value="{{$setting['custom_menu3_name']}}" placeholder="Name">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="custom_menu3_link" class="col-sm-2 col-form-label mt6">Link</label>
                                    <div class="col-sm-10">
                                        <input type="url" class="form-control" id="custom_menu3_link" name="custom_menu3_link" value="{{$setting['custom_menu3_link']}}" placeholder="e.g: http://www.website.com">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="custom_menu3_logo" class="col-sm-2 col-form-label mt6">Icon</label>
                                    <div class="col-sm-10">
                                        <input type="file" id="custom_menu3_logo" name="custom_menu3_logo"/>
                                        <img src="
                                            @if($setting['custom_menu3_logo'] != '')
                                                @if($setting['custom_menu3_logo'] == 'line.png') {{url('')}}/images/line.png @elseif($setting->custom_menu3_logo == 'fbmsg.png') {{url('')}}/images/fbmsg.png @elseif($setting->custom_menu3_logo == 'telegram.png') {{url('')}}/images/telegram.png @elseif($setting->custom_menu3_logo == 'wechat.png') {{url('')}}/images/wechat.png @elseif($setting->custom_menu3_logo == 'whatsapp.png') {{url('')}}/images/whatsapp.png @else {{url('')}}/uploads/{{$setting['custom_menu3_logo']}} @endif
                                            @else
                                                {{url('')}}/images/add/default_icon.png
                                            @endif" 
                                        width="40px" />
                                    </div>
                                    <div class="col-sm-10">
                                        <?php $menucechk3= $setting['custom_menu3_logo']; ?> 
                                        <input type="radio" name="menu3" value="line.png" <?php echo ($menucechk3== 'line.png') ?  "checked" : "" ;  ?> /> <img src='{{url("")}}/images/line.png'/>
                                        <input type="radio" name="menu3" value="fbmsg.png" <?php echo ($menucechk3== 'fbmsg.png') ?  "checked" : "" ;  ?> /> <img src='{{url("")}}/images/fbmsg.png'/>
                                        <input type="radio" name="menu3" value="telegram.png" <?php echo ($menucechk3== 'telegram.png') ?  "checked" : "" ;  ?> /> <img src='{{url("")}}/images/telegram.png'>
                                        <input type="radio" name="menu3" value="wechat.png" <?php echo ($menucechk3== 'wechat.png') ?  "checked" : "" ;  ?> /> <img src='{{url("")}}/images/wechat.png'>
                                        <input type="radio" name="menu3" value="whatsapp.png" <?php echo ($menucechk3== 'whatsapp.png') ?  "checked" : "" ;  ?> /> <img src='{{url("")}}/images/whatsapp.png'>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="custom_menu3_enable" class="col-sm-2 col-form-label mt6">Status</label>
                                    <div class="col-sm-10">
                                        <input type="checkbox" id="custom_menu3_enable" name="custom_menu3_enable" value="enable" @if($setting['custom_menu3_enable']) checked @endif class="mt6">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-xs-12">
                                        <button type="submit" id="custom_menu_form_save" class="btn btn-primary">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!--
                    <div class="form-top">
                        <label>E-Commerce Setting</label>
                    </div>
                    <div class="form-body">
                        <div class="setting-box">
                            <ul>
                                <li>
                                    <span class="setting-name" style="width: 84px;">E-Commerce</span>
                                    <span class="setting-value center">
                                        @if($setting['ecommerce_status'] == 'ACTIVE')
                                            <i class="setting-active">Active</i>
                                        @elseif($setting['ecommerce_status'] == 'IN_PROGRESS')
                                            <i class="setting-active">In Progress</i>
                                        @else
                                            <a onclick="set_ecommerce(this,'PROCESS')" href="#">
                                                <button class="setting-off" style="width:161px;  font-family: 'opensans-bold', sans-serif; background:#fff; height:25px; border-radius:5px;">OFF</button>
                                            </a>
                                        @endif
                                        </span>
                                    <span class="setting-nav"></span>
                                </li>
                            </ul>
                        </div>
                    </div>-->
                    <div class="form-top">
                        <label>Newsletter</label>
                    </div>
                    <div class="form-body">
                        <div class="setting-box">
                            <!-- <div class="backend-nav">
                                <label>
                                    <span><img src="{{url()}}/images/start-button-sm.png"/></span>
                                    <small>Create an email address on your own domain</small>
                                </label>
                            </div> -->
                            <div class="backend-detail" style="overflow-y: hidden;">
                                 <form method="post" class="form-create" action="{{ action('SettingController@postNewsletter') }}"> 
                                    <!--<ul id="error"></ul>-->
                                    <div class="form-group">
                                        <label>Subscribe Newsletter</label>
                                        <div class="col-group">
                                            <span class="col4"><input type="text" required name="account" placeholder="Email Address"/></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="" style="float: left">
                                            <button type="submit" id="btn_submit" class="btn btn-green">Submit</button>
                                        </div>
                                        <div style="text-align: right;clear: both;margin-top: 20px;"><!--
                                            <input required type="checkbox" style="clear: both;width: 20px;height: 20px;float: left;margin: 0;margin-top: 5px;"/> <span style="margin-top: 5px;float: left;">I Agree to the soulfy <a href="#">terms</a> & <a

                                                        href="#">services</a></span>-->
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

		    <!--
                    <div class="form-top">
                        <label>Create Email</label>
                    </div>
                    <div class="form-body">
                        <div class="setting-box">
                            <div class="backend-nav">
                                <label>
                                    <span><img src="{{url()}}/images/start-button-sm.png"/></span>
                                    <small>Create an email address on your own domain</small>
                                </label>
                            </div>
                            <div class="backend-detail" style="overflow-y: hidden;">
                                <form role="form" class="form-create" method="post" action="{{action("ApiController@postCreateEmail")}}">
                                    <ul id="error" ></ul>
                                    <div class="form-group">
                                        <label>Name</label>
                                        <div class="col-group" id="first1">
                                            <span class="col1"><input type="text" required name="first" placeholder="First"/></span>
                                            <span class="col2">&nbsp;</span>
                                            <span class="col1"><input type="text" required name="last" placeholder="Last"/></span>
                                        </div>
                                    </div>
                                    <div class="form-group" id="account1">
                                        <label>Email Account Name</label>
                                        <div class="col-group">
                                            <span class="col1"><input type="text" name="account" required placeholder="ex:amielee23"/></span>
                                            <span class="col2"><big>@</big></span>
                                            <span class="col1"><label style="margin-top: 6px;">{{$user['domain']}}</label></span>
                                        </div>
                                    </div>
                                    <div class="form-group danger" id="password1">
                                        <label>Create Password</label>
                                        <div class="col-group">
                                            <span class="col4"><input type="password" id="password" required name="password"/></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Confirm Password</label>
                                        <div class="col-group">
                                            <span class="col4"><input type="password" id="confirm_password" required name="password_confirmation"/></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="" style="float: left">
                                            <button type="submit" id="btn_submit" class="btn btn-green">Create Email</button>
                                        </div>
                                        <div style="text-align: right;clear: both;margin-top: 20px;">
                                            <input required type="checkbox" style="clear: both;width: 20px;height: 20px;float: left;margin: 0;margin-top: 5px;"/> <span style="margin-top: 5px;float: left;">I Agree to the soulfy <a href="#">terms</a> & <a href="#">services</a></span>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="form-btn">
                        <button class="btn" id="btn_create_email" type="button">
                            <img src="{{url('')}}/images/start-button.png"/>
                            <p>
                                LET'S SEND SOME MESSAGE
                            </p>
                            <h4>START</h4>
                        </button>
                    </div>
                    <div class="form-btn">
                        <button class="btn" id="btn_manage_emails" type="button">
                            <img src="{{url('')}}/images/manage-button.png"/>
                            <p>
                                Manage Your Email Accounts
                            </p>
                            <h3>Delete Account / Change Password</h3>
                        </button>
                    </div>-->
                </div>
                         <!-- tambahan arifin -->

                <div role="tabpanel" class="tab-pane tab3" id="themes" style="height: 100%"> 
                    <div class="form-top">
                        <label>change theme</label>
                    </div>
                    <div class="form-body">
                        <div class="setting-box">
                            <ul> 
                                <li><!-- $user_id = $user->id; -->
                                    <form action="{{ action('SettingController@postMenu')}}" method="post">
                                    <span class="setting-name">MENU COLOR</span>
                                    <!-- <form method="POST" action="/posts"> -->
                                    {{ csrf_field() }}  
                                    <span class="setting-value center">
                                    <select name="menu">
                                        <option value="">None</option>
                                        <option value="1">White(classic)</option>
                                        <option value="2">Black(classic)</option>
                                        <option value="ff0000">Red</option>
                                        <option value="39b54a">Green</option>
                                        <option value="faaf2c">Orange</option>
                                        <option value="0000ff">Blue</option>
                                        <option value="000000">Black</option>
                                        <option value="5e5f5f">Grey</option>
                                        <option value="000080">Navy</option>
                                        <option value="800000">Maroon</option>
                                        <option value="800080">Purple</option>
                                        <option value="824221">Brown</option>
                                    </select>
                                    <!--<div style="width: 150px; height: 30px;"><input type="image" src="http://localhost/framework_freshway/public_html/images/submit.png" value="SUBMIT" width="10">-->
                                    <input type="submit" value="Submit"> 
                                    </span>                                         
                                    <br><br><br>    
                                    </form>                                
                                </li>       
                                <li><!-- $user_id = $user->id; -->
                                    <!-- <style>
                                    .box .checkbox 
                                    {
                                        text-align: left;
                                        position: absolute;
                                        margin-left: -20px;
                                    }
                                    </style> -->

                                    <!-- <form action="{{URL::to('/home/theme')}}" method="post"> --> 
                                    <form action="{{ action('SettingController@getBackgroundTheme') }}" method="get">
                                        <span class="setting-name">THEME</span>
                                        <!-- <form method="POST" action="/posts"> -->
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}"> 
                                        <!-- {{ csrf_field() }} --> 
                                        <span class="setting-value center">
                                            <select name="menu">
                                                <option value="">All</option>
                                                <option value="Handicraft">Handicraft</option>
                                                <option value="Farming">Farming</option>
                                                <option value="Services">Services</option>
                                                <option value="Tour & Travel">Tour & Travel</option>
                                                <option value="Trading">Trading</option>
                                                <option value="Fishery">Fishery</option>            
                                                <option value="Lifestyle">Lifestyle</option>
                                                <option value="Music">Music</option>
                                                <option value="Property">Property</option>
                                                <option value="Hobby">Hobby</option>
                                                <option value="Politic">Politic</option>
                                                <option value="Ranch">Ranch</option>
                                                <option value="Culinary">Culinary</option>
                                            </select>
                                            <input type="submit" value="Submit">   
                                            <br><br>
                                        </span>
                                    </form>

                                    <form action="{{ action('SettingController@SendPicture') }}" method= "post" >

                                        {{ csrf_field() }}

                                        <table width="100">
                                            @foreach ($themes->chunk(3) as $chunk)
                                                <tr>
                                                @foreach ($chunk as $theme)
                                                    <td>
                                                        <a href="https://soulfy.com/stokfoto/{{$theme->pic_name}}.jpg" data-lightbox="image-gallery" data-title="{{$theme->pic_name}}" >
                                                            <img width="100px" height="100px"  src="https://soulfy.com/stokfoto/{{$theme->pic_name}}.jpg"/>
                                                        </a>
                                                        <center> 
                                                            <input type="checkbox" style="width: 15px" name="pic[{{$theme->pic_name}}]" value="{{$theme->pic_name}}"/>
                                                        </center>
                                                    </td> 
                                                @endforeach
                                                </tr>
                                            @endforeach
                                        </table>
                                        @if ( $themes->lastPage() == 0) <br><br><br><br> @endif 
                                        @if ( $themes->currentPage() != 1)

                                        <a href="{!! $themes->previousPageUrl() !!}"> << </a>@endif

                                        {!! $themes->currentPage() !!} of {!! $themes->lastPage() !!}

                                         @if ( $themes->currentPage() !=  $themes->lastPage())

                                        <a href="{!! $themes->nextPageUrl() !!}"> >> </a>@endif

                                        <br><br>

                                        <input style="width: 15px; margin-bottom: -10px; position: relative;" type="checkbox" required name="chkbox_agreement" value="Terms & Agreement"/>&nbsp;&nbsp;&nbsp;
                                        <a href="#myModal" data-backdrop="false" data-toggle="modal">Terms & Agreement</a>
                                        <div id="myModal" class="modal fade">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5>Terms & Agreement</h5>
                                                    </div>
                                                    <div class="modal-body">
                                                        By clicking Purchase you agree to the Term and Conditions.
                                                    </div>
                                                    <div class="modal-footer">
                                                         <button type="button" class="btn btn-default" data-dismiss="modal">Agree</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><br><br><br>
                                        <input type="submit" value="Purchase" id="notification">    
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- end arifin -->

                <!-- PLACEHOLDER SECTION -->
                <div class="placeholder _grey" id="backend-placeholder">
                    <div class="placeholder-first backend-first" style="display:none;">
                        <div class="placeholder-header">
                            <h3 ></h3>
                            <a class="btn-cancels"><span class="glyphicon glyphicon-remove"></span></a>
                        </div>
                        <div class="content-placeholder">
                            <p></p>
                        </div>
                        @if(Auth::check())
                        <div class="skype-box">
                            <div class="image-skype logged">
                                <img src="{{url()}}/images/skype-logo.png" alt="">
                            </div>
                            <div class="skype-id">
                                Skype ID : <p class="skype-info">{{$setting['skype_id']}}</p>
                                <div class="skype-act">
                                    <input type="text"   class="form-control skype_form" value="{{$setting['skype_id']}}" required>
                                    <a class="btn-skype-edit"><i class="fa fa-pencil-square-o"></i></a>
                                    <a class="btn-skype-save"><i class="fa fa-floppy-o"></i></a>
                                    <a class="btn-skype-cancel"><i class="fa fa-times"></i></a>
                                </div>
                            </div>
                        </div>
                        @else
                        <div class="skype-box">
                            <div class="image-skype">
                                <img src="{{url('')}}/images/skype-logo.png" alt="">
                            </div>
                            <div class="skype-id">
                                Skype ID : {{$setting['skype_id']}}
                            </div>
                        </div>
                        @endif
                        <p class="date-article"><i class='fa fa-user'></i> Published by {{$user['full_name']}}<i class='user'></i> | <i class='fa fa-calendar'></i></p>
                        <div style="clear:both;"></div>
                        <div class="placeholder-footer action">
                            <a class="first btn-act-like" onclick="likeTimeLine(this)">
                                <span class="glyphicon glyphicon-thumps-up"></span>
                            </a>
                            <a  class="second"></a>
                            @if(Auth::check())
                            <a class="third btn-act-delete" onclick="deleteTimeLine(this)"><span class="glyphicon glyphicon-trash"></span> </a>
                            @endif
                            <div class="fb-comment form-group"></div>
                            <div style="clear:both;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endif

@endsection

@section('js')

<script>
    $("#myModal").draggable({
        handle: ".modal-header"
    }); 
</script>

@if(Session::has('tab'))

    <script>
        $(document).ready(function()
        {
            //$(".tab").removeClass("active");
            //$(".tabpanel").removeClass("active");
            $('.nav-tabs a[href="#themes"]').tab('show');           
        });     
    </script>

@endif

<!--
@if(Session::has('tab2'))
    <script>
        $(document).ready(function()
        {
            //$(".tab").removeClass("active");
            //$(".tabpanel").removeClass("active");
            $('.nav-tabs a[href="#setting"]').tab('show')
        });     
    </script>
@endif
-->

<script>

    $("#notification").click(function(e){
        var check= $(this).val();    
        var pic = [];
        $("input[name^='pic']").each(function()
        {
            if($(this).is(':checked'))
            {
                //alert($(this).val());
                pic.push($(this).val());
            }
        });
        $.ajax({
            method: "POST",
            url: '{{action("SettingController@SendPicture")}}',
            data : {
                check:check,
                pic:pic
            },

            success: function (response) {
                pesanOk("Thank you. We will process your request. Please check your email.");
                //setTimeout(function(){location.reload()},1000);
            },  
            error:function()
            {
                pesanErr("failed");
            }
        });
        return false;
    });
</script>

<script>
    // Get the modal
    var modal = document.getElementById('myModal');
    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal 
    if(btn != null){
        btn.onclick = function() {
            modal.style.display = "block";
        }
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>

<link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>
<script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/js/bootstrap-editable.min.js"></script>

<script type="text/javascript">
    $.fn.editable.defaults.mode = 'inline';
    $(document).ready(function () {
        $('#txt_name').editable();
    });
    $("#setting").html(' <div id="loader"><img src="{{url()}}/images/loader.png"></div>');
    $.get("{{action('MemberController@getSetting')}}", function (data) {
        $("#setting").html(data);
    });

    $(".skype_form").hide();
    $(".btn-skype-save").hide();
    $(".btn-skype-cancel").hide();
    $(".btn-skype-edit").click(function(e){
        e.preventDefault();
        $(".btn-skype-cancel").show();
        $(this).hide();
        $(".btn-skype-save").show();
        $(".skype-info").hide();
        $(".skype_form").show();
    });

    $(".btn-skype-cancel").click(function(e){
        e.preventDefault();
        $(".skype_form").hide();
         $(".skype-info").show();
         $(this).hide();
         $(".btn-skype-save").hide();
         $(".btn-skype-edit").show();
    });

    $(".btn-skype-save").click(function(e){
        e.preventDefault();
        var skypeid = $(".skype_form").val();
        var id_user = {{$setting['id']}};
        $.ajax({
            type: "POST",
            url: '{{action("AjaxController@postEditSkype")}}',
            data : {
                id_user : id_user,
                skypeid : skypeid,
            },
            success: function (response) {
                if (response=='"success"') {
                    pesanOk("success");
                    $(".skype-info").html(skypeid);
                    $(".skype_form").hide();
                     $(".skype-info").show();
                     $(".btn-skype-save").hide();
                     $(".btn-skype-cancel").hide();
                     $(".btn-skype-edit").show();
                }else{
                    pesanErr("failed");
                };
            }
        });
    });

</script>

<script>
    $(document).ready(function () {
        $("form#custom_menu_form").submit(function(e) {
            e.preventDefault();
            var formData = new FormData(document.querySelector('form#custom_menu_form'));
            $.ajax({
                url: '{{action('SettingController@postCustommenu')}}',
                type: 'POST',
                data: formData,
                success: function (data) {
                    if(data == "done") {
                        pesanOk("Settings successfully saved");
                        location.reload();
                    }
                },
                cache: false,
                contentType: false,
                processData: false
            });
        });
        
        $("form#favicon_form").submit(function(e) {
            e.preventDefault();
            var formData = new FormData(document.querySelector('form#favicon_form'));
            $.ajax({
                url: '{{action('SettingController@postFavicon')}}',
                type: 'POST',
                data: formData,
                success: function (data) {
                    if(data == "done") {
                        pesanOk("Settings successfully saved");
                        location.reload();
                    }
                },
                cache: false,
                contentType: false,
                processData: false
            });
        });

        $('#editMail').click(function(e){
            e.preventDefault();
            $('#mailText').css('display','none');
            $('#create_mail').css('display','block');
        });

        $('#btn-edit-mail').click(function(e){
            e.preventDefault();
            $('#mailText').css('display','block');
            $('#create_mail').css('display','none');
        });

        $('#btn-create-mail').click(function(e){
            e.preventDefault();
            $('#spiner').html('<img style="width: 26px;" src="{{url('')}}/images/ajax-loader.gif"/>');
            var email = $('#cemail').val();
            $.post("{{action('SettingController@postSavemail')}}",{
                email:email
            },function(data){
                $('#spiner').html('');
                $('#btn-edit-mail').trigger('click');
                $('#mail-text').html(data);
            }).fail(function(data){
                $('#spiner').html('');
                try {
                    var message = JSON.parse(data.responseText);
                    $('#mail-error').empty();
                    $.each(message,function(k,v){
                        $('#mail-error').append($('<li>').append($('<span class="label label-danger">').text(v)));
                    });
                    if (message.message != "") {
                        pesanErr(message.message);
                    }
                } catch (ec) {
                    console.log(data);
                    pesanErr("Ooops, there is something error when submitting the data");
                }
            });
        });


        // Whatsapp Shop
        $('#editWashop').click(function(e){
            e.preventDefault();
            $('#washopText').css('display','none');
            $('#create_washop').css('display','block');
        });

        $('#btn-edit-washop').click(function(e){
            e.preventDefault();
            $('#washopText').css('display','block');
            $('#create_washop').css('display','none');
        });

        $('#create-washop-number').click(function(){
            var wa_number = $('#wa_number').val();
            var wa_username = $('#wa_username').val();
            console.log(wa_username);
            $.ajax({
               method: "POST",
                url: "{{action('SettingController@postWhatsappapi')}}",
                data: { 
                    wa_number : wa_number ,
                    wa_username : wa_username,
                    _token: '{{csrf_token()}}' 
                },
                success: function (response) {
                    var obj  = JSON.parse(response)
                    if (obj.message =="error") {
                        pesanErr("Please enter all the details");
                    }
                    else if (obj.message=="uexist"){
                        pesanErr('username already exist');
                    }
                    else if (obj.message=="nexist"){
                        pesanErr('number already exist');
                    }
                    else if (obj.message=="success"){
                        pesanOk('successful');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    }
                },
            });
        
        });

        var password = document.getElementById("password"), 
        confirm_password = document.getElementById("confirm_password");
        function validatePassword(){
            if(password.value != confirm_password.value) {
                confirm_password.setCustomValidity("Passwords Don't Match");
            } else {
                confirm_password.setCustomValidity('');
            }
        }

        if(password) password.onchange = validatePassword;
        if(confirm_password) confirm_password.onkeyup = validatePassword;
        var options = {
            beforeSubmit: function () {
                $("#btn_submit").button("loading");
            },
            success: function (data) {
                $("#btn_submit").button("reset");
                pesanOk(data.message);
                setTimeout(function(){
                    window.location.href = "{{action("HomeController@getSocial")}}";
                },1000);
            },

            error: function (data) {
                $("#btn_submit").button("reset");
                try {
                    var message = JSON.parse(data.responseText);
                    console.log(message);
                    $('#error').empty();
                    /*$.each(message,function(k,v){
                        $('#error').append($('<li>').append($('<span class="label label-danger">').text(v)));
                    });*/
                    if (message.message) {
                        pesanErr(message.message);
                    }
                    else if (message.password) {
                        pesanErr(message.password[0]);
                    }
                } catch (ec) {
                    console.log(data);
                    pesanErr("Ooops, there is something error when submitting the data");
                }
            }
        };
        $(".form-create").ajaxForm(options);
    });
</script>

<script>
    $(document).ready(function () {
        //$('#txt_name').editable("toggle");
        //$('.form_setting').ajaxForm(options);
        $("#btn_create_email").on("click",function(){
            window.location.href  = "{{action('HomeController@getEmail')}}";
        });
        $("#btn_manage_emails").on("click",function(){
            window.location.href  = "{{action('HomeController@getManageEmails')}}";
        });
    });
    function onCancel(base) {
        var parent = $(base).closest("li");
        cancel(parent);
    }

    function cancel(parent) {
        var form = $(parent).find("form");
        var editel = $(parent).find(".edit_form");
        var setting = $(parent).find(".setting-nav");
        var setting2 = $(parent).find(".setting-nav2");
        $(form).hide();
        $(setting).show();
        var element = '<a href="#" class="setting_save" style="margin-right: 5px;" onclick="javascript:onSave(this);"></a><a href="#" class="setting_cancel" onclick="javascript:onCancel(this);"></a>';
        $(setting2).html(element);
        $(setting2).hide();
        $(editel).show();
    }

    function onEdit(base) {
        var parent = $(base).closest("li");
        var form = $(parent).find("form");
        var editel = $(parent).find(".edit_form");
        var setting = $(parent).find(".setting-nav");
        var setting2 = $(parent).find(".setting-nav2");
        $(form).show();
        $(setting).hide();
        $(setting2).show();
        $(editel).hide();
        // $('#txt_name').editable("toggle");
    }

    function onSave(el) {
        var parent = $(el).closest("li");
        var form = $(parent).find("form");
        var editel = $(parent).find(".edit_form");
        var beforeText = $(parent).find(".setting-nav2").html();
        var options = {
            beforeSubmit: function () {
                var parent = $(el).closest("li");
                var loading_gif = "<img width='24px' src='{{url('')}}/images/loading.gif'/>"
                $(parent).find(".setting-nav2").html(loading_gif);
            },
            success: function (data) {
                $(editel).find("strong").html(data.message);
                cancel(parent);
                pesanOk("Configuration is saved successfully");
            },

            error: function (data) {
                try {
                    var message = JSON.parse(data.responseText);
                    if (message.message) {
                        pesanErr(message.message);
                    } else  pesanErr("Failed to save configuration");
                } catch (ec) {
                    console.log(data);
                    pesanErr("Error, the configuration is failed to save");
                }
                $(parent).find(".setting-nav2").html(beforeText);
            }
        };
        $(form).ajaxSubmit(options);
    }

    function onEditSocial(base, type) {
        var parent = $(base).closest("li");
        var setting = $(parent).find(".setting-active");
        var setting_el = $(parent).find(".setting-nav");
        var data = 0;
        if (setting.length > 0) {
            data = 0;
        } else {
            setting = $(parent).find(".setting-off");
            data = 1;
        }
        updateSetting(setting_el,setting, data, type);
    }

    function set_ecommerce(setting_el, setting) {
        var beforeText = $(setting_el).html();
        $.ajax({
            method: "POST",
            url: '{{action("SettingController@postReqEcommerce")}}',
            beforeSend: function () {
                var loading_gif = "<img width='24px' src='{{url('')}}/images/loading.gif'/>"
                $(setting_el).html(loading_gif);
            }
        })
            .success(function (msg) {
                var parent = $(setting_el).closest('span');
                var process="<i class=\"setting-active\">On Progress</i>";
                pesanOk("Your Request has been submit to Administrator, Please wait while we activating your E-Commerce.");
                $(parent).html(process);
            })
            .error(function (msg) {
                pesanErr("Error, the configuration is failed to save");
                $(setting_el).html(beforeText);
            });
        ;
    }

    function updateSetting(setting_el,setting, data, type) {
        var beforeText = $(setting_el).html();
        $.ajax({
            method: "POST",
            url: '{{action("SettingController@postSaveSocial")}}',
            data: {set: data, type: type},
            beforeSend: function () {
                var loading_gif = "<img width='24px' src='{{url('')}}/images/loading.gif'/>"
                $(setting_el).html(loading_gif);
            }
        }).success(function (msg) {

            if (data == 0) {
                $(setting).removeClass("setting-active");
                $(setting).addClass("setting-off");
                $(setting).html("off")
                data = 0;
            } else {
                $(setting).removeClass("setting-off");
                $(setting).addClass("setting-active");
                $(setting).html("active")
                data = 1;
                //alert(msg.url);
                if(msg.url != ""){
                    window.location.href = msg.url;
                }
            }

            pesanOk("Configuration is changed successfully");
            $(setting_el).html(beforeText);
        })

        .error(function (msg) {
            pesanErr("Error, the configuration is failed to save");
            $(setting_el).html(beforeText);
        });
        ;
    }

    function changeTheme(value){
        $.ajax({
            method: "POST",
            url: '{{action("SettingController@postChangeTheme")}}',
            data: { value : value, },
            beforeSend: function () {
              pesanOk("Please wait ...");
            }
        })
        .success(function (response) {
            if (response['message']=="success") {
                setTimeout(function(){pesanOk("Theme updated")},2000);
            }else{
                pesanErr("something wrong");
            };

            setTimeout(function(){
            window.location.href += "?type=themes";
            window.location.reload();
            },4000)
        })
    }

    function urlParam(name) {
        var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
        if(!results) return 0;
        return results[1] || 0;
    };

        var type = urlParam('type');
        if (type == "setting") {
            $("#tab_setting").trigger("click");
        }else if(type == "email"){
            $("#tab_email").trigger("click");
        }else if(type == "themes"){
            $("#tab_themes").trigger("click");
        };
            $("#tab_setting").click(function(e){
                e.preventDefault();
                var URL = "{{url("")}}/home/setting";
                window.history.pushState("object or string", "Title", URL);
    });

</script>

@endsection
