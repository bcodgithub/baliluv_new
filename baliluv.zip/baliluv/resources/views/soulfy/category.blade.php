<?php

/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 8/18/2015
 * Time: 9:57 AM
 */ 
?>

@extends('home')
@section('title', 'Home')

@section('content')

    <section id="content-desc" class="inner-section-container">
        <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>
        <div class="backend-box _grey backend-box-email">
            <div class="backend-nav">
                <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs" role="tablist">
                    <li class="active"><a id="tab_category" href="#category" aria-controls="category" role="tab" data-toggle="tab">Category</a></li>
                </ul>
            </div>
            <div class="tab-content backend-detail slimScroll">
                <div role="tabpanel" class="tab-pane active" id="category" style="height: 100%">
                    <div class="form-top">
                    	@if (session('status'))
						<div class="alert alert-success">
							{{ session('status') }}
						</div>	
						@endif
                        <table width="350px">
                            <!-- <form method="POST" action="{{action('HomeController@postCategory')}}"> -->
								{{ csrf_field() }}		
                				<tr>
                					<td style="color: white;">Category</td>
                					<td>
                                        <select name="category_id" required id="category_id">
                                            <option value="">Select</option>
                                            @foreach($category as $cat)
                                            <option value="{{$cat->id}}" <?php if($cat->id == $user_setting->category_id){?> selected="selected" <?php }  ?>>{{$cat->name}}</option>
                                            @endforeach
                                        </select>
                                    </td>
                				</tr>
                				<tr>
                                    <td style="color: white;">Category Level 1</td>
                                    <td>
                                        <select name="level1_id" id="level1_id">
                                            @foreach($category1 as $cat)
                                                <option value="{{$cat->id}}" {{$user_setting->category_level1 == $cat->id ? 'selected' : ''}} >{{$cat->name}}</option>
                                            @endforeach
                                        </select>
                                    </td>
                				</tr>
                				<tr>
                					<td style="color: white; padding-right: 10px;">Category Level 2</td>
                					<td>
                                        <select name="level2_id" id="level2_id">
                                            @foreach($category2 as $cat)
                                                <option value="{{$cat->id}}" {{$user_setting->category_level2 == $cat->id ? 'selected' : ''}} >{{$cat->name}}</option>
                                            @endforeach
                                        </select>
                					</td>
                				</tr>
                                <?php //print_r($user_settinglevel3); ?>
                                <tr>
                                    <td style="color: white; padding-right: 10px;">Category Level 3</td>
                                    <td id="leveltr_3">
                                        @if($user_settinglevel3->category_level3 != '')
                                        <select>
                                            @foreach($category3 as $cat)
                                                <option value="{{$cat->id}}" {{$user_setting->category_level3 == $cat->id ? 'selected' : ''}} >{{$cat->name}}</option>
                                            @endforeach
                                        </select>
                                        @endif
                                    </td>
                                </tr>
                                
                                
                				<tr>
                				    <td><br><button id="btn-save-seo"> Update </button></td>
                					<td></td>
                				</tr>
                			<!-- </form> -->
                		</table>
                    </div>
                </div>
            </div>
        </div> 

        <div class="placeholder-third" style="display:none">
            <div class="card-box">
                @include("soulfy/partial/bcard")
            </div>
            <div class="footer">
            </div>
        </div>
        <div class="placeholder _grey" id="backend-placeholder">
            <div class="placeholder-first backend-first" style="display:none">
                <div class="placeholder-header">
                    <h3 ></h3>
                    <a class="btn-cancels"><span class="glyphicon glyphicon-remove"></span></a>
                </div>
                <div class="content-placeholder">
                    <p>
                    </p>
                </div>
                <div style="clear:both;"></div>
                <div class="placeholder-footer action">
                    <a class="first btn-act-like" onclick="likeTimeLine(this)">
                        <span class="glyphicon glyphicon-thumps-up"></span>
                    </a>
                    <a  class="second"></a>
                    @if(Auth::check())
                    <a class="third btn-act-delete" onclick="deleteTimeLine(this)"><span class="glyphicon glyphicon-trash"></span> </a>
                    @endif
                    <div style="clear:both;"></div>
                </div>
            </div>
        </div>
    </section>
@endsection
@section('js')
<script>
    $(document).ready(function(){
         
        $('#category_id').change(function() {
            var categoryId = $(this).val();
            if (categoryId) {
                $.ajax({
                    type: "GET",
                    url: "{{action('ImageController@getCategoryLevel1')}}?parent_id=" + categoryId,
                    success: function(res) {
                        if (res) {
                            $("#level1_id").empty();
                            $("#level2_id").empty();
                            $('#leveltr_3').empty();
                            $('#level3_id').empty();
                            $("#level1_id").append('<option>Select</option>');
                            for (var i = 0; i < res.length; i++) {
                                let value =res[i];
                                $("#level1_id").append('<option value="' + value.id + '">' + value.name + '</option>');
                            }
                        } else {
                            $("#level1_id").empty();
                        }
                    }
                });
            } else {
                $("#level1_id").empty();
                $("#level2_id").empty();
                $("#level3_id").empty();
            }
        });
        $('#level1_id').on('change', function() {
            var level1_ID = $(this).val();
            if (level1_ID) {
                $.ajax({
                    type: "GET",
                    url: "{{action('ImageController@getCategoryLevel2')}}?parent_id=" + level1_ID,
                    success: function(res) {
                        if (res) {
                            $("#level2_id").empty();
                            $("#level2_id").append('<option value="">Select</option>');
                            for (var i = 0; i < res.length; i++) {
                                let value =res[i];
                                $("#level2_id").append('<option value="' + value.id + '">' + value.name + '</option>');
                            }
                        } else {
                            $("#level2_id").empty();
                        }
                    }
                });
            } else {
                $("#level2_id").empty();
                $("#level3_id").empty();
            }
        });
        $('#level2_id').on('change', function() {
            $('#leveltr_3').empty();
            var level2_ID = $(this).val();
            if (level2_ID) {
                $.ajax({
                    type: "GET",
                    url: "{{action('ImageController@getCategoryLevel3')}}?parent_id=" + level2_ID,
                    success: function(res) {
                        if (res) {
                            if(res.length>0){
                            $("#level3_id").empty();
                            $("#leveltr_3").append('<select name="level3_id" id="level3_id">');
                            $('#level3_id').append('<option value="">Select</option>')
                            for (var i = 0; i < res.length; i++) {
                                let value =res[i];
                                $("#level3_id").append('<option value="' + value.id + '">' + value.name + '</option>');
                            }
                            $("#leveltr_3").append('</select>');
                        }
                            
                        } else {
                            $("#level3_id").empty();
                        }
                    }
                });
            } else {
                $("#level3_id").empty();
            }
        });

        $('#btn-save-seo').click(function(){
            var category_id = $('#category_id').val();
            var level1_id = $('#level1_id').val();
            var level2_id = $('#level2_id').val();
            var level3_id = $('#level3_id').val();
            $.ajax({
                method: "POST",
                url: "{{action('HomeController@postCategory')}}",
                data: { 
                    category_id : category_id ,
                    level1_id : level1_id ,
                    level2_id : level2_id ,
                    level3_id : level3_id ,
                    _token: '{{csrf_token()}}' 
                },
                success: function (response) {
                    var obj  = JSON.parse(response)
                    if (obj.message =="empty") {
                        pesanErr("please select category and category level 1");
                    }
                    else if(obj.message =="error"){
                        pesanErr("something wrong try again");
                    }
                    else{
                        pesanOk('Add Successfully');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    }
                }
            });
        });
    });
</script>

@endsection

