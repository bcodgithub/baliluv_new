@extends('home')
@section('title', 'Home')
@section('content')

<section id="content-desc" class="inner-section-container">
    <a class="plus-minus-toggeler">
        <span class="glyphicon glyphicon-minus"></span>
    </a>
    <div class="backend-box _grey backend-box-email">
        <div class="backend-nav" >
            <ul style="margin-top: 20px;height: 32px;" class="nav" role="tablist" id="test">
                <?php 
                    $n=1;
                ?>
                
                @foreach($rss as $r)
                <?php //echo "<pre>";var_dump($r->tittle);die; ?>
                <li id="<?php echo  $n++; ?>" class>
                    <a id="tab_{{$r->rss_url}}" href="#{{$r->tittle}}" aria-controls="{{$r->tittle}}" role="tab" data-toggle="tab" style="font-size: 13px; color: white;" dataurl="{{$r->rss_url}}">
                        @if($r->tittle != "" || $r->tittle != null)
                        @if(strlen(strip_tags($r->tittle))>=10)
                            {{substr(strip_tags($r->tittle),0,9)}}....
                        @else
                            {{strip_tags($r->tittle)}}
                        @endif  
                        @endif
                        
                    </a>
                </li>
                @endforeach
                

            </ul>
        </div>
        <div class="tab-content backend-detail slimScroll">
            @include("soulfy/rss2html")
            @foreach($rss as $r)
            <div role="tabpanel" class="tab-pane active" id="{{$r->tittle}}" style="height: 100%">
                <div class="form-top create-article">
                    <label>{{$r->rss_tittle}}</label>
                </div>
                <div class="form-body  create-article">
                    <div class="notes-box" id="add">
                    <?php
                        output_rss_feed($r->rss_url ,$r->rss_title,$r->rss_link, 20, true, true, 200);
                    ?>
                        <!-- <ul>
                            <li>
                                <div class="notes-desc">
                                    <p><b>
                                    </b></p>
                                    <p class="date">
                                        <i class="fa fa-calendar"></i>
                                    </p>
                                </div>
                            </li>
                        </ul> -->
                    </div>
                </div>
            </div>
            @endforeach
         <!-- add here -->    
        </div>
    </div> 
</section>

@endsection


@section('js')

<script type="text/javascript">

    $(document).ready(function () {
        $('#2,#3').removeClass("active");
        $('#1').addClass("active");
    });
</script>

@endsection
