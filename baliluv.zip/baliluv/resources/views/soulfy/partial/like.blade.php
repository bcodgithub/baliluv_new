
<div aria-hidden="false" style="display: none; background: #FFF;" id="like_modal" class="modal fade in" tabindex="-1" data-focus-on="input:first">
    <div class="modal-header">
        <h4 class="modal-title">WhatsApp Details</h4>
    </div>
    <input type="hidden" name="timelineId" id="timelineId">
    <input type="hidden" name="socialType" id="socialType">
    <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
    <div class="modal-body">
        <div class="form-group">
            <div class="col-group">
                <input type="text" name="wa_username_like" id="wa_username_like" placeholder="Enter User Name" style="border: 1px solid #F1F1F1; width: 100%;"/>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-group col-sm-4">
                <select style="border: 1px solid #F1F1F1; width: 100%; height: 40px;"/ name="countryCodeLike" id="countryCodeLike">
                    <option value="">Select Country Code</option>
                    @foreach($countries as $cont)
                    <option value="{{$cont->countries_isd_code}}">{{$cont->countries_name}}(+{{$cont->countries_isd_code}})</option>
                    @endforeach
                </select>
            </div>
            <div class="col-group col-sm-8">
                <input type="number" name="wa_number_like" id="wa_number_like" placeholder="Enter WhatsApp Number" style="border: 1px solid #F1F1F1; width: 100%;"/><br>
                <span style="color: #e65f5f">Enter WhatsApp Number Without Zero(0).</span>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" data-dismiss="modal" class="btn btn-default" onclick="likclose()">Pause</button>
        <button type="submit" class="btn btn-success" id="likebtn">Proceed</button>
        
    </div>
</div>

<script type="text/javascript">
    function likeTimeLine(obj) {
        var id_timeline = $(obj).attr('data-id'),
            social_type = $(obj).attr('data-type');
        document.getElementById("like_modal").style.display = "block";
        document.getElementById("timelineId").value = id_timeline;
        document.getElementById("socialType").value = social_type;
    }
    function likclose(){
        document.getElementById('like_modal').style.display = 'none';
    }

    $("#likebtn").click(function () {
        var zNumber = $('#wa_number_like').val();
        if(zNumber.slice(0,1) == "0"){
            pesanErr("cannot start with  zeroe");
        }
        else if(!$('#wa_number_like').val().match('[0-9]{8}'))  {
            pesanErr("please put a valid mobile number");
        }
        else
        {
            var timelineId = $('#timelineId').val();
            var socialType = $('#socialType').val();
            var waUsername = $('#wa_username_like').val();
            var countryCode = $('#countryCodeLike').val();
            var waNumber = $('#wa_number_like').val();
            $.ajax({
                method: "POST",
                url: '{{action("ImageController@postLikedetails")}}',
                data: { 
                    timelineId : timelineId ,
                    socialType : socialType ,
                    waUsername : waUsername ,
                    countryCode : countryCode ,
                    waNumber : waNumber ,
                    _token: '{{csrf_token()}}' 
                },
                success: function (response) {
                    var obj  = JSON.parse(response)
                    if (obj.message =="error") {
                        pesanErr("Please enter all the details");
                    }
                    else if (obj.message=="uexist")
                    {
                        console.log('inside fun');
                        pesanErr('username already exist');
                    }
                    else if (obj.message=="nexist")
                    {
                        pesanErr('number already exist');
                    }
                    else if(obj.message=="liked")
                    {
                        pesanOk('already liked');
                        setTimeout(function() {
                            location.reload();
                        }, 10000);
                    }
                    else if (obj.message=="success")
                    {
                        pesanOk('like');
                        setTimeout(function() {
                            location.reload();
                        }, 10000);
                    }
                    else if(obj.message=="add")
                    {
                        pesanOk('like');
                        setTimeout(function() {
                            location.reload();
                        }, 10000);
                    }
                }
            })
        }
    });
</script>