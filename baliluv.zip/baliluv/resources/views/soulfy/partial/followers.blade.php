<?php
/**
 * Created by PhpStorm.
 * User: Muaaz Khalid
 * Date: 24/12/2018
 * Time: 8:38 AM
 */
?>


<div class="profile-list">
    @foreach($followers as $follower)
    <div class="element" id="{{$follower->id}}">
		<div class="profile-container">
			<div class="col-xs-9">
	    		<a target="_blank" href="http://<?PHP echo $follower->domain;?>">
	    			<img src="//<?PHP echo $follower->domain .'/'.$follower->image_profile ; ?>" class="profile-image" aligh="center">
	    			<div class="profile-name"><?PHP echo $follower->full_name; ?></div>
				</a>
			</div>
			<div class="col-xs-3">
				<a href="#" id="unfollow_web" onclick="statusUnFollower({{$follower->id}});">
	    			<div class="profile-name" id="unfollow_{{$follower->id}}" aligh="center">remove</div>
				</a>
			</div>
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
	@endforeach
</div>

<script type="text/javascript">

function statusUnFollower(id){

$.ajax({
       url: '{{action("AjaxController@postUnfollower")}}',
       type: 'post',
       data: {id:id},
       	success: function (response) {
		    console.log(response);
		    var data = JSON.parse(response);
		    if (data.status == 0) {
		    	pesanOk('Unfollow');
		    	 $('#'+id).css("display","none");
		    	//location.reload();
		    	//$('#follow_'+id).text('Follow');
		    }
		    else{
		    	//$('#follow_'+id).text('Unfollow');
		    	location.reload();
		    }

    	},
    	error: function (response) {
   			console.log(response);
    	}
   });
}
</script>
