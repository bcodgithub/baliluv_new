<?php

/**

 * Created by PhpStorm.

 * User: Muaaz Khalid

 * Date: 24/12/2018

 * Time: 8:38 AM

 */

?>

<div class="profile-list">

    <?PHP foreach($followings as $following) { ?>
    <div class="element" id="{{$following->id}}">
		<div class="profile-container">
			<div class="col-xs-9">
				<a target="_blank" href="http://{{$following->domain}}>">
	    			<img src="http://{{$following->domain}}/{{$following->image_profile}}" class="profile-image">
	    			<div class="profile-name">{{$following->full_name}}</div>
				</a>
			</div>
			<div class="col-xs-3">
				<a href="#" id="follow_web" onclick="statusChange({{$following->id}});">
	    			<div class="profile-name" id="follow_{{$following->id}}" aligh="center">Unfollow</div>
				</a>
			</div>
		</div>

		<div class="clear"></div>

	</div>

	<div class="clear"></div>

	<?PHP } ?>

</div>





<script type="text/javascript">

function statusChange(id){

$.ajax({
       url: '{{action("AjaxController@postUnfollow")}}',
       type: 'post',
       data: {id:id},
       	success: function (response) {
		    console.log(response);
		    var data = JSON.parse(response);
		    if (data.status == 0) {
		    	pesanOk('Unfollow');
		    	$('#follow_'+id).text('Follow');
		    }
		    else{
		    	$('#follow_'+id).text('Unfollow');
		    }

    	},
    	error: function (response) {
   			console.log(response);
    	}
   });
}
</script>