<?php

/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 9/27/2015
 * Time: 9:38 PM
 */
?>

<div aria-hidden="false" style="display: none; margin-top: -184px;" id="status_modal" class="modal fade in" tabindex="-1" data-focus-on="input:first">
    <div class="modal-header">
        <button type="button" class="close glyphicon glyphicon-remove" data-dismiss="modal" aria-hidden="true"></button>
        <h4 class="modal-title social_type"></h4>
    </div>
    <div class="modal-body modal-body-bubble">
        <p id="content_bubble">
        </p>
    </div>
    <div class="modal-footer " >
        <div class="action">
            <div class="fb-action">
                <a class='like'><span class='glyphicon glyphicon-thumbs-up'></span></a>&nbsp
                <a class='like btn-comment' ><span class='glyphicon glyphicon-comment'></span></a>
            </div>
            <div class="twitter-action">
                <a class='like'><span class='glyphicon glyphicon-retweet'></span></a>
            </div>
            <div class="google-action">
                <a class='like'><span class='glyphicon glyphicon-thumbs-up'></span></a>
            </div>
        </div>
        <div class="fb-comment"><textarea class="form-control"></textarea><button class="btn btn-danger">Submit</button></div>
    </div>
</div>

<div aria-hidden="false" style="display: none; margin-top: -184px;" id="skype" class="modal fade in" tabindex="-1" data-focus-on="input:first">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
        <h4 class="modal-title">Skype</h4>
    </div>
    <div class="modal-body">
        <p>Skype ID : {{$user_setting['skype_id']}}</p>
    </div>
    <div class="modal-footer">
        <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
    </div>
</div>

<div aria-hidden="false" style="display: none; margin-top: -184px;" id="contact_us" class="modal fade in" tabindex="-1" data-focus-on="input:first">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
        <h4 class="modal-title">Send email to us</h4>
    </div>
    <div class="modal-body">
        <form>
            <div class="form-group">
                <label for="exampleInputEmail1">Your email address</label>
                <input type="email" class="form-control" id="" placeholder="Email">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Subject</label>
                <input type="password" class="form-control" id="" placeholder="Subject">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Content</label>
                <textarea class="form-control" id="" ></textarea>
            </div>
        </form>
    </div>
    <div class="modal-footer">
        <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
        <button type="button" class="btn btn-primary">Submit</button>
    </div>
</div>

<div class="modal_popup fade" id="upload_background_dialog" style="display: none; margin-top: 122px;" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <div id="modaldialog" class="html5imageupload" data-resize="true" data-width="1500" data-height="938" data-url="{{action('AjaxController@postUploadProfile')}}" style="width: 100%;height: 300px">
                    <input type="file" name="thumb" />
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                </div>
            </div>
        </div>
    </div>
</div>

<div aria-hidden="false" style="display: none; background: #FFF;" id="info_profile" class="modal fade in" tabindex="-1" data-focus-on="input:first">
    <form role="form" id="form_update_profile_info" class="form-create" method="post" action="{{action("AjaxController@postUpdateprofileInfo")}}">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <h4 class="modal-title">Profile Info</h4>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <div class="col-group">
                    <textarea style="height: 150px;" class="form-control" id="profile_info" name="profile_info">{{$user_setting['info_profile']}}</textarea>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
            <button type="submit"  class="btn btn-success" id="btn_save_profile_info">Save</button>
        </div>
    </form>
</div>

<div aria-hidden="false" style="display: none; background: #FFF;" id="change_password_modal" class="modal fade in" tabindex="-1" data-focus-on="input:first">
    <form role="form" id="form_update_email_password" class="form-create" method="post" action="{{action("AjaxController@postUpdateEmailAccountPassword")}}">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <h4 class="modal-title">Update Password for <b id="modal_update_email_account_password"></b></h4>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <div class="col-group">
                    <input type="password" class="form-control" id="change-password1" placeholder="New Password" style="box-shadow: 0px 0px 1px;">
                    <br>
                    <input type="password" class="form-control" id="change-password2" placeholder="Confirm New Password" style="box-shadow: 0px 0px 1px;">
                    <input type="hidden" id="modal_user_email_account_password">
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
            <button type="submit"  class="btn btn-success">Update</button>
        </div>
    </form>
</div>

<div aria-hidden="false" style="display: none; background: #FFF;" id="business_link" class="modal modal-md fade in" tabindex="-1" data-focus-on="input:first">
    <form role="form" id="form_business_link" class="form-create" method="post" action="{{action("AjaxController@postUpdatelink")}}">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <h4 class="modal-title">Masukkan link akun bisnis anda?</h4>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <p style="color: #000000">Silahkan masukkan link bisnis anda dibawah ini, jika belum registrasi, silahkan registrasi di <a href="http://online.soulfy.com" target="_blank">online.soulfy.com</a></p>
                <div class="col-group">
                    <input type="text" name="link" id="" placeholder="Input your business link. Eg: http://online.soulfy.com" style="border: 1px solid #F1F1F1;"/>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
            <button type="submit" id="btn_save" class="btn btn-save">Save</button>
        </div>
        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
    </form>
</div>

<div aria-hidden="false" style="display: none; background: #FFF;" id="upload_image" class="modal modal-sm fade in" tabindex="-1" data-focus-on="input:first">
    <form role="form" id="form_upload_image_profile" class="form-create" method="post" action="{{action("AjaxController@postUploadImageProfile")}}">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <h4 class="modal-title">Upload Profile picture</h4>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <div class="col-group">
                    <input type="file" name="img" class="form-control" id="img"/>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
            <button type="submit" id="btn_save" class="btn btn-save">Save</button>
        </div>
        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
    </form>
</div>

<div aria-hidden="false" style="display: none; background: #FFF;" id="upload_image_background" class="modal modal-sm fade in" tabindex="-1" data-focus-on="input:first">
    <form role="form" id="form_upload_image_background" class="form-create" method="post" action="{{action("AjaxController@postUploadImageBackground")}}">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <h4 class="modal-title">Upload Image Background</h4>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <div class="col-group">
                    <input type="file" name="img" class="form-control" id="img"/>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
            <button type="submit" id="btn_save" class="btn btn-save">Save</button>
        </div>
        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
    </form>
</div>