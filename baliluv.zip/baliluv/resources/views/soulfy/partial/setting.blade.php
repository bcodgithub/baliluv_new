<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 9/6/2015
 * Time: 9:38 PM
 */


$domain = $_SERVER['SERVER_NAME'];
$user = \Soulfy\User::where('domain', $domain)->first();

//$user = \Soulfy\User::where('id', Auth::user()->id)->first();

$user_setting = \Soulfy\Setting::where('user_id',$user->id)->first();

//$user_setting = \Soulfy\Timeline::where('user_id',$user->id)->first();

?>


<div class="form-top">
    <label>Profile setting</label>
</div>
<div class="form-body">
    <div class="setting-box">
        <ul>
            <li>
                <span class="setting-name">Name</span>


                    <span class="setting-value">
                            <label class="edit_form" id="txt_name"><strong>{{$user->full_name}}</strong></label>

                            <form id="" class="form_setting" style="display: none;" method="post"
                                  action="{{action('SettingController@postSave')}}">
                                <input type="text" name="name" value="{{$user->full_name}}"/>
                            </form>

                    </span>
                    <span class="setting-nav">
                        <a href="#" onclick="javascript:onEdit(this);">
                        </a>
                    </span>

                     <span class="setting-nav2" style="display: none;">
                        <a href="#" class="setting_save" onclick="javascript:onSave(this);">
                        </a>
                          <a href="#" class="setting_cancel" onclick="javascript:onCancel(this);">
                          </a>
                    </span>

            </li>
            <li>
                <span class="setting-name">Login Email</span>
                    <span class="setting-value"><label class="edit_form"><strong>{{$user->email}}</strong></label>
                    <form id="" class="form_setting" style="display: none;" method="post"
                          action="{{action('SettingController@postSave')}}">
                        <input type="text" name="email" value="{{$user->email}}"/>
                    </form>
                        </span>
                     <span class="setting-nav">
                        <a href="#" onclick="javascript:onEdit(this);">
                        </a>
                    </span>

                     <span class="setting-nav2" style="display: none;">
                        <a href="#" class="setting_save" onclick="javascript:onSave(this);">
                        </a>
                          <a href="#" class="setting_cancel" onclick="javascript:onCancel(this);">
                          </a>
                    </span>
            </li>
            <li>
                <span class="setting-name">Address</span>
                    <span class="setting-value"><label class="edit_form"><strong>{{$user->address}}</strong></label>
                     <form id="" class="form_setting" style="display: none;" method="post"
                           action="{{action('SettingController@postSave')}}">
                         <input type="text" name="address" value="{{$user->address}}"/>
                     </form>
                    </span>
                     <span class="setting-nav">
                        <a href="#" onclick="javascript:onEdit(this);">
                        </a>
                    </span>

                     <span class="setting-nav2" style="display: none;">
                        <a href="#" class="setting_save" onclick="javascript:onSave(this);">
                        </a>
                          <a href="#" class="setting_cancel" onclick="javascript:onCancel(this);">
                          </a>
                    </span>
            </li>
            <li>
                <span class="setting-name">Language</span>
                    <span class="setting-value"><label class="edit_form"><strong>
                                @if($user->language == 'id')
                                    Indonesia (ID)
                                @else
                                    English (US)
                                @endif
                            </strong></label>
                         <form id="" class="form_setting" style="display: none;" method="post"
                               action="{{action('SettingController@postSave')}}">

                             <select name="language">
                                 <option value="en" {{$user->language == 'en'?"selected":""}}>English (US)</option>
                                 <option value="id" {{$user->language == 'id'?"selected":""}}>Indonesia (ID)</option>
                             </select>

                         </form>
                    </span>
                     <span class="setting-nav">
                        <a href="#" onclick="javascript:onEdit(this);">
                        </a>
                    </span>

                     <span class="setting-nav2" style="display: none;">
                        <a href="#" class="setting_save" onclick="javascript:onSave(this);">
                        </a>
                          <a href="#" class="setting_cancel" onclick="javascript:onCancel(this);">
                          </a>
                    </span>
            </li>
            <li>
                <span class="setting-name">Password</span>
                    <span class="setting-value">
                        <lable class="edit_form"><strong>***************</strong>
                        </lable>
                         <form id="" class="form_setting" style="display: none;" method="post"
                               action="{{action('SettingController@postSave')}}">
                             <input type="hidden" name="method" value="change_pwd">
                             <input style="margin-bottom: 10px" type="password" name="old_pwd" value=""/>
                             <input style="margin-bottom: 10px" type="password" name="new_pwd" value=""
                                    placeholder="New password"/>
                             <input style="margin-bottom: 10px" type="password" name="confirm_pwd" value=""
                                    placeholder="Confirm"/>
                         </form>
                    </span>
                     <span class="setting-nav">
                        <a href="#" onclick="javascript:onEdit(this);">
                        </a>
                    </span>

                     <span class="setting-nav2" style="display: none;">
                        <a href="#" class="setting_save" onclick="javascript:onSave(this);">
                        </a>
                          <a href="#" class="setting_cancel" onclick="javascript:onCancel(this);">
                          </a>
                    </span>
            </li>
        </ul>
    </div>
</div>
<div class="form-top">
    <label>profile info</label>
    <a class="setting-nav-edit setting-edit"></a>
    <a class="setting-nav-save setting_save"></a>
    <a class="setting-nav-cancel setting_cancel"></a>
</div>
<div class="form-body">
    <div class="setting-box profile" >
        
        {{ \Soulfy\Timeline::split_words($user_setting->info_profile,2000,"...")}} 
        
    </div>
    <!-- id="form_update_profile_info" -->
    <div class="setting-box profile-open">
        <form role="form" id="form_update_profile_info" method="post" action="{{action('AjaxController@postUpdateprofileInfo')}}">
    

            <div class="form-group">
            	 <!--
                <div class="col-group">
                    <textarea class="form-control" id="profile_info" style="margin-top: 0px; margin-bottom: 0px; height: 168px;" name="profile_info">{{$user_setting->info_profile}}</textarea>
                </div> id="profile_info"-->

                <div class="col-group">
                    <textarea style="height: 150px;" class="form-control" id="profile_info" name="profile_info">{{$user_setting['info_profile']}}</textarea>

                </div>
            </div>



    
    </form>
    </div>

</div>

<script> 
    CKEDITOR.replace( 'profile_info', {
        filebrowserBrowseUrl: '/filemanager/dialog.php',
        filebrowserUploadUrl: '/filemanager/upload.php'
    }); 

    CKEDITOR.on('instanceReady', function(){
      setInterval(function() {
          for (instance in CKEDITOR.instances) CKEDITOR.instances[instance].updateElement();
      }, 500);
    });
</script>

<script>
    $(document).ready(function () {
        //$('#txt_name').editable("toggle");


        //$('.form_setting').ajaxForm(options);

        $("#btn_create_email").on("click",function(){
            window.location.href  = "{{action('HomeController@getEmail')}}";
        });
    });

    function onCancel(base) {
        var parent = $(base).closest("li");
        cancel(parent);
    }

    function cancel(parent) {
        var form = $(parent).find("form");
        var editel = $(parent).find(".edit_form");
        var setting = $(parent).find(".setting-nav");
        var setting2 = $(parent).find(".setting-nav2");


        $(form).hide();
        $(setting).show();
        var element = '<a href="#" class="setting_save" style="margin-right: 5px;" onclick="javascript:onSave(this);"></a><a href="#" class="setting_cancel" onclick="javascript:onCancel(this);"></a>';
        $(setting2).html(element);
        $(setting2).hide();
        $(editel).show();
    }

    function onEdit(base) {
        var parent = $(base).closest("li");
        var form = $(parent).find("form");
        var editel = $(parent).find(".edit_form");
        var setting = $(parent).find(".setting-nav");
        var setting2 = $(parent).find(".setting-nav2");
        
        $(form).show();
        $(setting).hide();
        $(setting2).show();
        $(editel).hide();
        // $('#txt_name').editable("toggle");
    }

    function onSave(el) {

        var parent = $(el).closest("li");
        var form = $(parent).find("form");
        var editel = $(parent).find(".edit_form");
        var beforeText = $(parent).find(".setting-nav2").html();

        var options = {
            beforeSubmit: function () {
                var parent = $(el).closest("li");
                var loading_gif = "<img width='24px' src='{{url('')}}/images/loading.gif'/>";
                $(parent).find(".setting-nav2").html(loading_gif);
            },
            success: function (data) {
                $(editel).find("strong").html(data.message);
                cancel(parent);
                pesanOk("Configuration is saved successfully");
            },
            error: function (data) {

                try {
                    var message = JSON.parse(data.responseText);
                    if (message.message != "") {
                        pesanErr(message.message);
                    } else { pesanErr("Error, the configuration is failed to save"); }
                } catch (ec) {
                    console.log(data);
                    pesanErr("Error, the configuration is failed to save");
                    
                }

                $(parent).find(".setting-nav2").html(beforeText);

            }
        };

        $(form).ajaxSubmit(options);
    }

    function onEditSocial(base, type) {
        var parent = $(base).closest("li");
        var setting = $(parent).find(".setting-active");
        var setting_el = $(parent).find(".setting-nav");
        var data = 0;
        if (setting.length > 0) {
            data = 0;
        } else {
            setting = $(parent).find(".setting-off");
            data = 1;
        }

        updateSetting(setting_el,setting, data, type);

    }

    function updateSetting(setting_el,setting, data, type) {
        var beforeText = $(setting_el).html();
        $.ajax({
            method: "POST",
            url: '{{action("SettingController@postSaveSocial")}}',
            data: {set: data, type: type},
            beforeSend: function () {
                var loading_gif = "<img width='24px' src='{{url('')}}/images/loading.gif'/>"
                $(setting_el).html(loading_gif);
            }
        })
                .success(function (msg) {

                    if (data == 0) {
                        $(setting).removeClass("setting-active");
                        $(setting).addClass("setting-off");
                        $(setting).html("off")
                        data = 0;
                    } else {
                        $(setting).removeClass("setting-off");
                        $(setting).addClass("setting-active");
                        $(setting).html("active")
                        data = 1;
                        if(msg.url != ""){
                            window.location.href = msg.url;
                        }
                    }

                    pesanOk("Configuration changed successfully");
                    $(setting_el).html(beforeText);
                })
                .error(function (msg) {
                    pesanErr("Error, the configuration is failed to save");
                    $(setting_el).html(beforeText);
                });
        ;
    }
    $(".setting-nav-cancel").hide();
    $(".setting-nav-save").hide();
    $("div.profile-open").hide();
    $(".setting-nav-edit").click(function(e){
        e.preventDefault();
        $(".setting-nav-cancel").show();
        $("div.profile").hide();
        $("div.profile-open").show();
        $(".setting-nav-save").show();
        $(this).hide();
    });
    $(".setting-nav-cancel").click(function(e){
        e.preventDefault();
        $(".setting-nav-save").hide();
        $("div.profile").show();
        $("div.profile-open").hide();
        $(".setting-nav-edit").show();
        $(this).hide();
    });
    $(".setting-nav-save").click(function(e){
        e.preventDefault();
         var profile_info = $("#profile_info").val();
            
            $.ajax({
                type: "POST",
                url: '{{action("AjaxController@postUpdateprofileInfo")}}',
                dataType : "text",
                data : {
                     profile_info : profile_info,
                },
                success: function (response) {
                    if (response!="error") {
                        $("div.profile").show();
                        $(".setting-nav-save").hide();
                        $(".setting-nav-cancel").hide();
                        $(".setting-nav-edit").show();
                        $("div.profile-open").hide();
                        response = response.replace('"',' ');
                        response = response.replace('"','');
                        response = response.replace("\u00A0", " ").replace(/[\r\n]+/g, "\n");
                        $("div.profile").html(response);

                        pesanOk("success update profile info");
                        
                    }else{
                        pesanErr("Oops try again");
                    }
                    }
                });
    });

    /*
     $("#profile_info").wysihtml5({
            toolbar: {
                "font-styles": true, //Font styling, e.g. h1, h2, etc. Default true
                "emphasis": true, //Italics, bold, etc. Default true
                "lists": false, //(Un)ordered lists, e.g. Bullets, Numbers. Default true
                "html": false, //Button which allows you to edit the generated HTML. Default false
                "link": false, //Button to insert a link. Default true
                "image": false, //Button to insert an image. Default true,
                "color": false, //Button to change color of font
                "blockquote": false, //Blockquote
        }
    }); */
   
</script>