<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 9/6/2015
 * Time: 8:37 PM
 */

//$user_mail = \Soulfy\UserMail::where('user_id', $user->id)->get();
?>

<style>
    select:hover
    {
        color: #1B517E;
        cursor: pointer;
    }
</style>
@if(session('userMail'))
<div class="backend-top">
    <h6>
        <select class="select_mail">
            @foreach($emails as $mail)
                @if(session('userMail'))
                    <option value="{{$mail['user']}}" {{($mail['email']==session('userMail')['email']."@".$user->domain)?'selected':''}} >{{$mail['email']}}</option>
                @else
                    <option value="{{$mail['user']}}">{{$mail['user']}}</option>
                @endif
            @endforeach
        </select>
    </h6>
    <ul class="" role="tablist">
        <li class="active"><a id="tab_inbox" role="tab" data-toggle="tab" href="#">Inbox</a></li>
        <!-- <li class=""><a id="tab_sent" role="tab" data-toggle="tab" href="#">Sent</a></li> -->
        <li class=""><a id="tab_draft" role="tab" data-toggle="tab" href="#">Draft</a></li>

    </ul>
    <a href="#" id="btn_create_email" class="btn btn-green"><img src="{{url('')}}/images/icon-doc.png"/></a>
</div>

<div id="email_container">
    <div class="backend-list">
        <ul>
            
        </ul>
    </div>
</div>
@endif
<!-- BEGIN # BOOTSNIP INFO -->

<a href="#" id="btLogin" class="btn btn-primary" role="button" data-toggle="modal" data-target="#login-modal" style="display:none;"></a>
<!-- END # BOOTSNIP INFO -->

<script type="text/javascript">var winloc = "{{action('HomeController@getEmail')}}";</script>
<link rel="stylesheet" type="text/css" href="{{asset('css/modal.css')}}">
<script type="text/javascript" src="{{asset('js/modal.js')}}"></script>

<script>

    $(document).ready(function(){

        @if(!session('userMail'))
            $('#btLogin').trigger('click');
        @endif
        $("#tab_inbox").on("click", function () {
            $("#email_container").html(' <div id="loader"><img src="{{url()}}/images/spin.gif"></div>');
            var mail_value = $(".select_mail").val();

            $.get("{{action('MailController@getInbox')}}?mail="+mail_value, function (data) {
                $("#email_container").html(data);
            });
        });
        $('.select_mail').on('change',function(){
            @if(session('userMail'))
            if(! ("{{session('userMail')['email']}}"==$(this).val()) ){
                $('#btLogin').trigger('click');
            }
            @endif
        });
        $("#tab_sent").on("click", function () {
            $("#email_container").html(' <div id="loader"><img src="{{url()}}/images/loader.png"></div>');
            var mail_value = $(".select_mail").val();
            $.get("{{action('MailController@getSent')}}?mail="+mail_value, function (data) {
                $("#email_container").html(data);
            });
        });

        $("#tab_draft").on("click", function () {
            $("#email_container").html(' <div id="loader"><img src="{{url()}}/images/spin.gif"></div>');
            var mail_value = $(".select_mail").val();
            $.get("{{action('MailController@getDraft')}}?mail="+mail_value, function (data) {
                $("#email_container").html(data);
            });
        });

        $("#btn_create_email").on("click", function () {
            $("#email_container").html(' <div id="loader"><img src="{{url()}}/images/loader.png"></div>');

            $.get("{{action('MailController@getCreate')}}", function (data) {
                $("#email_container").html(data);
            });
        });

        $("#tab_inbox").trigger("click");
    });

</script>