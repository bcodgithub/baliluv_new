<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 9/6/2015
 * Time: 8:38 PM
 */

?>

<form role="form">
    <div class="form-top">
        <label>update</label>
        <ul class="form-nav">
            <li><a href="#"><img src="{{url('')}}/images//nav1.png"/></a></li>
            <li><a href="#"><img src="{{url('')}}/images//nav2.png"/></a></li>
        </ul>
    </div>
    <div class="form-body">
        <input type="text" name="update" id="txt_status" value="" placeholder="what's on your mind?"/>
    </div>
    <div class="form-btm">
        <div class="input-group">
            <input type="checkbox" id="ck_fb" name="social"/> <span><img src="{{url('')}}/images//icon-fb2.png"/></span>
            <input type="checkbox" id="ck_twitter" name="social"/> <span><img
                        src="{{url('')}}/images//icon-twitter2.png"/></span>
            <input type="checkbox" id="ck_path" name="social"/> <span><img
                        src="{{url('')}}/images//icon-path2.png"/></span>
            <input type="checkbox" id="ck_gplus" name="social"/> <span><img
                        src="{{url('')}}/images//icon-gplus.png"/></span>
        </div>
        <button type="button" class="btn btn-bk" id="btn_post">Post it</button>
    </div>

</form>
<form role="form" method="post" id="form_upload_img_gallery" enctype="multipart/form-data"
      action="{{action("MemberController@postUploadGallery")}}">
    <div class="form-top">
        <label>album</label>
    </div>
    <div class="form-body">
        <div class="album-box" style="position: relative;">
            <ul id="upload_list">
                <li>
                    <div id="upload_gallery">
                        <input type="file" name="images[]" id="btn_upload_gall" accept="gif|jpg|png|jpeg" maxlength="5"
                               class="multi with-preview"/>
                        <img id="btn_add_gallery" onclick="javascript:onAddclick(this);"
                             src="{{url('')}}/images//photo-add.png"/>
                    </div>
                </li>

            </ul>


        </div>
    </div>
    <div class="form-btm">
        <button class="btn btn-bk" id="btn_upload_img">Post it</button>
    </div>
</form>
<form role="form" method="post" id="form_upload_video">
    <div class="form-top">
        <label><span><img src="{{url('')}}/images//icon-youtube.png"/></span> channel</label>
    </div>
    <div class="form-body">
        <input required type="text" name="channel" placeholder="Paste URL Here"/>
    </div>
    <div class="form-btm">
        <button class="btn btn-bk" id="btn_upload_video">Post it</button>
    </div>
</form>

<form role="form" method="post" id="form_update_skype" action="{{action("AjaxController@postUpdateskype")}}">
    <div class="form-top">
        <label>SKYPE ID</label>
    </div>
    <div class="form-body">
        <input type="text" name="skype" placeholder="Your Skype ID"/>
    </div>
    <div class="form-btm">
        <button class="btn btn-bk" id="btn_update_skype">Save</button>
    </div>
</form>




