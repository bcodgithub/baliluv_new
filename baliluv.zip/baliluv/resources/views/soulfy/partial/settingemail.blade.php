

       
                <h3>{{$user->full_name}}</h3>

                <div class="backend-box">
                    <div class="backend-nav">
                        <label>
                            <span><img src="{{url()}}/images/start-button-sm.png"/></span>
                            <small>Create an email address on your very own domain</small>
                        </label>
                    </div>
                    <div class="backend-detail slimScroll">
                        <form role="form" class="form-create" method="post" action="{{action("ApiController@postCreateEmail")}}">
                            <div class="form-group">
                                <label>Name</label>

                                <div class="col-group">
                                    <span class="col1"><input type="text" required name="first" placeholder="First"/></span>
                                    <span class="col2">&nbsp;</span>
                                    <span class="col1"><input type="text" required name="last" placeholder="Last"/></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Email Account Name</label>

                                <div class="col-group">
                                    <span class="col1"><input type="text" name="account" required
                                                              placeholder="ex:amielee23"/></span>
                                    <span class="col2"><big>@</big></span>
                                    <span class="col1"><label style="margin-top: 6px;">{{$user->domain}}</label></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Create Password</label>

                                <div class="col-group">
                                    <span class="col4"><input type="password" id="password" required name="password"/></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Confirm Password</label>

                                <div class="col-group">
                                    <span class="col4"><input type="password" id="confirm_password" required name="confirm"/></span>
                                </div>
                            </div>


                            <div class="form-group">

                                <div class="" style="float: left">
                                    <button type="submit" id="btn_submit" class="btn btn-green">Create Email</button>
                                </div>
                                <div style="margin-left: 10px;text-align: right">
                                    <input required type="checkbox"/> <span>I Agree to the soulfy <a href="#">terms</a> & <a
                                                href="#">services</a></span>
                                </div>
                            </div>
                        </form>
                    </div>
                
        </div>
 