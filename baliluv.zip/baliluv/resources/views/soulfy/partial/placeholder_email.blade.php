<form method="post" action="{{action('HomeController@postSendEmail')}}" id="contact-form">
<input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
<div class="content-placeholder-email">
        <div class="form-group">
              <label for="email">Your email address</label>
              <input type="email" class="form-control" id="" name="email" placeholder="Email">
        </div>
        <div class="form-group">
              <label for="subject">Subject</label>
              <input type="text" class="form-control" id="" name="subject" placeholder="Subject">
         </div>
         <div class="form-group">
              <label for="content">Content</label>
              <textarea class="form-control" name="msg" id=""></textarea>
         </div>
</div>
<div style="clear:both;"></div>
<div class="placeholder-footer-email action">
     <br>
    <ul id="mail-error" ></ul>
     <button type="submit" class="button -green">Submit<div  id="btn-submit"></div></button>
     <div style="clear:both;"></div>
</div>
</form>
