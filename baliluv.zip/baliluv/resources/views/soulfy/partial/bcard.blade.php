<?php 
$user_setting = \Soulfy\Setting::where('user_id',$user['id'])->first();
 ?>
<a class="btn-cancel-video">
   <span class="glyphicon glyphicon-remove"></span>
</a>
<div class="photo">
   <img src="{{url('')}}/{{$user['image_profile']}}" alt="" />
</div>
<div class="list">
   <div class="list-text-name">
      {{$user['full_name']}}
   </div>
   <div class="list-text-occupation">
      {{$user['occupation']}} {{$user['full_name']}}
   </div>
   <div class="list-text-phone">
      Phone :<a href="tel:{{$user['phone']}}" style="text-decoration: none; color: black;">{{$user['phone']}}</a>
   </div>
   <div class="list-text-fax">
      Fax : {{$user['fax']}}
   </div>
   <div class="list-text-address">
      
      Address : <a href="https://maps.google.com/?q={{$user['address']}}" target="_blank" style="text-decoration: none; color: black;"> {{$user['address']}}</a>
   </div>
   <div class="list-text-website">
      Email : <a href="mailto:{{$user['email']}}?subject=Enquiry" style="text-decoration: none; color: black;">{{$user['email']}}</a>
   </div>