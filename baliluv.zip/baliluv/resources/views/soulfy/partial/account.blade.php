<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 9/6/2015
 * Time: 8:37 PM
 */

?>


<form role="form" class="form-create">
    <div class="form-group">
        <label>Name</label>

        <div class="col-group">
            <span class="col1"><input type="text" name="first" placeholder="First"/></span>
            <span class="col2">&nbsp;</span>
            <span class="col1"><input type="text" name="last" placeholder="Last"/></span>
        </div>
    </div>
    <div class="form-group">
        <label>Email Account Name</label>

        <div class="col-group">
            <span class="col1"><input type="text" name="account" placeholder="ex:amielee23"/></span>
            <span class="col2"><big>@</big></span>
            <span class="col1"><input type="text" name="domain" placeholder="ex:mycompany.com"/></span>
        </div>
    </div>
    <div class="form-group">
        <label>Create Password</label>

        <div class="col-group">
            <span class="col4"><input type="password" name="password"/></span>
        </div>
    </div>
    <div class="form-group">
        <label>Confirm Password</label>

        <div class="col-group">
            <span class="col4"><input type="password" name="confirm"/></span>
        </div>
    </div>
    <div class="form-group">
        <label>Birthday</label>

        <div class="col-group">
                      <span class="col1">
                        <select>
                            <option>Month</option>
                            <option>January</option>
                            <option>Februari</option>
                        </select>
                      </span>
            <span class="col3"><input type="text" name="day" placeholder="Day"/></span>
            <span class="col5"><input type="text" name="year" placeholder="Year"/></span>
        </div>
    </div>
    <div class="form-group">
        <label>Gender</label>

        <div class="col-group">
                      <span class="col4">
                        <select>
                            <option>I'm...</option>
                            <option>Male</option>
                            <option>Female</option>
                        </select>
                      </span>
        </div>
    </div>
    <div class="form-group">
        <label>Phone Number</label>

        <div class="col-group">
            <span class="col4"><input type="text" name="phone" placeholder="+62"/></span>
        </div>
    </div>
    <div class="form-group">
        <input required type="checkbox"/> <span>I Agree to the soulfy <a href="#">terms</a> & <a href="#">services</a></span>
    </div>
</form>
