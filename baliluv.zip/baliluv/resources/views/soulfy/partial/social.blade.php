<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 9/6/2015
 * Time: 8:38 PM
 */

$no = "1";
?>

 
<script language="JavaScript" src="http://www.geoplugin.net/javascript.gp" type="text/javascript"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">


<script>
jQuery(document).ready(function($) {
	alert("Your location is: " + geoplugin_countryName() + ", " + geoplugin_region() + ", " + geoplugin_city());

	var country = geoplugin_countryName();
	$("#country").append("<option value='1' selected>"+country+"");

	var zone = geoplugin_region();
	$("#zone").append("<option value='1' selected>"+zone+"");

	var district = geoplugin_city();
	$("#district").append("<option value='1' selected>"+district+"");
});

</script>

<p id="demo"></p>


<link href="{{url('')}}/css/bootstrap3-wysihtml5.css" rel="stylesheet"/>

<div class="form-top">
    <label>update</label>



    <div id="country"></div>
	<div id="zone"></div>
	<div id="district"></div>
  
    <ul class="form-nav">
        <li>
            <a href="#" class="btn-pict-open">
                <img src="{{url('')}}/images/nav1.png"/>
            </a>
            <a href="#">
                <img src="{{url('')}}/images/nav1.png"/>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="{{url('')}}/images/nav2.png"/>
            </a>
        </li>
    </ul>
</div>
<!-- <div class="url-pict">
        <div class="form-body ">
        <div class="album-box" style="position: relative;">
            <ul id="upload_list">
                <li>
                    <div id="pict-stats-form" class="btn-upload">
                    <input type="hidden" name="_token" value="{!! csrf_token() !!}">
                        <input type="file" name="pict_stats[]" id="pict-stats" accept="gif|jpg|png|jpeg" maxlength="5"
                               class="multi with-preview"/>

                    </div>
                </li>

            </ul>


        </div>
    </div>
    </div> -->
<div class="form-body">
    <textarea name="update" id="txt_status" placeholder="what's on your mind?"></textarea>
</div>
<div class="form-btm">
    <div class="input-group">
        <div class="checkbox-icon">
            <label>
                <input type="checkbox" {{$settings->fb_enable == true ? "" : "disabled"}} id="ck_fb"/>
                <span class="lbl padding-1" style="opacity: {{$settings->fb_enable == true ? '1' : '0.5'}};"></span>
            </label>
            <label>
                <input type="checkbox" {{$settings->twitter_enable == true ? "" : "disabled"}} id="ck_twitter"/>
                <span class="lbl padding-2"  style="opacity: {{$settings->twitter_enable == true ? '1' : '0.5'}};"></span>
            </label>
            <label>
                <input type="checkbox" {{$settings->google_enable == true ? "" : "disabled"}} id="ck_gplus"/>
                <span class="lbl padding-3"  style="opacity: {{$settings->google_enable == true ? '1' : '0.5'}};"></span>
            </label>
            <label>
                <input type="checkbox"/>
                <span class="lbl padding-4"></span>
            </label>
            <label>
                <input type="checkbox" class="soulfy-checkbox"/>
                <span class="lbl padding-5"></span>
            </label>
        </div>


    </div>
    <button type="submit" class="btn btn-bk" id="btn_post">Post it</button>
</div>

<form role="form" method="post" id="form_upload_img_gallery" enctype="multipart/form-data"
      action="{{action('MemberController@postUploadGallery')}}">
    <div class="form-top">
        <label>PHOTO GALLERY</label>
    </div>
    <div class="form-body ">
        <div class="album-box" style="position: relative;">
            <ul id="upload_list">
                <li>
                    <div id="upload_gallery" class="btn-upload">
                        <input type="hidden" name="_token" value="{!! csrf_token() !!}">
                        <input type="file" name="imagesg[]" id="btn_add_gallery" accept="gif|jpg|png|jpeg" maxlength="5"
                               class="multi with-preview"/>

                    </div>
                </li>

            </ul>
        </div><br>
        <label style="color: white;">Description</label>
        <textarea name="description" id="txt_status"></textarea>
    </div>
    <div class="form-btm">
        <button class="btn btn-bk" id="btn_upload_img">Post it</button>
    </div>
</form>
<form role="form" method="post">
    <div class="form-top">
        <label><span><img src="{{url('')}}/images//icon-youtube.png"/></span> channel</label>
    </div>
    <div class="form-body">
        <input required type="text" size="59" id="url_video" name="channel" placeholder="Paste YOUTUBE URL Here"/>
    </div>
    <div class="form-btm">
        <buttin class="btn btn-bk" id="btn_upload_video">Post It !</buttin>
    </div>
</form>




<!--
<form role="form" method="post"action="{ {action("AjaxController@postUpdateskype")}}">
    <div class="form-top">
        <label>SKYPE ID</label>
    </div>
    <div class="form-body">
        <input type="text" name="skype" placeholder="Your Skype ID"/>
    </div>
    <div class="form-btm">
        <button class="btn btn-bk" id="btn_update_skype">Save</button>
    </div>
</form>


 -->

<script type="text/javascript" src="{{url('')}}/js/jquery-1.10.2.min.js"></script>
<script src="{{url('')}}/js/bootstrap3-wysihtml5.all.min.js"></script>

<script type="text/javascript">
    $(".url-pict").hide();
    $(".form-body.picture-status").hide();
    $(".btn-pict-open").hide();

    // UPLOAD PICTURE ON STATUS
    $(".btn-pict-stats").click(function (e) {
        e.preventDefault();
        $(".btn-pict-open").show();
        $(this).hide();
        $(".url-pict").show();

    });
    $(".btn-pict-open").click(function (e) {
        e.preventDefault();
        $(".btn-pict-stats").show();
        $(".url-pict").hide();

        $(this).hide();
    });

    // $(".submit-photo").click(function(e){
    //     e.preventDefault();
    //   var photo = $(".photo-url").val();
    //   var url_photo = "<img src='"+photo+"' max-width='250px' >";

    // $('iframe').contents().find('.wysihtml5-editor').show();
    // });
    // $("#txt_status").wysihtml5({
    //            toolbar: {
    //                "font-styles": false, //Font styling, e.g. h1, h2, etc. Default true
    //                "emphasis": false, //Italics, bold, etc. Default true
    //                "lists": false, //(Un)ordered lists, e.g. Bullets, Numbers. Default true
    //                "html": false, //Button which allows you to edit the generated HTML. Default false
    //                "link": false, //Button to insert a link. Default true
    //                "image": false, //Button to insert an image. Default true,
    //                "color": false, //Button to change color of font
    //                "blockquote": false, //Blockquote
    //        }
    //    });
    $(document).ready(function () {
        $("#btn_upload_video").click(function (e) {
            e.preventDefault();

            var url_video = $("input#url_video").val();
            $.ajax({
                type: "POST",
                url: '{{action("AjaxController@postUrlYoutube")}}',
                dataType: "text",
                data: {
                    url_video: url_video,
                },
                success: function (response) {

                    if (response == '"success"') {
                        pesanOk("successfully updated");
                        location.reload();
                    } else if (response == '"error"') {
                        pesanErr("the URL you entered is wrong");
                    } else if (response == '"null"') {
                        pesanErr("Please type your URL");
                    }
                    ;
                }
            });

        }),
                {{--$("#btn_post").click(function (e) {--}}
                    {{--e.preventDefault();--}}

                    {{--var status = $("#txt_status").val();--}}
                    {{--if (status == "What is your mind?.") {--}}
                        {{--pesanErr("Please type your status");--}}
                    {{--} else {--}}
                        {{--$.ajax({--}}
                            {{--type: "POST",--}}
                            {{--url: '{{action("AjaxController@postStatus")}}',--}}
                            {{--dataType: "text",--}}
                            {{--data: {--}}
                                {{--status: status,--}}
                            {{--},--}}
                            {{--success: function (response) {--}}

                                {{--if (response == '"success"') {--}}
                                    {{--pesanOk("successfully update soulfy status");--}}
                                    {{--setTimeout(function () {--}}
                                        {{--location.reload()--}}
                                    {{--}, 1000);--}}
                                {{--} else if (response == '"error"') {--}}
                                    {{--pesanErr("the URL you entered is wrong");--}}
                                {{--} else if (response == '"null"') {--}}
                                    {{--pesanErr("Please type your status");--}}
                                {{--}--}}
                                {{--;--}}
                            {{--}--}}
                        {{--});--}}
                    {{--}--}}

                {{--});--}}


        $("#btn_post").on("click", function () {
            var ck_fb = $("#ck_fb").prop("checked");
            var ck_twitter = $("#ck_twitter").prop("checked");
            var ck_path = $("#ck_path").prop("checked");
            var ck_gplus = $("#ck_gplus").prop("checked");

            $(this).button("loading");
            var button = this;


            var type = 0;
            if (ck_fb) {
                type = 1;
                updateStatus(button, type);
            } else if (ck_twitter) {
                type = 2;
                updateStatus(button, type);
            } else if (ck_path) {
                type = 3;
                updateStatus(button, type);
            } else if (ck_gplus) {
                type = 4;
                updateStatus(button, type);
            }else{
                postStatus(button);
            }

        });

        function updateStatus(button, type) {
            var jqxhr = $.post("{{action('SocialController@postPublishStatus')}}", {
                type: type,
                status: $("#txt_status").val()
            }, function (data) {
                alert("Successfully update status");
                $("#txt_status").val('');
                $(button).button("reset");
            }).fail(function () {
                alert("Publish status error");
                $("#txt_status").val('');
                $(button).button("reset");
            });
        }

        function postStatus(button){
            var status = $("#txt_status").val();
            if (status == "what's on your mind?") {
                pesanErr("Please type your status");
            } else {
                $.ajax({
                    type: "POST",
                    url: '{{action("AjaxController@postStatus")}}',
                    dataType: "text",
                    data: {
                        status: status,
                        latitude : $("#latitude").val(),
                        longitude : $("#longitude").val(),
                    },
                    success: function (response) {
                        $(button).button("reset");
                        $("#txt_status").val('');
                        if (response == '"success"') {
                            pesanOk("Soulfy status updated");
                            setTimeout(function () {
//                                location.reload()
                            }, 1000);
                        } else if (response == '"error"') {
                            pesanErr("the URL you entered is wrong");
                        } else if (response == '"null"') {
                            pesanErr("Please type your status");
                        }
                        ;
                    },
                    error : function(){
                        $(button).button("reset");
                    }
                });
            }
        }

    });



    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    });

    $('.form-body textarea').keyup(function () {
        var len = this.value.length;
        if (len >= 1000) {
            this.value = this.value.substring(0, 1000);
            alert("Max input");
        }
        $('.form-body span.char-info').text(1000 - len);
    });

</script>

 <script>
var x = document.getElementById("txt_status");

function getLocation() {

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}
function showPosition(position) {
//alert("Latitude: " + position.coords.latitude +
  //  "<br>Longitude: " + position.coords.longitude);
     $.ajax({
                method: "GET",
                url: '{{action("AjaxController@getLocation")}}',
                data: { lat : position.coords.latitude, long : position.coords.longitude },
                success: function (response) {                    
                 	$("#status_location").text(response);
                
                },
                error:function()
                {
                	pesanErr("failed");
                }
            })
}

getLocation();
</script> 