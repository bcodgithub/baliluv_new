<div class="setting-box" >
    <form class=""  id="create_mail" style="display: none;">
        <div class="row">
            <div class="col-xs-6">
                <input type="email" class="form-control" id="cemail" placeholder="jane.doe@example.com">
                @if($errors->has('email'))
                    <span>{{$errors->first('email')}}</span>
                @endif
            </div>
            <div class="col-xs-6">
                <button type="submit" class="btn btn-success" id="btn-create-mail">Save</button>
                <button class="btn btn-danger" id="btn-edit-mail">Cancel</button>
            </div>
        </div>
    </form>
    <div class="row" id="mailText">
        <div class="col-xs-10">
            <span class="setting-name">hafizyousaf91@gmail.com</span>
        </div>
        <div class="col-xs-2">
            <a href="#" id="editMail"><img src="{{asset('/images/nav-edit.png')}}"></a>
        </div>
    </div>
</div>