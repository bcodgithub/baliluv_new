<?php
$no = 1;
$no1 = 1;
?>

@extends('home')

@section('title', 'Home')

@section('css')
    <link rel="stylesheet" href="{{url('')}}/lightbox/css/lightbox.min.css"/>
    <link href="{{url('')}}/js/flex_image/jquery.flex-images.css" rel="stylesheet"/>
    <link type="text/css" rel="stylesheet" href="{{url('')}}/js/gallery/css/lightgallery.css"/>
    <link rel="stylesheet" href="{{url('')}}/js/justified/css/justifiedGallery.min.css"/>
    

    <style>
        #wa_modal.modal {z-index: 99999;}
        .abcd {text-transform: uppercase;}
        select#countryCode {visibility: visible !important;}
    </style>
@endsection

@section('content')
    <section id="content-desc">
        <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>
        <div class="content-gallery ">
            <h3 class="content-placeholder-tittle">{{$user->full_name}} | Gallery</h3>
            <div class="gallery-box slimScroll">
                <div class="backend-box backend-box-email">
                    <div class="backend-nav">
                        <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs" role="tablist">
                            <li class="active"><a id="tab_gallery" href="#gallery" aria-controls="gallery" role="tab"data-toggle="tab">Gallery</a></li>
                            @if($user_setting->washop_enable)
                            <li >
                                <a href="#byimage" aria-controls="byimage" role="tab" data-toggle="tab" class="abcd">WASHOP</a>
                            </li>
                            @endif
                        </ul>
                    </div>
                    <div class="tab-content backend-detail slimScroll">
                        <div role="tabpanel" class="tab-pane active" id="gallery">
                            <!-- GALLERY IMAGE -->
                            @if(Auth::check())
                            <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>
                            <div class="backend-box">
                                <div class="form-top create-article1">
                                    <br><br>
                                    <div class="text-left">
                                        <label>GALLERY</label>
                                    </div>
                                    <ul class="form-nav">
                                        <a href="#" class="new-article1"><img src="{{url('')}}/images//nav3.png"/></a>
                                    </ul>
                                </div>
                                <div class="form-body create-article1">
                                    <div class="notes-box">
                                        <ul>
                                            @foreach($galleries as $data)
                                            <li>
                                                <div class="notes-desc">
                                                    <p><b>{{$no++}}.
                                                        @if(strlen($data->description)>=15)
                                                            {{substr($data->description,0,20)}}....
                                                        @else
                                                            {{$data->description}}
                                                        @endif
                                                    </b></p>
                                                    <p class="date">
                                                        @if(date("Y",strtotime($data->updated_at))=="1970") 
                                                            <i class="fa fa-calendar"></i> {{date("d M Y H:i",strtotime($data->created_at))}}
                                                        @else
                                                            <i class="fa fa-calendar-plus-o"></i> {{date("d M Y H:i",strtotime($data->updated_at))}}
                                                        @endif
                                                    </p>
                                                </div>
                                                <div class="notes-nav">
                                                    <a href="#" class="btn btn-green btn-act-delete1" onclick="deleteTimeLine(this)" data-id="{{$data->id}}" data-type="gallery">
                                                        <img src="{{url('')}}/images//icon-trash.png"/>
                                                    </a>
                                                    <a href="#" class="btn btn-green btn-act-edit1" data-id="{{$data->id}}" data-img="{{$data->content}}" data-content="{{$data->description}}"><i class="fa fa-pencil"></i></a>
                                                </div>
                                            </li>
                                            @endforeach
                                        </ul>
                                    </div>
                                </div>
                                <div class="backend-form create-article-form1" style="display:none;">
                                    <form role="form" method="post" id="form_upload_img_gallery" enctype="multipart/form-data" action="{{action('MemberController@postUploadGallery')}}">
                                        <div class="form-top">
                                            <div class="form-left">
                                                <label>Create GALLERY</label>
                                            </div>
                                            <div class="form-right" style="padding-right: 2% !important;">
                                                <button class="setting_save_gallery"></button>
                                                <button class="btn-cancel-article1 setting_cancel_gallery"></button>
                                            </div>
                                        </div>
                                    
                                        <!-- <div class="text-left">
                                            <label>GALLERY Image</label>
                                        </div> -->
                                        <div class="form-body _grey">
                                            <label>Image</label>
                                            <div class="album-box" style="position: relative;">
                                                <div id="upload_gallery" class="btn-upload">
                                                    <input type="hidden" name="_token" value="{!! csrf_token() !!}">
                                                    <input type="hidden" name="id">
                                                    <input type="file" name="imagesg[]" id="btn_add_gallery1" accept="gif|jpg|png|jpeg" maxlength="5" class="multi with-preview" onchange="galleryImg(this)"/>
                                                </div>
                                            </div><br>
                                            <div class="form-group">
                                                <label>Description</label>
                                            </div>
                                            <textarea name="description" id="description1" class="form-control" placeholder="Description"></textarea>
                                        </div>
                                    </form>
                                </div>
                                <div class="backend-form edit-article-form1 " style="display:none;">
                                    <form role="form" method="post" id="form_upload_img_gallery" enctype="multipart/form-data" action="{{action('MemberController@postUploadGallery')}}">
                                        <div class="form-top">
                                            <div class="form-left">
                                                <label>Edit GALLERY</label>
                                            </div>
                                            <div class="form-right" style="padding-right: 2% !important;">
                                                <button class="setting_save_gallery"></button>
                                                <button class="btn-cancel-article1 setting_cancel_gallery"></button>
                                            </div>
                                        </div>
                                    
                                        <!-- <div class="text-left">
                                            <label>GALLERY Image</label>
                                        </div> -->
                                        <div class="form-body _grey">
                                            <label>Image</label>
                                            <div class="album-box" style="position: relative;">
                                                <div id="upload_gallery" class="btn-upload">
                                                    <input type="hidden" name="_token" value="{!! csrf_token() !!}">
                                                    <input type="hidden" name="id" id="id-edit1">
                                                    <input type="file" name="imagesg[]" id="btn_add_gallery-edit1" accept="gif|jpg|png|jpeg" maxlength="5" class="multi with-preview"/>
                                                    <!-- <img src="" id="img-edit-preview1" style="max-height:100px; max-width:100px;"> -->
                                                </div>
                                            </div><br>
                                            <div class="form-group">
                                                <label>Description</label>
                                            </div>
                                            <textarea name="description" id="content-edit1" class="form-control" placeholder="description"></textarea>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <br>
                            <br>
                            @endif

                            <div id="gallery-foto" class="flex-images">
                                @foreach($galleries as $gallery)
                                <a title='{{date("d M Y",strtotime($gallery->created_at))}}' href='{{url("uploads")}}/{{$gallery->content}}' data-sub-html='

                                    <div style="overflow-y: auto; height: 98px;">
                                        <spna style="float: left; text-align:left;">{{$gallery->description}}
                                        </spna>
                                    </div>'>
                                    <?php
                                        $url = "{url('uploads')}/{$gallery->content}";
                                        $pathinfo = pathinfo($url);
                                    ?>
                                    <img src='{{url("uploads")}}/{{$gallery->content}}'>
                                </a>
                                @endforeach
                            </div>
                        </div>
                        <!-- End GALLREY IMAGE -->

                        <!-- WASHOP IMAGE -->
                        @if($user_setting->washop_enable)
                        <div role="tabpanel" class="tab-pane " id="byimage">
                            @if(Auth::check())
                            <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>
                            <div class="backend-box">
                                <div class="form-top create-article">
                                    <br><br>
                                    <div class="text-left">
                                        <label>WASHOP</label>
                                    </div>
                                    <ul class="form-nav">
                                        <a href="#" class="new-article"><img src="{{url('')}}/images//nav3.png"/></a>
                                    </ul>
                                </div>  
                                <div class="form-body create-article">
                                    <div class="notes-box">
                                        <ul>
                                            @foreach($galleriesProduct as $data)
                                            <li>
                                                <div class="notes-desc">
                                                    <p><b>{{$no1++}}.
                                                        @if(strlen($data->tittle)>=15)
                                                            {{substr($data->tittle,0,20)}}....
                                                        @else
                                                            {{$data->tittle}}
                                                        @endif
                                                    </b></p>
                                                    <p class="date">
                                                        @if(date("Y",strtotime($data->updated_at))=="1970") 
                                                            <i class="fa fa-calendar"></i> {{date("d M Y H:i",strtotime($data->created_at))}}
                                                        @else
                                                            <i class="fa fa-calendar-plus-o"></i> {{date("d M Y H:i",strtotime($data->updated_at))}}
                                                        @endif
                                                    </p>
                                                </div>
                                                <div class="notes-nav">
                                                    <a href="#" class="btn btn-green btn-act-delete" onclick="deleteTimeLine(this)" data-id="{{$data->id}}" data-type="gallery">
                                                        <img src="{{url('')}}/images//icon-trash.png"/>
                                                    </a>
                                                    <a href="#" class="btn btn-green btn-act-edit" data-id="{{$data->id}}" data-tittle="{{$data->tittle}}" data-price="{{$data->price}}" data-img="{{$data->content}}" data-content="{{$data->description}}"><i class="fa fa-pencil"></i></a>
                                                </div>
                                            </li>
                                            @endforeach
                                        </ul>
                                    </div>
                                </div>
                                <div class="backend-form create-article-form" style="display:none;">

                                    <form role="form" method="post" id="form_upload_img_gallery" enctype="multipart/form-data" action="{{url('/home/gallery')}}">
                                        <div class="form-top">
                                            <div class="form-left">
                                                <label>Create WASHOP</label>
                                            </div>
                                            <div class="form-right" style="padding-right: 2% !important;">
                                                <button class="setting_save_gallery"></button>
                                                <button class="btn-cancel-article setting_cancel_gallery"></button>
                                            </div>
                                        </div>
                                        <div class="form-body _grey">
                                            <label>Image</label>
                                            <div class="album-box" style="position: relative;">
                                                <div id="upload_gallery" class="btn-upload">
                                                    <input type="hidden" name="_token" value="{!! csrf_token() !!}">
                                                    <input type="hidden" name="id">
                                                    <input type="file" name="images[]" id="btn_add_gallery" accept="gif|jpg|png|jpeg" maxlength="5" class="multi with-preview" onchange="washopImg(this)" />
                                                </div>
                                            </div><br>
                                            <label>Title</label>
                                            <input type="tex" name="title" id="title" class="form-control" required placeholder="Image Title"><br>
                                        
                                            <label>Price</label>
                                            <input type="number" name="price" id="price" class="form-control" required placeholder="Price"><br>
                                            
                                            <div class="form-group">
                                                <label>Description</label>
                                            </div>
                                            <textarea name="description" id="description" class="form-control" placeholder="description"></textarea>
                                        </div>
                                    </form>
                                </div>
                                <div class="backend-form edit-article-form " style="display:none;">
                                    <form role="form" method="post" id="form_upload_img_gallery" enctype="multipart/form-data" action="{{url('/home/gallery')}}">
                                        <div class="form-top">
                                            <div class="form-left">
                                                <label>Edit WASHOP</label>
                                            </div>
                                            <div class="form-right" style="padding-right: 2% !important;">
                                                <button class="setting_save_gallery"></button>
                                                <button class="btn-cancel-article setting_cancel_gallery"></button>
                                            </div>
                                        </div>
                                   
                                        <!-- <div class="text-left">
                                            <label>WASHOP Image</label>
                                        </div> -->
                                        <div class="form-body _grey">
                                            <label>Image</label>
                                            <div class="album-box" style="position: relative;">
                                                <div id="upload_gallery" class="btn-upload">
                                                    <input type="hidden" name="_token" value="{!! csrf_token() !!}">
                                                    <input type="hidden" name="id" id="id-edit">
                                                    <input type="file" name="images[]" id="btn_add_gallery-edit" accept="gif|jpg|png|jpeg" maxlength="5" class="multi with-preview"/>
                                                    <!-- <img src="" id="img-edit-preview" style="max-height:100px; max-width:100px;"> -->
                                                </div>
                                            </div><br>
                                            <label>Title</label>
                                            <input type="tex" name="title" id="tittle-edit" class="form-control" required placeholder="Image Title"><br>
                                        
                                            <label>Price</label>
                                            <input type="number" name="price" id="price-edit" class="form-control" required placeholder="Price"><br>
                                            
                                            <div class="form-group">
                                                <label>Description</label>
                                            </div>
                                            <textarea name="description" id="content-edit" class="form-control" placeholder="description"></textarea>
                                        </div>
                                    </form> 
                                </div>
                            </div>
                            <br><br>
                            @endif
                            <div id="washopimg" class="flex-images">
                                <!-- $galleriesProduct -->
                                @foreach($galleriesProduct as $galleryp)
                                <?php
                                    $childImage = DB::table('timeline')->where('parent_id', $galleryp->id)->select('id','content')->get();
                                ?>
                                    <a id="disclaimer" href='{{url("uploads")}}/{{$galleryp->content}}' data-lightbox="example-set" data-title='
                                        <div>
                                            <span style="display: inline" class="abcd">{{$galleryp->tittle}}<br>
                                                Price 
                                                <span>
                                                    <?php if(!isset($_COOKIE['currency'])) { echo ' IDR'; } 
                                                        else { echo $_COOKIE["currency"]; } ?>
                                                    <?php if(!isset($_COOKIE['price'])) { echo $galleryp->price; } 
                                                        else { echo round($_COOKIE["price"]*$galleryp->price,4); } ?>
                                                </span>
                                            </span> 
                                            <button class="btn btn-primary" onclick="wamodal({{$galleryp->id}},{{$galleryp->price}},this)" style=" margin: 0 0 4px 10px; width: 60px; height: 21px; padding:0px; border-radius:12px; ">Buy</button>
                                            <br>
                                            <span class="prod-description">{{$galleryp->description}} </span>
                                        </div><br>
                                        <div style="overflow-y: auto; height: 500px; border-radius:12px ">

                                            @foreach($childImage as $data)
                                            <img src="{{url("uploads")}}/{{$data->content}}" style="width: 100%; border: 2px solid #fff;border-radius: 10px;">
                                            @endforeach
                                        </div>
                                        '>
                                        <?php
                                         $url = "{url('uploads')}/{$galleryp->content}";
                                            $pathinfo = pathinfo($url);
                                        ?>
                                       
                                        <img src='{{url("uploads")}}/{{$galleryp->content}}' style="z-index: -1">
                                        <button class="btn-info" style="position: absolute; bottom: 0px;">Buy</button>
                                    </a>
                                @endforeach
                            </div>
                        </div>
                        @endif
                        <!-- End WASHOP IMAGE -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="content-profile">
         <div class="placeholder transparent inner-section-container" id="backend-placeholder">

                <div class="tab-content backend-detail slimScroll" data-minus="150">

                    <div class="placeholder-first placeholder-header" id="grey-article">

                        <!-- <div class="placeholder-header">

                            <h3>{{$user['full_name']}} </h3>
                            
                            <br>
                        </div> -->

                        
                        <a class="btn-cancels" id="btn-cancels"><span class="glyphicon glyphicon-remove"></span></a>
                        <!--<div class="clrbth"></div><div class="tab-content backend-detail slimScroll" data-total="2" data-minus="270">-->

                        <div class="content-placeholder object-video">

                        </div>

                        <div style="clear:both;"></div>

                        <div class="placeholder-footer action">

                            <a class="first btn-act-like" onclick="likeTimeLine(this)">
                                <span class="glyphicon glyphicon-thumps-up"></span>
                                <span id="timline_count" style='font-size: 10px !important;'></span>
                            </a>
                            <a class="second"></a>
                            @if(Auth::check())
                            <a class="third btn-act-delete" onclick="deleteTimeLine(this)"><span class="glyphicon glyphicon-trash"></span> </a>
                            @endif

                            <div class="fb-comment form-group"></div>

                            <div style="clear:both;"></div>

                        </div>

                    </div>

                    <div class="placeholder-second placeholder _grey" style="display:none;">

                        <div class="placeholder-header-email">

                            <h3>Email Us</h3>

                            <a class="btn-cancel-video"><span class="glyphicon glyphicon-remove"></span></a>

                        </div>

                        @include("soulfy/partial/placeholder_email")

                    </div>

                    <div class="placeholder-third clearfix" style="display:none;">

                        <div class="card-box">

                            @include("soulfy/partial/bcard")

                        </div>

                        <div class="footer"></div>

                    </div>

                </div>

            </div>
    </section>

    <!-- WA Modal Start -->
    <div aria-hidden="false" style="display: none; background: #FFF;" id="wa_modal" class="modal fade in" tabindex="-1" data-focus-on="input:first">
        <div role="form" class="form-create" method="post">
            <div class="modal-header">
                <span class="close cursor" onclick="waclose()">&times;</span>
                <h4 class="modal-title">WhatsApp Details</h4>
            </div>
            <input type="hidden" name="imgId" id="imgId">
            <input type="hidden" name="imgPrice" id="imgPrice">
            <input type="hidden" name="imgDescription" id="imgDescription">
            <div class="modal-body">
                <div class="form-group">
                    <div class="col-group">
                        <input type="text" name="wa_username" id="wa_username" placeholder="Enter User Name" style="border: 1px solid #F1F1F1; width: 100%;"/>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-group col-sm-4">
                        <select style="border: 1px solid #F1F1F1; width: 100%; height: 40px;"/ name="countryCode" id="countryCode">
                            <option value="">Select Country Code</option>
                            @foreach($countries as $cont)
                                <option value="{{$cont->countries_isd_code}}">{{$cont->countries_name}}(+{{$cont->countries_isd_code}})</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-group col-sm-8">
                        <input type="number" name="wa_number" id="wa_number" placeholder="Enter WhatsApp Number" style="border: 1px solid #F1F1F1; width: 100%;"/><br>
                        <span style="color: #e65f5f">Enter WhatsApp Number Without Zero(0).</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success" id="wabtn">Proceed</button>
            </div>
            <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
        </div>
    </div>

@endsection

@section('js')

    {{--<script type="text/javascript" src="{{url('')}}/js/jquery.fancybox.js?v=2.1.5"></script>--}}
    <script type="text/javascript" src="{{url('')}}/js/flex_image/jquery.flex-images.min.js"></script>
    <script src="{{url()}}/js/gallery/js/lightgallery.js"></script>
    <script src="{{url()}}/js/justified/js/jquery.justifiedGallery.min.js"></script>

    <!-- lightgallery plugins -->
    <script src="{{url()}}/js/gallery/js/lg-thumbnail.js"></script>
    <script src="{{url()}}/js/gallery/js/lg-fullscreen.js"></script>
    <script src="{{url()}}/js/gallery/js/lg-zoom.js"></script>
    <script src="{{url()}}/js/gallery/js/lg-video.js"></script>
    <script src="{{url()}}/js/gallery/js/lg-autoplay.js"></script>
    <script> 
    
    CKEDITOR.replace( 'description'); 

    $('.btn-act-edit').on('focusout', function(){
    $(this).ckeditor(function(){
        this.destroy();
    });
});
</script>
    <script type="text/javascript">

        /*$(function() {
            CKEDITOR.replace('content-edit',{
            height: 150,
            allowedContent:true,
            extraAllowedContent: 'iframe[*]',
            extraAllowedContent: 'p[*] h1[*] h2[*] h3[*] h4[*] h5[*] h6[*] span[*] div[*] img[*] a[*]',
            extraAllowedContent: 'locationmap',
            extraAllowedContent : 'embed,embedsemantic,autoembed,autolink',
            });
        });

        $(function() {
            CKEDITOR.replace('description',{
            height: 150,
            allowedContent:true,
            extraAllowedContent: 'iframe[*]',
            extraAllowedContent: 'p[*] h1[*] h2[*] h3[*] h4[*] h5[*] h6[*] span[*] div[*] img[*] a[*]',
            extraAllowedContent: 'locationmap',
            extraAllowedContent : 'embed,embedsemantic,autoembed,autolink',
            });
        });*/

        $(".edit-article-form").hide();
        $(".create-article-form").hide();

        $(".new-article").click(function(e){
            e.preventDefault();
            $(".create-article").hide();
            $(".create-article-form").fadeIn();
        });
        $(".btn-cancel-article").click(function(e){
            e.preventDefault();
            $(".edit-article-form").hide();
            $(".create-article").fadeIn();
            $(".create-article-form").hide();
        });
        $(".btn-act-edit").click(function(e){
            e.preventDefault();
            var id = $(this).attr("data-id"),
            tittle = $(this).attr("data-tittle"),
            price = $(this).attr('data-price'),
            attachment = $(this).attr("data-attachment"),
            img = $(this).attr("data-img"),
            content = $(this).attr("data-content");            
            $(".create-article").hide();
            $(".edit-article-form").fadeIn();
            $("#id-edit").val(id);
            $("#tittle-edit").val(tittle);
            $("#price-edit").val(price);
            $("#content-edit").val(content);
            CKEDITOR.replace( 'content-edit');
            $('#btn_add_gallery-edit').empty();
            $('#btn_add_gallery-edit').append('<img src="//<?php echo  $domain ?>/uploads/'+img+'" id="img-edit-preview1" style="max-height:100px; max-width:100px;" name="editimg">');
        });

        $(".edit-article-form1").hide();
        $(".create-article-form1").hide();

        $(".new-article1").click(function(e){
            e.preventDefault();
            $(".create-article1").hide();
            $(".create-article-form1").fadeIn();
        });
        $(".btn-cancel-article1").click(function(e){
            e.preventDefault();
            $(".edit-article-form1").hide();
            $(".create-article1").fadeIn();
            $(".create-article-form1").hide();
        });
        $(".btn-act-edit1").click(function(e){
            e.preventDefault();
            var id = $(this).attr("data-id"),
            img = $(this).attr("data-img"),
            content = $(this).attr("data-content");            
            $(".create-article1").hide();
            $(".edit-article-form1").fadeIn();
            $("#id-edit1").val(id);
            $("#content-edit1").val(content);
            $('#btn_add_gallery-edit1').empty();
            $('#btn_add_gallery-edit1').append('<img src="//<?php echo  $domain ?>/uploads/'+img+'" id="img-edit-preview1" style="max-height:100px; max-width:100px;" name="editimg">');
        });


    </script>

    <script src="{{url('')}}/js/lightslider.min.js"></script>

    {{--<script type="text/javascript">--}}
    {{--$(document).ready(function() {--}}
    {{--$('.gallery1').lightSlider({--}}
    {{--keyPress:false,--}}
    {{--item:5,--}}
    {{--loop:true,--}}
    {{--pager:false,--}}
    {{--slideMargin: 0,--}}
    {{--onSliderLoad: function() {--}}
    {{--$('.gallery1').removeClass('cS-hidden');--}}
    {{--}--}}
    {{--});--}}
    {{--$('.gallery2').lightSlider({--}}
    {{--keyPress:false,--}}
    {{--item:5,--}}
    {{--loop:true,--}}
    {{--pager:false,--}}
    {{--slideMargin: 0,--}}
    {{--onSliderLoad: function() {--}}
    {{--$('.gallery2').removeClass('cS-hidden');--}}
    {{--}--}}
    {{--});--}}
    {{--$('.gallery3').lightSlider({--}}
    {{--keyPress:false,--}}
    {{--item:5,--}}
    {{--loop:true,--}}
    {{--pager:false,--}}
    {{--slideMargin: 0,--}}
    {{--onSliderLoad: function() {--}}
    {{--$('.gallery3').removeClass('cS-hidden');--}}
    {{--}--}}
    {{--});--}}
    {{--$('.gallery4').lightSlider({--}}
    {{--keyPress:false,--}}
    {{--item:5,--}}
    {{--loop:true,--}}
    {{--pager:false,--}}
    {{--slideMargin: 0,--}}
    {{--onSliderLoad: function() {--}}
    {{--$('.gallery4').removeClass('cS-hidden');--}}
    {{--}--}}
    {{--});--}}
    {{--$('.gallery5').lightSlider({--}}
    {{--keyPress:false,--}}
    {{--item:5,--}}
    {{--loop:true,--}}
    {{--pager:false,--}}
    {{--slideMargin: 0,--}}
    {{--onSliderLoad: function() {--}}
    {{--$('.gallery5').removeClass('cS-hidden');--}}
    {{--}--}}
    {{--});--}}
    {{--});--}}
    {{--</script>--}}
<script>

    function wamodal(picID,price, obj){
        document.getElementById("wa_modal").style.display = "block";
        document.getElementById("imgId").value = picID;
        document.getElementById("imgPrice").value = price;
        document.getElementById("imgDescription").value = $(obj).parent().find('.prod-description').text();
        
    }

    function waclose(){
        document.getElementById('wa_modal').style.display = 'none';
    }

    var $animThumbs = $('#washopimg');
    if ($animThumbs.length) {
        $animThumbs.justifiedGallery({
            border: 6,
                    margins: 10,
        }).on('jg.complete', function () {
        });
    }
    var $animThumb = $('#gallery-foto');
    if ($animThumb.length) {
        $animThumb.justifiedGallery({
            border: 6,
            margins: 10,
            captions: true
        }).on('jg.complete', function () {
            $animThumb.lightGallery({
                thumbnail: true
            });
        });
    };
    /*var $animThumb = $('#galery-foto');
    if ($animThumb.length) {
        $animThumb.justifiedGallery({
            border: 6,
            margins: 10,
            captions: true
        }).on('jg.complete', function () {
            $animThumb.lightGallery({
                thumbnail: true
            });
        });
    };*/

</script>
<script type="text/javascript">

    $('#disclaimer')
        .css('cursor', 'pointer')
        .click(function(e) {
            e.preventDefault();
            $('body').css('overflow', 'hidden');
        });
    $('.lb-close')
        .css('cursor', 'pointer')
        .click(function(e) {
            e.preventDefault();
            $('body').css('overflow', 'auto');
        });
</script>
<script type="text/javascript">
    function washopImg(e){
        var a=(e.files[0].size);
        if(a > 1703837) {
            alert('please choose 1.5MB image Size');
            $('.setting_save_gallery').hide();
        }else{
            $('.setting_save_gallery').show();
        }
    }

    function galleryImg(e){
        var a=(e.files[0].size);
        if(a > 1703837) {
            alert('please choose 1.5MB image Size');
            $('.setting_save_gallery').hide();
        }else{
            $('.setting_save_gallery').show();
        }
    }


    /*
    $('#btn_add_gallery').on('change', function() {
        var a=(this.files[0].size);
        alert(a+'inside'); 
        if(a > 1703837) {
            alert(a+'right');
            alert('please choose 1.5MB image Size');
            $('.setting_save_gallery').css('display','none');
        }else{
            alert(a+'left');
            alert('please choose 1.5MB image Size');
            $('.setting_save_gallery').css('display','block');
        }
    });*/

    $("#wabtn").click(function () {
        var zNumber = $('#wa_number').val();
        if(zNumber.slice(0,1) == "0"){
            pesanErr("cannot start with  zeroe");
        }
        else if(!$('#wa_number').val().match('[0-9]{8}'))  {
            pesanErr("please put a valid mobile number");
        }
        else
        {
            var imageId = $('#imgId').val();
            var waUsername = $('#wa_username').val();
            var countryCode = $('#countryCode').val();
            var waNumber = $('#wa_number').val();
            var imgPrice = $('#imgPrice').val();
            var imgDescription = $('#imgDescription').val();

            $.ajax({
               method: "POST",
                url: '{{action("ImageController@postWadetails")}}',
                data: { 
                    imageId : imageId ,
                    imgPrice : imgPrice ,
                    waUsername : waUsername ,
                    countryCode : countryCode ,
                    waNumber : waNumber ,
                    _token: '{{csrf_token()}}' 
                },

                success: function (response) {
                    var obj  = JSON.parse(response)
                    if (obj.message =="error") {
                        pesanErr("Please enter all the details");
                    }
                    else if (obj.message=="uexist"){
                        pesanErr('username already exist');
                    }
                    else if (obj.message=="nexist"){
                        pesanErr('number already exist');
                    }
                    else if (obj.message=="success"){
                        pesanOk('successful');
                        var number = {{$user_setting->wa_number}};
                        window.open('https://api.whatsapp.com/send?phone='+number+'&text='+imgDescription+' - IDR '+imgPrice, '_blank');
                        setTimeout(function() {
                            location.reload();
                        }, 10000);
                    }
                    else if(obj.message=="add"){
                        pesanOk('Add Successfully');
                        var number = {{$user_setting->wa_number}};
                        window.open('https://api.whatsapp.com/send?phone='+number+'&text='+imgDescription+' - IDR '+imgPrice, '_blank');
                        setTimeout(function() {
                            location.reload();
                        }, 10000);
                    }
                },
            })
        }
    });
    
    $(document).ready(function() {
        $('.status-box #status_content').each(function() {
           if($(this).find('img').length) {
               $(this).css('padding','0 0 0 4px')
           } 
        });
    });
</script>

@endsection
