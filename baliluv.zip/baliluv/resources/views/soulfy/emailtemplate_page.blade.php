<!DOCTYPE html>
  <html lang="en">
    <head>
        <title>Bootstrap Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <style>
          /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
          .row.content {height: 1500px}
          /* Set gray background color and 100% height */
          .sidenav {
          background-color: #f1f1f1;
          height: 100%;
          }
          /* Set black background color, white text and some padding */
          footer {
          background-color: #555;
          color: white;
          padding: 15px;
          }
          /* On small screens, set height to 'auto' for sidenav and grid */
          @media screen and (max-width: 767px) {
          .sidenav {
          height: auto;
          padding: 15px;
          }
          .row.content {height: auto;} 
          }
        </style>
    </head>
    <body>
        <div class="container-fluid">
          <div class="row content">
            <div class="col-sm-3 sidenav">
              <ul class="nav nav-pills nav-stacked">
                  <li class="active" style="text-align: left;display: block;float:unset;"><a id="tab_social" href="#social" aria-controls="social" role="tab" data-toggle="tab">dashboard</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="followers" role="tab" data-toggle="tab" class="capitalized">calender</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Appointments</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">services</a></li>
                  <ul>
                    <li style="text-align: left;display: block;float:unset;"><a href="admin/category" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Category Master</a></li>
                    <li style="text-align: left;display: block;float:unset;"><a href="admin/service" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Services Master</a></li>
                  </ul>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Agents</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Coupons</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Email & reminder</a></li>
                  <ul>
                    <li style="text-align: left;display: block;float:unset;"><a href="admin/email-template" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Email Templates</a></li>
                    <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Remainders</a></li>
                  </ul>
              </ul>
              <br>
            </div>

            <div class="tab-content common-tab-section min-height-480">

<div id="live-tab" class="tab-pane fade" style="opacity:1; display:block;">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
        <h1 class="head-name">Template</h1>
        <div class="float-right">
            <button class="white-btn" onclick="window.location.href='/baliluv_public/admin/email-template/add';"> + Add
                Email Template</button>
        </div>
    </div>


    <!-- form -->
    <div class="content-main form-dashboard">
        <form>

            <div class="table-responsive text-center message-table">
                <table id="example" class="table table-bordered table-style" style="width: 100%">
                    <thead>
                        <tr>
                            <th>Email Code</th>
                            <th>Email Name</th>
                            <th>Email Subject</th>
                            <th>E-Mail-Titel</th>
                            <th>Action</th>
                        </tr>
                        <tbody>
                           
                        </tbody>
                    </thead>

                </table>
            </div>
        </form>
    </div>
    <!--end form-->
</div> <!-- dropshipping-products -->

</div>
          </div>
        </div>
      </div>
    </body>
  </html>
  @section('extra_js')
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script>
    $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
    }
    });
    
    $('#servicesubmit').click(function(e){ 
    
    e.preventDefault();  
    //var formData =  new FormData(document.getElementById("templateForm"));
    
    var _token = $("input[name='_token']").val();
    var title = $("input[name='title']").val();
    var content = $("input[name='content']").val();
    var price = $("input[name='price']").val();
    var duration = $("input[name='duration']").val();
    
    //let email_code = $('#email_code').val();
    //let title = $('#title').val();
    //let subject = $('#subject').val();
    //let content = $('#content').val();
    $.ajax({
        //url: "/admin/service",
        //data: formData,
    
        data:{
            _token:_token,
            title:title,
            content:content,
            price:price,
            duration:duration,
          },
        processData: false,
        contentType: false,
        dataType: 'json',
        type: $('#serviceForm').attr('method'),
        success: function(data)
        
          {
            alert(data);
            if($.isEmptyObject(data.error)){
                    alert(data.success);
                }else{
                    printErrorMsg(data.error);
                }
    
            //alert(response);
    
            // console.log(response.msg.password[0]);
          
            /*if(response.flag == 1) {
                        swal({
                            text: response.msg,
                            button: false,
                            icon: 'success'
                          }) 
            }
            else {
                        swal({                            
                            text: response.msg,
                            button: false,
                            icon: 'error'
                          })
                          return false;
                }
            */
        },
        /* error: function (response) {
                      console.log(response);
        } */
    })
        
    });
    
    
    function printErrorMsg (msg) {
        $(".print-error-msg").find("ul").html('');
        $(".print-error-msg").css('display','block');
        $.each( msg, function( key, value ) {
            $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
    });

    };
  </script>

  
  <!--</div>-->