<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 8/16/2015
 * Time: 5:44 PM
 */

        ?>



@extends('soulfy')
@section('title', 'Home')
@section('content')
    <section id="content-desc">
        <div class="container">
            <div class="row">
                <h3>Amie Lee Johnson</h3>
                <div class="content-about">
                    <p>
                        Before photography was created, people already knew the priciples of how it eventually got to work.<br/>
                        They could process the image on the wall or piece of paper, however no printing was possible at the time.
                    </p>
                    <p>
                        As preserving light turned out to be a lot harder task than projecting it. The instrument that people used for processing pictures was called the Camera Obscura (which is Latin for the Dark Room) and it was around for a few centuries before photography came along.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section id="content">
        <div class="container">
            <div class="row">
                <div class="selector">
                    <ul class="social-media-box">
                        <li>
                            <input id="c1" type="checkbox">
                            <label for="c1"><a href="#"><img src="{{url(".")}}/images/button-green_01.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c2" type="checkbox">
                            <label for="c2"><a href="#"><img src="{{url(".")}}/images/button-green_02.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c3" type="checkbox">
                            <label for="c3"><a href="#"><img src="{{url(".")}}/images/button-green_3.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c4" type="checkbox">
                            <label for="c4"><a href="#"><img src="{{url(".")}}/images/button-green_4.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c5" type="checkbox">
                            <label for="c5"><a href="#"><img src="{{url(".")}}/images/button-green_5.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c6" type="checkbox">
                            <label for="c6"><a href="#"><img src="{{url(".")}}/images/button-green_6.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c7" type="checkbox">
                            <label for="c7"><a href="#"><img src="{{url(".")}}/images/button-green_7.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c8" type="checkbox">
                            <label for="c8"><a href="#"><img src="{{url(".")}}/images/button-green_8.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c8" type="checkbox">
                            <label for="c8"><a href="#"><img src="{{url(".")}}/images/button-green_9.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c8" type="checkbox">
                            <label for="c8"><a href="#"><img src="{{url(".")}}/images/button-green_10.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c8" type="checkbox">
                            <label for="c8"><a href="#"><img src="{{url(".")}}/images/button-green_11.resized.png"/></a></label>
                        </li>
                    </ul>
                    <button><span><img src="{{url(".")}}/images/user1.png"/></span></button>
                </div>
            </div>
        </div>
        <div class="stats-box stats1">
            <div class="stats stats-fb">
                <p>
                    Hello World!!<br/>
                    Let the world know
                </p>
                <span class="left">Jakarta</span>
                <span class="right">2 Juni 2015</span>
                <div class="stats-nav">
                    <a href="#" class="btn-circle btn1">C</a>
                    <a href="#" class="btn-circle btn2">L</a>
                </div>
            </div>
        </div>
        <div class="stats-box stats2">
            <div class="stats stats-twitter">
                <p>
                    Apa Kabar Dunia<br/>
                    Hong Kong Hujan Nih
                </p>
                <span class="left">Jakarta</span>
                <span class="right">2 Juni 2015</span>
                <div class="stats-nav">
                    <a href="#" class="btn-circle btn1">C</a>
                    <a href="#" class="btn-circle btn2">L</a>
                </div>
            </div>
        </div>
    </section>

@endsection

