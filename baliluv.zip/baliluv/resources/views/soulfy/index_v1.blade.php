<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 8/17/2015
 * Time: 4:00 PM
 */
$user = Auth::User();
?>


        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="{{ \DB::table('meta')->where('meta_id', 1)->first()->meta_description }}">
    <meta name="author" content="">
    <meta name="csrf-token" content="{{ csrf_token() }}"/>

    <title>Soulfy Web- Template</title>
    <!-- Custom styles for this template -->


    <link rel="stylesheet" href="{{url(".")}}/css/bootstrap.min.css">

    <!-- Optional theme -->
    <link rel="stylesheet" href="{{url(".")}}/css/bootstrap-theme.min.css">

    <link href="{{url('')}}/css/style_2.css" rel="stylesheet"/>
    <link href="{{url('')}}/css/demo.html5imageupload.css" rel="stylesheet"/>
    <link href="{{url('')}}/js/croppic/croppic.css" rel="stylesheet"/>

    <!--[if lt IE 9]>
    <link href="css/ie.css" rel="stylesheet"/>
    <script src="{{url('')}}/js/html5shiv.js" type="text/javascript"></script>
    <script src="{{url('')}}/js/respond.js" type="text/javascript"></script>
    <![endif]-->
    <!--[if lt IE 10]>
    <link href="css/ie.css" rel="stylesheet"/>
    <script src="{{url('')}}/js/html5shiv.js" type="text/javascript"></script>
    <script src="{{url('')}}/js/respond.js" type="text/javascript"></script>
    <![endif]-->

</head>
<body id="home">
<header style="position: fixed; top: 0px; width: 100%; z-index: 100;">
    <div class="" style="">
        <div class="row">
            <div class="nav-header">
                @if(Auth::check())
                    <form class="form-inline" id="form_login" method="post" action="{{ url('/auth/login') }}">

                        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
                        <ul class="nav-right">
                            <li>
                                <div class="form-group ">
                                    <span class="control-header">Welcome {{Auth::User()->full_name}}</span>
                                </div>


                            <li>
                                <h3>
                                    <h3><a href="{{url('/auth/logout')}}">Logout</a></h3>

                                </h3>
                            </li>

                            <li class="logo-box">
                                <a href="#"><img src="{{url(".")}}/images/logo.png"/></a>
                            </lI>
                        </ul>
                    </form>

                @else
                    <form class="form-inline" id="form_login" method="post" action="{{ url('/auth/login') }}">

                        <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
                        <ul class="nav-right">
                            <li>
                                <div class="form-group">
                                    <span class="control-header">email</span>
                                    <span><input type="text" name="email" required class="form-control"/></span>
                                </div>
                            </li>
                            <li>
                                <div class="form-group">
                                    <span class="control-header">password</span>
                                    <span><input type="password" name="password" required class="form-control"/></span>
                                </div>
                            </li>
                            <li>
                                <h3>
                                    <button type="submit" id="btn_login">login</button>
                                </h3>
                            </li>
                            <li class="logo-box">
                                <a href="#"><img src="{{url(".")}}/images/logo.png"/></a>
                            </lI>
                        </ul>
                    </form>
                @endif
            </div>
        </div>
    </div>
</header>

<div id="content_body" style="position: static">
    <section id="content-desc">
        <div class="container">
            <div class="row">
                <h3>Amie Lee Johnson</h3>

                <div class="content-about">
                    <p>
                        Before photography was created, people already knew the priciples of how it eventually got to
                        work.<br/>
                        They could process the image on the wall or piece of paper, however no printing was possible at
                        the
                        time.
                    </p>

                    <p>
                        As preserving light turned out to be a lot harder task than projecting it. The instrument that
                        people used for processing pictures was called the Camera Obscura (which is Latin for the Dark
                        Room)
                        and it was around for a few centuries before photography came along.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section id="content">
        <div class="container">
            <div class="row">
                <div class="selector">
                    <ul class="social-media-box">
                        <li>
                            <input id="c1" type="checkbox">
                            <label for="c1"><a href="#"><img src="{{url(".")}}/images/button-green_01.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c2" type="checkbox">
                            <label for="c2"><a href="{{action('HomeController@getFacebook')}}"><img
                                            src="{{url(".")}}/images/button-green_02.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c3" type="checkbox">
                            <label for="c3"><a href="#"><img src="{{url(".")}}/images/button-green_3.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c4" type="checkbox">
                            <label for="c4"><a href="#"><img src="{{url(".")}}/images/button-green_4.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c5" type="checkbox">
                            <label for="c5"><a href="#"><img src="{{url(".")}}/images/button-green_5.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c6" type="checkbox">
                            <label for="c6"><a href="#"><img src="{{url(".")}}/images/button-green_6.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c7" type="checkbox">
                            <label for="c7"><a href="#"><img src="{{url(".")}}/images/button-green_7.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c8" type="checkbox">
                            <label for="c8"><a href="#"><img src="{{url(".")}}/images/button-green_8.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c8" type="checkbox">
                            <label for="c8"><a href="#"><img src="{{url(".")}}/images/button-green_9.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c8" type="checkbox">
                            <label for="c8"><a href="#"><img src="{{url(".")}}/images/button-green_10.resized.png"/></a></label>
                        </li>
                        <li>
                            <input id="c8" type="checkbox">
                            <label for="c8"><a href="#"><img src="{{url(".")}}/images/button-green_11.resized.png"/></a></label>
                        </li>
                    </ul>
                    <div id="profile_image">
                        <button>
                            <span>
                               <div id="prossfile_pict">

                                   @if(Auth::check())
                                       <img id="profile_picture" src="{{url(".")}}/{{$user->image_profile}}"/>
                                   @else
                                       <img id="profile_picture" src="{{url(".")}}/images/user1.png"/>
                                   @endif

                               </div>

                            </span>
                        </button>
                        {{--<div class="dropzone" id="edit_image" data-width="176" data-height="174" data-resize="true" data-url="{{action('AjaxController@postUploadProfile')}}" style="width: 176px;height: 174px;left: 0px;display: none;">--}}
                        {{--<input type="file" id="profilefileupload" name="thumb" />--}}
                        {{--</div>--}}
                        <div id="image_upload"></div>
                        <div id="profile_image_edit" style="display: none;">
                            <a href="#" id="btn_upload" onclick="javascript:editProfile();" class="btn btn-info btn-sm"><span
                                        class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                        </div>

                        {{--<div id="profile_pict" class="dropzone" data-resize="true" data-url="canvas.php">--}}
                        {{--<img src="{{url(".")}}/images/user1.png"/>--}}
                        {{--<input type="file" id="profilefileupload" name="thumb" />--}}
                        {{--</div>--}}
                    </div>
                </div>
            </div>
        </div>
        <!--<div class="stats-box stats1">-->
        <!--<div class="stats stats-fb">-->
        <!--<p>-->
        <!--Hello World!!<br/>-->
        <!--Let the world know-->
        <!--</p>-->
        <!--<span class="left">Jakarta</span>-->
        <!--<span class="right">2 Juni 2015</span>-->
        <!--<div class="stats-nav">-->
        <!--<a href="#" class="btn-circle btn1">C</a>-->
        <!--<a href="#" class="btn-circle btn2">L</a>-->
        <!--</div>-->
        <!--</div>-->
        <!--</div>-->
        <!--<div class="stats-box stats2">-->
        <!--<div class="stats stats-twitter">-->
        <!--<p>-->
        <!--Apa Kabar Dunia<br/>-->
        <!--Hong Kong Hujan Nih-->
        <!--</p>-->
        <!--<span class="left">Jakarta</span>-->
        <!--<span class="right">2 Juni 2015</span>-->
        <!--<div class="stats-nav">-->
        <!--<a href="#" class="btn-circle btn1">C</a>-->
        <!--<a href="#" class="btn-circle btn2">L</a>-->
        <!--</div>-->
        <!--</div>-->
        <!--</div>-->
        <div id="status_container"></div>

    </section>
</div>


<!-- JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script type="text/javascript" src="{{url('')}}/js/jquery-1.10.2.min.js"></script>
<script src="{{url('')}}/js/bootstrap.min.js"></script>
<script src="{{url('')}}/js/jquery.form.min.js"></script>
<script src="{{url('')}}/js/jquery.bootstrap-growl.min.js"></script>
<script type="text/javascript" src="{{url('')}}/js/jquery.scrollme.min.js"></script>
<script type="text/javascript" src="{{url('')}}/js/jquery.mousewheel.min.js"></script>
<script type="text/javascript" src="{{url('')}}/js/jquery.transform2d.js"></script>
<script type="text/javascript" src="{{url('')}}/js/html5imageupload.min.js"></script>
<script type="text/javascript" src="{{url('')}}/js/croppic/croppic.js"></script>

<script type="text/javascript">

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var cropperOptions = {
        customUploadButtonId: 'btn_upload',
        outputImageId: 'profile_picture',
        onBeforeImgUpload: function () {
            $("#image_upload").css('display', 'block');
        },
        onAfterImgUpload: function () {
            $("#image_upload").css('display', 'none');
        },
        onAfterImgCrop: function () {
            cropperHeader.reset()
        },

        modal: true,
        uploadUrl: '{{action('AjaxController@postUploadimage')}}',
        cropUrl: '{{action('AjaxController@postCropimage')}}',
        loaderHtml: '<div class="loader bubblingG"><span id="bubblingG_1"></span><span id="bubblingG_2"></span><span id="bubblingG_3"></span></div> ',
    }

    var cropperHeader = new Croppic('image_upload', cropperOptions);

    var nbOptions = 11; // number of menus
    var angleStart = -360; // start angle
    $('.dropzone').html5imageupload({
        onAfterProcessImage: function () {
            // $("#edit_image").css('display','none');
            $("#prossfile_pict img").attr("src", '{{url('')}}' + $(this.element).data('name'));
            $("#edit_image").css('display', 'none');
        },
        onAfterCancel: function () {
            $("#edit_image").css('display', 'none');
        }
    });
    // jquery rotate animation
    function rotate(li, d) {
        $({d: angleStart}).animate({d: d}, {
            step: function (now) {
                $(li)
                        .css({transform: 'rotate(' + now + 'deg)'})
                        .find('label')
                        .css({transform: 'rotate(' + (-now) + 'deg)'});
            }, duration: 0
        });
    }

    function editProfile() {
        $('#profilefileupload').click();
        $("#edit_image").css('display', 'inline-block');
    }

    drawStatus();

    //    $(window).scroll(function () {
    //        console.log(1);
    //        $('div[id^="status"]').each(function (index) {
    //           // alert(1);
    //        });
    //    });

    var scale = 0.1;  // scale of the image
    var xLast = 100;  // last x location on the screen
    var yLast = 20;  // last y location on the screen
    var xImage = 100; // last x location on the image
    var yImage = 20; // last y location on the image

    // if mousewheel is moved
    //    $("#status_container").mousewheel(function(e, delta)
    //    {
    //        console.log(e.deltaX, e.deltaY, e.deltaFactor);
    //        // find current location on screen
    //        $("#status").animate({
    //            transform: 'translateX(50px)'
    //        });
    //       // alert(1);
    //        return false;
    //    });
    //    $("#status").animate({
    //        transform: 'translateX(50px)'
    //    });
    // $("#status").css('transform', 'rotate(45deg)');
    // using the following syntax, elem will always rotate 90deg anticlockwise
    // $("#status").animate({transform: '+=rotate(-90deg)'});


    //    $('body').on( 'DOMMouseScroll mousewheel', function ( event ) {
    //        if( event.originalEvent.detail > 0 || event.originalEvent.wheelDelta < 0 ) { //alternative options for wheelData: wheelDeltaX & wheelDeltaY
    //            //scroll down
    //            console.log('Down');
    //
    //            $('div[id="status"]').each(function(index ){
    //
    //                $(this).css({
    //                    'left':  "+=50px" ,
    //                    //'top' : ((object_position_left + 10) / (total - index)) + index * 50,
    //                    //'top' : myArray[index].top,
    //                    "top": "+=50px"
    //                });
    //
    //
    //            });
    //        } else {
    //            //scroll up
    //            console.log('Up');
    //
    //
    //            $('div[id="status"]').each(function(index ){
    //
    //                $(this).css({
    //                    'left':  "-=50px" ,
    //                    //'top' : ((object_position_left + 10) / (total - index)) + index * 50,
    //                    //'top' : myArray[index].top,
    //                    "top": "-=50px"
    //                });
    //
    //
    //            });
    //        }
    //        //prevent page fom scrolling
    //        return false;
    //    });

    $(function () {
        var total = 2;
        var window_width = $(window).height() - $('#status').height();

        var document_height = $(document).height() - $(window).height();
        $(window).scroll(function () {

            var scroll_position = $(window).scrollTop();
            //console.log(scroll_position);
            var myArray = [];

            $('div[id="status"]').each(function (index) {

                var object_position_left = window_width * (scroll_position / document_height) * total;
                console.log(object_position_left);
//            $('#status').css({
//                'left': object_position_left - 85,
//                'top' : object_position_left +10,
//            });

                var left = $(this).css("left");
                var top = $(this).css("top")

                var scale = scroll_position / document_height * 100 * total;
                scale = scale / 70;


                scale = scale + index * 0.20;
                scale = scale - 0.3;
                scale = scale / (total - index);

//                if(index < total-1){
//                    var next = ((object_position_left - 130 )/ (total - (index+1))) + (index+1) * 50;
//                    console.log(next);
//                }

                var data = {};
                data.left = ((object_position_left - 80 ) / (total - index)) + index * 160;
                data.top = ((object_position_left + 0) / (total - index)) + index * 160;
                //data.left = left + 40;
                //data.top = top + 40;
                data.scale = scale;
                myArray.push(data);

//
//                $(this).css({
//                    'left': ((object_position_left - 130 )/ (total - index)) + index * 50  ,
//                    //'top' : ((object_position_left + 10) / (total - index)) + index * 50,
//                    'top' : ((object_position_left -50) / (total - index)) + index * 20,
//                });
            });

            $('div[id="status"]').each(function (index) {
                var left = myArray[index].left;
                var scale = myArray[index].scale;
//                if(index < total - 1){
//                    left = myArray[index+1].left / 2;
//                    left = left - 60;
//                    scale = myArray[index+1].scale /2 ;
//                    console.log(left);
//                }else {
//                    left = left - 20;
//                }
                $(this).css({
                    'left': left,
                    //'top' : ((object_position_left + 10) / (total - index)) + index * 50,
                    'top': myArray[index].top,
                    //"top": "+=10px"
                });

                $(this).css({
                    transform: 'scale(' + scale + ',' + scale + ')',
                    opacity: scale > 1.5 ? 0 : scale
                });

                if (myArray[index].scale > 1.5) {
                    //$("#status_container").children("div[id=status]:last").hide();
                }
            });

//            $('div[id^="status"]').each(function(index ){
//               if(index == 0){
//                   $(this).css({
//                       'left': object_position_left - 85,
//                       'top' : object_position_left +10,
//                   });
//
//                   $(this).css({
//                       transform: 'scale('+scale+','+scale+')',
//                       opacity : scale
//                   });
//               }
//            });


        });
    });

    function drawStatus() {
        var height = 1000;
        for (i = 0; i < 2; i++) {
            var left = 0 - i * 50;
            var top = -1000;
            var template = '<div id="status" class="stats-box stats2 status" style="left:' + left + 'px;top: ' + top + 'px">' +
                    '<div class="stats stats-twitter">' +
                    '<p>Apa Kabar Dunia<br/>Hong Kong Hujan Nih</p>' +
                    '<span class="left">Jakarta</span>' +
                    '<span class="right">2 Juni 2015</span>' +
                    '<div class="stats-nav"><a href="#" class="btn-circle btn1">C</a>' +
                    '<a href="#" class="btn-circle btn2">L</a>' +
                    '</div>' +
                    '</div>' +
                    '</div>';
            $("#status_container").prepend(template);
            $("#status_container").css("height", height + "px");
            height += 2000;
        }


    }

    // show / hide the options
    function toggleOptions(s) {
        $(s).toggleClass('open');
        var li = $(s).find('li');
        var deg = $(s).hasClass('half') ? 180 / (li.length - 1) : 360 / li.length;
        for (var i = 0; i < li.length; i++) {
            var d = $(s).hasClass('half') ? (i * deg) - 90 : i * deg;
            $(s).hasClass('open') ? rotate(li[i], d) : rotate(li[i], angleStart);
        }
    }

    $('.selector button').click(function (e) {

        toggleOptions($(".selector"));
    });

    setTimeout(function () {
        toggleOptions('.selector');
    }, 100);
</script>

<script>

    $(".selector button,#profile_image_edit").hover(
            function () {
                $("#profile_image_edit").css('display', 'block');
            }, function () {
                $("#profile_image_edit").css('display', 'none');
            }
    );

</script>
</body>
</html>
