<?php

use Soulfy\User;

$domain = $_SERVER['SERVER_NAME'];
$user = User::where('domain', $domain)->first();
$user_setting = \Soulfy\Setting::where('user_id',$user->id)->first();
$no = "1";
$url = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$pos = strrpos($url, '/');
$id = $pos === false ? $url : substr($url, $pos + 1); 
$pages2 = \Soulfy\Pages::where('id', $id)->first();
$navcolor = \Soulfy\UserProfile::where('user_id', $user->id)->first();
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" content="{!!$pages2->pages_keyword!!}">
<meta name="description" content="{!!$pages2->pages_description!!}">
<title>{!!$pages2->pages_title!!}</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
    .container-fluid {
        width: 100%;
    }
  .navbar-inverse {
    background-color: {{ $navcolor->nav_color }};
    border-color: {{ $navcolor->nav_color }};
  }
  .navbar-inverse .navbar-collapse, .navbar-inverse .navbar-form {
    border-color: #c0b6b6;
  }
  .navbar-inverse .navbar-nav > li > a {
    color: #fff5f5;
  }
</style>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
          <!--  width="70" height="70"  -->
        <li><a href="{{url('')}}" style="padding: 6px 15px;"><img class="img-responsive " src="{{url('').'/'.$user->image_profile}}" style="border-radius: 50%;width: 70px;height: 70px;"></a></li>
        @foreach( $pages as $p) 
          <li><a href="{{url('')}}/home/pages/{{ $p->id }}">{{ $p->pages_name }}</a></li>
        @endforeach
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li></li>
      </ul>
    </div>
  </div>
</nav>             
<div class="container">
    <div class="row">
      <div class="col-md-12" style="background-color: white; padding: 20px;"><br>
        <div class="desktop2">
          <b>
            @if(isset($pages2->pages_title) && ($pages2->pages_title != ''))
                {{ $pages2->pages_title }}
            @endif
            </b><br> 
            @if(isset($pages2->pages_content) && ($pages2->pages_content != ''))    
                {!! $pages2->pages_content !!}
            @else
				<!--Kualitas produk merupakan hal penting dalam kegiatan kami. Namun kepuasan pelanggan adalah yang terpenting. Teknologi yang tepat membantu komunikasi yang ampuh namun efektif.<br>
				<br>
				Erik Nainggolan, pakar internet & brand advisor!<br>
				<a href="http://www.eriknainggolan.com">pakar internet</a> Erik Nainggolan&nbsp;<br />
				<a href="http://www.eriknainggolan.com">brand advisor</a> Erik Nainggolan&nbsp;<br />-->
				Erik Nainggolan - CEO & Founder Soulfy.com, <a href="http://www.eriknainggolan.com">pakar internet</a> & <a href="http://www.eriknainggolan.com">brand advisor</a>
            @endif          
      </div>
    </div>
  </div>
</div>
