@extends('home')

@section('title', 'Home')

@section('css')
    
@endsection

@section('content')

<section id="content-desc">
    <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>
    <div class="content-gallery ">
        <h3 class="content-placeholder-tittle"> | RSS FEED</h3>
        <div class="gallery-box slimScroll">
            <div class="backend-box backend-box-email">
                <div class="backend-nav">
                    <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs" role="tablist">
                        <?php
                        $no = 1;
                        $no_1 = 1;
                        $no_2 = 1; 
                        ?>
                        @foreach($rss as $r)
                        <li id={{$no++}}>
                            <a href="#test{{$no_1++}}" aria-controls="test{{$no_2++}}" role="tab"data-toggle="tab">{{$r->tittle}}</a>
                        </li>
                        @endforeach

                    </ul>
                </div>
                <div class="tab-content backend-detail slimScroll">
                    <?php
                        $no_3 = 1;
                    ?>
                    @foreach($rss as $rs)
                    <div role="tabpanel" class="tab-pane" id="test{{$no_3++}}">
                        <iframe src="{{$rs->rss_url}}" width="100%" height="380" frameborder="0" allowtransparency="true"></iframe>
                    </div>   
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</section>

@endsection

@section('js')
<script type="text/javascript">

    $(document).ready(function () {
        $('#1').addClass("active");
    });
    $(document).ready(function () {
        $('#test1').addClass("active");
    });
</script>
@endsection
