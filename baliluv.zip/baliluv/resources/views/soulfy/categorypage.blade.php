<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="{{ URL::asset('https://cdn.datatables.net/v/bs4/dt-1.10.22/datatables.min.css') }}" rel="stylesheet">
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
    .row.content {height: 1500px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height: auto;} 
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
     
      <ul class="nav nav-pills nav-stacked">
      <li class="active" style="text-align: left;display: block;float:unset;"><a id="tab_social" href="#social" aria-controls="social" role="tab" data-toggle="tab">dashboard</a></li>

<li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="followers" role="tab" data-toggle="tab" class="capitalized">calender</a></li>

<li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Appointments</a></li>

<li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">services</a></li>

<ul>
    <li style="text-align: left;display: block;float:unset;"><a href="admin/category" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Category Master</a></li>

    <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Services Master</a></li>
</ul>

<li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Agents</a></li>

<li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Coupons</a></li>

<li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Email & reminder</a></li>
      </ul><br>
    </div>

    <div class="col-sm-9">
      <h4><small>Category Master</small></h4>

      <button type="submit" class="btn btn-success"><a href="/baliluv_public/category/add">+ Add category</a></button>

      <button type="submit" class="btn btn-success"><a href="/baliluv_public/sub_category/add">+ Add sub-category</a></button>


      <div class="tab-content common-tab-section min-height-480">

            <div id="live-tab" class="tab-pane fade" style="opacity:1; display:block;">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
                    <h1 class="head-name">Category</h1>
                </div>


                <!-- form -->
                <div class="content-main form-dashboard">
                    <form>

                        <div class="table-responsive text-center message-table">
                            <table id="example" class="table table-bordered table-style" style="width: 100%">
                                <thead>
                                    <tr>
                                        <th>Category Name</th>
                                        <th>Category Description</th>
                                       
                                    </tr>
                                    <tbody>
                                      @foreach($service_cat as $category_value)
                                      <tr>
                                        <td>{{ $category_value->category_name }} </td>
                                        <td>{{ $category_value->category_description }}</td>
                                      </tr>
                                      @endforeach
                                    </tbody>
                                </thead>

                            </table>
                        </div>
                    </form>
                </div>
                <!--end form-->
            </div> <!-- dropshipping-products -->

        </div>

    </div>
  </div>
</div>



</body>
</html>


<script src="{{ URL::asset('https://cdn.datatables.net/v/bs4/dt-1.10.22/datatables.min.js') }}"></script>
<script type="text/javascript">
        $(document).ready(function() {
            $('#example').DataTable({
                "language": {
                    "infoFiltered": "",
                    "search": '',
                    "searchPlaceholder": "Search",
                    "paginate": {
                        next: '<i class="fas fa-angle-right"></i>',
                        previous: '<i class="fas fa-angle-left"></i>'
                    }
                },
                "order": [[ 0, "desc" ]],
            });
        });
    </script>



















