<?php
 $no = "1";  
?>

@extends('home')
@section('title', 'Home')
@section('css')
<style type="text/css">
    #rss_modal.modal {
            width: 100%;
            left:50%;
            margin:0;
            max-width:150px;
            z-index:9999;
            transform: translate(-50%);
            z-index: 9999;
            background: #525251;
            border-radius: 27px;
            text-align: center;
            font-family: "opensans-bold", sans-serif;
            font-size: 14px;
    }
</style>
@endsection

@section('content')

<section id="content-desc" class="inner-section-container">
    <a class="plus-minus-toggeler">
        <span class="glyphicon glyphicon-chevron-down"></span>
    </a>
    <div class="backend-box _grey backend-box-email">
        <div class="backend-nav">
            <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs" role="tablist">
                <li class="active">
                    <a id="tab_articles" href="#articles" aria-controls="articles" role="tab" data-toggle="tab">RSS FEED
                    </a>
                </li>   
            </ul>
        </div>

        <div class="tab-content backend-detail slimScroll">
            <div role="tabpanel" class="tab-pane active" id="articles" style="height: 100%">
                <div class="form-top create-article">
                    <label>Rss Feed</label>
                    <ul class="form-nav">
                        <li><a href="#" class="new-article">
                            <img src="{{url('')}}/images//nav3.png"/></a>
                        </li>
                    </ul>
                </div>
                <div class="form-body  create-article">
                    <div class="notes-box">
                        <ul>
                        @foreach($rssfeeds as $data)
                            <li>
                                <div class="notes-desc">
                                    <p><b>{{$no++}}.
                                        @if(strlen($data->tittle)>=10)
                                            {{substr($data->tittle,0,15)}}....
                                        @else
                                            {{$data->tittle}}
                                        @endif
                                    </b></p>
                                    <p class="date">
                                       @if(date("Y",strtotime($data->updated_at))=="1970") 
                                        <i class="fa fa-calendar"></i> {{date("d M Y H:i",strtotime($data->created_at))}}
                                       @else
                                        <i class="fa fa-calendar-plus-o"></i> {{date("d M Y H:i",strtotime($data->updated_at))}}
                                       @endif
                                    </p>
                                </div>
                                <div class="notes-nav">
                                    <a href="#" class="btn btn-green btn-act-delete" onclick="deletemodal({{$data->id}})">
                                        <img src="{{url('')}}/images//icon-trash.png"/>

                                    </a>

                                    <a href="#" class="btn btn-green btn-act-edit" data-id="{{$data->id}}" data-tittle="{{$data->tittle}}" data-url="{{$data->rss_url}}">
                                        <i class="fa fa-pencil"></i>
                                    </a>
                                </div>
                            </li>
                        @endforeach
                        </ul>
                    </div>
                </div>
                <div class="backend-form create-article-form" style="display:none;">
                    <div class="form-top">
                        <div class="form-left">
                            <h4>Create Rss Feed</h4>
                        </div>
                        <div class="form-right">
                            <a href="#" class="btn-save-article setting_save"></a>
                            <a href="#" class="btn-cancel-article setting_cancel"></a>
                        </div>
                    </div>
                    <div class="form-body">
                        <div class="form-group">
                            <span>Title</span><input type="text" name="tittle" id="tittle" class="tittle" required/>
                        </div> 
                        <div class="form-group">
                            <span>RSS URL</span><input type="url" name="url" id="url" class="tittle" required/>
                        </div>
                    </div>
                </div>
                <div class="backend-form edit-article-form" style="display:none;">
                    <div class="form-top">
                        <div class="form-left">
                            <h4>Edit Rss Feed</h4>
                        </div>
                        <div class="form-right">
                            <a href="#" class="btn-save-edit-article setting_save"></a>
                            <a href="#" class="btn-cancel-article setting_cancel"></a>
                        </div>
                    </div>
                    <div class="form-body">
                        <!-- <form id="form-edit"> -->
                        <div class="form-group">
                            <input type="hidden" id="id-edit" name="id-edit" class="id-edit">
                            <span>Title</span><input type="text" name="tittle" id="tittle-edit" class="tittle"/>
                        </div>
                        <div class="form-group">
                            <span style="width: 16%">RSS URL</span><input type="text" name="url-edit" id="url-edit" class="tittle-edit"/>
                        </div>
                        <!-- </form>  -->
                    </div>   
                </div>
            </div>
        </div>
    </div> 
</section>
<div aria-hidden="false" style="display: none;" id="rss_modal" class="modal fade in" tabindex="-1" data-focus-on="input:first">
        <div role="form" class="form-create" method="post">
            <input type="hidden" name="rss_id" id="rss_id">

            <div class="modal-body">
                <p style="color: red">Delete RSS?</p>
            </div>
            <div class="modal-footer">
                <button type="button" data-dismiss="modal" class="btn btn-default" onclick="rssclose()">No</button>
                <button type="submit" class="btn btn-success" id="rss_delete">Yes</button>
            </div>
            <input type="hidden" id="_token" name="_token" value="{{ csrf_token() }}">
        </div>
    </div>

@endsection

@section('js')
<script>

    $(document).ready(function(){  
        $(".edit-article-form").hide();
        $(".create-article-form").hide();
        $(".new-article").click(function(e){
            e.preventDefault();
            $(".create-article").hide();
            $(".create-article-form").fadeIn();

         //   $(' iframe').contents().find('.ckeditor').html('');
            if(!content) content = "";
        });

        $(".btn-cancel-article").click(function(e){
            e.preventDefault();
            $(".edit-article-form").hide();
            $(".create-article").fadeIn();
            $(".create-article-form").hide();
        });

        //Edit Rss
        $(".btn-act-edit").click(function(e){
            e.preventDefault();
            var id = $(this).attr("data-id"),
            tittle = $(this).attr("data-tittle"),
            content = $(this).attr("data-url");
            $(".create-article").hide();
            $(".edit-article-form").fadeIn();
            $(".id-edit").val(id);
            $("#tittle-edit").val(tittle);
            $("#url-edit").val(content);
        });

        //Save Rss
        $(".btn-save-article").click(function(e){
            e.preventDefault();
            var tittle = $("#tittle").val(),
            url = $("#url").val();
            $.ajax({
                method: "POST",
                url: '{{action("RssController@postCreateRssFeed")}}',
                data: { tittle : tittle, url : url},
                success: function (response) {
                    if (response=='"error"') {
                        pesanErr("please fill the title and Rss Url");
                    }else{ 
                    pesanOk("Rss Feed add Successfully");
                    setTimeout(function(){location.reload()},1000);
                    };
                },
            })
        });

        // Upadate Rss
        $(".btn-save-edit-article").click(function(e){
            e.preventDefault();
            var id_edit = $("#id-edit").val(),
            tittle_edit = $("#tittle-edit").val(),
            url_edit = $("#url-edit").val();
           
            $.ajax({
                method: "POST",
                url: '{{action("RssController@postUpdateRssFeed")}}',
                data: { id : id_edit, tittle : tittle_edit, url : url_edit},
                success: function (response) {
                //    alert(response);
                    pesanOk("Rss updated");
                   setTimeout(function(){location.reload()},1000);
                },
                error:function()
                {
                    pesanErr("Fail");
                }
            })
        });
        // publish Rss
    });

    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    });

    function deletemodal(picID){
        document.getElementById("rss_modal").style.display = "block";
        document.getElementById("rss_id").value = picID;

    }
    function rssclose(){
        document.getElementById('rss_modal').style.display = 'none';
    }
    $("#rss_delete").click(function(e){
        var id = $('#rss_id').val();
        $.ajax({
            url:'{{action("RssController@postDeleteRssFeed")}}',
            data:'id='+id,
            method:'POST',
            success: function (response) {
            //    alert(response);
                pesanOk("Delete");
               setTimeout(function(){location.reload()},100);
            },
            error:function()
            {
                pesanErr("Fail");
            }
        })
    });
</script>

@endsection

