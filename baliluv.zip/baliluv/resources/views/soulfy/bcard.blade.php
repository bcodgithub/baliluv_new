<?php

/**

 * Created by PhpStorm.

 * User: FID_KHADAFI

 * Date: 8/18/2015

 * Time: 10:01 AM

 */

$user_setting = \Soulfy\Setting::where('user_id',$user['id'])->first();



?>





@extends('home')



@section('title', 'Home')





@section('content')



    <section id="content-desc" class="inner-section-container">

     

				<a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>

                <div class="backend-box backend-box-email">

                    <div class="backend-nav">

                        <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs" role="tablist">

                            <li class="active"><a id="tab_social" href="#bcard" aria-controls="social" role="tab"

                                                  data-toggle="tab">INFO</a></li>

                           

                        </ul>

                    </div>

                    <div class="tab-content backend-detail slimScroll">

                        <div role="tabpanel" class="tab-pane active" id="bcard" style="height: 100%">

                                

                        <form role="form" method="post" id="form_update_business_card" action="{{action("AjaxController@postUpdateinfo")}}">



                            <div class="form-top">

                                <label>My Business Card</label>

                            </div>

                            <div class="form-body">

                                <div class="form-inline">

                                    <ul id="business_card">

                                        <li>

                                            <span>Name </span> : <input style="width: 64%" name="full_name" type="text" value="{{$user->full_name}}">

                                            <br>

                                        </li>

                                        <li>

                                            <span>Address</span> : <input style="width: 64%" name="address" type="text" value="{{$user->address}}">

                                        </li>

                                        {{--<li>--}}

                                            {{--<span>Occupation</span> : <input style="width: 64%" name="occupation" type="text" value="{{$user->occupation}}">--}}

                                        {{--</li>--}}

                                        <li>

                                            <span>Phone</span> : <input style="width: 64%" name="phone" type="text" value="{{$user->phone}}">

                                        </li>

                                        <li>

                                            <span>Fax</span> : <input style="width: 64%" name="fax" type="text" value="{{$user->fax}}">

                                        </li>

                                        <li>

                                            <span>Email</span> : <input style="width: 64%" name="website" type="text" value="{{$user->contact_email}}">

                                        </li>



                                    </ul>

                                </div>

                            </div>

                            <div class="form-btm">

                                <button type="submit" id="btn_update_business_card" class="btn btn-bk">Save</button>

                            </div>

                        </form>











                        </div>



                 

            </div>

        </div>

        <div class="placeholder _grey" id="backend-placeholder">

                <div class="placeholder-first backend-first" style="display:none">

                    <div class="placeholder-header">



                            <h3 ></h3>

                            <a class="btn-cancels"><span class="glyphicon glyphicon-remove"></span></a>

                    </div>



                              <div class="content-placeholder">

                                        <p>

                                           

                                        </p>

                             </div>

                             @if(Auth::check())

                             <div class="skype-box">

                                    <div class="image-skype logged">

                                        <img src="{{url()}}/images/skype-logo.png" alt="">

                                    </div>

                                    <div class="skype-id">

                                         Skype ID : <p class="skype-info">{{$user_setting['skype_id']}}</p> 

                                         <div class="skype-act">

                                         <input type="text"   class="form-control skype_form" value="{{$user_setting['skype_id']}}" required>

                                         <a class="btn-skype-edit"><i class="fa fa-pencil-square-o"></i></a>

                                         <a class="btn-skype-save"><i class="fa fa-floppy-o"></i></a>

                                         <a class="btn-skype-cancel"><i class="fa fa-times"></i></a>

                                         </div>

                                         

                                    </div>

                             </div>

                             @else

                             <div class="skype-box">

                                    <div class="image-skype">

                                        <img src="{{url('')}}/images/skype-logo.png" alt="">

                                    </div>

                                    <div class="skype-id">

                                         Skype ID : {{$user_setting['skype_id']}}

                                    </div>

                             </div>

                             @endif

                    <p class="date-article"><i class='fa fa-user'></i> Published by  {{$user->full_name}} <i class='user'></i> | <i class='fa fa-calendar'></i></p>

                    <div style="clear:both;"></div>



                    <div class="placeholder-footer action">

                                            <a class="first btn-act-like" onclick="likeTimeLine(this)">
                        <span class="glyphicon glyphicon-thumps-up"></span>
                    </a>

                                            <a  class="second"></a>

                                            @if(Auth::check())

                                            <a class="third btn-act-delete" onclick="deleteTimeLine(this)"><span class="glyphicon glyphicon-trash"></span> </a>

                                            @endif



                            <div class="fb-comment form-group"></div>

                            <div style="clear:both;"></div>

                    </div>

                    </div>

                    

            </div>

    </section>



@endsection





@section('js')



    <link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css"

          rel="stylesheet"/>

    <script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/js/bootstrap-editable.min.js"></script>



    <script type="text/javascript">

        $.fn.editable.defaults.mode = 'inline';

        $(document).ready(function () {

            $('#txt_name').editable();

        });



        $("#tab_setting").on("click", function () {

            $("#setting").html(' <div id="loader"><img src="{{url()}}/images/loader.png"></div>');



            $.get("{{action('MemberController@getSetting')}}", function (data) {

                $("#setting").html(data);

            });

        });



        $("#tab_email").on("click", function () {

            $("#email").html(' <div id="loader"><img src="{{url()}}/images/loader.png"></div>');



            $.get("{{action('MemberController@getEmail')}}", function (data) {

                $("#email").html(data);

            });

        });



    </script>



    {{--Social module js--}}

    <script>

        $("#btn_post").on("click", function () {

            var ck_fb = $("#ck_fb").prop("checked");

            var ck_twitter = $("#ck_twitter").prop("checked");

            var ck_path = $("#ck_path").prop("checked");

            var ck_gplus = $("#ck_gplus").prop("checked");



            $(this).button("loading");

            var button = this;





            var type = 0;

            if (ck_fb) {

                type = 1;

                updateStatus(button, type);

            } else if (ck_twitter) {

                type = 2;

                updateStatus(button, type);

            } else if (ck_path) {

                type = 3;

                updateStatus(button, type);

            } else if (ck_gplus) {

                type = 4;

                updateStatus(button, type);

            }



        });



        function updateStatus(button, type) {

            var jqxhr = $.post("{{action('SocialController@postPublishStatus')}}", {

                type: type,

                status: $("#txt_status").val()

            }, function (data) {

                alert("Publish status sukses");

                $(button).button("reset");

            }).fail(function () {

                alert("Publish status error");

                $(button).button("reset");

            });

        }

    </script>



    {{--Setting module js--}}



    <script>

        //        $("#btn_add_gallery").on("click",function()

        //        {

        //            var obj = $( "#btn_upload_gall input" ).last();

        //            $(obj).click();

        //        });



        function onAddclick(base) {



            var obj = $("#btn_upload_gall input").last();

            $(obj).click();

        }



        $("#btn_upload_gall").MultiFile({

            preview: true,

            list: '#upload_list',

            STRING: {

                file: '<em title="Click to remove" onclick="$(this).parent().prev().click()"></em>',

                remove: '<span class="glyphicon glyphicon-remove" style="" aria-hidden="true"></span>',



            },

            afterFileAppend: function (element, value, master_element) {



            },

        });



        var options = {

            beforeSubmit: function () {

                $("#btn_upload_img").button("loading");

            },

            success: function () {

                $("#btn_upload_img").button("reset");

                $(".MultiFile-remove").each(function () {

                    $(this).click();

                });

                pesanOk("Album photos uploaded");

            },

            error: function () {

                $("#btn_upload_img").button("reset");

                pesanErr("this is something error occured");

            }

        };



        $('#form_upload_img_gallery').ajaxForm(options);



        var options = {

            beforeSubmit: function () {

                $("#btn_upload_video").button("loading");

            },

            success: function () {

                $("#btn_upload_video").button("reset");



                pesanOk("Album photos uploaded");

            },

            error: function () {

                $("#btn_upload_video").button("reset");

                pesanErr("Oops try again");

            }

        };



        $('#form_upload_video').ajaxForm(options);



        var options = {

            beforeSubmit: function () {

                $("#btn_update_skype").button("loading");

            },

            success: function () {

                $("#btn_update_skype").button("reset");



                pesanOk("Skype ID updated");

            },

            error: function () {

                $("#btn_update_skype").button("reset");

                pesanErr("this is something error occured");

            }

        };



        $('#form_update_skype').ajaxForm(options);



        var options = {

            beforeSubmit: function () {

                $("#btn_update_skype").button("loading");

            },

            success: function () {

                $("#btn_update_business_card").button("reset");



                pesanOk("Business card updated");

            },

            error: function () {

                $("#btn_update_business_card").button("reset");

                pesanErr("Oops try again");

            }

        };



        $('#form_update_business_card').ajaxForm(options);



         //skype edit



         $(".skype_form").hide();

            $(".btn-skype-save").hide();

            $(".btn-skype-cancel").hide();

            $(".btn-skype-edit").click(function(e){

                e.preventDefault();

                $(".btn-skype-cancel").show();

                $(this).hide();

                $(".btn-skype-save").show();

                $(".skype-info").hide();

                $(".skype_form").show();

            });

            $(".btn-skype-cancel").click(function(e){

                e.preventDefault();

                $(".skype_form").hide();

                 $(".skype-info").show();

                 $(this).hide();

                 $(".btn-skype-save").hide();

                 $(".btn-skype-edit").show();

            });

            $(".btn-skype-save").click(function(e){

                e.preventDefault();

                var skypeid = $(".skype_form").val();

                var id_user = {{$user_setting['id']}};

                $.ajax({

                type: "POST",

                url: '{{action("AjaxController@postEditSkype")}}',

                data : {

                    id_user : id_user,

                     skypeid : skypeid,

                },



                success: function (response) {

                    if (response=='"success"') {

                        pesanOk("success");

                        $(".skype-info").html(skypeid);

                        $(".skype_form").hide();

                         $(".skype-info").show();

                         $(".btn-skype-save").hide();

                         $(".btn-skype-cancel").hide();

                         $(".btn-skype-edit").show();

                    }else{

                        pesanErr("failed");

                    };

                }

            });

            });



    </script>





    {{--setting jquery --}}

   



@endsection