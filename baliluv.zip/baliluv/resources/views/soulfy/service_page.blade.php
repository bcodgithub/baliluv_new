  <!DOCTYPE html>
  <html lang="en">
    <head>
        <title>Bootstrap Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <style>
          /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
          .row.content {height: 1500px}
          /* Set gray background color and 100% height */
          .sidenav {
          background-color: #f1f1f1;
          height: 100%;
          }
          /* Set black background color, white text and some padding */
          footer {
          background-color: #555;
          color: white;
          padding: 15px;
          }
          /* On small screens, set height to 'auto' for sidenav and grid */
          @media screen and (max-width: 767px) {
          .sidenav {
          height: auto;
          padding: 15px;
          }
          .row.content {height: auto;} 
          }
        </style>
    </head>
    <body>
        <div class="container-fluid">
          <div class="row content">
            <div class="col-sm-3 sidenav">
              <ul class="nav nav-pills nav-stacked">
                  <li class="active" style="text-align: left;display: block;float:unset;"><a id="tab_social" href="#social" aria-controls="social" role="tab" data-toggle="tab">dashboard</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="followers" role="tab" data-toggle="tab" class="capitalized">calender</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Appointments</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">services</a></li>
                  <ul>
                    <li style="text-align: left;display: block;float:unset;"><a href="admin/category" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Category Master</a></li>
                    <li style="text-align: left;display: block;float:unset;"><a href="admin/service" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Services Master</a></li>
                  </ul>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Agents</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Coupons</a></li>
                  <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Email & reminder</a></li>
                  <ul>
                    <li style="text-align: left;display: block;float:unset;"><a href="admin/email-template" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Email Templates</a></li>
                    <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Remainders</a></li>
                  </ul>
              </ul>
              <br>
            </div>

            <div class="col-sm-9">
              <h4><small>Add category</small></h4>
              <form method="POST" id="serviceForm" >
              <meta name="csrf-token" content="{{ csrf_token() }}">           
                <div class="customize-add-section"> 

                  <div class="alert alert-danger print-error-msg" style="display:none">
                    <ul></ul>
                  </div>

                  <div class="col-sm-7 customize-add-inner-sec">
                    <label for="meta_title">Service Name</label>
                    <input class="form-control" type="text" name="title" id="title"
                      placeholder="Enter service name" required="">
                  </div>

                  <!-- col-sm-6 -->
                  <div class="col-sm-7 customize-add-inner-sec page-content-textarea">
                    <label for="page_content">Service Description</label>
                    <textarea class="form-control" name="content" id="content" placeholder="Enter service description"
                      required=""></textarea>
                  </div>

                  <div class="col-sm-7 customize-add-inner-sec">
                    <label for="meta_title">Select Category Name</label>
                      <select class="form-control form-select" aria-label="Default select example" name="category" id="category">
                        <option selected>Select Category</option>
                        @foreach($subcategory as $subcategory_value)
                          <option value="{{ $subcategory_value->id }}">{{ $subcategory_value->category_name }}</option>
                        @endforeach
                      </select>
                  </div>

                  <div class="col-sm-7 customize-add-inner-sec">
                    <label for="meta_title">Select Sub Category Name</label>
                      <select class="form-control form-select" aria-label="Default select example" name="sub_category" id="sub_category">
                        <option selected>Select Sub-Category</option>
                       
                      </select>
                  </div>
                  
                  <!-- col-sm-6 -->
                  <div class="col-sm-7 customize-add-inner-sec">
                    <label for="meta_title">Price</label>
                    <input class="form-control" type="text" name="price" id="price"
                      placeholder="Price" required="">
                  </div>

                  <!-- col-sm-6 -->
                  <div class="col-sm-7 customize-add-inner-sec page-content-textarea">
                    <label for="page_content">Duration</label>
                    <textarea class="form-control" name="duration" id="duration" placeholder="Duration"
                      required=""></textarea>
                  </div>

                </div>
                <!-- customize-add-section -->
                <div class="col-sm-7 download-discard-small ">
                  <!--<button class="white-btn" type="reset">Discard</button>-->
                  <button class="white-btn" type="submit" id="servicesubmit">Save</button>
                </div><!-- download-discard-small  -->
              </form>
            </div>
          </div>
        </div>
      </div>
    </body>
  </html>
  @section('extra_js')
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script>
    $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
    }
    });
    
    $('#servicesubmit').click(function(e){ 
    
    e.preventDefault();  
    //var formData =  new FormData(document.getElementById("templateForm"));
    
    var _token = $("input[name='_token']").val();
    var title = $("input[name='title']").val();
    var content = $("input[name='content']").val();
    var price = $("input[name='price']").val();
    var duration = $("input[name='duration']").val();
    
    //let email_code = $('#email_code').val();
    //let title = $('#title').val();
    //let subject = $('#subject').val();
    //let content = $('#content').val();
    $.ajax({
        //url: "/admin/service",
        //data: formData,
    
        data:{
            _token:_token,
            title:title,
            content:content,
            price:price,
            duration:duration,
          },
        processData: false,
        contentType: false,
        dataType: 'json',
        type: $('#serviceForm').attr('method'),
        success: function(data)
        
          {
            alert(data);
            if($.isEmptyObject(data.error)){
                    alert(data.success);
                }else{
                    printErrorMsg(data.error);
                }
    
            //alert(response);
    
            // console.log(response.msg.password[0]);
          
            /*if(response.flag == 1) {
                        swal({
                            text: response.msg,
                            button: false,
                            icon: 'success'
                          }) 
            }
            else {
                        swal({                            
                            text: response.msg,
                            button: false,
                            icon: 'error'
                          })
                          return false;
                }
            */
        },
        /* error: function (response) {
                      console.log(response);
        } */
    })
        
    });
    
    
    function printErrorMsg (msg) {
        $(".print-error-msg").find("ul").html('');
        $(".print-error-msg").css('display','block');
        $.each( msg, function( key, value ) {
            $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
    });

    };
  </script>

  <script type="text/javascript">
    $(document).ready(function () { 
      //console.log('hi');
              $(document).on('change','.category',function(){
                var cat_id=$(this).val();
                var div=$(this).parent();
                var op=" ";
              //alert(cat_id);
              //ajax
              $.ajax({
                type:'post',
                url:'{!!URL::to('findProductName')!!}',
                data:{'id':cat_id},
                success:function(data){
                  //console.log('success');

                  //console.log(data);

                  //console.log(data.length);
                  op+='<option value="0" selected disabled>chose product</option>';
                  for(var i=0;i<data.length;i++){
                  op+='<option value="'+data[i].id+'">'+data[i].sub_category+'</option>';
                  }

                  div.find('.sub_category').html(" ");
                  div.find('.sub_category').append(op);
                },
                error:function(){

                }
              });

          });
        });

  </script>
  
  <!--</div>-->