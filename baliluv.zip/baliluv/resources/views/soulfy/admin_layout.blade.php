<section id="admin-content-desc" style="position:absolute;left:420px;max-width:500px;">
            <a class="plus-minus-toggeler"><span class="glyphicon glyphicon-chevron-down"></span></a>
            <div class="backend-box backend-box-email">
                <div class="backend-nav">

                    <ul style="margin-top: 20px;height: 32px;" class="nav nav-tabs admin-tabs" role="tablist">

                        <li class="active" style="text-align: left;display: block;float:unset;"><a id="tab_social" href="#social" aria-controls="social" role="tab" data-toggle="tab">dashboard</a></li>

						<li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="followers" role="tab" data-toggle="tab" class="capitalized">calender</a></li>

                        <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Appointments</a></li>

                        <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">services</a></li>

                        <ul>
                            <li style="text-align: left;display: block;float:unset;"><a href="admin/category" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Category Master</a></li>

                            <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Services Master</a></li>
                        </ul>

                        <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Agents</a></li>

                        <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Coupons</a></li>

                        <li style="text-align: left;display: block;float:unset;"><a href="#" aria-controls="following" role="tab" data-toggle="tab" class="capitalized">Email & reminder</a></li>
                    </ul>

                </div>

 

            </div>

            
</section>