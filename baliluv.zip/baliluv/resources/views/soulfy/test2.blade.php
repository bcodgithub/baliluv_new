<?php
/**
 * Created by PhpStorm.
 * User: FID_KHADAFI
 * Date: 7/28/2015
 * Time: 1:49 PM
 */
?>

        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Soulfy Web- Template</title>
    <!-- Custom styles for this template -->
    <link href="{{url(".")}}/css/style.css" rel="stylesheet"/>
    <link href="{{url(".")}}/css/latest6d23.css" rel="stylesheet"/>
    <link href="{{url(".")}}/css/user-controls6d23.css" rel="stylesheet"/>
    <!--[if lt IE 9]>
    <link href="{{url(" .")}}/css/ie.css" rel="stylesheet"/>
    <script src="{{url(" .")}}/js/html5shiv.js" type="text/javascript"></script>
    <
    script
    src = "{{url(".
    ")}}/js/respond.js"
    type = "text/javascript" ></script>
    <![endif]-->
    <!--[if lt IE 10]>
    <link href="{{url(" .")}}/css/ie.css" rel="stylesheet"/>
    <script src="{{url(" .")}}/js/html5shiv.js" type="text/javascript"></script>
    <
    script
    src = "{{url(".
    ")}}/js/respond.js"
    type = "text/javascript" ></script>
    <![endif]-->

</head>
<body id="home">
<header>
    <div class="container">
        <div class="row">
            <div class="nav-header">
                <ul class="nav-right">
                    <li>
                        <div class="form-group">
                            <span class="control-header">email</span>
                            <span><input type="text" class="form-control"/></span>
                        </div>
                    </li>
                    <li>
                        <div class="form-group">
                            <span class="control-header">password</span>
                            <span><input type="password" class="form-control"/></span>
                        </div>
                    </li>
                    <li>
                        <h3><a href="#">login</a></h3>
                    </li>
                    <li class="logo-box">
                        <a href="#"><img src="{{url(".")}}/images/logo.png"/></a>
                    </lI>
                </ul>
            </div>
        </div>
    </div>
</header>

<section id="content">
    <div class="container">
        <div class="row">
            <div class="selector">
                <ul class="social-media-box">
                    <li>
                        <input id="c1" type="checkbox">
                        <label for="c1"><a href="#"><img
                                        src="{{url(".")}}/images/button-green_01.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c2" type="checkbox">
                        <label for="c2"><a href="#"><img
                                        src="{{url(".")}}/images/button-green_02.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c3" type="checkbox">
                        <label for="c3"><a href="#"><img
                                        src="{{url(".")}}/images/button-green_3.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c4" type="checkbox">
                        <label for="c4"><a href="#"><img
                                        src="{{url(".")}}/images/button-green_4.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c5" type="checkbox">
                        <label for="c5"><a href="#"><img
                                        src="{{url(".")}}/images/button-green_5.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c6" type="checkbox">
                        <label for="c6"><a href="#"><img
                                        src="{{url(".")}}/images/button-green_6.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c7" type="checkbox">
                        <label for="c7"><a href="#"><img
                                        src="{{url(".")}}/images/button-green_7.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c8" type="checkbox">
                        <label for="c8"><a href="#"><img
                                        src="{{url(".")}}/images/button-green_8.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c8" type="checkbox">
                        <label for="c8"><a href="#"><img
                                        src="{{url(".")}}/images/button-green_9.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c8" type="checkbox">
                        <label for="c8"><a href="#"><img
                                        src="{{url(".")}}/images/button-green_10.resized.png"/></a></label>
                    </li>
                    <li>
                        <input id="c8" type="checkbox">
                        <label for="c8"><a href="#"><img
                                        src="{{url(".")}}/images/button-green_11.resized.png"/></a></label>
                    </li>
                </ul>
                <button><span><img src="{{url(".")}}/images/user1.png"/></span></button>
            </div>
            <div id="tl-stage-holder" class="tl-font">
                <!--<img src="/assets/ui/empty-image2.gif" alt="" id="tl-stage-image" />-->
                <div id="tl-stage-main-photo-credit"></div>
                <div id="tl-stage-scale-blackener"></div>
                <div class="tl-stage"></div>
                <div class="tl-stage-fixed-position-content"></div>
                <canvas id="tl-3d-view-canvas" width="100" height="100"></canvas>

                <div id="tl-stage-date-displayer"></div>
                <div class="tl-stage-border-top"></div>
                <div class="tl-stage-border-bottom"></div>
            </div>
            <div id="tl-slider-holder" class="tl-font">
                <div id="tl-slider-scale-holder">
                    <div id="tl-slider-scale">
                        <canvas class="tl-scale-canvas" width="5000" height="52"></canvas>
                        <div id="tl-slider-scale-times-holder">
                        </div>
                        <div id="tl-slider-markers-holder">
                        </div>
                    </div>
                </div>
                <div id="tl-slider-dragger">
                    <div class="tlsd-inner">
                        <div class="tlsd-inner-inner">
                            <div class="tlsd-corner tlsd-c-tl"></div>
                            <div class="tlsd-corner tlsd-c-tr"></div>
                            <div class="tlsd-corner tlsd-c-bl"></div>
                            <div class="tlsd-corner tlsd-c-br"></div>
                        </div>
                    </div>
                </div>
                <div id="tl-slider-interaction-preventer"></div>
            </div>
        </div>
    </div>
</section>

<div class="tl-timeline-info">
    <h2>safasdfasdf</h2>
    <p class="tl-ah-about-text">asf</p>

</div>

<!-- JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script type="text/javascript" src="{{url(".")}}/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="{{url(".")}}/js/support6d23.js?version=7.135"></script>
<script type="text/javascript" src="{{url(".")}}/js/latest6d23.js?version=7.135"></script>
<script type="text/javascript">
    var nbOptions = 11; // number of menus
    var angleStart = -360; // start angle

    // jquery rotate animation
    function rotate(li, d) {
        $({d: angleStart}).animate({d: d}, {
            step: function (now) {
                $(li)
                        .css({transform: 'rotate(' + now + 'deg)'})
                        .find('label')
                        .css({transform: 'rotate(' + (-now) + 'deg)'});
            }, duration: 0
        });
    }

    // show / hide the options
    function toggleOptions(s) {
        $(s).toggleClass('open');
        var li = $(s).find('li');
        var deg = $(s).hasClass('half') ? 180 / (li.length - 1) : 360 / li.length;
        for (var i = 0; i < li.length; i++) {
            var d = $(s).hasClass('half') ? (i * deg) - 90 : i * deg;
            $(s).hasClass('open') ? rotate(li[i], d) : rotate(li[i], angleStart);
        }
    }

    $('.selector button').click(function (e) {
        toggleOptions($(this).parent());
    });

    setTimeout(function () {
        toggleOptions('.selector');
    }, 100);
</script>
<script id="timelinedata-script" type="text/javascript">
    var TLTimelineData = {
        host: "www.tiki-toki.com",
        homePage: false,
        showAdBlock: "false",
        id:481827,
        title:"Test",
        urlFriendlyTitle:"Test",
        startDate:"2015-07-15 14:42:28",
        endDate:"2015-07-31 14:42:32",
        introText:"safasdfasdf",
        introImage:"",
        authorName:"daffi_gusti",
        "accountType":"Standard",
        backgroundImage:"",
        introImageCredit:"",
        backgroundImageCredit:"",
        feed: "",
        mainColour: "A879BE",
        zoom: "",
        initialFocus: "first",
        embedHash: "5687169190",
        embed: "true",
        secret: "false",
        public: "yes",
        dontDisplayIntroPanel: 0,
        openReadMoreLinks: 1,
        storyDateStatus: 0,
        storySpacing: 0,
        viewType: 0,
        showTitleBlock: 1,
        backgroundColour: "1A1A1A",
        storyDateFormat: "auto",
        topDateFormat: "auto",
        sliderDateFormat: "auto",
        language: "english",
        displayStripes: 1,
        htmlFormatting: 0,
        sliderBackgroundColour: "000000",
        sliderTextColour: "808080",
        sliderDetailsColour: "282828",
        sliderDraggerColour: "808080",
        headerBackgroundColour: "000000",
        headerTextColour: "808080",
        showGroupAuthorNames: "1",
        durHeadlineColour: "ffffff",
        cssFile: "",
        altFlickrImageUrl: "",
        fontBase: 'default',
        fontHead: 'default',
        fontBody: 'default',
        lightboxStyle: '0',
        showControls: '1',
        lazyLoading: '1',
        protection: "",
        expander: "2",
        copyable: "0",
        settings3d: "2,4D924D,0.23912,300,0.3116,0.2,2,3,0.25",

        bgStyle: 0,
        bgScale: 100,
        urlHashing: 1,
        categories:[],
        feeds:[],
        stories:[{
            id:4972624,
            ownerId:"525275",
            ownerName:"",
            title:"New story 1",
            startDate:"2015-07-15 14:42:28",
            endDate:"2015-07-15 14:42:28",
            text:"Enter story info here",
            fullText:"none",
            category:"0",
            dateFormat: "auto",
            externalLink:"",
            media:[]
        },{
            id:40,
            ownerId:"",
            ownerName:"",
            title:"Getting ready for launch",
            startDate:"2015-07-16 14:42:28",
            endDate:"2015-07-16 14:42:28",
            text:"We are beginning to get excited. Development work on TikiToki timeline software has finished. All but the most minor bugs have been sorted. All we need to do now is work up some marketing material and we'll be ready to launch. Wish us luck!",
            fullText:"none",
            category:"0",
            dateFormat: "auto",
            externalLink:"",
            media:[]
        },{
            id:951,
            ownerId:"",
            ownerName:"",
            title:"Timeline of the Arab uprisings",
            startDate:"2015-07-16 14:44:28",
            endDate:"2015-07-16 14:46:28",
            text:"One of the things we hope our timeline software will be used for is to document events of great historic importance such as the revolutions taking place in the Arab world.",
            fullText:"",
            category:"74",
            dateFormat: "auto",
            externalLink:"",
            media:[]
        }]
    }
</script>
</body>
</html>
