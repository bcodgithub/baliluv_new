<?php

return [

	/*
	|--------------------------------------------------------------------------
	| oAuth Config
	|--------------------------------------------------------------------------
	*/

	/**
	 * Storage
	 */
	'storage' => 'Session',

	/**
	 * Consumers
	 */
	'consumers' => [

		'Facebook' => [
			'client_id'     => '',
			'client_secret' => '',
			'scope'         => [],
		],
		'Google' => [
			'client_id'     => '179378881643-n5paj9h2oct0nti63grv2rr8canmbch1.apps.googleusercontent.com',
			'client_secret' => '9_3N7ir3AHPFYdcNoDsLgUQb',
			'scope'         => ['userinfo_email', 'userinfo_profile',
				\OAuth\OAuth2\Service\Google::SCOPE_GPLUS_STREAM_READ,
				\OAuth\OAuth2\Service\Google::SCOPE_GPLUS_STREAM_WRITE,
				\OAuth\OAuth2\Service\Google::SCOPE_GPLUS_ME,
				\OAuth\OAuth2\Service\Google::SCOPE_GPLUS_LOGIN
			],
		],
		'Linkedin' => [
			'client_id'     => '75rmraknrjl20z',
			'client_secret' => 'skKIqGqYubuQnARP',
		],
		'Foursquare' => [
			'client_id'     => 'GA4BKADHUU4BTSSMLRIYBYA3K5S3LNICD23RC3C5PR5MAS3E',
			'client_secret' => '3RZDGYSZLJCW4AHJ4IGBRQZVWH1Q3CLBZU11SLPA12Y0LK14',
		],
		'Flickr' => [
			'client_id'     => '5028ee065efbb368144b7ea2bf0aaf2f',
			'client_secret' => 'e0a084283ae39200',
		],
	]

];